﻿namespace RiskLab.Subscriber.WindowsService
{
    using log4net;
    using Microsoft.Extensions.Logging;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Infrastructure.Interfaces;
    using StructureMap;

    /// <summary>
    /// Windows service to subscribe to passport.
    /// </summary>
    public class WSPassportSubscriber : IDisposable
    {
        /// <summary>
        /// The logger.
        /// </summary>
        //private readonly ILogger<WSPassportSubscriber> logger;
        private readonly ILog log = LogManager.GetLogger(typeof(WSPassportSubscriber));
        /// <summary>
        /// Object for <see cref="IRabbitMQSettings"/>.
        /// </summary>
        private readonly IRabbitMQSettings settings;

        /// <summary>
        /// Object for <see cref="IMessageQueueService"/>.
        /// </summary>
        private readonly IMessageQueueService messageQueueService;

        /// <summary>
        /// Object for <see cref="IDeadLetterService"/>.
        /// </summary>
        private readonly Func<IDeadLetterService> deadLetterServiceFactory;

        /// <summary>
        /// Object for <see cref="IContainer"/>.
        /// </summary>
        private readonly IContainer ioc;

        /// <summary>
        /// Boolean variable to be used for the <see cref="IDisposable"/>interface.
        /// </summary>
        private bool disposed;

        /// <summary>
        /// Initializes a new instance of the <see cref="WSPassportSubscriber"/> class.
        /// </summary>
        /// <param name="settings"><see cref="IRabbitMQSettings"/> object.</param>
        /// <param name="ioc"><see cref="IContainer"/>object.</param>
        /// <param name="messageQueueService"><see cref="IMessageQueueService"/>object.</param>
        /// <param name="deadLetterServiceFactory"><see cref="IDeadLetterService"/>object.</param>
        public WSPassportSubscriber(IRabbitMQSettings settings, IContainer ioc, IMessageQueueService messageQueueService, Func<IDeadLetterService> deadLetterServiceFactory) //, ILogger<WSPassportSubscriber> logger)
        {
            this.settings = settings;
            this.ioc = ioc;
            this.messageQueueService = messageQueueService;
            this.deadLetterServiceFactory = deadLetterServiceFactory;
            //this.logger = logger;
        }

        /// <summary>
        /// Gets or sets a value indicating whether gets a boolean variable to check if the service is started or stopped.
        /// </summary>
        protected bool Stopped { get; set; }

        /// <summary>
        /// Star method used within the windows service.
        /// </summary>
        /// <returns>Returns a <see cref="bool"/>to check the state.</returns>
        public bool Start()
        {
            try
            {
                this.log.Info("RiskLab.Subscriber windows service starting");
                Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);
                SubscribeToQueues();
                this.log.Info("WSPassportSubscriber::Service started for RMQ subscriber/publisher");
            }
            catch (Exception ex)
            {
                this.log.Error("WSPassportSubscriber::Failed to start service for RMQ subscriber/publisher {0}", ex);
                return false;
            }

            Stopped = false;

            return true;
        }

        /// <summary>
        /// Stopped method used within the windows service.
        /// </summary>
        /// <returns>Returns a <see cref="bool"/>to check the state.</returns>
        public bool Stop()
        {
            StopProcessing();
            return Stopped = true;
        }

        /// <summary>
        /// Class dispose method.
        /// </summary>
        public void Dispose()
        {
            if (disposed)
            {
                return;
            }

            StopProcessing();
            disposed = true;
        }

        /// <summary>
        /// Subscribe to RabbitMQ queues.
        /// </summary>
        private void SubscribeToQueues()
        {
            try
            {
                this.log.Info("RiskLab.Publisher windows service starting");
                messageQueueService.SubscribeProcessor(
                    ioc.GetInstance<IMessageProcessor<Acquisition.Contracts.Risk.Passport.SuspectedFraudulentTransaction>>(), y => y.MessageId, MessageIdentifier.TransactionRequest);
                this.log.Info("WSPassportSubscriber::Subscribe successfully for Acquisition.Contracts.Risk.Passport.SuspectedFraudulentTransaction");

                messageQueueService.SubscribeProcessor(
                   ioc.GetInstance<IMessageProcessor<Acquisition.Contracts.Risk.Passport.FraudReleasedTransactionConfirmation>>(), y => y.MessageId, MessageIdentifier.TransactionRequest);
                this.log.Info("WSPassportSubscriber::Subscribe successfully for Acquisition.Contracts.Risk.Passport.FraudReleasedTransactionConfirmation");

                messageQueueService.SubscribeProcessor(ioc.GetInstance<IMessageProcessor<Acquisition.Contracts.Risk.Passport.SuspectedFraudulentBatch>>(), y => y.MessageId, MessageIdentifier.BatchRequest);
                this.log.Info("WSPassportSubscriber::Subscribe successfully for Acquisition.Contracts.Risk.Passport.SuspectedFraudulentBatch");

                messageQueueService.SubscribeProcessor(
                  ioc.GetInstance<IMessageProcessor<Acquisition.Contracts.Risk.Passport.FraudReleasedBatchConfirmation>>(), y => y.MessageId, MessageIdentifier.BatchRequest);
                this.log.Info("WSPassportSubscriber::Subscribe successfully for Acquisition.Contracts.Risk.Passport.FraudReleasedBatchConfirmation");

                messageQueueService.SubscribeAdvanced(
                    "EasyNetQ_Default_Error_Queue",
                    (b) =>
                    {
                        IDeadLetterService service = null;
                        try
                        {
                            service = deadLetterServiceFactory();
                            service.ProcessIncoming(System.Text.Encoding.Default.GetString(b));
                        }
                        catch (Exception)
                        {
                            string message = string.Format("Unable to process deadletter:{0}", System.Text.Encoding.Default.GetString(b));
                            return;
                        }
                        finally
                        {
                            if (service != null)
                            {
                                service.Dispose();
                                service = null;
                            }
                        }
                    });
            }
            catch (Exception ex)
            {
                log.ErrorFormat("WSPassportSubscriber::Error while subscribing to RMQ {0}", ex);
            }
        }

        /// <summary>
        /// Stopp processing the windows service.
        /// </summary>
        private void StopProcessing()
        {
            if (Stopped) return;
            using (messageQueueService)
            {
            }
        }
    }
}