﻿using log4net.Config;
using Microsoft.Extensions.Configuration;
using RiskLab.Subscriber.WindowsService;
using StatsdClient;
using StructureMap;
using Topshelf;

XmlConfigurator.Configure();
HostFactory.Run(c =>
{
    c.SetServiceName("RiskLab.Subscriber.WindowsService");
    c.StartAutomatically();
    c.RunAsLocalSystem();
    c.UseLog4Net();
    c.Service<WSPassportSubscriber>(configurator =>
    {
        var builder = new ConfigurationBuilder().AddJsonFile($"appsettings.json", true, true);
        var config = builder.Build();
        var applicationName = config["AppSettings:ApplicationName"];
        var environmentCode = config["AppSettings:EnvironmentCode"];
        var container = IoC.Container(applicationName, environmentCode);
        var options = new StatsdConfig
        {
            StatsdServerName = "127.0.0.1",
            StatsdPort = 8125,
            Prefix = "RiskLabAPI",
        };
        DogStatsd.Configure(options);

        IContainer nestedContainer = null;
        configurator.ConstructUsing(() =>
        {
            nestedContainer = container.GetNestedContainer();
            return nestedContainer.GetInstance<WSPassportSubscriber>();
        });
        configurator.WhenStarted((svc, hc) => svc.Start());
        configurator.WhenStopped((svc, hc) =>
        {
            var stopped = svc.Stop();
            using (nestedContainer)
            {
            }

            using (container)
            {
            }

            using (svc)
            {
            }

            return stopped;
        });
    });
});