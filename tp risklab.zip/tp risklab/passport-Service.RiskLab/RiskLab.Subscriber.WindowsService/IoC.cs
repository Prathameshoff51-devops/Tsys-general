﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RiskLab.Core.Interfaces;
using RiskLab.Core.Interfaces.Processors;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Services;
using RiskLab.Infrastructure;
using RiskLab.Infrastructure.Dapper;
using RiskLab.Infrastructure.Dapper.Repository;
using RiskLab.Infrastructure.Interfaces;
using RiskLab.Infrastructure.MessageProcessor;
using RiskLab.Infrastructure.Settings;
using StructureMap;

namespace RiskLab.Subscriber.WindowsService
{
    /// <summary>
    /// Class to handle the Inversion of Control.
    /// </summary>
    public class IoC
    {
        /// <summary>
        /// IoC container.
        /// </summary>
        /// <returns><see cref="IContainer"/>object.</returns>
        public static IContainer Container(string applicationName, string environmentCode)
        {
            return new Container(x =>
            {
                x.For(typeof(ILogger<>)).Use(typeof(Logger<>));
                //x.For(typeof(IOptionsMonitor<LoggerFilterOptions>)).Use(typeof(OptionsMonitor<LoggerFilterOptions>));
                //x.For(typeof(ILoggerFactory)).Use(new LoggerFactory());
                x.For<ISettingsManagerWrapper>().Use(new SettingsManagerWrapper(applicationName, environmentCode));
                x.For<IRabbitMQSettings>().Use<RabbitMQSettings>();
                x.For<WSPassportSubscriber>().Use<WSPassportSubscriber>().Singleton();
                x.For<IMessageQueueService>().Use<MessageQueueService>();
                x.For<ISuspectedFraudulentTransaction>().Use<SuspectedFraudulentTransactionProcessor>();
                x.For<IFraudReleasedTransactionConfirmation>().Use<FraudReleasedTransactionConfirmationProcessor>();
                x.For<ISuspectedFraudulentBatch>().Use<SuspectedFraudulentBatchProcessor>();
                x.For<IDeadLetterService>().Use<DeadLetterService>();
                x.For<ISqlDbConnectionManager>().Use<SqlDbConnectionManager>();
                x.For<IIndividualTransactionsRepository>().Use<IndividualTransactionsRepository>();
                x.For<IBatchTransactionsRepository>().Use<BatchTransactionsRepository>();
                x.For<INotificationService>().Use<NotificationService>();
                x.For<IBatchRejectsRepository>().Use<BatchRejectsRepository>();
                x.For<IFraudReleasedBatchConfirmation>().Use<FraudReleasedBatchConfirmationProcessor>();
            });
        }
    }
}