using CoreLoggingNetCore;
using RiskLab.API.Configurations;
using RiskLab.API.Healthcheck.Infrastructure;
using RiskLab.API.Healthcheck.Infrastructure.Extensions;
using RiskLab.API.Hubs;
using RiskLab.API.Middleware;
using RiskLab.Core.Interfaces;
using RiskLab.Infrastructure;
using StatsdClient;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwagger();
builder.Services.AddSignalR();
builder.Services.AddHttpClient();

var applicationName = builder.Configuration["AppSettings:ApplicationName"].Trim() ;
var environmentCode = builder.Configuration["AppSettings:EnvironmentCode"].Trim();

builder.Configuration.SetBasePath(Directory.GetCurrentDirectory())
 .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
 .AddJsonFile($"appsettings.{environmentCode}.json", optional: true, reloadOnChange: true)
 .AddEnvironmentVariables();

var settingsManagerWrapper = new SettingsManagerWrapper(
        applicationName,
        environmentCode);
builder.Services.AddSingleton<ISettingsManagerWrapper>(_ => settingsManagerWrapper);
builder.Services.AddServiceSettings(settingsManagerWrapper, builder.Configuration);

var applicationSettingsManager = settingsManagerWrapper.ApplicationSettingsManager;
var coreloggingUrl = applicationSettingsManager.GetSettingByKey("CoreLoggingServiceUrl").Result.Value.Trim();
var riskLabRabbitMqConnection = applicationSettingsManager.GetSettingByKey("RiskLabRabbitMqConnection").Result.Value.Trim();
var riskLabDbConnectionString = applicationSettingsManager.GetConnectionString("RiskLab").Result.Value;
var hcsDbConnectionString = applicationSettingsManager.GetConnectionString("HcsDB").Result.Value;

builder.Services.AddServiceDIProviders(applicationSettingsManager, builder.Configuration);

builder.Host.ConfigureLogging(logging =>
{
    logging.AddConfiguration(builder.Configuration.GetSection("Logging"));
    logging.AddConsole();
    logging.AddDebug();
    logging.AddDatabaseLogger(environmentCode, applicationName, coreloggingUrl);
    logging.AddLog4Net();
});
builder.Services.AddHealthChecks(c =>
{
    c.AddSqlServerHealthCheck(hcsDbConnectionString, "HcsDB");
    c.AddSqlServerHealthCheck(riskLabDbConnectionString, "RiskLabDB");
    c.AddCoreloggingApiHealthCheck(coreloggingUrl, "Corelogging");
    c.AddRabbitMQHealthCheck(riskLabRabbitMqConnection, "RabbitMQ");
});
var app = builder.Build();

DogStatsd.Configure(new StatsdConfig
{
    StatsdServerName = "127.0.0.1",
    StatsdPort = 8125,
    Prefix = "RiskLabAPI",
});

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger(applicationSettingsManager);
}

app.UseHealthChecks();
app.UseMiddleware<ExceptionLoggingMiddleware>();
app.UseMiddleware<CustomResponseHeaderMiddleware>();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseMiddleware<CustomAuthenticationMiddleware>();
app.UseMiddleware<MyAuthorizationMiddlewareResultHandler>();
app.UseAuthorization();
app.MapControllers();
app.MapHub<NotificationHub>("/notification");
app.Run();