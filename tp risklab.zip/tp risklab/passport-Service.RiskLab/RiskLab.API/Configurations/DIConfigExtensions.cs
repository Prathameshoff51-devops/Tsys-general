﻿namespace RiskLab.API.Configurations
{
    using Hps.SettingsManagerClient;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using RiskLab.API.Healthcheck.Infrastructure;
    using RiskLab.API.Healthcheck.Infrastructure.Interfaces;
    using RiskLab.Core.Interfaces.Processors;
    using RiskLab.Core.Interfaces.Repositories;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Core.Services;
    using RiskLab.Infrastructure.Dapper;
    using RiskLab.Infrastructure.Dapper.Repository;
    using RiskLab.Infrastructure.Interfaces;
    using RiskLab.Infrastructure.MessageProcessor;
    using RiskLab.Infrastructure.Settings;

    public static class DIConfigExtensions
    {
        /// <summary>
        /// Adds the service di providers.
        /// </summary>
        /// <param name="services">The services.</param>
        /// <param name="manager">The manager.</param>
        /// <param name="configuration">The configuration.</param>
        /// <returns></returns>
        public static IServiceCollection AddServiceDIProviders(this IServiceCollection services, ISettingsManager manager, IConfiguration configuration)
        {
            services.AddSingleton<IRabbitMQSettings, RabbitMQSettings>();
            services.AddSingleton<ISqlDbConnectionManager, SqlDbConnectionManager>();
            services.AddTransient<IHealthCheckService, HealthCheckService>();
            services.AddTransient<IIndividualTransactionsRepository, IndividualTransactionsRepository>();
            services.AddTransient<IIndividualTransactionsService, IndividualTransactionsService>();
            services.AddTransient<IRoleRepository, RoleRepository>();
            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<ITokenValidationService, TokenValidationService>();
            services.AddTransient<INotificationService, NotificationService>();
            services.AddTransient<IBatchRejectsService, BatchRejectsService>();
            services.AddTransient<IBatchRejectsRepository, BatchRejectsRepository>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IExcelExportService, ExcelExportService>();

            var issuer = manager.GetConfigurationValue(Constants.OktaSettings.Issuer, configuration);
            var audience = manager.GetConfigurationValue(Constants.OktaSettings.Audience, configuration);
            var oAuthEndpoint = $"{manager.GetConfigurationValue(Constants.OktaSettings.Issuer, configuration)}/oauth2/{manager.GetConfigurationValue(Constants.OktaSettings.AuthorizationServer, configuration)}";

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.Authority = oAuthEndpoint;
                options.Audience = audience;
                options.RequireHttpsMetadata = false;
            });

            return services;
        }
    }
}
