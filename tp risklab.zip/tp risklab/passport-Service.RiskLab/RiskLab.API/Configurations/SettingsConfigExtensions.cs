﻿namespace RiskLab.API.Configurations
{
    using Hps.SettingsManagerClient;
    using RiskLab.Core.Interfaces;
    using RiskLab.Core.Settings;

    public static class SettingsConfigExtensions
    {
        /// <summary>
        /// Adds the service settings.
        /// </summary>
        /// <param name="services">The services.</param>
        /// <param name="settingsManagerWrapper">The settings manager wrapper.</param>
        /// <param name="configuration">The configuration.</param>
        /// <returns></returns>
        public static IServiceCollection AddServiceSettings(this IServiceCollection services, ISettingsManagerWrapper settingsManagerWrapper, IConfiguration configuration)
        {
            services.Configure<ApplicationSettings>(setting =>
            {
            var applicationSettingsManager = settingsManagerWrapper.ApplicationSettingsManager;
            setting.EnvironmentCode = applicationSettingsManager.EnvironmentCode;
            setting.AppName = applicationSettingsManager.ApplicationName;
            setting.RiskLabApiUrl = applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.RiskLabApiUrl, configuration, applicationSettingsManager.ApplicationName);
            setting.RiskLabUiUrl = applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.RiskLabUiUrl, configuration, applicationSettingsManager.ApplicationName);
            setting.CoreloggingServiceUrl = applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.CoreLoggingServiceUrl, configuration);
            setting.DefaultGridPageSize = int.Parse(applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.DefaultGridPageSize, configuration));
            setting.DefaultBatchGridPageSize = int.Parse(applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.DefaultBatchGridPageSize, configuration));
            setting.DefaultBackOfficeGridPageSize = int.Parse(applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.DefaultBackOfficeGridPageSize, configuration));
            setting.DaysToAct = int.Parse(applicationSettingsManager.GetConfigurationValue(Constants.AppSettings.DaysToAct, configuration));
            setting.ClientId = applicationSettingsManager.GetConfigurationValue(Constants.OktaSettings.Client_Id, configuration);
            setting.Issuer = applicationSettingsManager.GetConfigurationValue(Constants.OktaSettings.Issuer, configuration);
            setting.IntrospectEndPoint = applicationSettingsManager.GetConfigurationValue(Constants.OktaSettings.IntrospectEndpoint, configuration);
            setting.AuthorizationServer = applicationSettingsManager.GetConfigurationValue(Constants.OktaSettings.AuthorizationServer, configuration);
            });

            return services;
        }

        public static string GetConfigurationValue(this ISettingsManager manager, string key, IConfiguration configuration, string externalAppName = null)
        {
            if (configuration != null && !string.IsNullOrEmpty(configuration[key]))
            {
                return configuration[key];
            }

            return string.IsNullOrEmpty(externalAppName)
                ? manager.GetSettingByKey(key).Result.Value
                : manager.GetSettingByKeyAndApplicationName(key, externalAppName).Result.Value;
        }

        /// <summary>
        /// Get Configuration Value
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="key"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static string GetConfigurationValue(this ISettingsManager manager, string key, IConfiguration configuration)
        {
            return GetConfigurationValue(manager, key, configuration, null);
        }

        /// <summary>
        /// Get Configuration Value
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="key"></param>
        /// <param name="externalAppName"></param>
        /// <returns></returns>
        public static string GetConfigurationValue(this ISettingsManager manager, string key, string externalAppName)
        {
            return GetConfigurationValue(manager, key, null, externalAppName);
        }

        /// <summary>
        /// Get Configuration Value
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetConfigurationValue(this ISettingsManager manager, string key)
        {
            return GetConfigurationValue(manager, key, null, null);
        }
    }
}