﻿namespace RiskLab.API
{
    public class Constants
    {
        public static class AppSettings
        {
            public const string RiskLabApiUrl = "RiskLabApiUrl";
            public const string RiskLabUiUrl = "RiskLabUrl";
            public const string ApiKey = "RiskLabApiKey";
            public const string AzureADClientId = "RiskLabClientId";
            public const string AzureADSecret = "RiskLabClientSecret";
            public const string MinimumSearchLength = "MinimumSearchLength";
            public const string DefaultGridPageSize = "DefaultGridPageSize";
            public const string DefaultBatchGridPageSize = "DefaultBatchGridPageSize";
            public const string DefaultBackOfficeGridPageSize = "DefaultBackOfficeGridPageSize";
            public const string DaysToAct = "DaysToAct";
            public const string CoreLoggingServiceUrl = "CoreLoggingServiceUrl";
            public const string RiskLabRabbitMqConnection = "RiskLabRabbitMqConnection";
            public static readonly string[] StandardScopes = { "openid", "userInfo" };
        }

        public static class OktaSettings
        {
            public const string Issuer = "Issuer";
            public const string Audience = "Audience";
            public const string AuthorizationServer = "AuthorizationServer";
            public const string IntrospectEndpoint = "IntrospectEndPoint";
            public const string Client_Id = "Client_Id";
        }

        public static class Routes
        {
            public const string DefaultRouteV1 = "api/v1/[controller]";
        }

        public static class UserClaim
        {
            public const string NameIdentifier = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
            public const string RiskUserClaimName = "RiskUserClaimName";
        }

        public static class UserRole
        {
            public const string RiskLab = "RiskLab";
            public const string FraudServiceDetailsRole = "Fraud Service Details";
        }

        public static class ResponseMessages
        {
            public const string ErrorResponseMessage = "An exception was encountered while processing your request.  Please contact technical support for more information.";
            public const string InvalidUser = "Invalid User.";
            public const string InvalidTransactionStatus = "Invalid Transaction Status.";
            public const string InvalidMerchantNumber = "Provided merchant number is invalid.";
            public const string InvalidMerchantSequenceKey = "Provided merchant sequence key is invalid.";
            public const string TxnsNotFound = "Rejected transactions not found for the merchant number ";
            public const string MerchantFound = "Merchant not Found.";
            public const string InvalidBatchStatus = "Invalid batch status.";
            public const string BatchRejectNotFound = "Batch Reject not found";
            public const string InvalidRejectType = "Invalid Reject type.";
            public const string InvalidPageName = "Invalid Rejected Refunds Type.";
            public const string InvalidMissingParameters = "Missing Required Parameters.";
        }
    }
}