﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace RiskLab.API.Hubs
{
    [AllowAnonymous]
    public class NotificationHub : Hub
    {
        public async Task SendMessageForIndividualTxn(object o)
        => await Clients.Others.SendAsync("NotifyIndividualTxnTab");

        public async Task SendMessageForQueueTxn(object o)
        => await Clients.Others.SendAsync("NotifyQueueTxnTab");

        public async Task SendMessageForBatchNew(object o)
        => await Clients.Others.SendAsync("NotifyNewBatchRejectsTab");

        public async Task SendMessageForBatchNewTxn(object o)
        => await Clients.Others.SendAsync("NotifyNewBatchTxnRejectsTab", o);

        public async Task SendMessageForBatchQueue(object o)
       => await Clients.Others.SendAsync("NotifyQueueBatchRejectsTab");

        public async Task SendMessageForBatchQueueTxn(object o)
        => await Clients.Others.SendAsync("NotifyQueueBatchTxnRejectsTab", o);
    }
}
