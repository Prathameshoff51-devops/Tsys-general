﻿namespace RiskLab.API.Middleware
{
    using System.Net;

    public class CustomResponseHeaderMiddleware
    {
        private readonly RequestDelegate _next;

        public CustomResponseHeaderMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            context.Response.OnStarting(
                state =>
                {
                    var httpContext = (HttpContext)state;
                    if (!httpContext.Response.Headers.Any(x => x.Key.Equals("cache-control", StringComparison.InvariantCultureIgnoreCase)))
                    {
                        httpContext.Response.Headers.Add("cache-control", "no-cache, no-store,must-revalidate");
                    }

                    httpContext.Response.Headers.Add("Referrer-Policy", "no-referrer");
                    httpContext.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                    httpContext.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
                    httpContext.Response.Headers.Add("X-Frame-Options", "SAMEORIGIN");
                    httpContext.Response.Headers.Add("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
                    httpContext.Response.Headers.Add("Content-Security-Policy", "default-src 'self' style-src 'self' 'unsafe-inline';");

                    return Task.CompletedTask;
                }, context);

            await _next(context);
        }
    }
}
