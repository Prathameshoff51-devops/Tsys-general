﻿namespace RiskLab.API.Middleware
{
    using System.Net;
    using System.Security.Claims;
    using Microsoft.AspNetCore.Authorization;
    using RiskLab.Core.Interfaces.Repositories;

    public class MyAuthorizationMiddlewareResultHandler
    {
        private readonly RequestDelegate _next;
        private readonly IUserRepository _userRepository;
        private readonly ILogger<MyAuthorizationMiddlewareResultHandler> _logger;
        private readonly IRoleRepository _roleRepository;

        public MyAuthorizationMiddlewareResultHandler(
                RequestDelegate next,
                ILogger<MyAuthorizationMiddlewareResultHandler> logger,
                IUserRepository userRepository,
                IRoleRepository roleRepository)
        {
            _next = next;
            _userRepository = userRepository;
            _logger = logger;
            _roleRepository = roleRepository;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                var endpoint = httpContext.GetEndpoint();
                if (endpoint?.Metadata?.GetMetadata<IAllowAnonymous>() is object)
                {
                    await _next(httpContext);
                    return;
                }

                var userEmailAddressClaim = httpContext.User.Claims.FirstOrDefault(p => p.Type == Constants.UserClaim.NameIdentifier);

                // an email address is required
                if (string.IsNullOrWhiteSpace(userEmailAddressClaim?.Value))
                {
                    httpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    _logger.LogError($"Error Code - {HttpStatusCode.Unauthorized} , Claim not found");
                    return;
                }

                var user = await _userRepository.GetUserByEmail(userEmailAddressClaim.Value);

                // a user must exist within the HSC
                if (user == null || user.Id == 0)
                {
                    httpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    _logger.LogError($"Error Code - {HttpStatusCode.Unauthorized} , The user {userEmailAddressClaim.Value} is not found");
                    return;
                }

                var claims = new List<Claim> { new Claim(type: Constants.UserClaim.RiskUserClaimName, value: user.LoginName.ToString()) };

                var roles = await _roleRepository.GetUserRoles(user.Id);

                if (!roles.Any())
                {
                    httpContext.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                    _logger.LogError($"Error Code - {HttpStatusCode.Forbidden} , The user {userEmailAddressClaim.Value} does not have any roles.");
                    return;
                }

                foreach (var role in roles)
                {
                    if (!string.IsNullOrEmpty(role.Role))
                    {
                        claims.Add(new Claim(ClaimTypes.Role, role.Role));
                    }
                }

                var identity = new ClaimsIdentity(claims);
                httpContext.User.AddIdentity(identity);

                _logger.LogInformation($"User claim generated successfully- {userEmailAddressClaim.Value}");
            }
            catch (Exception e)
            {
                _logger.LogError(e, e.Message);
                httpContext.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                return;
            }

            await _next(httpContext);
        }
    }
}
