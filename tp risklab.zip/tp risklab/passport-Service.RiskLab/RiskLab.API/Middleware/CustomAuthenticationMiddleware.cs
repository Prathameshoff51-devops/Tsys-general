﻿using System.Net;
using Hps.SettingsManagerClient;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using RiskLab.API.Configurations;
using RiskLab.Core.Interfaces;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Settings;

namespace RiskLab.API.Middleware
{
    public class CustomAuthenticationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<CustomAuthenticationMiddleware> _logger;
        private readonly ApplicationSettings _setting;
        private readonly ITokenValidationService _tokenValidationService;

        public CustomAuthenticationMiddleware(
            RequestDelegate next,
            ILogger<CustomAuthenticationMiddleware> logger,
            IOptions<ApplicationSettings> setting,
            ITokenValidationService tokenValidationService)
        {
            _next = next;
            _logger = logger;
            _setting = setting.Value;
            _tokenValidationService = tokenValidationService;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                var endpoint = httpContext.GetEndpoint();
                if (endpoint?.Metadata?.GetMetadata<IAllowAnonymous>() is object)
                {
                    await _next(httpContext);
                    return;
                }

                var acessToken = httpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

                if (!string.IsNullOrWhiteSpace(acessToken))
                {
                    var oktaIntrospectEndPoint = BuildUrlForInspectEndPoint();
                    if (!string.IsNullOrWhiteSpace(oktaIntrospectEndPoint))
                    {
                        if (!await _tokenValidationService.IsTokenValid(acessToken, oktaIntrospectEndPoint, _setting.ClientId))
                        {
                            _logger.LogError("CustomAuthMiddleware::Invoke() : Token validation failed...");
                            throw new UnauthorizedAccessException();
                        }
                    }
                    else
                    {
                        _logger.LogError("CustomAuthMiddleware::Invoke() : Okta introspect endpoint information is missing.");
                        throw new Exception("Okta introspect endpoint information is missing");
                    }
                }
                else
                {
                    _logger.LogError("CustomAuthMiddleware::Invoke() : unable to detect authorization header in the request.");
                    throw new UnauthorizedAccessException();
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(ex, ex.Message);
                httpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                return;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, ex.Message);
                httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return;
            }
            catch (Exception e)
            {
                _logger.LogError(e, e.Message);
                httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return;
            }

            await _next(httpContext);
        }

        private string BuildUrlForInspectEndPoint()
        {
            return (_setting.Issuer + "/oauth2/" + _setting.AuthorizationServer + "/" + _setting.IntrospectEndPoint).Trim();
        }
    }
}
