﻿namespace RiskLab.API.Middleware
{
    using System.Net;

    public class ExceptionLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionLoggingMiddleware> _logger;

        public ExceptionLoggingMiddleware(RequestDelegate next, ILogger<ExceptionLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception e)
            {
                var id = Guid.NewGuid();
                try
                {
                    _logger.LogError(e, $"Error Id: {id} , Exception Mesasge: {e.Message}");
                }
                catch (Exception)
                {
                    // Don't let this exception cause anything to stop.
                }

                httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                await httpContext.Response.WriteAsync(Constants.ResponseMessages.ErrorResponseMessage + $", Error Id: {id}");
            }
        }
    }
}
