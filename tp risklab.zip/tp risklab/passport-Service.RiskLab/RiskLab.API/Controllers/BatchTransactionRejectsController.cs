﻿using Microsoft.AspNetCore.Mvc;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Helpers;
using StatsdClient;

namespace RiskLab.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BatchTransactionRejectsController : BaseController
    {
        private readonly IBatchRejectsService batchRejectsService;
        private readonly IUserService userService;

        public BatchTransactionRejectsController(
            ILogger<BatchTransactionRejectsController> logger,
            IBatchRejectsService batchRejectsService,
            IUserService userService)
            : base(logger)
        {
            this.batchRejectsService = batchRejectsService;
            this.userService = userService;
        }

        [HttpGet]
        public async Task<IActionResult> GetBatchTransactionRejects(int batchRejectId)
        {
            using (DogStatsd.StartTimer("RiskLab.BatchTransactionRejectsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    BatchTransactionRejectsViewDto bTxns = await batchRejectsService.GetBatchTransactionRejects(batchRejectId);
                    if (bTxns == null)
                        return NotFound(Constants.ResponseMessages.BatchRejectNotFound);

                    return Ok(bTxns);
                }
                catch (Exception ex)
                {
                    Logger.LogError("BatchTransactionRejectsController::GetBatchTransactionRejects() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateBatchTransactionsStatus([FromBody] BatchTransactionRejectsUpdateDto batchTransactionRejects)
        {
            using (DogStatsd.StartTimer("RiskLab.BatchTransactionRejectsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    if (!await userService.IsUserValid(batchTransactionRejects.UserName))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidUser);
                    }

                    if (await batchRejectsService.GetBatchRejectById(batchTransactionRejects.BatchRejectId) == null)
                    {
                        return BadRequest(Constants.ResponseMessages.BatchRejectNotFound);
                    }

                    return !ValidateRiskUserClaimName(batchTransactionRejects.UserName)
                        ? Unauthorized(Constants.ResponseMessages.InvalidUser)
                        : Ok(await batchRejectsService.UpdateBatchTransactionRejects(batchTransactionRejects));
                }
                catch (Exception ex)
                {
                    Logger.LogError("BatchTransactionRejectsController::UpdateBatchTransactionsStatus() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        [HttpPost("bulk")]
        public async Task<IActionResult> UpdateBulkBatchTransactionsStatus([FromBody] BatchTransactionRejectsStatusUpdateDto batchTransactionRejects)
        {
            using (DogStatsd.StartTimer("RiskLab.BatchTransactionRejectsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    if (!await userService.IsUserValid(batchTransactionRejects.UserName))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidUser);
                    }

                    // Validate that there are transactions to update
                    if (batchTransactionRejects.BatchTransactionsStatus == null || !batchTransactionRejects.BatchTransactionsStatus.Any())
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidTransactionStatus);
                    }

                    // Validate that all batch reject IDs exist
                    var distinctBatchRejectIds = batchTransactionRejects.BatchTransactionsStatus
                        .Select(x => x.BatchRejectId)
                        .Distinct()
                        .ToList();

                    foreach (var batchRejectId in distinctBatchRejectIds)
                    {
                        if (await batchRejectsService.GetBatchRejectById(batchRejectId) == null)
                        {
                            return BadRequest(Constants.ResponseMessages.BatchRejectNotFound);
                        }
                    }

                    return !ValidateRiskUserClaimName(batchTransactionRejects.UserName)
                        ? Unauthorized(Constants.ResponseMessages.InvalidUser)
                        : Ok(await batchRejectsService.UpdateBulkBatchTransactionRejects(batchTransactionRejects));
                }
                catch (Exception ex)
                {
                    Logger.LogError("BatchTransactionRejectsController::UpdateBulkBatchTransactionsStatus() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        private bool ValidateRiskUserClaimName(string batchUserName)
        {
            var riskUserClaimName = HttpContext.User.Claims.FirstOrDefault(p => p.Type == Constants.UserClaim.RiskUserClaimName);
            return riskUserClaimName?.Value.ToLower() == batchUserName.ToLower();
        }
    }
}
