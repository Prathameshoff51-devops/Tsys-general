﻿using Microsoft.AspNetCore.Mvc;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Helpers;
using StatsdClient;

namespace RiskLab.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BatchRejectsController : BaseController
    {
        private readonly IBatchRejectsService batchRejectsService;
        private readonly IUserService userService;

        public BatchRejectsController(
            ILogger<BatchRejectsController> logger,
            IBatchRejectsService batchRejectsService,
            IUserService userService)
            : base(logger)
        {
            this.batchRejectsService = batchRejectsService;
            this.userService = userService;
        }

        [HttpGet]
        public async Task<IActionResult> GetBatchRejects(string status)
        {
            using (DogStatsd.StartTimer("RiskLab.BatchRejectsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    BatchRejectStatuses batchStatus;
                    if (Enum.TryParse(status, true, out batchStatus) && Enum.IsDefined(typeof(BatchRejectStatuses), batchStatus))
                    {
                        return Ok(await batchRejectsService.GetBatchRejectsByStatus(batchStatus.ToString()));
                    }
                    else
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidBatchStatus);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError("BatchRejectsController::GetBatchRejects() - " + ex.ToString());
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateBatchStatus([FromBody] BatchRejectUpdateDto batchReject)
        {
            using (DogStatsd.StartTimer("RiskLab.BatchRejectsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    if (!await userService.IsUserValid(batchReject.UserName))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidUser);
                    }

                    return !ValidateRiskUserClaimName(batchReject.UserName)
                        ? Unauthorized(Constants.ResponseMessages.InvalidUser)
                        : Ok(await batchRejectsService.UpdateBatchRejectStatus(batchReject));
                }
                catch (Exception ex)
                {
                    Logger.LogError("BatchRejectsController::UpdateBatchStatus() - " + ex.ToString());
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        private bool ValidateRiskUserClaimName(string batchUserName)
        {
            var riskUserClaimName = HttpContext.User.Claims.FirstOrDefault(p => p.Type == Constants.UserClaim.RiskUserClaimName);
            return riskUserClaimName?.Value.ToLower() == batchUserName.ToLower();
        }
    }
}
