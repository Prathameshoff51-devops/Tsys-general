﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RiskLab.Core.Constants;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Helpers;
using StatsdClient;
using System.Text.Json;
using static RiskLab.API.Constants;

namespace RiskLab.API.Controllers
{
    [Route("[controller]")]
    [Authorize(Roles = UserRole.RiskLab)]
    public class ExcelExportController : BaseController
    {
        private readonly IExcelExportService excelExportService;
        private readonly IIndividualTransactionsService individualTransactionsService;
        private readonly IBatchRejectsService batchRejectsService;

        public ExcelExportController(ILogger<ExcelExportController> logger, IIndividualTransactionsService individualTransactionsService, IExcelExportService excelExportService, IBatchRejectsService batchRejectsService)
            : base(logger)
        {
            this.excelExportService = excelExportService;
            this.individualTransactionsService = individualTransactionsService;
            this.batchRejectsService = batchRejectsService;
        }

        [HttpGet]
        public async Task<IActionResult> ExportExcelFile(string pageName, string status)
        {
            using (DogStatsd.StartTimer("RiskLab.ExcelExportAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    RejectStatuses txnStatus;
                    object data = null; // Initialize 'data' to null to resolve CS0165
                    string sheetName = string.Empty;
                    string statusNewOrQueue = string.Empty;
                    if (string.IsNullOrEmpty(pageName) && string.IsNullOrEmpty(status))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidMissingParameters);
                    }

                    if (string.IsNullOrEmpty(pageName))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidPageName);
                    }

                    if (string.IsNullOrEmpty(status))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidTransactionStatus);
                    }

                    if (Enum.TryParse(status, true, out txnStatus) && Enum.IsDefined(typeof(RejectStatuses), txnStatus))
                    {
                        if ((int)txnStatus > 2)
                        {
                            return BadRequest(Constants.ResponseMessages.InvalidTransactionStatus);
                        }
                    }
                    else
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidTransactionStatus);
                    }

                    if (pageName.ToLower() == "individual")
                    {
                        pageName = "Individual_Transactions";
                        if (Enum.TryParse(status, true, out txnStatus) && Enum.IsDefined(typeof(RejectStatuses), txnStatus))
                        {
                            data = await individualTransactionsService.GetIndividualTransactionsByStatus(txnStatus.ToString());
                            sheetName = pageName + "_" + txnStatus.ToString();
                            statusNewOrQueue = txnStatus.ToString();
                        }
                    }
                    else if (pageName.ToLower() == "batch")
                    {
                        pageName = "Batch_Transactions";
                        if (Enum.TryParse(status, true, out txnStatus) && Enum.IsDefined(typeof(RejectStatuses), txnStatus))
                        {
                            data = await batchRejectsService.GetBatchTransactionRejectByStatus(txnStatus.ToString());
                            sheetName = pageName + "_" + txnStatus.ToString();
                            statusNewOrQueue = txnStatus.ToString();
                        }
                    }
                    else
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidPageName);
                    }

                    if (data == null)
                    {
                        return BadRequest(Constants.ResponseMessages.TxnsNotFound);
                    }

                    // Calculate the count of items in the data
                    int count = (data as IEnumerable<object>)?.Count() ?? 0;
                    if (count == 0)
                    {
                        return BadRequest(Constants.ResponseMessages.TxnsNotFound);
                    }

                    var jsonElement = JsonSerializer.SerializeToElement(data);
                    var excelBytes = this.excelExportService.ExportJsonTOExcel(jsonElement, sheetName, statusNewOrQueue);

                    // Add the count to the response headers
                    Response.Headers.Append("X-TotalTransactions-Count", count.ToString());

                    return File(
                        excelBytes,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        $"{pageName + "_" + statusNewOrQueue + DateTime.UtcNow.ToString("yyyy-MM-dd") ?? "Export"}.xlsx");
                }
                catch (Exception ex)
                {
                    Logger.LogError("IndividualTransactionsController::GetIndividualTransactions() - " + ex.ToString());
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }
    }
}
