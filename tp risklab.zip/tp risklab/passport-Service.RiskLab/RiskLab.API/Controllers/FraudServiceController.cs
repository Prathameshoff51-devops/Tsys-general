﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RiskLab.Core.Dtos;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Helpers;
using StatsdClient;
using UserRole = RiskLab.API.Constants.UserRole;

namespace RiskLab.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    [Authorize(Roles = UserRole.FraudServiceDetailsRole)]
    public class FraudServiceController : BaseController
    {
        private readonly IIndividualTransactionsService individualTransactionsService;

        public FraudServiceController(
            ILogger<FraudServiceController> logger,
            IIndividualTransactionsService individualTransactionsService)
            : base(logger)
        {
            this.individualTransactionsService = individualTransactionsService;
        }

        [HttpGet]
        public async Task<IActionResult> GetIndividualTxnsbyMerchantSequencekey(int sequenceKey)
        {
            using (DogStatsd.StartTimer("RiskLab.FraudServiceAPI" + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    if (sequenceKey > 0)
                    {
                        Merchant? merchant = null;
                        MerchantViewDto merchantViewDto = new MerchantViewDto();
                        merchant = await individualTransactionsService.GetMerchantNumberFromSequenceKey(sequenceKey);
                        if (merchant != null)
                        {
                            merchantViewDto.MerchantNumber = merchant.MerchantNumber;
                            merchantViewDto.MerchantName = merchant.MerchantName;
                            merchantViewDto.MerchantRejects = await individualTransactionsService.GetRejectsByMerchantNumber(merchantViewDto.MerchantNumber);
                            if (!merchantViewDto.MerchantRejects.Any())
                            {
                                return StatusCode(StatusCodes.Status404NotFound, Constants.ResponseMessages.TxnsNotFound + merchant.MerchantNumber);
                            }

                            return Ok(merchantViewDto);
                        }
                        else
                        {
                            return StatusCode(StatusCodes.Status404NotFound, Constants.ResponseMessages.MerchantFound);
                        }
                    }

                    throw new ArgumentException(Constants.ResponseMessages.InvalidMerchantSequenceKey);
                }
                catch (ArgumentException ex)
                {
                    Logger.LogError("FraudServiceAPI::GetIndividualTxnsbyMerchantSequencekey() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status400BadRequest, ex.Message);
                }
                catch (Exception ex)
                {
                    Logger.LogError("FraudServiceAPI::GetIndividualTxnsbyMerchantSequencekey() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        [HttpGet]
        [Route("GetRejectsByMerchantNumber")]
        public async Task<IActionResult> GetRejectsByMerchantNumber(string merchantNumber)
        {
            using (DogStatsd.StartTimer("RiskLab.FraudServiceAPI" + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(merchantNumber) && long.TryParse(merchantNumber, out long tempMerchNum))
                    {
                        MerchantViewDto merchantViewDto = new MerchantViewDto();
                        merchantViewDto.MerchantNumber = merchantNumber;
                        merchantViewDto.MerchantRejects = await individualTransactionsService.GetRejectsByMerchantNumber(merchantNumber);
                        if (merchantViewDto.MerchantRejects.Any())
                        {
                            merchantViewDto.MerchantName = merchantViewDto.MerchantRejects.FirstOrDefault().MerchantName;
                            return Ok(merchantViewDto);
                        }
                        else
                        {
                            return StatusCode(StatusCodes.Status404NotFound, Constants.ResponseMessages.TxnsNotFound + merchantNumber);
                        }
                    }

                    throw new ArgumentException(Constants.ResponseMessages.InvalidMerchantNumber);
                }
                catch (ArgumentException ex)
                {
                    Logger.LogError("FraudServiceAPI::GetRejectsByMerchantNumber() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status400BadRequest, ex.Message);
                }
                catch (Exception ex)
                {
                    Logger.LogError("FraudServiceAPI::GetRejectsByMerchantNumber() - " + ex.ToString());
                    return StatusCode(StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }
    }
}
