﻿namespace RiskLab.API.Controllers
{
    using Microsoft.AspNetCore.Mvc;

    [Route(Constants.Routes.DefaultRouteV1)]
 //   [Authorize]
    public class BaseController : Controller
    {
        /// <summary>Application Logger</summary>
        private readonly ILogger logger;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="logger"></param>
        public BaseController(ILogger logger)
        {
            this.logger = logger;
        }

        protected ILogger Logger => logger;
    }
}
