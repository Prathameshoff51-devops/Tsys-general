﻿namespace RiskLab.API.Controllers
{
    using System.Security.Claims;
    using CoreLoggingNetCore;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using RiskLab.API.Model;
    using RiskLab.Core.Interfaces;
    using RiskLab.Core.Settings;
    using RiskLab.Infrastructure.Helpers;
    using StatsdClient;

    [Route("[controller]")]
    [ApiController]
    [Authorize]
    public class ConfigurationsController : BaseController
    {
        private readonly ApplicationSettings setting;

        public ConfigurationsController(ISettingsManagerWrapper settings, ILogger<ConfigurationsController> logger, IOptions<ApplicationSettings> setting)
            : base(logger)
        {
            this.setting = setting.Value;
        }

        [HttpGet]
        public IActionResult Index()
        {
            using (DogStatsd.StartTimer("RiskLab.ConfigurationsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    List<AppMenu> appMenu = new List<AppMenu>();

                    bool isFraudServiceUser = false;
                    bool isRiskLabUser = false;

                    var userRoles = HttpContext.User.Claims.Where(p => p.Type == ClaimTypes.Role);
                    if (userRoles != null)
                    {
                        var riskLabRole = userRoles.ToList().FirstOrDefault(a => a.Value == Constants.UserRole.RiskLab);
                        if (riskLabRole != null)
                        {
                            isRiskLabUser = true;
                            AppMenu riskRejectGroupMenu = GetGroupMenu();
                            appMenu.Add(riskRejectGroupMenu);
                        }

                        var fraudServiceDetailsRole = userRoles.ToList().FirstOrDefault(a => a.Value == Constants.UserRole.FraudServiceDetailsRole);
                        if (fraudServiceDetailsRole != null)
                        {
                            isFraudServiceUser = true;
                            appMenu.Add(new AppMenu() { Name = "FraudServiceDetails", DisplayName = "Fraud Service Details", IconName = "fas fa-copy", Route = "secure/merchantrejectedtxns", Link = "/secure/merchantrejectedtxns" });
                        }
                    }

                    var settingsViewModel = new SettingsViewModel(this.setting)
                    {
                        Username = this.HttpContext.User.Claims.FirstOrDefault(p => p.Type == Constants.UserClaim.RiskUserClaimName)?.Value,
                        IsFraudServiceUser = isFraudServiceUser,
                        IsRiskLabUser = isRiskLabUser,
                        Menu = appMenu,
                    };
                    return this.Ok(settingsViewModel);
                }
                catch (Exception ex)
                {
                    this.Logger.LogError("ConfigurationsController::Index() - " + ex.ToString());
                    return this.StatusCode(StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        private AppMenu GetGroupMenu()
        {
            var riskRejectGroup = new AppMenu();
            riskRejectGroup.DisplayName = "Risk Rejects";
            riskRejectGroup.IconName = "fas fa-file-alt fa-lg";
            riskRejectGroup.Name = "RiskRejects";

            List<AppMenu> childMenus = new List<AppMenu>();

            var individualRefundMenu = new AppMenu()
            {
                Name = "IndividualRefunds",
                DisplayName = "Individual Refunds",
                Route = "secure/risklab",
                Link = "/secure/risklab",
            };

            var batchRefundMenu = new AppMenu()
            {
                Name = "BatchRefunds",
                DisplayName = "Batch Refunds",
                Route = "secure/batchrejects",
                Link = "/secure/batchrejects",
            };

            childMenus.Add(individualRefundMenu);
            childMenus.Add(batchRefundMenu);
            riskRejectGroup.ChildrenMenuItems = childMenus;

            return riskRejectGroup;
        }
    }
}
