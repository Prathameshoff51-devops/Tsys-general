﻿namespace RiskLab.API.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Infrastructure.Helpers;
    using StatsdClient;
    using static RiskLab.API.Constants;

    [Route("[controller]")]
    [Authorize(Roles = UserRole.RiskLab)]
    public class IndividualTransactionsController : BaseController
    {
        private readonly IIndividualTransactionsService individualTransactionsService;

        public IndividualTransactionsController(ILogger<IndividualTransactionsController> logger, IIndividualTransactionsService individualTransactionsService)
            : base(logger)
        {
            this.individualTransactionsService = individualTransactionsService;
        }

        [HttpGet]
        public async Task<IActionResult> GetIndividualTransactions(string status)
        {
            using (DogStatsd.StartTimer("RiskLab.IndividualTransactionsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    RejectStatuses txnStatus;
                    if (Enum.TryParse(status, true, out txnStatus) && Enum.IsDefined(typeof(RejectStatuses), txnStatus))
                    {
                        return Ok(await individualTransactionsService.GetIndividualTransactionsByStatus(txnStatus.ToString()));
                    }
                    else
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidTransactionStatus);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError("IndividualTransactionsController::GetIndividualTransactions() - " + ex.ToString());
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateTransactionStatuses([FromBody] IndividualTransactionStatusUpdateDto transactions)
        {
            using (DogStatsd.StartTimer("RiskLab.IndividualTransactionsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    if (!await individualTransactionsService.IsUserValid(transactions.UserName))
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidUser);
                    }

                    return !ValidateRiskUserClaimName(transactions.UserName)
                        ? Unauthorized(Constants.ResponseMessages.InvalidUser)
                        : Ok(await individualTransactionsService.UpdateIndividualTransactionStatus(transactions));
                }
                catch (Exception ex)
                {
                    Logger.LogError("IndividualTransactionsController::UpdateTransactionStatuses() - " + ex.ToString());
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        [HttpGet]
        [Route("GetTransactionRejectsCount")]
        public async Task<IActionResult> GetTransactionRejectsCount(string status)
        {
            using (DogStatsd.StartTimer("RiskLab.IndividualTransactionsAPI." + MethodNameHelper.GetActualAsyncMethodName() + ".time", 1, null))
            {
                try
                {
                    RejectStatuses txnStatus;
                    if (Enum.TryParse(status, true, out txnStatus))
                    {
                        int count = (await individualTransactionsService.GetIndividualTransactionsByStatus(txnStatus.ToString())).Count();
                        return Ok(new RejectsCountDto { Count = count, Status = status });
                    }
                    else
                    {
                        return BadRequest(Constants.ResponseMessages.InvalidTransactionStatus);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError("IndividualTransactionsController::GetTransactionRejectsCount() - " + ex.ToString());
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, Constants.ResponseMessages.ErrorResponseMessage);
                }
            }
        }

        private bool ValidateRiskUserClaimName(string transactionUserName)
        {
            var riskUserClaimName = HttpContext.User.Claims.FirstOrDefault(p => p.Type == Constants.UserClaim.RiskUserClaimName);
            return riskUserClaimName?.Value.ToLower() == transactionUserName.ToLower();
        }
    }
}
