﻿namespace RiskLab.API.Healthcheck.Infrastructure
{
    using RiskLab.API.Healthcheck.Infrastructure.Interfaces;

    public class HealthCheckService : IHealthCheckService
    {
        private IEnumerable<IHealthCheck> _checks;

        public HealthCheckService(IEnumerable<IHealthCheck> checks)
        {
            _checks = checks;
        }

        public async Task<CompositeHealthCheckResult> CheckAll()
        {
            return new CompositeHealthCheckResult
            {
                Results = await Task.WhenAll(_checks.Select(async c => await c.CheckHealthAsync())),
            };
        }
    }
}
