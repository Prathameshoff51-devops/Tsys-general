﻿namespace RiskLab.API.Healthcheck.Infrastructure.Interfaces
{
    public interface IHealthCheckBuilder
    {
        IHealthCheckBuilder Add(Func<IServiceProvider, IHealthCheck> factory);

        IEnumerable<Func<IServiceProvider, IHealthCheck>> GetAll();
    }
}
