﻿namespace RiskLab.API.Healthcheck.Infrastructure
{
    public interface IHealthCheck
    {
        Task<HealthCheckResult> CheckHealthAsync();
    }
}