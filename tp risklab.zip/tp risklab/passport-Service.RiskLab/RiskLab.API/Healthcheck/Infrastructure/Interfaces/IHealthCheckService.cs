﻿namespace RiskLab.API.Healthcheck.Infrastructure.Interfaces
{
    public interface IHealthCheckService
    {
        Task<CompositeHealthCheckResult> CheckAll();
    }
}
