﻿namespace RiskLab.API.Healthcheck.Infrastructure
{
    public class CompositeHealthCheckResult
    {
        public IEnumerable<HealthCheckResult> Results { get; set; }

        public HealthStatus CompositeStatus => Results.Any(r => r.Status == HealthStatus.Unhealthy) ? HealthStatus.Unhealthy : HealthStatus.Healthy;
    }
}
