﻿namespace RiskLab.API.Healthcheck.Infrastructure
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using Newtonsoft.Json.Serialization;
    using RiskLab.API.Healthcheck.Infrastructure.Interfaces;

    public class HealthCheckMiddleware
    {
        private readonly RequestDelegate _next;

        public HealthCheckMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context, IHealthCheckService healthCheckService)
        {
            if (context.Request.Path.Equals("/healthcheck") && context.Request.Method == HttpMethods.Get)
            {
                var result = await healthCheckService.CheckAll();

                context.Response.Headers.Add("content-type", "application/json");
                await context.Response.WriteAsync(
                    JsonConvert.SerializeObject(
                        result,
                        new JsonSerializerSettings
                        {
                            Converters = { new StringEnumConverter() },
                            ContractResolver = new CamelCasePropertyNamesContractResolver(),
                        }));
                return;
            }

            await _next(context);
        }
    }
}
