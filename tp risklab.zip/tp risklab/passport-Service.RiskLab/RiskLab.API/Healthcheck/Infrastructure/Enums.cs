﻿namespace RiskLab.API.Healthcheck.Infrastructure
{
    public enum HealthStatus
    {
        Unhealthy = 0,
        Degraded = 1,
        Healthy = 2,
    }
}
