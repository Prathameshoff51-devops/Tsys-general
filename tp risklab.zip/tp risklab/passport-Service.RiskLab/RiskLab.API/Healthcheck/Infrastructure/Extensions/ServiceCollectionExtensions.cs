﻿namespace RiskLab.API.Healthcheck.Infrastructure.Extensions
{
    using RiskLab.API.Healthcheck.Infrastructure.Interfaces;

    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, Action<IHealthCheckBuilder> configureHealthCheckBuilder)
        {
            if (configureHealthCheckBuilder == null)
            {
                throw new ArgumentNullException(nameof(configureHealthCheckBuilder));
            }

            // services.AddTransient<IHealthCheckService, HealthCheckService>();

            var builder = new HealthCheckBuilder();
            configureHealthCheckBuilder(builder);

            foreach (var factory in builder.GetAll())
            {
                services.AddTransient(sp => factory(sp));
            }

            return services;
        }
    }
}
