﻿namespace RiskLab.API.Healthcheck.Infrastructure.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app) =>
            app.UseMiddleware<HealthCheckMiddleware>();
    }
}
