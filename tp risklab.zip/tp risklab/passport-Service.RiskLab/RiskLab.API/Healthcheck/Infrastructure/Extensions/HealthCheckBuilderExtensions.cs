﻿namespace RiskLab.API.Healthcheck.Infrastructure.Extensions
{
    using RiskLab.API.Healthcheck.Infrastructure.Interfaces;
    using static RiskLab.API.Healthcheck.HealthCheckProviders;

    public static class HealthCheckBuilderExtensions
    {
        public static IHealthCheckBuilder AddSqlServerHealthCheck(this IHealthCheckBuilder builder, string connectionString, string description = "") =>
            builder.Add(sp => new SqlServerHealthCheck(string.IsNullOrEmpty(description) ? nameof(SqlServerHealthCheck) : description, connectionString));

        public static IHealthCheckBuilder AddCoreloggingApiHealthCheck(this IHealthCheckBuilder builder, string url, string description = "") =>
           builder.Add(sp => new CoreloggingApiHealthCheck(string.IsNullOrEmpty(description) ? nameof(CoreloggingApiHealthCheck) : description, url));

        public static IHealthCheckBuilder AddRabbitMQHealthCheck(this IHealthCheckBuilder builder, string url, string description = "") =>
           builder.Add(sp => new RabbitMQHealthCheck(string.IsNullOrEmpty(description) ? nameof(RabbitMQHealthCheck) : description, url));
    }
}
