﻿//Todo - add appropirate healthcheck logic in respective functions
namespace RiskLab.API.Healthcheck
{
    using RiskLab.API.Healthcheck.Infrastructure;

    public class HealthCheckProviders
    {
        public abstract class HealthCheck : IHealthCheck
        {
            private readonly string description;

            public HealthCheck(string description)
            {
                this.description = description;
            }

            protected string Description => description;

            public abstract Task<HealthCheckResult> CheckHealthAsync();
        }

        public abstract class SwaggerApiHealthCheck : HealthCheckProviders.HealthCheck
        {
            private readonly string _serviceBaseUrl;

            public SwaggerApiHealthCheck(string description, string serviceBaseUrl)
                : base(description)
            {
                _serviceBaseUrl = serviceBaseUrl;
            }

            public async override Task<HealthCheckResult> CheckHealthAsync()
            {
                using (HttpClient client = new HttpClient())
                {
                    try
                    {
                        var response = await client.GetAsync($"{_serviceBaseUrl}/swagger/");
                        if (!response.IsSuccessStatusCode)
                        {
                            throw new Exception("Url not responding with 200 OK");
                        }
                    }
                    catch (Exception ex)
                    {
                        return HealthCheckResult.Unhealthy(description: Description, exception: ex);
                    }
                }

                return await Task.FromResult(HealthCheckResult.Healthy(Description));
            }
        }

        public class SqlServerHealthCheck : HealthCheck
        {
            private readonly string _connectionString;

            public SqlServerHealthCheck(string description, string connectionString)
                : base(description)
            {
                _connectionString = connectionString;
            }

            public override async Task<HealthCheckResult> CheckHealthAsync()
            {
               return HealthCheckResult.Healthy(description: Description);
            }
        }

        public class CoreloggingApiHealthCheck : SwaggerApiHealthCheck, IHealthCheck
        {
            public CoreloggingApiHealthCheck(string description, string url)
                : base(description, url)
            {
            }
        }

        public class RabbitMQHealthCheck : HealthCheck
        {
            private readonly string _connectionString;

            public RabbitMQHealthCheck(string description, string connectionString)
                : base(description)
            {
                _connectionString = connectionString;
            }

            public override async Task<HealthCheckResult> CheckHealthAsync()
            {
                return HealthCheckResult.Healthy(description: Description);
            }
        }
    }
}
