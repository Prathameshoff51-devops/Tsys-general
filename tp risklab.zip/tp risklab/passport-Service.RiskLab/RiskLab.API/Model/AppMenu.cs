﻿namespace RiskLab.API.Model
{
    public class AppMenu
    {
        public string Name
        {
            get;
            set;
        }

        public string DisplayName
        {
            get;
            set;
        }

        public string Link
        {
            get;
            set;
        }

        public string IconName
        {
            get;
            set;
        }

        public string Route
        {
            get;
            set;
        }

        public List<AppMenu> ChildrenMenuItems
        {
            get;
            set;
        }
    }
}
