﻿namespace RiskLab.API.Model
{
    using Hps.RoleManagement.Models;
    using RiskLab.Core.Settings;

    public class SettingsViewModel
    {
        public SettingsViewModel(ApplicationSettings appSettings)
        {
            Environment = appSettings.EnvironmentCode;
            RiskLabApiUrl = appSettings.RiskLabApiUrl;
            RiskLabUiUrl = appSettings.RiskLabUiUrl;
            CoreloggingServiceUrl = appSettings.CoreloggingServiceUrl;
            DefaultGridPageSize = appSettings.DefaultGridPageSize;
            DefaultBackOfficeGridPageSize = appSettings.DefaultBackOfficeGridPageSize;
            DefaultBatchGridPageSize = appSettings.DefaultBatchGridPageSize;
            DaysToAct = appSettings.DaysToAct;
        }

        public string Environment { get; set; }

        public string ScaPersonInfoUrl { get; set; }

        public int DefaultGridPageSize { get; set; }

        public int DefaultBackOfficeGridPageSize { get; set; }

        public int DefaultBatchGridPageSize { get; set; }

        public int DaysToAct { get; set; }

        public int MinimumSearchLength { get; set; }

        public string RiskLabApiUrl { get; set; }

        public string RiskLabUiUrl { get; set; }

        public string? Username { get; set; }

        public string CoreloggingServiceUrl { get; set; }

        public string JwtClaimsToken { get; set; }

        public bool IsSuperAdmin { get; set; }

        public List<AppMenu> Menu { get; set; }

        public int ThreadId => new Random().Next(int.MaxValue);

        public bool IsFraudServiceUser { get; set; }

        public bool IsRiskLabUser { get; set; }
    }
}
