﻿namespace RiskLab.Infrastructure.Settings
{
    using RiskLab.Core.Interfaces;
    using RiskLab.Infrastructure.Interfaces;
    using System.Transactions;

    /// <summary>
    /// Class for RabbitMQ settings.
    /// </summary>
    public class RabbitMQSettings : IRabbitMQSettings
    {
        private ISettingsManagerWrapper settingsManagerWrapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="RabbitMQSettings"/> class.
        /// </summary>
        public RabbitMQSettings(ISettingsManagerWrapper settingsManagerWrapper)
        {
            this.settingsManagerWrapper = settingsManagerWrapper;
        }

        /// <summary>
        /// Setting the RabbitMQ connection string.
        /// </summary>
        /// <param name="key">Key stored in <see cref="SettingsManagerWrapper "/>.</param>
        /// <returns>Returns the value against the key.</returns>
        public string this[string key]
        {
            get
            {
                using (new TransactionScope(TransactionScopeOption.Suppress))
                {
                    var settingmanager = settingsManagerWrapper.RabbitMQSettingsManager.GetSettingByKey(key);
                    return settingmanager.Result.Value;
                }
            }
        }

        /// <summary>
        /// Class Dispose method.
        /// </summary>
        public void Dispose()
        {
            this.settingsManagerWrapper = null;
        }
    }
}