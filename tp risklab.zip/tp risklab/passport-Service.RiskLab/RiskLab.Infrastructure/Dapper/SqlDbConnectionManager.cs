﻿namespace RiskLab.Infrastructure.Dapper
{
    using System.Data;
    using System.Data.SqlClient;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Interfaces;
    using RiskLab.Infrastructure.Interfaces;

    public class SqlDbConnectionManager : ISqlDbConnectionManager
    {
        private readonly ISettingsManagerWrapper settingsManagerWrapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="SqlDbConnectionManager"/> class.
        /// </summary>
        /// <param name="settingsManagerWrapper">The settings manager wrapper.</param>
        /// <exception cref="System.ArgumentNullException">
        /// ConnectionStrings empty or risklabconnectionString or hcsDBConnectionString
        /// </exception>
        public SqlDbConnectionManager(ISettingsManagerWrapper settingsManagerWrapper)
        {
            this.settingsManagerWrapper = settingsManagerWrapper;
            var risklabconnectionString = settingsManagerWrapper.ApplicationSettingsManager.GetConnectionString("RiskLab").Result.Value;
            var hcsDBConnectionString = settingsManagerWrapper.ApplicationSettingsManager.GetConnectionString("HcsDB").Result.Value;
            if (!string.IsNullOrEmpty(risklabconnectionString) && !string.IsNullOrEmpty(hcsDBConnectionString))
            {
                RiskLabConnectionString = risklabconnectionString;
                HCSDBConnectionString = hcsDBConnectionString;
            }
            else
            {
                if (string.IsNullOrEmpty(hcsDBConnectionString) && string.IsNullOrEmpty(risklabconnectionString))
                {
                    throw new ArgumentNullException("ConnectionStrings empty");
                }
                else if (string.IsNullOrEmpty(risklabconnectionString))
                {
                    throw new ArgumentNullException(nameof(risklabconnectionString));
                }
                else
                {
                    throw new ArgumentNullException(nameof(hcsDBConnectionString));
                }
            }
        }

        public string RiskLabConnectionString { get; protected set; }

        public string HCSDBConnectionString { get; protected set; }

        public virtual async Task<IDbConnection> PrepareConnection(DBs dbContnext = DBs.RiskLab)
        {
            string connectionString = RiskLabConnectionString;
            if (dbContnext == DBs.HCSDB)
            {
                connectionString = HCSDBConnectionString;
            }

            var dbConnection = new SqlConnection(connectionString);
            await dbConnection.OpenAsync();
            return dbConnection;
        }
    }
}
