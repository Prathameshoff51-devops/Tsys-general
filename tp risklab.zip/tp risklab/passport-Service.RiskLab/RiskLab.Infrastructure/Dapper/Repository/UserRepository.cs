﻿namespace RiskLab.Infrastructure.Dapper.Repository
{
    using RiskLab.Core.Constants;
    using RiskLab.Core.Entities;
    using RiskLab.Core.Interfaces.Repositories;
    using RiskLab.Infrastructure.Interfaces;

    public class UserRepository : BaseQueryRepository, IUserRepository
    {
        private const string _spGetUserByEmail = "dbo.spGetUserByEmail";
        private const string _spGetUserById = "dbo.spGetUserById";
        private const string _spGetUserByLoginName = "dbo.spGetUser";

        public UserRepository(ISqlDbConnectionManager connectionManager)
            : base(connectionManager)
        {
        }

        /// <summary>
        /// Get user by Login Name
        /// </summary>
        /// <param name="loginName"></param>
        /// <returns></returns>
        public Task<User> GetUserByLoginName(string loginName)
        {
            return GetAsync<User>(
                _spGetUserByLoginName,
                new
                {
                    @LOGONID = loginName,
                    @mode = 1,
                },
                isStoredProcedure: true,
                DBs.HCSDB);
        }

        /// <summary>
        /// get user by email
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public Task<User> GetUserByEmail(string email)
        {
            return GetAsync<User>(
                _spGetUserByEmail,
                new
                {
                    @EmailId = email,
                    @mode = 1,
                },
                isStoredProcedure: true,
                DBs.HCSDB);
        }

        /// <summary>
        /// get user by userid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Task<User> GetUserByUserId(int userId)
        {
            return GetAsync<User>(
                _spGetUserById,
                new
                {
                    @UserId = userId,
                },
                isStoredProcedure: true,
                DBs.HCSDB);
        }
    }
}
