﻿using System.Data;
using Dapper;
using RiskLab.Core.Constants;
using RiskLab.Infrastructure.Interfaces;

namespace RiskLab.Infrastructure.Dapper.Repository
{
    public abstract class BaseQueryRepository
    {
        private readonly ISqlDbConnectionManager connectionManager;

        public BaseQueryRepository(ISqlDbConnectionManager connectionManager)
        {
            this.connectionManager = connectionManager;
        }

        protected ISqlDbConnectionManager ConnectionManager => connectionManager;

        protected async Task<IEnumerable<T>> GetListAsync<T>(string query, object queryParam = null, bool isStoredProcedure = false, DBs dbContnext = DBs.RiskLab)
            where T : class
        {
                using (var dbConnection = await ConnectionManager.PrepareConnection(dbContnext))
                {
                    return await dbConnection.QueryAsync<T>(query, queryParam, null, null, isStoredProcedure ? CommandType.StoredProcedure : null);
                }
        }

        protected async Task<T> GetAsync<T>(string query, object queryParam = null, bool isStoredProcedure = false, DBs dbContnext = DBs.RiskLab)
            where T : class
        {
            var result = await GetListAsync<T>(query, queryParam, isStoredProcedure, dbContnext);
            return result.SingleOrDefault();
        }

        protected async Task<T> GetScalarAsync<T>(string query, object queryParam = null, bool isStoredProcedure = false, DBs dbContnext = DBs.RiskLab)
        {
            using (var dbConnection = await ConnectionManager.PrepareConnection(dbContnext))
            {
                return await dbConnection.ExecuteScalarAsync<T>(query, queryParam, null, null, isStoredProcedure ? CommandType.StoredProcedure : null);
            }
        }

        protected async Task<T> ExecuteScalarAsync<T>(string query, object queryParam = null, bool isStoredProcedure = false, DBs dbContnext = DBs.RiskLab)
            where T : struct
        {
            using (var dbConnection = await ConnectionManager.PrepareConnection(dbContnext))
            {
                return await dbConnection.ExecuteScalarAsync<T>(query, queryParam, null, null, isStoredProcedure ? CommandType.StoredProcedure : null);
            }
        }

        protected async Task<int> ExecuteAsync(string query, object queryParam = null, DBs dbContnext = DBs.RiskLab)
        {
            using (var dbConnection = await ConnectionManager.PrepareConnection(dbContnext))
            {
                return await dbConnection.ExecuteAsync(query, queryParam, commandType: CommandType.StoredProcedure);
            }
        }
    }
}