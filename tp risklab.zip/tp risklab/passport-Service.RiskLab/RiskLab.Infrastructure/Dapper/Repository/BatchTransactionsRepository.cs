﻿using System.Data;
using System.Data.Common;
using Dapper;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure.Interfaces;

namespace RiskLab.Infrastructure.Dapper.Repository
{
    public class BatchTransactionsRepository : BaseQueryRepository, IBatchTransactionsRepository
    {
        private const string SpCheckIfMessageExistsForBatch = "spCheckIfMessageExistsForBatch";
        private const string SpInsertBatchRejects = "spInsertBatchRejects";
        private const string SpInsertOrUpdateAck = "spInsertOrUpdateAck";

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="connectionManager"></param>
        public BatchTransactionsRepository(ISqlDbConnectionManager connectionManager)
          : base(connectionManager)
        {
        }

        /// <summary>
        /// Checks if message consumed.
        /// </summary>
        /// <param name="messageId">The message identifier.</param>
        /// <returns>True if message is consumed.</returns>
        public Task<bool> CheckIfMessageConsumed(Guid messageId)
        {
            // Check if messageId exists in TransactionReject Table.
            return this.ExecuteScalarAsync<bool>(
                SpCheckIfMessageExistsForBatch,
                new
                {
                    @MessageId = messageId,
                    @IsBatch=true,
                }, true);
        }

        /// <summary>
        /// Save Error Payload
        /// </summary>
        /// <param name="payload"></param>
        /// <param name="messageId"></param>
        /// <returns></returns>
        public async Task<Tuple<bool, string, string>> InsertErrorPayload(string payload, string error, Guid messageId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@MessageId", messageId, DbType.Guid, direction: ParameterDirection.Input);
            parameters.Add("@Payload", payload, DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@Error", error, DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@Return", null, DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", null, DbType.String, direction: ParameterDirection.Output, 500);
            parameters.Add("@ErrorMessage", null, DbType.String, direction: ParameterDirection.Output, -1);

            await this.ExecuteAsync("spInsertErrorPayload", parameters);

            return new (parameters.Get<bool>("@Return"), parameters.Get<string>("@ErrorCode"), parameters.Get<string>("@ErrorMessage"));
        }

        /// <summary>
        /// Save the batch acknowledgment.
        /// </summary>
        /// <param name="payload"></param>
        /// <param name="batchDeatils"></param>
        /// <returns></returns>
        public async Task<Tuple<bool, string, string>> InsertBatchAck(string payload, BatchDto batchDeatils)
        {
                var parameters = new DynamicParameters();
                parameters.Add("@MessageId", batchDeatils.MessageId, DbType.Guid, direction: ParameterDirection.Input);
                parameters.Add("@MessageContent", payload, DbType.String, direction: ParameterDirection.Input);
                parameters.Add("@AckSent", true, DbType.Boolean, direction: ParameterDirection.Input);
                parameters.Add("@Return", null, DbType.Boolean, direction: ParameterDirection.Output);
                parameters.Add("@ErrorCode", null, DbType.String, direction: ParameterDirection.Output, 500);
                parameters.Add("@ErrorMessage", null, DbType.String, direction: ParameterDirection.Output, -1);

                await this.ExecuteAsync(SpInsertOrUpdateAck, parameters);

                return new (parameters.Get<bool>("@Return"), parameters.Get<string>("@ErrorCode"), parameters.Get<string>("@ErrorMessage"));
        }

        /// <summary>
        /// Insert batch rejects details.
        /// </summary>
        /// <param name="batchDeatils"></param>
        /// <param name="batchRejectReasons"></param>
        /// <param name="transactionList"></param>
        /// <returns></returns>
        public Task<int> InsertBatchFromPassport(BatchDto batchDeatils, DataTable batchRejectReasons, DataTable transactionList)
        {
            // Insert the records in TransactionRejects table.
            return this.ExecuteScalarAsync<int>(
                SpInsertBatchRejects,
                new
                {
                    @MessageId = batchDeatils.MessageId,
                    @TxnUuid = batchDeatils.TxnUuid,
                    @MerchantNumber = batchDeatils.MerchantNumber,
                    @MerchantName = batchDeatils.MerchantName,
                    @LegalName = batchDeatils.LegalName,
                    @ChainOID = batchDeatils.ChainOID,
                    @MCC = batchDeatils.MCC,
                    @BatchAmount = batchDeatils.BatchAmount,
                    @OriginalBatchNumber = batchDeatils.OriginalBatchNumber,
                    @BatchCloseDate = batchDeatils.BatchCloseDate,
                    @SubmitterId = batchDeatils.SubmitterID,
                    @SubmitterIDDescription = batchDeatils.SubmitterIdDescription,
                    @CreditCount = batchDeatils.CreditCount,
                    @Status = (int)RejectStatuses.New,
                    @LastUpdatedBy = 22094, // sys_cardbrand user
                    @BusinessDateUtc = batchDeatils.BusinessDateUTC,
                    @BatchTransactionList = transactionList,
                    @InsertBatchRejectReason = batchRejectReasons,
                }, true);
        }
    }
}
