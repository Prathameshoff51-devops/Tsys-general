﻿using Acquisition.Contracts.Risk.Jville;
using Acquisition.Contracts.Risk.Passport;
using Dapper;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure.Interfaces;
using System.Data;

namespace RiskLab.Infrastructure.Dapper.Repository
{
    public class BatchRejectsRepository : BaseQueryRepository, IBatchRejectsRepository
    {
        private const string SPGetBatchRejects = "spGetBatchRejects";
        private const string SPUpdateBatchRejectStatus = "spUpdateBatchRejectStatus";
        private const string SPGetBatchRejectById = "spGetBatchRejectById";
        private const string SPGetBatchTransactionRejects = "SPGetBatchTransactionRejects";
        private const string SPUpdateBatchTransactionRejectStatus = "spUpdateBatchTransactionRejectStatus";
        private const string SPGetBatchTransactionRejectById = "spGetBatchTransactionRejectById";
        private const string SPGetBatchTransactionRejectsByStatus = "spGetBatchTransactionRejectsByStatus";

        public BatchRejectsRepository(ISqlDbConnectionManager connectionManager)
            : base(connectionManager)
        {
        }

        public async Task<BatchRejectViewDto> GetBatchRejectById(int batchRejectId)
        {
            var lookup = new Dictionary<int, BatchRejectViewDto>();
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                IEnumerable<BatchRejectViewDto> transactions = await dbConnection.QueryAsync<BatchRejectViewDto, string,
                    BatchRejectViewDto>(
                    "exec " + SPGetBatchRejectById + " @BatchRejectId",
                    (batch, errorCode) =>
                    {
                        BatchRejectViewDto found;
                        if (!lookup.TryGetValue(batch.BatchRejectId, out found))
                        {
                            found = batch;
                            lookup.Add(batch.BatchRejectId, found);
                            found.RejectReasons = new List<string>();
                        }

                        found.RejectReasons.Add(errorCode);
                        return found;
                    },
                    splitOn: "FraudRejectReasonCodes",
                    param: new { @BatchRejectId = batchRejectId });

                return transactions.FirstOrDefault();
            }
        }

        public async Task<IEnumerable<BatchRejectViewDto>> GetBatchRejects(string status)
        {
            var lookup = new Dictionary<int, BatchRejectViewDto>();
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                IEnumerable<BatchRejectViewDto> transactions = await dbConnection.QueryAsync<BatchRejectViewDto, string, BatchRejectViewDto>(
                        "exec " + SPGetBatchRejects + " @status",
                        (batch, errorCode) =>
                        {
                            BatchRejectViewDto found;
                            if (!lookup.TryGetValue(batch.BatchRejectId, out found))
                            {
                                found = batch;
                                lookup.Add(batch.BatchRejectId, found);
                                found.RejectReasons = new List<string>();
                            }

                            found.RejectReasons.Add(errorCode);
                            return found;
                        },
                        splitOn: "FraudRejectReasonCodes",
                        param: new { @status = status });

                return transactions.Distinct();
            }
        }

        public async Task<BatchTransactionRejectViewDto> GetBatchTransactionRejectById(int batchTransactionRejectId)
        {
            var lookup = new Dictionary<int, BatchTransactionRejectViewDto>();
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                IEnumerable<BatchTransactionRejectViewDto> batchTxns = await dbConnection.QueryAsync<BatchTransactionRejectViewDto, string,
                    BatchTransactionRejectViewDto>(
                    "exec " + SPGetBatchTransactionRejectById + " @BatchTransactionRejectId",
                    (txn, errorCode) =>
                    {
                        BatchTransactionRejectViewDto found;
                        if (!lookup.TryGetValue(txn.BatchTransactionRejectId, out found))
                        {
                            found = txn;
                            lookup.Add(txn.BatchTransactionRejectId, found);
                            found.RejectReasons = new List<string>();
                        }

                        found.RejectReasons.Add(errorCode);
                        return found;
                    },
                    splitOn: "FraudRejectReasonCodes",
                    param: new { @BatchTransactionRejectId = batchTransactionRejectId });

                return batchTxns.FirstOrDefault();
            }
        }

        public async Task<BatchTransactionRejectsViewDto> GetBatchTransactionRejects(int batchRejectId)
        {
            var batchReject = await GetBatchRejectById(batchRejectId);
            IEnumerable<BatchTransactionRejectViewDto> batchTransactions;
            var lookup = new Dictionary<int, BatchTransactionRejectViewDto>();

            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                batchTransactions = await dbConnection.QueryAsync<BatchTransactionRejectViewDto, string, BatchTransactionRejectViewDto>(
                        "exec " + SPGetBatchTransactionRejects + " @batchRejectId",
                        (txn, errorCode) =>
                        {
                            BatchTransactionRejectViewDto found;

                            if (!lookup.TryGetValue(txn.BatchTransactionRejectId, out found))
                            {
                                found = txn;
                                lookup.Add(txn.BatchTransactionRejectId, found);
                                found.RejectReasons = new List<string>();
                            }

                            found.RejectReasons.Add(errorCode);
                            return found;
                        },
                        splitOn: "FraudRejectReasonCodes",
                        param: new { @batchRejectId = batchRejectId });
            }

            if (batchReject == null || batchTransactions == null)
                return null;

            return new BatchTransactionRejectsViewDto
            {
                BatchRejectId = batchRejectId,
                BatchAmount = batchReject.BatchAmount,
                BatchCloseDateUTC = batchReject.BatchCloseDate,
                MerchantName = batchReject.MerchantName,
                MerchantNumber = batchReject.MerchantNumber,
                OriginalBatchNumber = batchReject.BatchNumber,
                Status = batchReject.Status,
                Transactions = batchTransactions.Distinct().ToList(),
            };
        }

        public async Task<IEnumerable<BatchTransactionRejectByStatusViewDto>> GetBatchTransactionRejectByStatus(string status)
        {
            IEnumerable<BatchTransactionRejectByStatusViewDto> batchTransactions;
            var lookup = new Dictionary<int, BatchTransactionRejectByStatusViewDto>();

            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                batchTransactions = await dbConnection.QueryAsync<BatchTransactionRejectByStatusViewDto, string, BatchTransactionRejectByStatusViewDto>(
                        "exec " + SPGetBatchTransactionRejectsByStatus + " @status",
                        (txn, errorCode) =>
                        {
                            BatchTransactionRejectByStatusViewDto found;

                            if (!lookup.TryGetValue(txn.BatchTransactionRejectId, out found))
                            {
                                found = txn;
                                lookup.Add(txn.BatchTransactionRejectId, found);
                                found.FraudRejectReasonCodes = new List<string>();
                            }

                            found.FraudRejectReasonCodes.Add(errorCode);
                            return found;
                        },
                        splitOn: "FraudRejectReasonCodes",
                        param: new { @status = status });
            }

            if (batchTransactions == null)
                return null;

            return batchTransactions.Distinct();
        }

        public async Task<BatchRejectUpdateResultDto> UpdateBatchRejectStatus(BatchRejectUpdateDto batchReject)
        {
            return await this.GetAsync<BatchRejectUpdateResultDto>(
                SPUpdateBatchRejectStatus,
                new
                {
                    @BatchRejectId = batchReject.BatchRejectId,
                    @NewStatus = batchReject.NewStatus,
                    @UserName = batchReject.UserName,
                },
                true);
        }

        public async Task<BatchTransactionRejectUpdateStatus> UpdateBatchTransactionRejectStatus(
            BatchTransactionStatus batchTransactionReject,
            string userName)
        {
            return await this.GetAsync<BatchTransactionRejectUpdateStatus>(
                SPUpdateBatchTransactionRejectStatus,
                new
                {
                    @BatchTransactionRejectId = batchTransactionReject.BatchTransactionRejectId,
                    @NewStatus = batchTransactionReject.NewStatus,
                    @UserName = userName,
                },
                true);
        }

        public async Task<IEnumerable<ReleasedBatchDto>> GetReleasedBatchesForPassport()
        {
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                return await this.GetListAsync<ReleasedBatchDto>("spGetReleasedBatchesForPassport", true);
            }
        }

        public async Task<Tuple<bool, string, string>> InsertReleasedBatchToPassport(FraudReleasedBatch fraudReleasedBatch, ReleasedBatchDto releasedBatchDto, string payload)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@JvillMessageId", fraudReleasedBatch.MessageId, DbType.Guid, direction: ParameterDirection.Input);
            parameters.Add("@MessageContent", payload, DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@AckRecvd", false, DbType.Boolean, direction: ParameterDirection.Input);
            parameters.Add("@PassportMessageId", releasedBatchDto.MessageId, DbType.Guid, direction: ParameterDirection.Input);
            parameters.Add("@TxnUUID", releasedBatchDto.TxnUuid, DbType.Int64, direction: ParameterDirection.Input);
            parameters.Add("@NumberOfAttempts", releasedBatchDto.NumberOfAttempts, DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@Return", null, DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", null, DbType.String, direction: ParameterDirection.Output, 500);
            parameters.Add("@ErrorMessage", null, DbType.String, direction: ParameterDirection.Output, -1);

            await this.ExecuteAsync("spInsertBatchMessageToPassport", parameters);

            return new (parameters.Get<bool>("@Return"), parameters.Get<string>("@ErrorCode"), parameters.Get<string>("@ErrorMessage"));
        }

        public Task<bool> CheckIfBatchIsInProcess(ReleasedBatchDto batch)
        {
            return this.ExecuteScalarAsync<bool>(
                "spCheckInFlightBatch",
                new
                {
                    @TxnUUID = batch.TxnUuid,
                }, true);
        }

        public Task ResetInFlightBatch(ReleasedBatchDto batch)
        {
            return this.ExecuteScalarAsync<bool>(
                "spResetInflightBatch",
                new
                {
                    @TxnUUID = batch.TxnUuid,
                }, true);
        }

        public async Task<IEnumerable<NotificationMessageDto>> CheckNotificationStatusForMessageIds(List<ReleasedBatchDto> unAckBatches)
        {
            DataTable txns = new DataTable("MessageIdList");
            txns.Columns.Add("MessageID", typeof(Guid));
            foreach (ReleasedBatchDto transaction in unAckBatches)
            {
                txns.Rows.Add(transaction.JvilleMessageId);
            }

            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                return await this.GetListAsync<NotificationMessageDto>("spCheckNotificationStatus", new { @messageIds = txns }, true);
            }
        }

        public async Task<bool> UpdateNotificationStatusForMessageIds(List<ReleasedBatchDto> unAckBatchList)
        {
            DataTable txns = new DataTable("MessageIdList");
            txns.Columns.Add("MessageID", typeof(Guid));
            foreach (var item in unAckBatchList)
            {
                txns.Rows.Add(item.JvilleMessageId);
            }

            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                return await this.ExecuteScalarAsync<bool>("spUpdateNotificationStatus", new { @messageIds = txns }, true);
            }
        }

        public Task<int> UpdateReleasedBatchAck(FraudReleasedBatchConfirmation fraudReleasedBatchConfirmation)
        {
            return this.ExecuteScalarAsync<int>(
                "spUpdateReleasedTransactionAck",
                new
                {
                    @MessageId = fraudReleasedBatchConfirmation.MessageId,
                    @AckRecvd = true,
                }, true);
        }
    }
}
