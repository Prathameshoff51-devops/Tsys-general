﻿namespace RiskLab.Infrastructure.Dapper.Repository
{
    using RiskLab.Core.Constants;
    using RiskLab.Core.Entities;
    using RiskLab.Core.Interfaces.Repositories;
    using RiskLab.Infrastructure.Interfaces;

    public class RoleRepository : BaseQueryRepository, IRoleRepository
    {
        private const string _spGetUserRolesByEmail = "dbo.GetUserRoles";

        public RoleRepository(ISqlDbConnectionManager connectionManager)
            : base(connectionManager)
        {
        }

        /// <summary>
        /// To get user roles
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        Task<IEnumerable<UserRole>> IRoleRepository.GetUserRoles(int userID)
        {
            return GetListAsync<UserRole>(
                _spGetUserRolesByEmail,
                new
                {
                    @zsysUserID = userID,
                }, isStoredProcedure: true,
                DBs.HCSDB);
        }
    }
}
