﻿using Acquisition.Contracts.Risk.Jville;
using Dapper;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure.Interfaces;
using System.Data;

namespace RiskLab.Infrastructure.Dapper.Repository
{
    public class IndividualTransactionsRepository : BaseQueryRepository, IIndividualTransactionsRepository
    {
        private const string SPGetAllActiveIndividualTransactions = "spGetAllActiveIndividualTransactions";
        private const string SPUpdateIndividualTransactionStatus = "spUpdateIndividualTransactionStatus";
        private const string SPGetTransactionRejectDetails = "spGetTransactionRejectDetails";
        private const string SpGetMerchantNumberFromSequenceKey = "spGetMerchantNumberFromSequenceKey";
        private const string SpGetRejectsForFraudServiceDetailsByMerchantNumber = "spGetRejectsByMerchantNumber";

        public IndividualTransactionsRepository(ISqlDbConnectionManager connectionManager)
            : base(connectionManager)
        {
        }

        public async Task<IndividualTransactionViewDto> GetTransaction(int id)
        {
            //return await GetAsync<IndividualTransactionDto>(spGetTransactionRejectDetails, new { @TransactionRejectId = id }, true);
            var lookup = new Dictionary<int, IndividualTransactionViewDto>();
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                IEnumerable<IndividualTransactionViewDto> transactions = await dbConnection.QueryAsync<IndividualTransactionViewDto, string, IndividualTransactionViewDto>(
                    "exec " + SPGetTransactionRejectDetails + " @TransactionRejectId",
                    (txn, errorCode) =>
                    {
                        IndividualTransactionViewDto found;
                        if (!lookup.TryGetValue(txn.IndividualTxnId, out found))
                        {
                            found = txn;
                            lookup.Add(txn.IndividualTxnId, found);
                            found.FraudRejectReasonCodes = new List<string>();
                        }

                        found.FraudRejectReasonCodes.Add(errorCode);
                        return found;
                    },
                    splitOn: "FraudRejectReasonCodes",
                    param: new { @TransactionRejectId = id });

                return transactions.FirstOrDefault();
            }
        }

        public async Task<IEnumerable<IndividualTransactionViewDto>> GetTransactions(string status)
        {
            var lookup = new Dictionary<int, IndividualTransactionViewDto>();
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                IEnumerable<IndividualTransactionViewDto> transactions = await dbConnection.QueryAsync<IndividualTransactionViewDto, string, IndividualTransactionViewDto>(
                        "exec " + SPGetAllActiveIndividualTransactions + " @status",
                        (txn, errorCode) =>
                        {
                            IndividualTransactionViewDto found;
                            if (!lookup.TryGetValue(txn.IndividualTxnId, out found))
                            {
                                found = txn;
                                lookup.Add(txn.IndividualTxnId, found);
                                found.FraudRejectReasonCodes = new List<string>();
                            }

                            found.FraudRejectReasonCodes.Add(errorCode);
                            return found;
                        },
                        splitOn: "FraudRejectReasonCodes",
                        param: new { @status = status });

                return transactions.Distinct();
            }
        }

        public async Task<IEnumerable<IndividualTransactionStatusUpdateResultDto>> UpdateIndividualTransactionStatus(IndividualTransactionStatusUpdateDto transactions)
        {
            DataTable txns = new DataTable("Transactions");
            txns.Columns.Add("TransactionId", typeof(int));
            txns.Columns.Add("NewStatus", typeof(int));

            foreach (var txn in transactions.TransactionsStatus)
            {
                Enum.TryParse(txn.NewStatus, true, out RejectStatuses newStatus);
                var row = txns.NewRow();
                row["TransactionId"] = txn.TransactionId.Value;
                row["NewStatus"] = newStatus;
                txns.Rows.Add(row);
            }

            return await this.GetListAsync<IndividualTransactionStatusUpdateResultDto>(SPUpdateIndividualTransactionStatus, new { @Transactions = txns, @UserName = transactions.UserName }, true);
        }

        /// <summary>
        /// Saves the Individual transaction values fetched from the RabbitMQ queue.
        /// </summary>
        /// <param name="individualTransaction"><see cref="IndividualTransactionDto"/>object.</param>
        /// <returns>Returns<see cref="IEnumerable{IndividualTransactionAcknowledgementResultDto}"/>object.</returns>
        public Task<int> InsertIndividualTransactionFromPassport(IndividualTransactionDto individualTransaction, DataTable transactionRejectReasons)
        {
            // Insert the records in TransactionRejects table.
            return this.ExecuteScalarAsync<int>(
                "spInsertTransactionRejects",
                new
                {
                    @MessageId = individualTransaction.MessageId,
                    @TxnUuid = individualTransaction.TxnUuid,
                    @TxnDetailId = individualTransaction.TxnDetailId,
                    @MerchantNumber = individualTransaction.MerchantNumber,
                    @MerchantName = individualTransaction.MerchantName,
                    @LegalName = individualTransaction.LegalName,
                    @ChainOID = individualTransaction.ChainOID,
                    @MCC = individualTransaction.MCC,
                    @Amount = individualTransaction.Amount,
                    @CardNumberMask = individualTransaction.CardNumberMask,
                    @TxnDateUtc = individualTransaction.TxnDateUtc,
                    @OriginalBatchNumber = individualTransaction.OriginalBatchNumber,
                    @AuthCode = individualTransaction.AuthCode,
                    @ExpDate = individualTransaction.ExpDate,
                    @ServiceOptionTxnTypeID = individualTransaction.ServiceOptionTxnTypeID,
                    @BatchCloseDate = individualTransaction.BatchCloseDate,
                    @SubmitterId = individualTransaction.SubmitterId,
                    @SubmitterIDDescription = individualTransaction.SubmitterIDDescription,
                    @Status = (int)RejectStatuses.New,
                    @LastUpdatedBy = 22094, // sys_cardbrand user
                    @BusinessDateUtc = individualTransaction.BusinessDateUtc,
                    @InsertTransactionRejectReason = transactionRejectReasons,
                }, true);
        }

        /// <summary>
        /// Save the individual Transaction acknowledgment.
        /// </summary>
        /// <param name="payload"></param>
        /// <param name="individualTransactionDto"></param>
        /// <returns></returns>
        public async Task<Tuple<bool, string, string>> InsertIndividualTransactionAck(string payload, IndividualTransactionDto individualTransactionDto)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@MessageId", individualTransactionDto.MessageId, DbType.Guid, direction: ParameterDirection.Input);
            parameters.Add("@MessageContent", payload, DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@AckSent", true, DbType.Boolean, direction: ParameterDirection.Input);
            parameters.Add("@Return", null, DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", null, DbType.String, direction: ParameterDirection.Output, 500);
            parameters.Add("@ErrorMessage", null, DbType.String, direction: ParameterDirection.Output, -1);

            await this.ExecuteAsync("spInsertIndividualTransactionAck", parameters);

            return new (parameters.Get<bool>("@Return"), parameters.Get<string>("@ErrorCode"), parameters.Get<string>("@ErrorMessage"));
        }

        /// <summary>
        /// Gets the released transaction reject.
        /// </summary>
        /// <param name="transactionRejectIds">The transaction reject ids.</param>
        /// <returns>Returns IndividualTransactionDto</returns>
        public async Task<IEnumerable<FraudReleasedTransaction>> GetReleasedTransactionReject(List<int> transactionRejectIds)
        {
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                DataTable txns = new DataTable("TransactionRejectIds");
                txns.Columns.Add("TransactionRejectIds", typeof(int));

                foreach (var txn in transactionRejectIds)
                {
                    var row = txns.NewRow();
                    row["TransactionRejectIds"] = txn;
                    txns.Rows.Add(row);
                }

                return await this.GetListAsync<FraudReleasedTransaction>("spGetReleasedTransactionReject", new { @TransactionRejectIds = txns }, true);
            }
        }

        /// <summary>
        ///  Inserts the released transaction to passport.
        /// </summary>
        /// <param name="fraudReleasedTransaction"></param>
        /// <param name="releasedIndividualTransactionRejectDto"></param>
        /// <param name="payload"></param>
        /// <returns></returns>
        public async Task<Tuple<bool, string, string>> InsertReleasedTransactionToPassport(FraudReleasedTransaction fraudReleasedTransaction, ReleasedIndividualTransactionDto releasedIndividualTransactionRejectDto, string payload)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@JvillMessageId", fraudReleasedTransaction.MessageId, DbType.Guid, direction: ParameterDirection.Input);
            parameters.Add("@MessageContent", payload, DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@AckRecvd", false, DbType.Boolean, direction: ParameterDirection.Input);
            parameters.Add("@PassportMessageId", releasedIndividualTransactionRejectDto.MessageId, DbType.Guid, direction: ParameterDirection.Input);
            parameters.Add("@TxnUUID", releasedIndividualTransactionRejectDto.TxnUuid, DbType.Int64, direction: ParameterDirection.Input);
            parameters.Add("@TxnDetailId", releasedIndividualTransactionRejectDto.TxnDetailId, DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@NumberOfAttempts", releasedIndividualTransactionRejectDto.NumberOfAttempts, DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@TargetType", releasedIndividualTransactionRejectDto.TargetType, DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@TargetId", releasedIndividualTransactionRejectDto.TargetId, DbType.Int32, direction: ParameterDirection.Input);

            parameters.Add("@Return", null, DbType.Boolean, direction: ParameterDirection.Output);
            parameters.Add("@ErrorCode", null, DbType.String, direction: ParameterDirection.Output, 500);
            parameters.Add("@ErrorMessage", null, DbType.String, direction: ParameterDirection.Output, -1);

            await this.ExecuteAsync("spInsertMessageToPassport", parameters);

            return new (parameters.Get<bool>("@Return"), parameters.Get<string>("@ErrorCode"), parameters.Get<string>("@ErrorMessage"));
        }

        /// <summary>
        /// Checks if message consumed.
        /// </summary>
        /// <param name="messageId">The message identifier.</param>
        /// <returns>True if message is consumed.</returns>
        public Task<bool> CheckIfMessageConsumed(Guid messageId)
        {
            // Check if messageId exists in TransactionReject Table.
            return this.ExecuteScalarAsync<bool>(
                "spCheckIfMessageExists",
                new
                {
                    @MessageId = messageId,
                }, true);
        }

        /// <summary>
        /// Updates the message to passport transaction rejects.
        /// </summary>
        /// <param name="individualTransaction">The individual transaction.</param>
        /// <returns></returns>
        public Task<int> UpdateReleasedTransactionAck(Acquisition.Contracts.Risk.Passport.FraudReleasedTransactionConfirmation fraudReleasedTransactionConfirmation)
        {
            // Update the jvillMessageId in MessageToPassport column in TransactionRejectTable.
            return this.ExecuteScalarAsync<int>(
                "spUpdateReleasedTransactionAck",
                new
                {
                    @MessageId = fraudReleasedTransactionConfirmation.MessageId,
                    @AckRecvd = true,
                }, true);
        }

        /// <summary>
        /// Get transcastions from database.
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ReleasedIndividualTransactionDto>> GetTransactionsForPassport()
        {
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                return await this.GetListAsync<ReleasedIndividualTransactionDto>("spGetTransactionsForPassport", true);
            }
        }

        public async Task<IEnumerable<MerchantRejects>> GetRejectsByMerchantNumber(string merchantNumber)
        {
            var lookup = new Dictionary<int, MerchantRejects>();
            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                IEnumerable<MerchantRejects> transactions = await dbConnection.QueryAsync<MerchantRejects, string, MerchantRejects>(
                        "exec " + SpGetRejectsForFraudServiceDetailsByMerchantNumber + " @merchantNumber",
                        (txn, errorCode) =>
                        {
                            MerchantRejects? merchantTxns;
                            if (!lookup.TryGetValue(txn.Id, out merchantTxns))
                            {
                                merchantTxns = txn;
                                lookup.Add(txn.Id, merchantTxns);
                                merchantTxns.FraudRejectReasonCodes = new List<string>();
                            }

                            merchantTxns.FraudRejectReasonCodes.Add(errorCode);
                            return merchantTxns;
                        },
                        splitOn: "FraudRejectReasonCodes",
                        param: new { @merchantNumber = merchantNumber });

                return transactions.Distinct();
            }
        }

        /// <summary>
        ///  Get MeerchantNumber from sequenceKey
        /// </summary>
        /// <param name="sequenceKey"></param>
        /// <returns></returns>
        public Task<Merchant> GetMerchantNumberFromSequenceKey(int sequenceKey)
        {
            return GetAsync<Merchant>(
               SpGetMerchantNumberFromSequenceKey,
               new
               {
                   @SequenceKey = sequenceKey,
               },
               isStoredProcedure: true,
               DBs.HCSDB);
        }

        /// <summary>
        ///  Check if transaction exist or not.
        /// </summary>
        /// <param name="sequenceKey"></param>
        /// <returns></returns>
        public Task<bool> CheckIfTransactionIsInFlight(FraudReleasedTransaction fraudReleasedTransaction)
        {
            // Check if Transaction exists in inflighttransactions Table.
            return this.ExecuteScalarAsync<bool>(
                "spCheckIfTransactionIsInFlight",
                new
                {
                    @TxnUUID = fraudReleasedTransaction.TxnUuid,
                    @TxnDetailId = fraudReleasedTransaction.TxnDetailId,
                }, true);
        }

        /// <summary>
        ///  Check if transaction exist or not.
        /// </summary>
        /// <param name="sequenceKey"></param>
        /// <returns></returns>
        public Task ResetInflightFlagForTransaction(FraudReleasedTransaction fraudReleasedTransaction)
        {
            // Updates the Isprocessing flag to 0 when Transaction is processed.
            return this.ExecuteScalarAsync<bool>(
                "spResetInflightFlagForTransaction",
                new
                {
                    @TxnUUID = fraudReleasedTransaction.TxnUuid,
                    @TxnDetailId = fraudReleasedTransaction.TxnDetailId,
                }, true);
        }

        public async Task<IEnumerable<NotificationMessageDto>> CheckNotificationStatusForMessageIds(List<ReleasedIndividualTransactionDto> unAckTransactionsList)
        {
            DataTable txns = new DataTable("MessageIdList");
            txns.Columns.Add("MessageID", typeof(Guid));
            foreach (ReleasedIndividualTransactionDto transaction in unAckTransactionsList)
            {
                txns.Rows.Add(transaction.JvilleMessageId);
            }

            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                return await this.GetListAsync<NotificationMessageDto>("spCheckNotificationStatus", new { @messageIds = txns }, true);
            }
        }

        public async Task<bool> UpdateNotificationStatusForMessageIds(List<ReleasedIndividualTransactionDto> unAckTransactionsList)
        {
            DataTable txns = new DataTable("MessageIdList");
            txns.Columns.Add("MessageID", typeof(Guid));
            foreach (var item in unAckTransactionsList)
            {
                txns.Rows.Add(item.JvilleMessageId);
            }

            using (var dbConnection = await this.ConnectionManager.PrepareConnection())
            {
                return await this.ExecuteScalarAsync<bool>("spUpdateNotificationStatus", new { @messageIds = txns }, true);
            }
        }

        /// <summary>
        /// Updates the message to passport transaction rejects.
        /// </summary>
        /// <param name="individualTransaction">The individual transaction.</param>
        /// <returns></returns>
        private Task<int> UpdateMessageToPassportTransactionRejects(Guid passportMessageId, Guid jvilleMessageId)
        {
            // Update the jvillMessageId in MessageToPassport column in TransactionRejectTable.
            return this.ExecuteScalarAsync<int>(
                "spUpdateMessageToPassportTransactionRejects",
                new
                {
                    @MessageToPassport = jvilleMessageId,
                    @MessageId = passportMessageId,
                }, true);
        }
    }
}