﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Infrastructure.Helpers
{
    public static class MethodNameHelper
    {
        public static string GetActualAsyncMethodName([CallerMemberName] string name = null) => name;
    }
}
