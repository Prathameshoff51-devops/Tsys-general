﻿using EasyNetQ;
using Hps.RabbitMq.Consumer.Common;
using Hps.RabbitMq.Consumer.EasyNetQ;

namespace RiskLab.Infrastructure
{
    public static class BusFactory
    {
        /// <summary>
        /// Create bus
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static IAdvancedBus CreateBus(string connectionString)
        {
            var credsFactory = new RabbitMqCredentialsFactory();
            var easyNetQConnectionConf = new EasyNetQCredentialsFactory(credsFactory)
           .DeserializeFromString(connectionString)
           .ToConnectionConfiguration();
            return RabbitHutch.CreateBus(easyNetQConnectionConf, x => x.EnableConsoleLogger()).Advanced;
        }
    }
}
