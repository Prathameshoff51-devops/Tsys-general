﻿using Hps.SettingsManagerClient;
using RiskLab.Core.Interfaces;

namespace RiskLab.Infrastructure
{
    /// <summary>
    /// Setting manager wrapper.
    /// </summary>
    public class SettingsManagerWrapper : ISettingsManagerWrapper
    {
        private readonly SettingsManager rabbitMQSettingsManager;
        private readonly SettingsManager applicationSettingsManager;

        public SettingsManagerWrapper(string applicationName, string environmentCode)
        {
            this.rabbitMQSettingsManager = new SettingsManager(applicationName, environmentCode);
            this.applicationSettingsManager = new SettingsManager(applicationName, environmentCode);
        }

        public SettingsManager RabbitMQSettingsManager => this.rabbitMQSettingsManager;

        public SettingsManager ApplicationSettingsManager => this.applicationSettingsManager;
    }
}
