﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Acquisition.Contracts.Risk.Passport;
using log4net;
using Newtonsoft.Json;
using RiskLab.Core.Constants;
using RiskLab.Core.Interfaces.Processors;
using RiskLab.Core.Interfaces.Repositories;

namespace RiskLab.Infrastructure.MessageProcessor
{
    public class FraudReleasedBatchConfirmationProcessor : Core.Interfaces.Processors.IFraudReleasedBatchConfirmation
    {
        private readonly IBatchRejectsRepository batchRejectsRepository;

        private readonly ILog log = LogManager.GetLogger(typeof(FraudReleasedBatchConfirmationProcessor));

        public FraudReleasedBatchConfirmationProcessor(IBatchRejectsRepository batchRejectsRepository)
        {
            this.batchRejectsRepository = batchRejectsRepository;
        }

        public async Task<MessageStatusIdentifier> Process(string payload)
        {
            try
            {
                var releasedBatchConfirmation = JsonConvert.DeserializeObject<FraudReleasedBatchConfirmation>(payload);
                await this.batchRejectsRepository.UpdateReleasedBatchAck(releasedBatchConfirmation);

                log.InfoFormat("FraudReleasedBatchConfirmationProcessor::Process() Successfully update the released batch confirmation message {0}", releasedBatchConfirmation.MessageId);
                return MessageStatusIdentifier.Successful;
            }
            catch (Exception ex)
            {
                log.ErrorFormat("FraudReleasedBatchConfirmationProcessor::Process() Exception while processing Acquisition.Contracts.Risk.Passport.FraudReleasedBatchConfirmationProcessor() {0} {1}", ex, payload);
                return MessageStatusIdentifier.Failed;
            }
        }
    }
}
