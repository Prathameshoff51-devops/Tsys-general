﻿using System.Data;
using System.Text;
using System.Threading.Tasks;
using Acquisition.Contracts.Risk.Jville;
using log4net;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Processors;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Interfaces;

namespace RiskLab.Infrastructure.MessageProcessor
{
    /// <summary>
    /// Process and save the incoming individual transaction.
    /// </summary>
    public class SuspectedFraudulentTransactionProcessor : ISuspectedFraudulentTransaction
    {
        private readonly IIndividualTransactionsRepository individualTransactionsRepository;
        private readonly IMessageQueueService messageQueueService;
        private readonly INotificationService notificationService;
        private readonly IRabbitMQSettings settings;

        /// <summary>
        /// The logger.
        /// </summary>
        private readonly ILog log = LogManager.GetLogger(typeof(SuspectedFraudulentTransactionProcessor));
        // private readonly ILogger<SuspectedFraudulentTransactionProcessor> logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="individualTransactionsRepository"></param>
        /// <param name="messageQueueService"></param>
        public SuspectedFraudulentTransactionProcessor(IIndividualTransactionsRepository individualTransactionsRepository, IMessageQueueService messageQueueService, INotificationService notificationService, IRabbitMQSettings settings)
        {
            this.individualTransactionsRepository = individualTransactionsRepository;
            this.messageQueueService = messageQueueService;
            this.notificationService = notificationService;
            this.settings = settings;
        }

        private string RiskLabUrl
        {
            get { return this.settings["RiskLabAPIUrl"].Trim(); }
        }

        /// <summary>
        /// Process method for individual transaction.
        /// </summary>
        /// <param name="payload">Payload received from the TransactionRequest queue.</param>
        /// <returns><see cref="ProcessingStatus"/>object.</returns>
        public async Task<MessageStatusIdentifier> Process(string payload)
        {
            Guid messageId = Guid.Empty;
            var serializerSettings = new JsonSerializerSettings
            {
                DateFormatHandling = DateFormatHandling.MicrosoftDateFormat,
                DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind,
                DateParseHandling = DateParseHandling.DateTimeOffset,
            };
            try
            {
                if (string.IsNullOrEmpty(payload))
                {
                    this.log.Error("SuspectedFraudulentTransactionProcessor::Exception while processing message - Empty payload");
                    return MessageStatusIdentifier.Failed;
                }

                var individualTransaction = JsonConvert.DeserializeObject<IndividualTransactionDto>(payload, serializerSettings);

                messageId = individualTransaction.MessageId;
                var fraudReleasedTransactionConfirmation = new SuspectedFraudulentTransactionConfirmation
                {
                    MessageId = messageId,
                };

                var jsonString = JsonConvert.SerializeObject(fraudReleasedTransactionConfirmation);
                byte[] fraudTransactionConfirmationPayload = Encoding.ASCII.GetBytes(jsonString);

                // Check if message is already consumed.
                if (await this.individualTransactionsRepository.CheckIfMessageConsumed(individualTransaction.MessageId))
                {
                    log.InfoFormat("SuspectedFraudulentTransactionProcessor::Process():Duplicate message detected from Passport for MessageId {0}", individualTransaction.MessageId);
                    var messagePublished = messageQueueService.PublishMessage(fraudReleasedTransactionConfirmation, fraudTransactionConfirmationPayload);
                    if (messagePublished)
                    {
                        log.InfoFormat("SuspectedFraudulentTransactionProcessor::Process() Duplicate message ack published successfully for MessageId {0}", messageId);
                        bool res = await SaveIndividualTransactionAck(individualTransaction, payload);
                        if (res)
                        {
                            log.InfoFormat($"SuspectedFraudulentTransactionProcessor::Process() Duplicate message update MessageFromPassport table successfully for MessageId {0} ", messageId);
                        }
                        else
                        {
                            log.ErrorFormat($"SuspectedFraudulentTransactionProcessor::Process() Duplicate message update MessageFromPassport table failed for MessageId {0} ", messageId);
                        }
                    }
                    else
                    {
                        log.ErrorFormat("SuspectedFraudulentTransactionProcessor::Process() Duplicate message unable to publish the ack for MessageId {0},{1}", messageId, jsonString);
                        return MessageStatusIdentifier.FailedToAckDuplicateMessage;
                    }

                    return MessageStatusIdentifier.DuplicateMessage;
                }

                // Save the individual transaction.
                DataTable transactionRejectReasons = CreateTransactionRejectReasons(individualTransaction);
                int result = await this.individualTransactionsRepository.InsertIndividualTransactionFromPassport(individualTransaction, transactionRejectReasons);

                if (result == 1)
                {
                    log.DebugFormat("SuspectedFraudulentTransactionProcessor::Process() Individual transaction inserted successfully for MessageId {0}", messageId);

                    await notificationService.NotifySignalrHub(RiskLabUrl, SignalRConstants.RejectedIndividualRefunds, 0);

                    bool messagePublished = messageQueueService.PublishMessage(fraudReleasedTransactionConfirmation, fraudTransactionConfirmationPayload);
                    if (messagePublished)
                    {
                        log.InfoFormat("SuspectedFraudulentTransactionProcessor::Process() Message ack sent successfully for MessageId {0}", messageId);
                        bool res = await SaveIndividualTransactionAck(individualTransaction, payload);
                        if (res)
                        {
                            log.InfoFormat("SuspectedFraudulentTransactionProcessor::Process() Inserted MessageFromPassport table successfully for MessageId {0}", messageId);
                        }
                        else
                        {
                            log.ErrorFormat("SuspectedFraudulentTransactionProcessor::Process() Inserted MessageFromPassport table failed for MessageId {0}", messageId);
                        }
                    }
                    else
                    {
                        log.ErrorFormat("SuspectedFraudulentTransactionProcessor::Process() Unable to publish the ack for the message {0},{1}", messageId, jsonString);
                        return MessageStatusIdentifier.FailedToAck;
                    }
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("SuspectedFraudulentTransactionProcessor::Process() Exception while processing message {0},{1} {2}", messageId, ex.TargetSite, ex);
                return MessageStatusIdentifier.Failed;
            }

            return MessageStatusIdentifier.Successful;
        }

        /// <summary>
        /// Save acknowledgment message sent for the individual transaction.
        /// </summary>
        /// <param name="payload">Payload received from passport.</param>
        public async Task<bool> SaveIndividualTransactionAck(IndividualTransactionDto individualTransaction, string payload)
        {
            try
            {
                var result = await this.individualTransactionsRepository.InsertIndividualTransactionAck(payload, individualTransaction);
                if (result.Item1)
                {
                    log.InfoFormat("SuspectedFraudulentTransactionProcessor::Inserted to MessageFromPassport successfully for message {0}", individualTransaction.MessageId);
                }
                else
                {
                    log.ErrorFormat("SuspectedFraudulentTransactionProcessor::DB operation failed while saving individual transaction acknowledgment for message {0} , {1} ,{2}", individualTransaction.MessageId, result.Item2, result.Item3);
                    return false;
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("SuspectedFraudulentTransactionProcessor::Exception while saving individual transaction acknowledgment for message {0} , {1} ,{2}", individualTransaction.MessageId, ex.TargetSite, ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Create Transaction Reject reasons to be store in the database.
        /// </summary>
        /// <param name="individualTransaction"><see cref="IndividualTransactionDto"/>object.</param>
        /// <returns>Returns a <see cref="DataTable"/>with the inserted resons.</returns>
        private static DataTable CreateTransactionRejectReasons(IndividualTransactionDto individualTransaction)
        {
            DataTable transactionRejectReasons = new DataTable("TransactionRejectReasons");
            transactionRejectReasons.Columns.Add("ErrorCodeId", typeof(int));

            foreach (var txn in individualTransaction.FraudRejectReasonCodeIds)
            {
                var row = transactionRejectReasons.NewRow();
                row["ErrorCodeId"] = txn;
                transactionRejectReasons.Rows.Add(row);
            }

            return transactionRejectReasons;
        }
    }
}