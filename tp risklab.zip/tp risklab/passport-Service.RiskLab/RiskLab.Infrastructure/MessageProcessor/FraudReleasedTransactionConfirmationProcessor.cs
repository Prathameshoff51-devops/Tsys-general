﻿using Acquisition.Contracts.Risk.Passport;
using log4net;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RiskLab.Core.Constants;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;

namespace RiskLab.Infrastructure.MessageProcessor
{
    public class FraudReleasedTransactionConfirmationProcessor : Core.Interfaces.Processors.IFraudReleasedTransactionConfirmation
    {
        private readonly IIndividualTransactionsRepository individualTransactionsRepository;

        /// <summary>
        /// The logger.
        /// </summary>
        private readonly ILog log = LogManager.GetLogger(typeof(FraudReleasedTransactionConfirmationProcessor));
//        private readonly ILogger<FraudReleasedTransactionConfirmationProcessor> logger;

        public FraudReleasedTransactionConfirmationProcessor(IIndividualTransactionsRepository individualTransactionsRepository) //, ILogger<FraudReleasedTransactionConfirmationProcessor> logger)
        {
            this.individualTransactionsRepository = individualTransactionsRepository;
          //  this.logger = logger;
        }

        /// <summary>
        /// Process method for individual transaction.
        /// </summary>
        /// <param name="payload">Payload received from the TransactionRequest queue.</param>
        /// <returns><see cref="ProcessingStatus"/>object.</returns>
        public async Task<MessageStatusIdentifier> Process(string payload)
        {
            try
            {
                var releasedTransactionConfirmation = JsonConvert.DeserializeObject<FraudReleasedTransactionConfirmation>(payload);
                await this.individualTransactionsRepository.UpdateReleasedTransactionAck(releasedTransactionConfirmation);

                log.InfoFormat("FraudReleasedTransactionConfirmationProcessor::Process() Successfully update the released transaction confirmation message {0}", releasedTransactionConfirmation.MessageId);
                return MessageStatusIdentifier.Successful;
            }
            catch (Exception ex)
            {
                log.ErrorFormat("FraudReleasedTransactionConfirmationProcessor::Process() Exception while processing Acquisition.Contracts.Risk.Passport.FraudReleasedTransactionConfirmation() {0} {1}", ex, payload);
                return MessageStatusIdentifier.Failed;
            }
        }
    }
}
