﻿using System.Data;
using System.Linq.Expressions;
using System.Text;
using Acquisition.Contracts.Risk.Jville;
using Acquisition.Contracts.Risk.Passport;
using log4net;
using Newtonsoft.Json;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Processors;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Interfaces;

namespace RiskLab.Infrastructure.MessageProcessor
{
    public class SuspectedFraudulentBatchProcessor : Core.Interfaces.Processors.ISuspectedFraudulentBatch
    {
        private readonly IBatchTransactionsRepository batchTransactionsRepository;
        private readonly IMessageQueueService messageQueueService;
        private readonly INotificationService notificationService;
        private readonly IRabbitMQSettings settings;

        /// <summary>
        /// The logger.
        /// </summary>
        private readonly ILog log = LogManager.GetLogger(typeof(SuspectedFraudulentBatchProcessor));

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="batchTransactionsRepository"></param>
        /// <param name="messageQueueService"></param>
        /// <param name="notificationService"></param>
        /// <param name="settings"></param>
        public SuspectedFraudulentBatchProcessor(IBatchTransactionsRepository batchTransactionsRepository, IMessageQueueService messageQueueService, INotificationService notificationService, IRabbitMQSettings settings)
        {
            this.batchTransactionsRepository = batchTransactionsRepository;
            this.messageQueueService = messageQueueService;
            this.notificationService = notificationService;
            this.settings = settings;
        }

        private string RiskLabUrl
        {
            get { return this.settings["RiskLabAPIUrl"].Trim(); }
        }

        private bool IsErrorPayloadCapture
        {
            get
            {
               return System.Convert.ToBoolean(settings["IsErrorPayloadCapture"]);
            }
        }

        /// <summary>
        /// Process method for batch.
        /// </summary>
        /// <param name="payload">Payload received from the SuspectedFraudulentBatch queue.</param>
        /// <returns><see cref="ProcessingStatus"/>object.</returns>
        public async Task<MessageStatusIdentifier> Process(string payload)
        {
            Guid messageId = Guid.Empty;
            var serializerSettings = new JsonSerializerSettings
            {
                DateFormatHandling = DateFormatHandling.MicrosoftDateFormat,
                DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind,
                DateParseHandling = DateParseHandling.DateTimeOffset,
            };
            try
            {
                var batchDetails = JsonConvert.DeserializeObject<BatchDto>(payload, serializerSettings);
                if (batchDetails != null)
                {
                    messageId = batchDetails.MessageId;
                    var suspectedFraudulentBatchConfirmation = new SuspectedFraudulentBatchConfirmation
                    {
                        MessageId = messageId,
                    };

                    var jsonString = JsonConvert.SerializeObject(suspectedFraudulentBatchConfirmation);
                    byte[] suspectedFraudulentBatchConfirmationPayload = Encoding.ASCII.GetBytes(jsonString);
                    // Check if message is already consumed.
                    if (await this.batchTransactionsRepository.CheckIfMessageConsumed(batchDetails.MessageId))
                    {
                        log.InfoFormat("SuspectedFraudulentBatchProcessor::Process():Duplicate message detected from Passport for MessageId {0}", batchDetails.MessageId);
                        var messagePublished = messageQueueService.PublishMessage(suspectedFraudulentBatchConfirmation, suspectedFraudulentBatchConfirmationPayload);
                        if (messagePublished)
                        {
                            log.InfoFormat("SuspectedFraudulentBatchProcessor::Process() Duplicate message ack published successfully for MessageId {0}, Payload {1}", messageId, payload);
                            bool res = await SaveBatchAck(batchDetails, payload);
                            if (res)
                            {
                                log.InfoFormat($"SuspectedFraudulentBatchProcessor::Process() Duplicate message update MessageFromPassport table successfully for MessageId {0} ", messageId);
                            }
                            else
                            {
                                log.ErrorFormat($"SuspectedFraudulentBatchProcessor::Process() Duplicate message update MessageFromPassport table failed for MessageId {0} ", messageId);
                            }
                        }
                        else
                        {
                            log.ErrorFormat("SuspectedFraudulentTransactionProcessor::Process() Duplicate message unable to publish the ack for MessageId {0},{1}", messageId, jsonString);
                            return MessageStatusIdentifier.FailedToAckDuplicateMessage;
                        }

                        return MessageStatusIdentifier.DuplicateMessage;
                    }

                    // Save the Batch.
                    DataTable batchRejectReasons = CreateBatchRejectReasons(batchDetails);
                    DataTable transactionList = CreateBatchTransactionList(batchDetails);
                    int result = await this.batchTransactionsRepository.InsertBatchFromPassport(batchDetails, batchRejectReasons, transactionList);

                    if (result == 1)
                    {
                        log.DebugFormat("SuspectedFraudulentBatchProcessor::Process() Batch inserted successfully for MessageId {0}", messageId);

                        await notificationService.NotifySignalrHub(RiskLabUrl, SignalRConstants.RejectedNewBatchRefunds, 0);

                        var messagePublished = messageQueueService.PublishMessage(suspectedFraudulentBatchConfirmation, suspectedFraudulentBatchConfirmationPayload);

                        if (messagePublished)
                        {
                            log.InfoFormat("SuspectedFraudulentBatchProcessor::Process() Message ack sent successfully for MessageId {0}", messageId);
                            bool res = await SaveBatchAck(batchDetails, payload);
                            if (res)
                            {
                                log.InfoFormat("SuspectedFraudulentBatchProcessor::Process() Inserted MessageFromPassport table successfully for MessageId {0}", messageId);
                            }
                            else
                            {
                                log.ErrorFormat("SuspectedFraudulentBatchProcessor::Process() Inserted MessageFromPassport table failed for MessageId {0}", messageId);
                            }
                        }
                        else
                        {
                            log.ErrorFormat("SuspectedFraudulentBatchProcessor::Process() Unable to publish the ack for the message {0},{1}", messageId, jsonString);
                            return MessageStatusIdentifier.FailedToAck;
                        }
                    }
                }
                else
                {
                    log.ErrorFormat("SuspectedFraudulentBatchProcessor::Process() Exception while processing message - Null Values");
                    return MessageStatusIdentifier.Failed;
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("SuspectedFraudulentBatchProcessor::Process() Exception while processing message {0},{1} {2}", messageId, ex.TargetSite, ex);
                await SaveErrorPayload(messageId, payload, ex.Message);
                return MessageStatusIdentifier.Failed;
            }

            return MessageStatusIdentifier.Successful;
        }

        /// <summary>
        /// Save payload into table table
        /// </summary>
        /// <param name="payload">Payload received from passport.</param>
        public async Task<bool> SaveErrorPayload(Guid messageId, string payload, string error)
        {
            try
            {
                if (IsErrorPayloadCapture)
                {
                    var result = await this.batchTransactionsRepository.InsertErrorPayload(payload, error, messageId);

                    if (result.Item1)
                    {
                        log.InfoFormat("SuspectedFraudulentBatchProcessor::Inserted to ErrorPayload successfully for messageID {0}", messageId);
                    }
                    else
                    {
                        log.ErrorFormat("SuspectedFraudulentBatchProcessor::DB operation failed while saving payload in table {0} , {1} ,{2}", messageId, result.Item2, result.Item3);
                        return false;
                    }
                }
            }
            catch (Exception iex)
            {
                log.ErrorFormat("SuspectedFraudulentBatchProcessor::SaveErrorPayload() failing to save payload in table{0},{1} {2}", messageId, iex.TargetSite, iex);
            }

            return true;
        }

        /// <summary>
        /// Save acknowledgment message sent for the batch.
        /// </summary>
        /// <param name="payload">Payload received from passport.</param>
        public async Task<bool> SaveBatchAck(BatchDto batchDetails, string payload)
        {
            try
            {
                var result = await this.batchTransactionsRepository.InsertBatchAck(payload, batchDetails);
                if (result.Item1)
                {
                    log.InfoFormat("SuspectedFraudulentBatchProcessor::Inserted to MessageFromPassport successfully for message {0}", batchDetails.MessageId);
                }
                else
                {
                    log.ErrorFormat("SuspectedFraudulentBatchProcessor::DB operation failed while saving Batch acknowledgment for message {0} , {1} ,{2}", batchDetails.MessageId, result.Item2, result.Item3);
                    return false;
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("SuspectedFraudulentBatchProcessor::Exception while saving Batch acknowledgment for message {0} , {1} ,{2}", batchDetails.MessageId, ex.TargetSite, ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Create Batch Reject reasons to be store in the database.
        /// </summary>
        /// <param name="individualTransaction"></param>
        /// <returns></returns>
        private static DataTable CreateBatchRejectReasons(BatchDto batchDetails)
        {
            DataTable batchRejectReasons = new DataTable("BatchRejectReasons");
            batchRejectReasons.Columns.Add("ErrorCodeId", typeof(int));

            foreach (var txn in batchDetails.FraudRejectReasonCodeIds)
            {
                var row = batchRejectReasons.NewRow();
                row["ErrorCodeId"] = txn;
                batchRejectReasons.Rows.Add(row);
            }

            return batchRejectReasons;
        }

        /// <summary>
        ///  Create Batch Transcation List to be store in the the database.
        /// </summary>
        /// <param name="batchDetails"></param>
        /// <returns></returns>
        private static DataTable CreateBatchTransactionList(BatchDto batchDetails)
        {
            DataTable batchTransactionList = new DataTable("BatchTransactionList2");
            batchTransactionList.Columns.Add("TxnDetailId", typeof(int));
            batchTransactionList.Columns.Add("Amount", typeof(decimal));
            batchTransactionList.Columns.Add("CardNumberMask", typeof(string)).MaxLength = 20;
            batchTransactionList.Columns.Add("TxnDateUtc", typeof(DateTime));
            batchTransactionList.Columns.Add("AuthCode", typeof(string)).MaxLength = 10;
            batchTransactionList.Columns.Add("ExpDate", typeof(DateTimeOffset));
            batchTransactionList.Columns.Add("ServiceOptionTxnTypeID", typeof(int));
            batchTransactionList.Columns.Add("TxnTypeDescription", typeof(string)).MaxLength = 50;
            batchTransactionList.Columns.Add("FraudRejectReasonCodes", typeof(string)).MaxLength = 50;

            foreach (var txn in batchDetails.TransactionList)
            {
                var row = batchTransactionList.NewRow();
                row["TxnDetailId"] = txn.TxnDetailId;
                row["Amount"] = txn.Amount;
                row["CardNumberMask"] = txn.CardNumberMask;
                row["TxnDateUtc"] = txn.TxnDateUtc;
                row["AuthCode"] = txn.AuthCode;
                if (txn.ExpDate != null)
                {
                    row["ExpDate"] = txn.ExpDate;
                }

                row["ServiceOptionTxnTypeID"] = txn.ServiceOptionTxnTypeID;
                row["TxnTypeDescription"] = txn.TxnTypeDescription;
                string fraudRejectReasonCodes = string.Empty;
                foreach (var fraudRejectReasonCodesId in txn.FraudRejectReasonCodeIds)
                {
                    fraudRejectReasonCodes += fraudRejectReasonCodesId;
                    if (fraudRejectReasonCodesId != txn.FraudRejectReasonCodeIds.Last())
                    {
                        fraudRejectReasonCodes += ",";
                    }
                }

                row["FraudRejectReasonCodes"] = fraudRejectReasonCodes;
                batchTransactionList.Rows.Add(row);
            }

            return batchTransactionList;
        }
    }
}
