﻿using EasyNetQ;
using EasyNetQ.Topology;

namespace RiskLab.Infrastructure
{
    public abstract class QueueBasePublish<T>
        where T : class
    {
        private bool _started;
        private Exchange _exchange;
        private IDisposable _subscriptionHandle;
        private Exchange _deadLetterExchange;

        public string RoutingKey { get; set; }

        public string QueueName { get; set; }

        public string DeadLetterExchangeName { get; set; }

        public string ExchangeName { get; set; }

        protected IAdvancedBus Bus { get; set; }

        protected Exchange DeadLetterExchange => Bus.ExchangeDeclare($"{DeadLetterExchangeName}", ExchangeType.Topic);

        protected Exchange Exchange => Bus.ExchangeDeclare(ExchangeName, ExchangeType.Topic);

        public async Task StartAsync()
        {
            if (_started) return;

            await SetupExchangeAndQueuesAsync();
            _started = true;
        }

        public virtual void Stop()
        {
            if (!_started) return;

            if (_subscriptionHandle != null)
            {
                _subscriptionHandle.Dispose();
                _subscriptionHandle = null;
            }

            if (Bus != null)
            {
                Bus.Dispose();
                Bus = null;
            }

            _started = false;
        }

        private async Task<Queue> SetupExchangeAndQueuesAsync()
        {
            // create & bind the main message queue
            var queue = await Bus.QueueDeclareAsync(QueueName, config =>
            {
                if (config is null)
                {
                    throw new ArgumentNullException(nameof(config));
                }

                config.WithDeadLetterExchange(DeadLetterExchange);
            });
            await Bus.BindAsync(Exchange, queue, RoutingKey, null);
            return queue;
        }
    }
}
