﻿namespace RiskLab.Infrastructure.Interfaces
{
    using System.Data;
    using RiskLab.Core.Constants;

    public interface ISqlDbConnectionManager
    {
        string RiskLabConnectionString { get; }

        string HCSDBConnectionString { get; }

        Task<IDbConnection> PrepareConnection(DBs dbContnext = DBs.RiskLab);
    }
}
