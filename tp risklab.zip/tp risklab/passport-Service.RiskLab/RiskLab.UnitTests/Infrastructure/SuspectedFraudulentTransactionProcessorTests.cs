﻿using Acquisition.Contracts.Risk.Jville;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Interfaces;
using RiskLab.Infrastructure.MessageProcessor;
using System;
using System.Data;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure
{
    internal class SuspectedFraudulentTransactionProcessorTests
    {
        public const string Payload = "{\r\n    \"MessageId\": \"8a1538dc-acc1-43c0-9772-5f4ff48cb35b\",\r\n    \"TxnUuid\": 2022092600009335,\r\n    \"TxnDetailId\": 2,\r\n    \"MerchantNumber\": \"650000004051664\",\r\n    \"MerchantName\": \"COLLINS FAMILY DENTISTRY\",\r\n    \"LegalName\": \"KENNETH M COLLINS D D S P S\",\r\n    \"Mcc\": \"8021\",\r\n    \"Amount\": 206.10,\r\n    \"CardNumberMask\": \"410039******3213\",\r\n    \"TxnDateUtc\": \"2022-10-22T16:26:16.0000000-05:00\",\r\n    \"FraudRejectReasonCodeIds\": [\r\n        1,\r\n        2\r\n    ],\r\n    \"OriginalBatchNumber\": \"000693\",\r\n    \"ServiceOptionTxnTypeId\": 20,\r\n    \"TxnTypeDescription\": \"Return\",\r\n    \"BatchCloseDate\": \"2022-10-22T16:26:16.0000000-05:00\",\r\n    \"SubmitterId\": 1,\r\n    \"SubmitterIdDescription\": \"Exchange\",\r\n    \"BusinessDateUtc\" : \"2022-10-22T16:26:16.0000000-05:00\"\r\n}";

        private readonly IIndividualTransactionsRepository individualTransactionsRepository;
        private readonly IMessageQueueService messageQueueService;
        private readonly INotificationService notificationService;
        private readonly IRabbitMQSettings settings;

        public SuspectedFraudulentTransactionProcessorTests()
        {
            individualTransactionsRepository = new Mock<IIndividualTransactionsRepository>().Object;
            messageQueueService = new Mock<IMessageQueueService>().Object;
            notificationService = new Mock<INotificationService>().Object;
            settings = new Mock<IRabbitMQSettings>().Object;
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessor_FailedToAckDuplicateMessage()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.FailedToAckDuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_DuplicateMessage()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            var tupletoReturn = Tuple.Create<bool, string, string>(true, string.Empty, string.Empty);
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionAck(It.IsAny<string>(), It.IsAny<IndividualTransactionDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.DuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_SaveBatchAck_false_DuplicateMessage()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionAck(It.IsAny<string>(), It.IsAny<IndividualTransactionDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.DuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_SaveBatchAck_Exception_DuplicateMessage()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.DuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_SaveBatchAck_false_Successful()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionFromPassport(It.IsAny<IndividualTransactionDto>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            mockSettings.Setup(x => x["RiskLabAPIUrl"]).Returns("apiUrl");
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionAck(It.IsAny<string>(), It.IsAny<IndividualTransactionDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Successful);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_Successful()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionFromPassport(It.IsAny<IndividualTransactionDto>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            mockSettings.Setup(x => x["RiskLabAPIUrl"]).Returns("apiUrl");
            var tupletoReturn = Tuple.Create<bool, string, string>(true, string.Empty, string.Empty);
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionAck(It.IsAny<string>(), It.IsAny<IndividualTransactionDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Successful);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_FailedToAck()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionFromPassport(It.IsAny<IndividualTransactionDto>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(false);
            mockSettings.Setup(x => x["RiskLabAPIUrl"]).Returns("apiUrl");
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionAck(It.IsAny<string>(), It.IsAny<IndividualTransactionDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.FailedToAck);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_Failed()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(string.Empty);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Failed);
        }

        [Test]
        public async Task SuspectedFraudulentTransactionProcessorTests_Exception_FailedToAck()
        {
            // Arrange
            var mockIndividualTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockIndividualTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockIndividualTransactionsRepository.Setup(x => x.InsertIndividualTransactionFromPassport(It.IsAny<IndividualTransactionDto>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentTransactionConfirmation>(), It.IsAny<byte[]>())).Returns(false);
            mockSettings.Setup(x => x["IsErrorPayloadCapture"]).Returns("true");
            SuspectedFraudulentTransactionProcessor processer = new SuspectedFraudulentTransactionProcessor(mockIndividualTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Failed);
        }
    }
}
