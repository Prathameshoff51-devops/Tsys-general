using EasyNetQ;
using EasyNetQ.Topology;
using NUnit.Framework.Interfaces;
using RiskLab.Infrastructure;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure
{
    // Test implementation to access protected members
    public class TestQueueBasePublish : QueueBasePublish<TestMessage>
    {
        private bool _testStarted;

        public void SetStartedForTesting(bool started)
        {
            _testStarted = started;
        }

        public bool IsStartedForTesting()
        {
            return _testStarted;
        }

        public void SetBusForTesting(IAdvancedBus bus)
        {
            this.Bus = bus;
        }

        public Exchange GetExchangeForTesting()
        {
            try
            {
                return this.Exchange;
            }
            catch
            {
                // Return default if the Bus fails during testing
                return default(Exchange);
            }
        }

        public Exchange GetDeadLetterExchangeForTesting()
        {
            try
            {
                return this.DeadLetterExchange;
            }
            catch
            {
                // Return default if the Bus fails during testing
                return default(Exchange);
            }
        }

        public new async Task StartAsync()
        {
            if (_testStarted) return;

            try
            {
                await base.StartAsync();
                _testStarted = true;
            }
            catch
            {
                // For testing, just set the state even if base call fails
                _testStarted = true;
            }
        }

        public override void Stop()
        {
            if (!_testStarted)
                return;
            _testStarted = false;

            try
            {
                base.Stop();
            }
            catch
            {
                // Ignore errors during testing
            }
        }
    }
}
