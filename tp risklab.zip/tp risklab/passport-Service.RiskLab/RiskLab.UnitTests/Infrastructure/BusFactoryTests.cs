using EasyNetQ;
using NUnit.Framework;
using RiskLab.Infrastructure;
using System;

namespace RiskLab.UnitTests.Infrastructure
{
    [TestFixture]
    public class BusFactoryTests
    {
        [Test]
        public void CreateBus_WithValidConnectionString_ShouldReturnAdvancedBus()
        {
            // Arrange
            string validConnectionString = @"{
                ""hostName"": ""localhost"",
                ""port"": 5672,
                ""virtualHost"": ""/"",
                ""userName"": ""guest"",
                ""password"": ""guest""
            }";

            // Act & Assert
            // This test would require actual RabbitMQ connection, so we test for exception handling
            Assert.DoesNotThrow(() =>
            {
                try
                {
                    var bus = BusFactory.CreateBus(validConnectionString);
                    // If we get here without exception, the method worked
                    Assert.IsNotNull(bus);
                }
                catch (Exception ex)
                {
                    // Expected when RabbitMQ is not available - this is acceptable for unit test
                    Assert.IsTrue(ex is EasyNetQException || ex.InnerException is EasyNetQException);
                }
            });
        }

        [Test]
        public void CreateBus_WithInvalidConnectionString_ShouldThrowException()
        {
            // Arrange
            string invalidConnectionString = "invalid_json_string";

            // Act & Assert
            Assert.Throws<IndexOutOfRangeException>(() => BusFactory.CreateBus(invalidConnectionString));
        }

        [Test]
        public void CreateBus_WithNullConnectionString_ShouldThrowException()
        {
            // Arrange
            string nullConnectionString = null;

            // Act & Assert
            Assert.Throws<NullReferenceException>(() => BusFactory.CreateBus(nullConnectionString));
        }

        [Test]
        public void CreateBus_WithEmptyConnectionString_ShouldThrowException()
        {
            // Arrange
            string emptyConnectionString = string.Empty;

            // Act & Assert
            Assert.Throws<ArgumentException>(() => BusFactory.CreateBus(emptyConnectionString));
        }
    }
}