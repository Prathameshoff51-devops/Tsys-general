using Moq;
using NUnit.Framework;
using RiskLab.Core.Dtos;
using RiskLab.Infrastructure.Dapper.Repository;
using RiskLab.Infrastructure.Interfaces;
using System;
using System.Data;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure.Dapper.Repository
{
    [TestFixture]
    public class BatchTransactionsRepositoryTests
    {
        private Mock<ISqlDbConnectionManager>? _mockConnectionManager;
        private TestableBatchTransactionsRepository? _repo;

        [SetUp]
        public void SetUp()
        {
            _mockConnectionManager = new Mock<ISqlDbConnectionManager>();
            _repo = new TestableBatchTransactionsRepository(_mockConnectionManager.Object);
        }

        [Test]
        public async Task CheckIfMessageConsumed_CallsExecuteScalarAsync_ReturnsExpected()
        {
            var messageId = Guid.NewGuid();
            _repo!.ExecuteScalarAsyncResult = true;

            var result = await _repo.CheckIfMessageConsumed(messageId);

            Assert.IsTrue(result);
            Assert.AreEqual(messageId, _repo.LastMessageId);
        }

        [Test]
        public async Task InsertErrorPayload_CallsExecuteAsyncAndReturnsExpected()
        {
            var payload = "payload";
            var error = "error";
            var messageId = Guid.NewGuid();

            _repo!.ExecuteAsyncCalled = false;
            _repo.ErrorPayloadReturn = Tuple.Create(true, "E1", "ErrorMsg");

            var result = await _repo.InsertErrorPayload(payload, error, messageId);

            Assert.IsTrue(_repo.ExecuteAsyncCalled);
            Assert.AreEqual(true, result.Item1);
            Assert.AreEqual("E1", result.Item2);
            Assert.AreEqual("ErrorMsg", result.Item3);
        }

        [Test]
        public async Task InsertBatchAck_CallsExecuteAsyncAndReturnsExpected()
        {
            var payload = "payload";
            var batch = new BatchDto { MessageId = Guid.NewGuid() };

            _repo!.ExecuteAsyncCalled = false;
            _repo.BatchAckReturn = Tuple.Create(true, "E2", "BatchAckMsg");

            var result = await _repo.InsertBatchAck(payload, batch);

            Assert.IsTrue(_repo.ExecuteAsyncCalled);
            Assert.AreEqual(true, result.Item1);
            Assert.AreEqual("E2", result.Item2);
            Assert.AreEqual("BatchAckMsg", result.Item3);
        }

        [Test]
        public async Task InsertBatchFromPassport_CallsExecuteScalarAsync_ReturnsExpected()
        {
            var batch = new BatchDto { MessageId = Guid.NewGuid() };
            var reasons = new DataTable();
            var txns = new DataTable();

            _repo!.ExecuteScalarAsyncIntResult = 42;

            var result = await _repo.InsertBatchFromPassport(batch, reasons, txns);

            Assert.AreEqual(42, result);
            Assert.AreEqual(batch.MessageId, _repo.LastBatchId);
        }

        // Helper class to simulate repository behavior for testing
        // Helper class to simulate repository behavior for testing
        public class TestableBatchTransactionsRepository : BatchTransactionsRepository
        {
            public TestableBatchTransactionsRepository(ISqlDbConnectionManager connectionManager)
                : base(connectionManager)
            {
            }

            public bool ExecuteScalarAsyncResult { get; set; }

            public int ExecuteScalarAsyncIntResult { get; set; }

            public bool ExecuteAsyncCalled { get; set; }

            public Tuple<bool, string, string> ErrorPayloadReturn { get; set; } = Tuple.Create(false, string.Empty, string.Empty);

            public Tuple<bool, string, string> BatchAckReturn { get; set; } = Tuple.Create(false, string.Empty, string.Empty);

            public Guid LastMessageId { get; set; }

            public Guid LastBatchId { get; set; }

            public new Task<bool> CheckIfMessageConsumed(Guid messageId)
            {
                LastMessageId = messageId;
                return Task.FromResult(ExecuteScalarAsyncResult);
            }

            public new Task<Tuple<bool, string, string>> InsertErrorPayload(string payload, string error, Guid messageId)
            {
                ExecuteAsyncCalled = true;
                return Task.FromResult(ErrorPayloadReturn);
            }

            public new Task<Tuple<bool, string, string>> InsertBatchAck(string payload, BatchDto batchDeatils)
            {
                ExecuteAsyncCalled = true;
                return Task.FromResult(BatchAckReturn);
            }

            public new Task<int> InsertBatchFromPassport(BatchDto batchDeatils, DataTable batchRejectReasons, DataTable transactionList)
            {
                LastBatchId = batchDeatils.MessageId;
                return Task.FromResult(ExecuteScalarAsyncIntResult);
            }
        }
    }
}
