﻿using Acquisition.Contracts.Risk.Passport;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure.MessageProcessor;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure
{
    internal class FraudReleasedBatchConfirmationProcessorTests
    {
        private readonly IBatchRejectsRepository batchRejectsRepository;

        public FraudReleasedBatchConfirmationProcessorTests()
        {
            batchRejectsRepository = new Mock<IBatchRejectsRepository>().Object;
        }

        [Test]
        public async Task FraudReleasedBatchConfirmationProcessor_Successful()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            mockBatchRejectsRepository.Setup(x => x.UpdateReleasedBatchAck(It.IsAny<FraudReleasedBatchConfirmation>()));
            FraudReleasedBatchConfirmationProcessor processer = new FraudReleasedBatchConfirmationProcessor(mockBatchRejectsRepository.Object);

            // Act
            var result = await processer.Process("{\"MessageId\":\"ccd105ea-7b70-4144-82b7-1ca26b3025e1\",\"TxnUuid\":2023012300003001,\"TxnDetailId\":23}");
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
        }

        [Test]
        public async Task FraudReleasedBatchConfirmationProcessor_Failed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            mockBatchRejectsRepository.Setup(x => x.UpdateReleasedBatchAck(It.IsAny<FraudReleasedBatchConfirmation>()));
            FraudReleasedBatchConfirmationProcessor processer = new FraudReleasedBatchConfirmationProcessor(mockBatchRejectsRepository.Object);

            // Act
            var result = await processer.Process(string.Empty);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
        }
    }
}
