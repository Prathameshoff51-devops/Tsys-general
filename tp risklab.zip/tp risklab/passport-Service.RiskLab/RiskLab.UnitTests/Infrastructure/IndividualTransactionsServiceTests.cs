using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Services;
using RiskLab.Core.Settings;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Core.Services
{
    [TestFixture]
    public class IndividualTransactionsServiceTests
    {
        private Mock<IIndividualTransactionsRepository>? _mockRepo;
        private Mock<ILogger<IndividualTransactionsService>>? _mockLogger;
        private Mock<IUserRepository>? _mockUserRepo;
        private Mock<INotificationService>? _mockNotificationService;
        private IOptions<ApplicationSettings>? _options;
        private ApplicationSettings? _settings;
        private IndividualTransactionsService? _service;

        [SetUp]
        public void SetUp()
        {
            _mockRepo = new Mock<IIndividualTransactionsRepository>();
            _mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            _mockUserRepo = new Mock<IUserRepository>();
            _mockNotificationService = new Mock<INotificationService>();
            _settings = new ApplicationSettings
            {
                RiskLabApiUrl = "http://localhost",
            };
            _options = Options.Create(_settings);

            _service = new IndividualTransactionsService(
                _mockRepo.Object,
                _mockLogger.Object,
                _mockUserRepo.Object,
                _options,
                _mockNotificationService.Object);
        }

        [Test]
        public async Task GetDeletedIndividualTransactions_ReturnsExpected()
        {
            var expected = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto() };
            _mockRepo!.Setup(r => r.GetTransactions(RejectStatuses.Deleted.ToString()))
                .ReturnsAsync(expected);

            var result = await _service!.GetDeletedIndividualTransactions();

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task GetIndividualTransactionsByStatus_ReturnsExpected()
        {
            var expected = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto() };
            _mockRepo!.Setup(r => r.GetTransactions("status")).ReturnsAsync(expected);

            var result = await _service!.GetIndividualTransactionsByStatus("status");

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task GetIndividualTransaction_ReturnsExpected()
        {
            var expected = new IndividualTransactionViewDto();
            _mockRepo!.Setup(r => r.GetTransaction(1)).ReturnsAsync(expected);

            var result = await _service!.GetIndividualTransaction(1);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task GetNewIndividualTransactions_ReturnsExpected()
        {
            var expected = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto() };
            _mockRepo!.Setup(r => r.GetTransactions(RejectStatuses.New.ToString()))
                .ReturnsAsync(expected);

            var result = await _service!.GetNewIndividualTransactions();

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task GetQueuedIndividualTransactions_ReturnsExpected()
        {
            var expected = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto() };
            _mockRepo!.Setup(r => r.GetTransactions(RejectStatuses.Queued.ToString()))
                .ReturnsAsync(expected);

            var result = await _service!.GetQueuedIndividualTransactions();

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task GetReleasedIndividualTransactions_ReturnsExpected()
        {
            var expected = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto() };
            _mockRepo!.Setup(r => r.GetTransactions(RejectStatuses.Released.ToString()))
                .ReturnsAsync(expected);

            var result = await _service!.GetReleasedIndividualTransactions();

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task BroadCastMessage_CallsNotificationService()
        {
            var result = new List<IndividualTransactionStatusUpdateResultDto>
            {
                new IndividualTransactionStatusUpdateResultDto { UpdateStatus = UpdateStatuses.Success },
            };
            var statusMap = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>(RejectStatuses.New.ToString(), RejectStatuses.Queued.ToString()),
            };

            _mockNotificationService!.Setup(n => n.NotifySignalrHub(It.IsAny<string>(), It.IsAny<string>(), 0))
                .ReturnsAsync(true);

            await _service!.BroadCastMessage(result, statusMap);

            _mockNotificationService.Verify(n => n.NotifySignalrHub(_settings!.RiskLabApiUrl.Trim(), SignalRConstants.RejectedIndividualRefunds, 0), Times.Once);
        }

        [Test]
        public void CanUpdateStatus_AllPaths()
        {
            // toStatus <= fromStatus
            Assert.IsFalse(_service!.CanUpdateStatus("Queued", "New"));

            // Deleted <-> Released
            Assert.IsFalse(_service.CanUpdateStatus("Released", "Deleted"));
            Assert.IsFalse(_service.CanUpdateStatus("Deleted", "Released"));

            // Purged
            Assert.IsFalse(_service.CanUpdateStatus("Queued", "Purged"));

            // Valid
            Assert.IsTrue(_service.CanUpdateStatus("New", "Queued"));
        }

        [Test]
        public async Task SaveIndividualTransactionFromPassport_CallsRepo()
        {
            var dto = new IndividualTransactionDto();
            var dt = new DataTable();
            _mockRepo!.Setup(r => r.InsertIndividualTransactionFromPassport(dto, dt)).ReturnsAsync(1);

            var result = await _service!.SaveIndividualTransactionFromPassport(dto, dt);

            Assert.AreEqual(1, result);
        }

        [Test]
        public void Dispose_DoesNotThrow()
        {
            Assert.DoesNotThrow(() => _service!.Dispose());
        }

        [Test]
        public async Task IsUserValid_ReturnsTrue_WhenUserExists()
        {
            var user = new User();
            _mockUserRepo!.Setup(r => r.GetUserByLoginName("user")).ReturnsAsync(user);
            var result = await _service!.IsUserValid("user");
            Assert.IsTrue(result);
        }

        [Test]
        public async Task IsUserValid_ReturnsFalse_WhenUserDoesNotExist()
        {
            _mockUserRepo!.Setup(r => r.GetUserByLoginName("user")).ReturnsAsync((User?)null);
            var result = await _service!.IsUserValid("user");
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsUserValid_ReturnsFalse_OnException()
        {
            _mockUserRepo!.Setup(r => r.GetUserByLoginName("user")).ThrowsAsync(new Exception());
            var result = await _service!.IsUserValid("user");
            Assert.IsFalse(result);
        }

        [Test]
        public async Task GetRejectsByMerchantNumber_ReturnsExpected()
        {
            var expected = new List<MerchantRejects>();
            _mockRepo!.Setup(r => r.GetRejectsByMerchantNumber("m")).ReturnsAsync((IEnumerable<MerchantRejects>)expected);

            var result = await _service!.GetRejectsByMerchantNumber("m");

            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task GetMerchantNumberFromSequenceKey_ReturnsExpected()
        {
            var expected = new Merchant();
            _mockRepo!.Setup(r => r.GetMerchantNumberFromSequenceKey(1)).ReturnsAsync(expected);

            var result = await _service!.GetMerchantNumberFromSequenceKey(1);

            Assert.AreEqual(expected, result);
        }
    }
}
