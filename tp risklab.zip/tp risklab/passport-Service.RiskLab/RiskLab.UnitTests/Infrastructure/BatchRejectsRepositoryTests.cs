namespace RiskLab.UnitTests.Infrastructure.Dapper.Repository
{
    using Acquisition.Contracts.Risk.Passport;
    using Moq;
    using NUnit.Framework;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Interfaces.Repositories;
    using RiskLab.Infrastructure.Interfaces;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;

    [TestFixture]
    public class BatchRejectsRepositoryTests
    {
        private Mock<ISqlDbConnectionManager>? _mockConnMgr;
        private Mock<IDbConnection>? _mockDbConn;

        [SetUp]
        public void SetUp()
        {
            _mockConnMgr = new Mock<ISqlDbConnectionManager>();
            _mockDbConn = new Mock<IDbConnection>();
            _mockConnMgr.Setup(m => m.PrepareConnection(It.IsAny<DBs>()))
                .ReturnsAsync(_mockDbConn.Object);
        }

        [Test]
        public async Task GetBatchRejectById_ReturnsBatchRejectViewDto()
        {
            var batchRejectId = 1;
            var batch = new BatchRejectViewDto { BatchRejectId = batchRejectId, RejectReasons = new List<string>() };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.GetBatchRejectById(batchRejectId)).ReturnsAsync(batch);

            var result = await repoMock.Object.GetBatchRejectById(batchRejectId);

            Assert.NotNull(result);
        }

        [Test]
        public async Task GetBatchRejects_ReturnsBatchRejectViewDtoList()
        {
            var status = "Open";
            var batch = new BatchRejectViewDto { BatchRejectId = 1, RejectReasons = new List<string>() };
            var batches = new List<BatchRejectViewDto> { batch };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.GetBatchRejects(status)).ReturnsAsync(batches);

            var result = await repoMock.Object.GetBatchRejects(status);

            Assert.NotNull(result);
            Assert.IsTrue(result.Any());
        }

        [Test]
        public async Task GetBatchTransactionRejectById_ReturnsBatchTransactionRejectViewDto()
        {
            var id = 1;
            var txn = new BatchTransactionRejectViewDto { BatchTransactionRejectId = id, RejectReasons = new List<string>() };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.GetBatchTransactionRejectById(id)).ReturnsAsync(txn);

            var result = await repoMock.Object.GetBatchTransactionRejectById(id);

            Assert.NotNull(result);
        }

        [Test]
        public async Task GetBatchTransactionRejects_ReturnsBatchTransactionRejectsViewDto()
        {
            var batchRejectId = 1;
            var batch = new BatchRejectViewDto
            {
                BatchRejectId = batchRejectId,
                BatchAmount = 10,
                BatchCloseDate = DateTime.Now,
                MerchantName = "M",
                MerchantNumber = "MN",
                BatchNumber = "BN",
                Status = "S",
                RejectReasons = new List<string>(),
            };
            var txn = new BatchTransactionRejectViewDto { BatchTransactionRejectId = 1, RejectReasons = new List<string>() };
            var txns = new List<BatchTransactionRejectViewDto> { txn };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.GetBatchRejectById(batchRejectId)).ReturnsAsync(batch);
            repoMock.Setup(r => r.GetBatchTransactionRejects(batchRejectId)).ReturnsAsync(new BatchTransactionRejectsViewDto
            {
                BatchRejectId = batchRejectId,
                BatchAmount = batch.BatchAmount,
                BatchCloseDateUTC = batch.BatchCloseDate,
                MerchantName = batch.MerchantName,
                MerchantNumber = batch.MerchantNumber,
                OriginalBatchNumber = batch.BatchNumber,
                Status = batch.Status,
                Transactions = txns,
            });

            var result = await repoMock.Object.GetBatchTransactionRejects(batchRejectId);

            Assert.NotNull(result);
            Assert.AreEqual(batchRejectId, result.BatchRejectId);
        }

        [Test]
        public async Task GetBatchTransactionRejectByStatus_ReturnsList()
        {
            var status = "Open";
            var txn = new BatchTransactionRejectByStatusViewDto { BatchTransactionRejectId = 1, FraudRejectReasonCodes = new List<string>() };
            var txns = new List<BatchTransactionRejectByStatusViewDto> { txn };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.GetBatchTransactionRejectByStatus(status)).ReturnsAsync(txns);

            var result = await repoMock.Object.GetBatchTransactionRejectByStatus(status);

            Assert.NotNull(result);
            Assert.IsTrue(result.Any());
        }

        [Test]
        public async Task UpdateBatchRejectStatus_ReturnsResult()
        {
            var dto = new BatchRejectUpdateDto { BatchRejectId = 1, NewStatus = "Closed", UserName = "user" };
            var expected = new BatchRejectUpdateResultDto { BatchRejectId = 1, UpdateStatus = "OK", StatusCode = "200" };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.UpdateBatchRejectStatus(dto)).ReturnsAsync(expected);

            var result = await repoMock.Object.UpdateBatchRejectStatus(dto);

            Assert.NotNull(result);
            Assert.AreEqual(expected.BatchRejectId, result.BatchRejectId);
        }

        [Test]
        public async Task UpdateBatchTransactionRejectStatus_ReturnsResult()
        {
            var dto = new BatchTransactionStatus { BatchTransactionRejectId = 1, NewStatus = "Closed" };
            var expected = new BatchTransactionRejectUpdateStatus { BatchTransactionRejectId = 1, UpdateStatus = "OK", StatusCode = "200" };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.UpdateBatchTransactionRejectStatus(dto, "user")).ReturnsAsync(expected);

            var result = await repoMock.Object.UpdateBatchTransactionRejectStatus(dto, "user");

            Assert.NotNull(result);
            Assert.AreEqual(expected.BatchTransactionRejectId, result.BatchTransactionRejectId);
        }

        [Test]
        public async Task GetReleasedBatchesForPassport_ReturnsList()
        {
            var expected = new List<ReleasedBatchDto> { new ReleasedBatchDto { MessageId = Guid.NewGuid() } };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.GetReleasedBatchesForPassport()).ReturnsAsync(expected);

            var result = await repoMock.Object.GetReleasedBatchesForPassport();

            Assert.NotNull(result);
            Assert.IsTrue(result.Any());
        }

        [Test]
        public async Task InsertReleasedBatchToPassport_ReturnsTuple()
        {
            var fraudReleasedBatch = new Acquisition.Contracts.Risk.Jville.FraudReleasedBatch
            {
                MessageId = Guid.NewGuid(),
            };
            var releasedBatchDto = new ReleasedBatchDto { MessageId = Guid.NewGuid() };
            var payload = "payload";
            var expected = Tuple.Create(true, "E1", "msg");

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock
                .Setup(r => r.InsertReleasedBatchToPassport(
                    It.IsAny<Acquisition.Contracts.Risk.Jville.FraudReleasedBatch>(),
                    It.IsAny<ReleasedBatchDto>(),
                    It.IsAny<string>()))
                .ReturnsAsync(expected);

            var result = await repoMock.Object.InsertReleasedBatchToPassport(fraudReleasedBatch, releasedBatchDto, payload);

            Assert.NotNull(result);
            Assert.AreEqual(expected, result);
        }

        [Test]
        public async Task CheckIfBatchIsInProcess_ReturnsBool()
        {
            var batch = new ReleasedBatchDto { MessageId = Guid.NewGuid() };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.CheckIfBatchIsInProcess(batch)).ReturnsAsync(true);

            var result = await repoMock.Object.CheckIfBatchIsInProcess(batch);

            Assert.IsTrue(result);
        }

        [Test]
        public async Task ResetInFlightBatch_ReturnsTask()
        {
            var batch = new ReleasedBatchDto { MessageId = Guid.NewGuid() };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.ResetInFlightBatch(batch)).Returns(Task.CompletedTask);

            await repoMock.Object.ResetInFlightBatch(batch);

            Assert.Pass();
        }

        [Test]
        public async Task CheckNotificationStatusForMessageIds_ReturnsList()
        {
            var unAckBatches = new List<ReleasedBatchDto> { new ReleasedBatchDto { MessageId = Guid.NewGuid() } };
            var expected = new List<NotificationMessageDto> { new NotificationMessageDto { MessageId = Guid.NewGuid() } };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.CheckNotificationStatusForMessageIds(unAckBatches)).ReturnsAsync(expected);

            var result = await repoMock.Object.CheckNotificationStatusForMessageIds(unAckBatches);

            Assert.NotNull(result);
            Assert.IsTrue(result.Any());
        }

        [Test]
        public async Task UpdateNotificationStatusForMessageIds_ReturnsBool()
        {
            var unAckBatchList = new List<ReleasedBatchDto> { new ReleasedBatchDto { MessageId = Guid.NewGuid() } };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.UpdateNotificationStatusForMessageIds(unAckBatchList)).ReturnsAsync(true);

            var result = await repoMock.Object.UpdateNotificationStatusForMessageIds(unAckBatchList);

            Assert.IsTrue(result);
        }

        [Test]
        public async Task UpdateReleasedBatchAck_ReturnsInt()
        {
            FraudReleasedBatchConfirmation? confirmation = new ()
            {
                MessageId = Guid.NewGuid(),
            };

            var repoMock = new Mock<IBatchRejectsRepository>();
            repoMock.Setup(r => r.UpdateReleasedBatchAck(It.IsAny<FraudReleasedBatchConfirmation>())).ReturnsAsync(1);

            var result = await repoMock.Object.UpdateReleasedBatchAck(confirmation);

            Assert.AreEqual(1, result);
        }
    }
}
