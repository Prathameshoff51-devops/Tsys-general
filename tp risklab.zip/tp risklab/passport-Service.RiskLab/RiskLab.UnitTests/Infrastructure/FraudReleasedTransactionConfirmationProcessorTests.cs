﻿using Acquisition.Contracts.Risk.Passport;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure.MessageProcessor;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure
{
    internal class FraudReleasedTransactionConfirmationProcessorTests
    {
        private readonly IIndividualTransactionsRepository individualTransactionsRepository;

        public FraudReleasedTransactionConfirmationProcessorTests()
        {
            individualTransactionsRepository = new Mock<IIndividualTransactionsRepository>().Object;
        }

        [Test]
        public async Task FraudReleasedTransactionConfirmationProcessor_Successful()
        {
            // Arrange
            var mockIndividualRejectsRepository = new Mock<IIndividualTransactionsRepository>();
            mockIndividualRejectsRepository.Setup(x => x.UpdateReleasedTransactionAck(It.IsAny<FraudReleasedTransactionConfirmation>()));
            FraudReleasedTransactionConfirmationProcessor processer = new FraudReleasedTransactionConfirmationProcessor(mockIndividualRejectsRepository.Object);

            // Act
            var result = await processer.Process("{\"MessageId\":\"ccd105ea-7b70-4144-82b7-1ca26b3025e1\",\"TxnUuid\":2023012300003001,\"TxnDetailId\":23}");
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
        }

        [Test]
        public async Task FraudReleasedTransactionConfirmationProcessor_Failed()
        {
            // Arrange
            var mockIndividualRejectsRepository = new Mock<IIndividualTransactionsRepository>();
            mockIndividualRejectsRepository.Setup(x => x.UpdateReleasedTransactionAck(It.IsAny<FraudReleasedTransactionConfirmation>()));
            FraudReleasedTransactionConfirmationProcessor processer = new FraudReleasedTransactionConfirmationProcessor(mockIndividualRejectsRepository.Object);

            // Act
            var result = await processer.Process(string.Empty);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
        }
    }
}
