﻿using Acquisition.Contracts.Risk.Jville;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Interfaces;
using RiskLab.Infrastructure.MessageProcessor;
using System;
using System.Data;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure
{
    internal class SuspectedFraudulentBatchProcessorTests
    {
        public const string Payload = "{\r\n    \"MessageId\": \"63d2a95b-386e-4cfe-98b6-f230d293af97\",\r\n    \"OriginalBatchNumber\": \"000418\",\r\n    \"TxnUuid\": 2023063000853418,\r\n    \"MerchantNumber\": \"650000004051668\",\r\n    \"MerchantName\": \"103 BRAUMS STORE\",\r\n    \"LegalName\": \"BRAUMS INC\",\r\n    \"ChainOid\": \"116280\",\r\n    \"Mcc\": \"5812\",\r\n    \"BusinessDateUtc\": \"2023-06-30T12:00:00.0000000-05:00\",\r\n    \"BatchAmount\": 305.0,\r\n    \"CreditCount\": 3,\r\n    \"TxnDateUtc\": \"2023-04-30T20:20:20.0000000-05:00\",\r\n    \"BatchCloseDate\": \"2023-06-30T00:22:21.0000000-05:00\",\r\n    \"SubmitterId\": 1,\r\n    \"SubmitterIdDescription\": \"Exchange\",\r\n    \"FraudRejectReasonCodeIds\": [\r\n        1,\r\n        2\r\n    ],\r\n    \"TransactionList\": [\r\n        {\r\n            \"TxnDetailId\": 1,\r\n            \"Amount\": 50.0,\r\n            \"CardNumberMask\": \"421783******9809\",\r\n            \"TxnDateUtc\": \"2023-02-18T23:08:10.0000000-05:00\",\r\n            \"FraudRejectReasonCodeIds\": [\r\n                1,2\r\n            ],\r\n            \"ExpDate\": \"2027-01-31T00:00:00.0000000-06:00\",\r\n            \"ServiceOptionTxnTypeId\": 20,\r\n            \"TxnTypeDescription\": \"Return\"\r\n        },\r\n        {\r\n            \"TxnDetailId\": 2,\r\n            \"Amount\": 105.0,\r\n            \"CardNumberMask\": \"421783******9809\",\r\n            \"TxnDateUtc\": \"2023-02-20T23:08:10.0000000-05:00\",\r\n            \"FraudRejectReasonCodeIds\": [\r\n                2\r\n            ],\r\n            \"ExpDate\": \"2027-01-31T00:00:00.0000000-06:00\",\r\n            \"ServiceOptionTxnTypeId\": 2,\r\n            \"TxnTypeDescription\": \"Sale\"\r\n        }\r\n    ]\r\n}";
        private readonly IBatchTransactionsRepository batchTransactionsRepository;
        private readonly IMessageQueueService messageQueueService;
        private readonly INotificationService notificationService;
        private readonly IRabbitMQSettings settings;

        public SuspectedFraudulentBatchProcessorTests()
        {
            batchTransactionsRepository = new Mock<IBatchTransactionsRepository>().Object;
            messageQueueService = new Mock<IMessageQueueService>().Object;
            notificationService = new Mock<INotificationService>().Object;
            settings = new Mock<IRabbitMQSettings>().Object;
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_FailedToAckDuplicateMessage()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.FailedToAckDuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_DuplicateMessage()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            var tupletoReturn = Tuple.Create<bool, string, string>(true, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchAck(It.IsAny<string>(), It.IsAny<BatchDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.DuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_SaveBatchAck_false_DuplicateMessage()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchAck(It.IsAny<string>(), It.IsAny<BatchDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.DuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_SaveBatchAck_Exception_DuplicateMessage()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(true));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.DuplicateMessage);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_SaveBatchAck_false_Successful()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchFromPassport(It.IsAny<BatchDto>(), It.IsAny<DataTable>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            mockSettings.Setup(x => x["RiskLabAPIUrl"]).Returns("apiUrl");
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchAck(It.IsAny<string>(), It.IsAny<BatchDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Successful);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_Successful()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchFromPassport(It.IsAny<BatchDto>(), It.IsAny<DataTable>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(true);
            mockSettings.Setup(x => x["RiskLabAPIUrl"]).Returns("apiUrl");
            var tupletoReturn = Tuple.Create<bool, string, string>(true, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchAck(It.IsAny<string>(), It.IsAny<BatchDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Successful);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_FailedToAck()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchFromPassport(It.IsAny<BatchDto>(), It.IsAny<DataTable>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(false);
            mockSettings.Setup(x => x["RiskLabAPIUrl"]).Returns("apiUrl");
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchAck(It.IsAny<string>(), It.IsAny<BatchDto>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.FailedToAck);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_Failed()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(string.Empty);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Failed);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_Exception_FailedToAck()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchFromPassport(It.IsAny<BatchDto>(), It.IsAny<DataTable>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(false);
            var tupletoReturn = Tuple.Create<bool, string, string>(true, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertErrorPayload(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            mockSettings.Setup(x => x["IsErrorPayloadCapture"]).Returns("true");
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Failed);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_Exception_InsertErrorPayload_false_FailedToAck()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchFromPassport(It.IsAny<BatchDto>(), It.IsAny<DataTable>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(false);
            var tupletoReturn = Tuple.Create<bool, string, string>(false, string.Empty, string.Empty);
            mockBatchTransactionsRepository.Setup(x => x.InsertErrorPayload(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(tupletoReturn));
            mockSettings.Setup(x => x["IsErrorPayloadCapture"]).Returns("true");
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Failed);
        }

        [Test]
        public async Task SuspectedFraudulentBatchProcessorTests_SaveErrorPayload_Exception_FailedToAck()
        {
            // Arrange
            var mockBatchTransactionsRepository = new Mock<IBatchTransactionsRepository>();
            var mockMessageQueueService = new Mock<IMessageQueueService>();
            var mockNotificationService = new Mock<INotificationService>();
            var mockSettings = new Mock<IRabbitMQSettings>();
            mockBatchTransactionsRepository.Setup(x => x.CheckIfMessageConsumed(It.IsAny<Guid>()))
                                  .Returns(Task.FromResult(false));
            mockBatchTransactionsRepository.Setup(x => x.InsertBatchFromPassport(It.IsAny<BatchDto>(), It.IsAny<DataTable>(), It.IsAny<DataTable>()))
                                  .Returns(Task.FromResult(1));
            mockMessageQueueService.Setup(x => x.PublishMessage(It.IsAny<SuspectedFraudulentBatchConfirmation>(), It.IsAny<byte[]>())).Returns(false);
            mockSettings.Setup(x => x["IsErrorPayloadCapture"]).Returns("true");
            SuspectedFraudulentBatchProcessor processer = new SuspectedFraudulentBatchProcessor(mockBatchTransactionsRepository.Object, mockMessageQueueService.Object, mockNotificationService.Object, mockSettings.Object);

            // Act
            var result = await processer.Process(Payload);
            var okResult = result;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult, MessageStatusIdentifier.Failed);
        }
    }
}
