using NUnit.Framework;
using RiskLab.Infrastructure.Helpers;

namespace RiskLab.UnitTests.Infrastructure
{
    [TestFixture]
    public class MethodNameHelperTests
    {
        [Test]
        public void GetActualAsyncMethodName_WithoutParameter_ReturnsCallerMemberName()
        {
            // Act
            var result = MethodNameHelper.GetActualAsyncMethodName();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("GetActualAsyncMethodName_WithoutParameter_ReturnsCallerMemberName", result);
        }

        [Test]
        public void GetActualAsyncMethodName_WithExplicitName_ReturnsProvidedName()
        {
            // Arrange
            var expectedName = "TestMethodName";

            // Act
            var result = MethodNameHelper.GetActualAsyncMethodName(expectedName);

            // Assert
            Assert.AreEqual(expectedName, result);
        }

        [Test]
        public void GetActualAsyncMethodName_WithNullName_ReturnsNull()
        {
            // Act
            var result = MethodNameHelper.GetActualAsyncMethodName(null);

            // Assert
            Assert.IsNull(result);
        }

        [Test]
        public void GetActualAsyncMethodName_WithEmptyName_ReturnsEmpty()
        {
            // Act
            var result = MethodNameHelper.GetActualAsyncMethodName(string.Empty);

            // Assert
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void GetActualAsyncMethodName_CalledFromDifferentMethods_ReturnsCorrectNames()
        {
            // Act
            var result1 = GetMethodName1();
            var result2 = GetMethodName2();

            // Assert
            Assert.AreEqual("GetMethodName1", result1);
            Assert.AreEqual("GetMethodName2", result2);
        }

        private string GetMethodName1()
        {
            return MethodNameHelper.GetActualAsyncMethodName();
        }

        private string GetMethodName2()
        {
            return MethodNameHelper.GetActualAsyncMethodName();
        }
    }
}
