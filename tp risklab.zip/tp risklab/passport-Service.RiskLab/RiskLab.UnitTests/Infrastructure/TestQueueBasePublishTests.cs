using EasyNetQ;
using EasyNetQ.Topology;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Infrastructure
{
    [TestFixture]
    public class TestQueueBasePublishTests
    {
        private TestQueueBasePublish _queueBasePublish;
        private Mock<IAdvancedBus> _mockBus;
        private Exchange _exchange;
        private Exchange _deadLetterExchange;

        [SetUp]
        public void SetUp()
        {
            _queueBasePublish = new TestQueueBasePublish();
            _mockBus = new Mock<IAdvancedBus>();
            _exchange = new Exchange("test-exchange", ExchangeType.Topic);
            _deadLetterExchange = new Exchange("test-dlx", ExchangeType.Topic);

            // Set up the bus for testing
            _queueBasePublish.SetBusForTesting(_mockBus.Object);
            // Remove reflection code that sets Exchange and DeadLetterExchange
        }

        [Test]
        public void SetStartedForTesting_SetsState()
        {
            _queueBasePublish.SetStartedForTesting(true);
            Assert.IsTrue(_queueBasePublish.IsStartedForTesting());
            _queueBasePublish.SetStartedForTesting(false);
            Assert.IsFalse(_queueBasePublish.IsStartedForTesting());
        }

        [Test]
        public void SetBusForTesting_SetsBus()
        {
            var bus = new Mock<IAdvancedBus>().Object;
            _queueBasePublish.SetBusForTesting(bus);
            // No exception means success
            Assert.Pass();
        }

        [Test]
        public async Task StartAsync_WhenNotStarted_CallsBaseAndSetsStarted()
        {
            _queueBasePublish.SetStartedForTesting(false);
            await _queueBasePublish.StartAsync();
            Assert.IsTrue(_queueBasePublish.IsStartedForTesting());
        }

        [Test]
        public async Task StartAsync_WhenAlreadyStarted_DoesNotCallBaseAgain()
        {
            _queueBasePublish.SetStartedForTesting(true);
            await _queueBasePublish.StartAsync();
            Assert.IsTrue(_queueBasePublish.IsStartedForTesting());
        }

        [Test]
        public void Stop_WhenStarted_CallsBaseAndResetsStarted()
        {
            _queueBasePublish.SetStartedForTesting(true);
            _queueBasePublish.Stop();
            Assert.IsFalse(_queueBasePublish.IsStartedForTesting());
        }

        [Test]
        public void Stop_WhenNotStarted_DoesNothing()
        {
            _queueBasePublish.SetStartedForTesting(false);
            _queueBasePublish.Stop();
            Assert.IsFalse(_queueBasePublish.IsStartedForTesting());
        }
    }
}
