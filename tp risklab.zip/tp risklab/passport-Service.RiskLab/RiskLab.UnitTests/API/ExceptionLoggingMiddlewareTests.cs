﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.API.Middleware;
using System;
using System.Net;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    internal class ExceptionLoggingMiddlewareTests
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionLoggingMiddleware> _logger;

        public ExceptionLoggingMiddlewareTests()
        {
            _next = new Mock<RequestDelegate>().Object;
            _logger = new Mock<ILogger<ExceptionLoggingMiddleware>>().Object;
        }

        [Test]
        public async Task ExceptionLoggingMiddleware_Successful()
        {
            //Arrange
            bool isNextDelegateCalled = false;
            var requestDelegate = new RequestDelegate(async (innerContext) =>
            {
                isNextDelegateCalled = true;

                await Task.CompletedTask;
            });
            ExceptionLoggingMiddleware middleware = new ExceptionLoggingMiddleware(requestDelegate, _logger);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.True(isNextDelegateCalled);
        }

        [Test]
        public async Task CustomAuthenticationMiddleware_witherrorCode_InternalServerError()
        {
            //Arrange
            bool isNextDelegateCalled = false;
            var requestDelegate = new RequestDelegate(async (innerContext) =>
            {
                isNextDelegateCalled = true;

                throw new Exception();
            });
            ExceptionLoggingMiddleware middleware = new ExceptionLoggingMiddleware(requestDelegate, _logger);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.True(isNextDelegateCalled);
            Assert.AreEqual((int)HttpStatusCode.InternalServerError, defaultContext.Response.StatusCode);
        }
    }
}
