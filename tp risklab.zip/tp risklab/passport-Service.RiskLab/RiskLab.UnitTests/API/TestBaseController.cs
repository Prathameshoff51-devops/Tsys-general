using Microsoft.Extensions.Logging;
using RiskLab.API.Controllers;

namespace RiskLab.UnitTests.API
{
    // Test implementation of BaseController for testing purposes
    public class TestBaseController : BaseController
    {
        public TestBaseController(ILogger logger)
            : base(logger)
        {
        }

        // Expose the protected Logger property publicly for testing
        public new ILogger Logger => base.Logger;

        public ILogger GetLoggerFromMethod()
        {
            return base.Logger;
        }

        public bool CanAccessLogger()
        {
            return base.Logger != null;
        }

        public void TestLogCall()
        {
            base.Logger.LogInformation("Test log message");
        }
    }
}
