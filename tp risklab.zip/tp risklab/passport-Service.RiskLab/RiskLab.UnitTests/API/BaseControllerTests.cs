using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using System;

namespace RiskLab.UnitTests.API
{
    [TestFixture]
    public class BaseControllerTests
    {
        private Mock<ILogger> mockLogger;
        private TestBaseController baseController;

        [SetUp]
        public void SetUp()
        {
            mockLogger = new Mock<ILogger>();
            baseController = new TestBaseController(mockLogger.Object);
        }

        [Test]
        public void Constructor_WithValidLogger_InitializesSuccessfully()
        {
            // Arrange & Act
            var controller = new TestBaseController(mockLogger.Object);

            // Assert
            Assert.IsNotNull(controller);
            Assert.IsNotNull(controller.Logger);
            Assert.AreSame(mockLogger.Object, controller.Logger);
        }

        [Test]
        public void Logger_Property_ReturnsCorrectLogger()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            var logger = controller.Logger;

            // Assert
            Assert.AreSame(mockLogger.Object, logger);
        }

        [Test]
        public void BaseController_IsController_ReturnsTrue()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act & Assert
            Assert.IsInstanceOf<Controller>(controller);
        }

        [Test]
        public void BaseController_HasRouteAttribute_ReturnsTrue()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            var routeAttribute = controller.GetType().BaseType.GetCustomAttributes(typeof(RouteAttribute), false);

            // Assert
            Assert.IsNotEmpty(routeAttribute);
        }

        [Test]
        public void BaseController_InheritsFromController_ReturnsTrue()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act & Assert
            Assert.IsTrue(controller.GetType().BaseType.IsSubclassOf(typeof(Controller)));
        }

        [Test]
        public void BaseController_CanBeInstantiatedMultipleTimes()
        {
            // Arrange & Act
            var controller1 = new TestBaseController(mockLogger.Object);
            var controller2 = new TestBaseController(mockLogger.Object);

            // Assert
            Assert.IsNotNull(controller1);
            Assert.IsNotNull(controller2);
            Assert.AreNotSame(controller1, controller2);
        }

        [Test]
        public void BaseController_LoggerProperty_IsNotNull()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            var logger = controller.Logger;

            // Assert
            Assert.IsNotNull(logger);
        }

        [Test]
        public void BaseController_LoggerProperty_IsReadOnly()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            var logger1 = controller.Logger;
            var logger2 = controller.Logger;

            // Assert
            Assert.AreSame(logger1, logger2);
        }

        [Test]
        public void BaseController_WithDifferentLoggers_MaintainsCorrectLogger()
        {
            // Arrange
            var mockLogger1 = new Mock<ILogger>();
            var mockLogger2 = new Mock<ILogger>();
            var controller1 = new TestBaseController(mockLogger1.Object);
            var controller2 = new TestBaseController(mockLogger2.Object);

            // Act
            var logger1 = controller1.Logger;
            var logger2 = controller2.Logger;

            // Assert
            Assert.AreSame(mockLogger1.Object, logger1);
            Assert.AreSame(mockLogger2.Object, logger2);
            Assert.AreNotSame(logger1, logger2);
        }

        [Test]
        public void BaseController_CanAccessLoggerFromDerivedClass()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            var loggerFromMethod = controller.GetLoggerFromMethod();

            // Assert
            Assert.AreSame(mockLogger.Object, loggerFromMethod);
        }

        [Test]
        public void BaseController_LoggerIsProtected()
        {
            // Arrange
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            var canAccessLogger = controller.CanAccessLogger();

            // Assert
            Assert.IsTrue(canAccessLogger);
        }

        [Test]
        public void BaseController_WithMockedLogger_CanTrackLogCalls()
        {
            // Arrange
            var mockLogger = new Mock<ILogger>();
            var controller = new TestBaseController(mockLogger.Object);

            // Act
            controller.TestLogCall();

            // Assert
            mockLogger.Verify(
                x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Test log message")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }

        [Test]
        public void BaseController_MultipleInstances_HaveIndependentLoggers()
        {
            // Arrange
            var mockLogger1 = new Mock<ILogger>();
            var mockLogger2 = new Mock<ILogger>();
            var controller1 = new TestBaseController(mockLogger1.Object);
            var controller2 = new TestBaseController(mockLogger2.Object);

            // Act
            controller1.TestLogCall();
            controller2.TestLogCall();

            // Assert
            mockLogger1.Verify(
                x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Test log message")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);

            mockLogger2.Verify(
                x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Test log message")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }

        [TearDown]
        public void TearDown()
        {
            baseController = null;
        }
    }
}
