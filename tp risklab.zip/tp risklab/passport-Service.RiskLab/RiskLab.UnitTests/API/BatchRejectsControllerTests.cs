﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.API.Controllers;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Services;
using RiskLab.UnitTests.Helpers;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    public class BatchRejectsControllerTests
    {
        private readonly ILogger<BatchRejectsController> logger;
        private readonly IBatchRejectsService batchRejectsService;
        private readonly IUserService userService;

        public BatchRejectsControllerTests()
        {
            logger = new Mock<ILogger<BatchRejectsController>>().Object;
            batchRejectsService = new Mock<IBatchRejectsService>().Object;
            userService = new Mock<IUserService>().Object;
        }

        #region GetBatchRejectsTests
        [Test]
        public async Task GetBatchRejects_WhenCalledForStatusNew_ReturnNewTransactions()
        {
            // Arrange
            string batchRejectStatus = RejectStatuses.New.ToString();
            var mockBatchRejectsService = new Mock<IBatchRejectsService>();
            mockBatchRejectsService.Setup(x => x.GetBatchRejectsByStatus(batchRejectStatus))
                                  .Returns(Task.FromResult(BatchRejectsHelper.GetBatchRejects()));
            BatchRejectsController controller = new BatchRejectsController(logger, mockBatchRejectsService.Object, userService);

            // Act
            var result = await controller.GetBatchRejects(batchRejectStatus);
            var okResult = result as ObjectResult;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<IEnumerable<BatchRejectViewDto>>(okResult.Value);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, okResult.StatusCode);
        }

        [Test]
        public async Task GetBatchRejects_WhenCalledForInvalidStatus_ReturnBadRequest()
        {
            //Arrange
            BatchRejectsController controller = new BatchRejectsController(logger, batchRejectsService, userService);

            //Act
            var result = await controller.GetBatchRejects(It.IsAny<string>());
            var badRequestResult = result as ObjectResult;

            //Assert
            Assert.IsTrue(badRequestResult is BadRequestObjectResult);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
        }

        [Test]
        public async Task GetBatchRejects_WhenCalled_ReturnInternalServerError()
        {
            //Arrange
            var mockBatchRejectsService = new Mock<IBatchRejectsService>();
            mockBatchRejectsService.Setup(x => x.GetBatchRejectsByStatus(It.IsAny<string>()))
                                  .Throws(new Exception());
            BatchRejectsController controller = new BatchRejectsController(logger, mockBatchRejectsService.Object, userService);

            //Act
            var result = await controller.GetBatchRejects("new") as ObjectResult;

            //Assert
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, result.StatusCode);
        }
        #endregion GetTransactionsTests

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalled_ReturnOk()
        {
            //Arrange
            var batchRejectToUpdate = BatchRejectsHelper.GetBatchRejectStatusUpdateDto();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.UpdateBatchRejectStatus(batchRejectToUpdate))
                                  .Returns(Task.FromResult(BatchRejectsHelper.GetBatchRejectsUpdateResult()));
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            BatchRejectsController controller = new BatchRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            //Act
            var result = await controller.UpdateBatchStatus(batchRejectToUpdate);
            var okResult = result as ObjectResult;

            //Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<BatchRejectUpdateResultDto>(okResult.Value);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, okResult.StatusCode);
        }

        [Test]
        public async Task UpdateBatchRejectStatus_UserNameTampered_WhenCalledReturn401()
        {
            //Arrange
            var batchRejectToUpdate = BatchRejectsHelper.GetBatchRejectStatusUpdateDto();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.UpdateBatchRejectStatus(batchRejectToUpdate))
                                  .Returns(Task.FromResult(BatchRejectsHelper.GetBatchRejectsUpdateResult()));
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            BatchRejectsController controller = new BatchRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "diffrentUser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            //Act
            var result = await controller.UpdateBatchStatus(batchRejectToUpdate);
            var inValidResult = result as ObjectResult;

            //Assert
            Assert.IsNotNull(inValidResult);
            Assert.IsTrue(inValidResult is UnauthorizedObjectResult);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized, inValidResult.StatusCode);
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalled_ReturnInternalServerError()
        {
            //Arrange
            var batchRejectToUpdate = BatchRejectsHelper.GetBatchRejectStatusUpdateDto();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.UpdateBatchRejectStatus(batchRejectToUpdate))
                                  .Returns(Task.FromResult(BatchRejectsHelper.GetBatchRejectsUpdateResult()));
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            BatchRejectsController controller = new BatchRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            //Act
            var result = await controller.UpdateBatchStatus(It.IsAny<BatchRejectUpdateDto>()) as ObjectResult;

            //Assert
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, result.StatusCode);
        }
    }
}