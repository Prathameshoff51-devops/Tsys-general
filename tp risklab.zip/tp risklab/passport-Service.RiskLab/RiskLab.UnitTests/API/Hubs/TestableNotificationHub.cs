using Microsoft.AspNetCore.SignalR;
using RiskLab.API.Hubs;

namespace RiskLab.UnitTests.API.Hubs
{
    // Test helper class to make NotificationHub testable
    public class TestableNotificationHub : NotificationHub
    {
        public TestableNotificationHub(IHubCallerClients clients)
        {
            // Use reflection to set the Clients property since it's not virtual
            var clientsProperty = typeof(Hub).GetProperty("Clients");
            if (clientsProperty != null)
            {
                clientsProperty.SetValue(this, clients);
            }
        }
    }
}
