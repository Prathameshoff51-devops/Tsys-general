﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using RiskLab.API.Controllers;
using RiskLab.API.Model;
using RiskLab.Core.Interfaces;
using RiskLab.Core.Settings;
using System.Security.Claims;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    internal class ConfigurationsControllerTests
    {
        private readonly ApplicationSettings setting;

        public ConfigurationsControllerTests()
        {
            setting = new Mock<ApplicationSettings>().Object;
        }

        [Test]
        public async Task ConfigurationsController_Successful()
        {
            //Arrange
            var logger = new Mock<ILogger<ConfigurationsController>>().Object;
            var settings = new Mock<IOptions<ApplicationSettings>>().Object;
            var mockSetting = new Mock<ISettingsManagerWrapper>().Object;
            ApplicationSettings appSetting = new ApplicationSettings()
            {
                Issuer = It.IsAny<string>(),
                AuthorizationServer = It.IsAny<string>(),
                IntrospectEndPoint = It.IsAny<string>(),
                EnvironmentCode = It.IsAny<string>(),
                RiskLabApiUrl = It.IsAny<string>(),
                RiskLabUiUrl = It.IsAny<string>(),
                CoreloggingServiceUrl = It.IsAny<string>(),
                DefaultGridPageSize = It.IsAny<int>(),
                DefaultBackOfficeGridPageSize = It.IsAny<int>(),
                DefaultBatchGridPageSize = It.IsAny<int>(),
                DaysToAct = It.IsAny<int>(),
            };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            ConfigurationsController controller = new ConfigurationsController(mockSetting, logger, mockApplicationSettings.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "RiskLab"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "Fraud Service Details"),
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };
            var appmenu = new AppMenu();
            var settingsViewModel = new SettingsViewModel(appSetting)
            {
                ScaPersonInfoUrl = It.IsAny<string>(),
                MinimumSearchLength = 0,
                JwtClaimsToken = It.IsAny<string>(),
                IsSuperAdmin = It.IsAny<bool>(),
            };
            //Act
            var result = controller.Index();

            // Assert
            Assert.AreEqual(appmenu.Name, null);
            Assert.AreEqual(appmenu.IconName, null);
            Assert.AreEqual(appmenu.DisplayName, null);
            Assert.AreEqual(appmenu.Link, null);
            Assert.AreEqual(appmenu.Route, null);
            Assert.AreEqual(appmenu.ChildrenMenuItems, null);
            Assert.AreEqual(settingsViewModel.Environment, null);
            Assert.AreEqual(settingsViewModel.ScaPersonInfoUrl, null);
            Assert.AreEqual(settingsViewModel.DefaultGridPageSize, 0);
            Assert.AreEqual(settingsViewModel.DefaultBatchGridPageSize, 0);
            Assert.AreEqual(settingsViewModel.DefaultBackOfficeGridPageSize, 0);
            Assert.AreEqual(settingsViewModel.DaysToAct, 0);
            Assert.AreEqual(settingsViewModel.MinimumSearchLength, 0);
            Assert.AreEqual(settingsViewModel.Username, null);
            Assert.AreEqual(settingsViewModel.RiskLabApiUrl, null);
            Assert.AreEqual(settingsViewModel.RiskLabUiUrl, null);
            Assert.AreEqual(settingsViewModel.Menu, null);
            Assert.AreEqual(settingsViewModel.IsFraudServiceUser, false);
            Assert.AreEqual(settingsViewModel.IsRiskLabUser, false);
            Assert.AreEqual(settingsViewModel.JwtClaimsToken, null);
            Assert.AreEqual(settingsViewModel.IsSuperAdmin, false);
            Assert.AreEqual(settingsViewModel.CoreloggingServiceUrl, null);
            Assert.That(settingsViewModel.ThreadId, Is.Not.Null);
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<IActionResult>());
        }
    }
}
