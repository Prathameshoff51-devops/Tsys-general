using Moq;
using NUnit.Framework;
using RiskLab.API.Healthcheck.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API.Healthcheck
{
    [TestFixture]
    public class HealthCheckServiceTests
    {
        private HealthCheckService healthCheckService;
        private Mock<IHealthCheck> mockHealthCheck1;
        private Mock<IHealthCheck> mockHealthCheck2;
        private Mock<IHealthCheck> mockHealthCheck3;

        [SetUp]
        public void SetUp()
        {
            mockHealthCheck1 = new Mock<IHealthCheck>();
            mockHealthCheck2 = new Mock<IHealthCheck>();
            mockHealthCheck3 = new Mock<IHealthCheck>();
        }

        [Test]
        public void Constructor_WithValidChecks_InitializesSuccessfully()
        {
            // Arrange
            var checks = new List<IHealthCheck> { mockHealthCheck1.Object };

            // Act
            var service = new HealthCheckService(checks);

            // Assert
            Assert.IsNotNull(service);
        }

        [Test]
        public void Constructor_WithEmptyChecks_InitializesSuccessfully()
        {
            // Arrange
            var checks = new List<IHealthCheck>();

            // Act
            var service = new HealthCheckService(checks);

            // Assert
            Assert.IsNotNull(service);
        }

        [Test]
        public async Task CheckAll_WithSingleHealthyCheck_ReturnsHealthyResult()
        {
            // Arrange
            var healthCheckResult = HealthCheckResult.Healthy("Healthy");
            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object };
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Results);
            Assert.AreEqual(1, result.Results.Count());
            Assert.AreEqual(HealthStatus.Healthy, result.Results.First().Status);
            Assert.AreEqual("Healthy", result.Results.First().Description);
        }

        [Test]
        public async Task CheckAll_WithSingleUnhealthyCheck_ReturnsUnhealthyResult()
        {
            // Arrange
            var healthCheckResult = HealthCheckResult.Unhealthy("Unhealthy");
            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object };
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Results);
            Assert.AreEqual(1, result.Results.Count());
            Assert.AreEqual(HealthStatus.Unhealthy, result.Results.First().Status);
            Assert.AreEqual("Unhealthy", result.Results.First().Description);
        }

        [Test]
        public async Task CheckAll_WithMultipleHealthyChecks_ReturnsAllHealthyResults()
        {
            // Arrange
            var healthCheckResult1 = HealthCheckResult.Healthy("Database Healthy");
            var healthCheckResult2 = HealthCheckResult.Healthy("Cache Healthy");
            var healthCheckResult3 = HealthCheckResult.Healthy("Queue Healthy");

            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult1);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult2);
            mockHealthCheck3.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult3);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object, mockHealthCheck3.Object };
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Results);
            Assert.AreEqual(3, result.Results.Count());
            Assert.IsTrue(result.Results.All(r => r.Status == HealthStatus.Healthy));
        }

        [Test]
        public async Task CheckAll_WithMixedHealthyAndUnhealthyChecks_ReturnsAllResults()
        {
            // Arrange
            var healthCheckResult1 = HealthCheckResult.Healthy("Database Healthy");
            var healthCheckResult2 = HealthCheckResult.Unhealthy("Cache Unhealthy");
            var healthCheckResult3 = HealthCheckResult.Healthy("Queue Healthy");

            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult1);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult2);
            mockHealthCheck3.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult3);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object, mockHealthCheck3.Object };
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Results);
            Assert.AreEqual(3, result.Results.Count());
            Assert.AreEqual(2, result.Results.Count(r => r.Status == HealthStatus.Healthy));
            Assert.AreEqual(1, result.Results.Count(r => r.Status == HealthStatus.Unhealthy));
        }

        [Test]
        public async Task CheckAll_WithEmptyChecks_ReturnsEmptyResults()
        {
            // Arrange
            var checks = new List<IHealthCheck>();
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Results);
            Assert.AreEqual(0, result.Results.Count());
        }

        [Test]
        public async Task CheckAll_WithCheckThrowingException_HandlesGracefully()
        {
            // Arrange
            var healthCheckResult1 = HealthCheckResult.Healthy("Database Healthy");
            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult1);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).ThrowsAsync(new Exception("Check failed"));

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object };
            var service = new HealthCheckService(checks);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(async () => await service.CheckAll());
        }

        [Test]
        public async Task CheckAll_WithSlowCheck_WaitsForCompletion()
        {
            // Arrange
            var healthCheckResult1 = HealthCheckResult.Healthy("Fast Check");
            var healthCheckResult2 = HealthCheckResult.Healthy("Slow Check");

            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult1);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).Returns(async () =>
            {
                await Task.Delay(100);
                return healthCheckResult2;
            });

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object };
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Results.Count());
            Assert.IsTrue(result.Results.All(r => r.Status == HealthStatus.Healthy));
        }

        [Test]
        public async Task CheckAll_WithNullResultFromCheck_HandlesGracefully()
        {
            // Arrange
            var healthCheckResult1 = HealthCheckResult.Healthy("Valid Check");
            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult1);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).ThrowsAsync(new InvalidOperationException("Health check failed"));

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object };
            var service = new HealthCheckService(checks);

            // Act & Assert
            Assert.ThrowsAsync<InvalidOperationException>(async () => await service.CheckAll());
        }

        [Test]
        public async Task CheckAll_WithChecksReturningDifferentMessages_PreservesAllMessages()
        {
            // Arrange
            var healthCheckResult1 = HealthCheckResult.Healthy("Database connection successful");
            var healthCheckResult2 = HealthCheckResult.Unhealthy("Cache connection failed: timeout");
            var healthCheckResult3 = HealthCheckResult.Healthy("Message queue is operational");

            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult1);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult2);
            mockHealthCheck3.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult3);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object, mockHealthCheck3.Object };
            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(3, result.Results.Count());
            Assert.AreEqual("Database connection successful", result.Results.ElementAt(0).Description);
            Assert.AreEqual("Cache connection failed: timeout", result.Results.ElementAt(1).Description);
            Assert.AreEqual("Message queue is operational", result.Results.ElementAt(2).Description);
        }

        [Test]
        public async Task CheckAll_VerifyAllChecksAreCalled()
        {
            // Arrange
            var healthCheckResult = HealthCheckResult.Healthy("OK");
            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult);
            mockHealthCheck2.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult);
            mockHealthCheck3.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object, mockHealthCheck2.Object, mockHealthCheck3.Object };
            var service = new HealthCheckService(checks);

            // Act
            await service.CheckAll();

            // Assert
            mockHealthCheck1.Verify(x => x.CheckHealthAsync(), Times.Once);
            mockHealthCheck2.Verify(x => x.CheckHealthAsync(), Times.Once);
            mockHealthCheck3.Verify(x => x.CheckHealthAsync(), Times.Once);
        }

        [Test]
        public async Task CheckAll_CalledMultipleTimes_ExecutesChecksEachTime()
        {
            // Arrange
            var healthCheckResult = HealthCheckResult.Healthy("OK");
            mockHealthCheck1.Setup(x => x.CheckHealthAsync()).ReturnsAsync(healthCheckResult);

            var checks = new List<IHealthCheck> { mockHealthCheck1.Object };
            var service = new HealthCheckService(checks);

            // Act
            await service.CheckAll();
            await service.CheckAll();
            await service.CheckAll();

            // Assert
            mockHealthCheck1.Verify(x => x.CheckHealthAsync(), Times.Exactly(3));
        }

        [Test]
        public async Task CheckAll_WithLargeNumberOfChecks_HandlesEfficiently()
        {
            // Arrange
            var checks = new List<IHealthCheck>();
            var mocks = new List<Mock<IHealthCheck>>();

            for (int i = 0; i < 100; i++)
            {
                var mock = new Mock<IHealthCheck>();
                mock.Setup(x => x.CheckHealthAsync()).ReturnsAsync(HealthCheckResult.Healthy($"Check {i}"));
                mocks.Add(mock);
                checks.Add(mock.Object);
            }

            var service = new HealthCheckService(checks);

            // Act
            var result = await service.CheckAll();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(100, result.Results.Count());
            Assert.IsTrue(result.Results.All(r => r.Status == HealthStatus.Healthy));
        }

        [TearDown]
        public void TearDown()
        {
            healthCheckService = null;
        }
    }
}
