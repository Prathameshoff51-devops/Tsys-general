﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.API.Controllers;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Services;
using RiskLab.UnitTests.Helpers;
using static RiskLab.API.Constants;

namespace RiskLab.UnitTests.API
{
    public class FraudServiceControllerTest
    {
        private readonly ILogger<FraudServiceController> logger;
        private readonly IIndividualTransactionsService transactionsService;

        public FraudServiceControllerTest()
        {
            logger = new Mock<ILogger<FraudServiceController>>().Object;
            transactionsService = new Mock<IIndividualTransactionsService>().Object;
        }

        [Test]
        public async Task GetRejectsbyMerchatNumber_OK()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetRejectsByMerchantNumber(It.IsAny<string>()))
                                  .Returns(await Task.FromResult(IndividualTransactionsHelper.GetRejectTxns()));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);

            var result = await controller.GetRejectsByMerchantNumber("6500");
            var resultOk = result as ObjectResult;

            Assert.IsNotNull(resultOk);
            Assert.IsInstanceOf<MerchantViewDto>(resultOk.Value);
            Assert.AreEqual(StatusCodes.Status200OK, resultOk.StatusCode);
        }

        [Test]
        public async Task GetRejectsbyMerchatNumber_InvalidMerchantNumber()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetRejectsByMerchantNumber(It.IsAny<string>()))
                                  .Returns(await Task.FromResult(IndividualTransactionsHelper.GetRejectTxns()));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);

            var result = await controller.GetRejectsByMerchantNumber("650000008840244A");
            var result400 = result as ObjectResult;

            Assert.IsNotNull(result400);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result400.StatusCode);
        }

        [Test]
        public async Task GetRejectsbyMerchatNumber_TransactionsNotFound()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetMerchantNumberFromSequenceKey(It.IsAny<int>()))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetMerchantFromSequencekey()));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);

            var result = await controller.GetRejectsByMerchantNumber("65");
            var result404 = result as ObjectResult;

            Assert.IsNotNull(result404);
            Assert.AreEqual(StatusCodes.Status404NotFound, result404.StatusCode);
            Assert.AreEqual(result404.Value, ResponseMessages.TxnsNotFound + "65");
        }

        [Test]
        public async Task GetIndividualTxnsbyMerchantSequencekey_OK()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetMerchantNumberFromSequenceKey(It.IsAny<int>()))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetMerchantFromSequencekey()));

            mockTransactionService.Setup(x => x.GetRejectsByMerchantNumber(It.IsAny<string>()))
                                  .Returns(await Task.FromResult(IndividualTransactionsHelper.GetRejectTxns()));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);
            var result = await controller.GetIndividualTxnsbyMerchantSequencekey(10);
            var resultOk = result as ObjectResult;
            Assert.IsNotNull(resultOk);
            Assert.IsInstanceOf<MerchantViewDto>(resultOk.Value);
            Assert.AreEqual(StatusCodes.Status200OK, resultOk.StatusCode);
        }

        [Test]
        public async Task GetIndividualTxnsbyMerchantSequencekey_TransactionsNotFound()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetMerchantNumberFromSequenceKey(It.IsAny<int>()))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetMerchantFromSequencekey()));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);
            var result = await controller.GetIndividualTxnsbyMerchantSequencekey(1234);
            var result404 = result as ObjectResult;
            Assert.IsNotNull(result404);
            Assert.AreEqual(StatusCodes.Status404NotFound, result404.StatusCode);
            Assert.AreEqual(result404.Value, ResponseMessages.TxnsNotFound + "650000008840244");
        }

        [Test]
        public async Task GetIndividualTxnsbyMerchantSequencekey_InvalidSequenceKey()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetMerchantNumberFromSequenceKey(It.IsAny<int>()))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetMerchantFromSequencekey()));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);
            var result = await controller.GetIndividualTxnsbyMerchantSequencekey(0);
            var result400 = result as ObjectResult;
            Assert.IsNotNull(result400);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result400.StatusCode);
        }

        [Test]
        public async Task GetIndividualTxnsbyMerchantSequencekey_MerchantNotFound()
        {
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetMerchantNumberFromSequenceKey(It.IsAny<int>()))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetMerchantFromSequencekey(It.IsAny<int>())));

            FraudServiceController controller = new FraudServiceController(logger, mockTransactionService.Object);
            var result = await controller.GetIndividualTxnsbyMerchantSequencekey(10);
            var result404 = result as ObjectResult;
            Assert.IsNotNull(result404);
            Assert.AreEqual(StatusCodes.Status404NotFound, result404.StatusCode);
        }
    }
}
