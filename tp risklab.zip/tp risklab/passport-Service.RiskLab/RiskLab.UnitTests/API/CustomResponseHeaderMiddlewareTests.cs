﻿using Microsoft.AspNetCore.Http;
using Moq;
using NUnit.Framework;
using RiskLab.API.Middleware;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    internal class CustomResponseHeaderMiddlewareTests
    {
        private readonly RequestDelegate _next;

        public CustomResponseHeaderMiddlewareTests()
        {
            _next = new Mock<RequestDelegate>().Object;
        }

        [Test]
        public async Task CustomResponseHeaderMiddleware_Successful()
        {
            //Arrange
            bool isNextDelegateCalled = false;
            var requestDelegate = new RequestDelegate(async (innerContext) =>
            {
                isNextDelegateCalled = true;

                await Task.CompletedTask;
            });
            CustomResponseHeaderMiddleware middleware = new CustomResponseHeaderMiddleware(requestDelegate);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.True(isNextDelegateCalled);
        }
    }
}
