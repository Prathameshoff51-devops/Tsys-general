﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using RiskLab.API.Middleware;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Settings;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    internal class CustomAuthenticationMiddlewareTests
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<CustomAuthenticationMiddleware> _logger;
        private readonly IOptions<ApplicationSettings> _setting;
        private readonly ITokenValidationService _tokenValidationService;

        public CustomAuthenticationMiddlewareTests()
        {
            _next = new Mock<RequestDelegate>().Object;
            _logger = new Mock<ILogger<CustomAuthenticationMiddleware>>().Object;
            _setting = new Mock<IOptions<ApplicationSettings>>().Object;
            _tokenValidationService = new Mock<ITokenValidationService>().Object;
        }

        [Test]
        public async Task CustomAuthenticationMiddleware_witherrorCode_Unauthorized()
        {
            //Arrange
            CustomAuthenticationMiddleware middleware = new CustomAuthenticationMiddleware(_next, _logger, _setting, _tokenValidationService);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.AreEqual((int)HttpStatusCode.Unauthorized, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task CustomAuthenticationMiddleware_with_appSetting()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);

            CustomAuthenticationMiddleware middleware = new CustomAuthenticationMiddleware(_next, _logger, mockApplicationSettings.Object, _tokenValidationService);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            defaultContext.Request.Headers["Authorization"] = "Token";

            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.AreEqual((int)HttpStatusCode.Unauthorized, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task CustomAuthenticationMiddleware_with_Successful()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockTokenValidationService = new Mock<ITokenValidationService>();
            mockTokenValidationService.Setup(ap => ap.IsTokenValid(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(true));

            CustomAuthenticationMiddleware middleware = new CustomAuthenticationMiddleware(_next, _logger, mockApplicationSettings.Object, mockTokenValidationService.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            defaultContext.Request.Headers["Authorization"] = "Token";

            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.AreEqual((int)HttpStatusCode.OK, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task CustomAuthenticationMiddleware_with_HttpRequestException()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockTokenValidationService = new Mock<ITokenValidationService>();
            mockTokenValidationService.Setup(ap => ap.IsTokenValid(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Throws(new HttpRequestException());

            CustomAuthenticationMiddleware middleware = new CustomAuthenticationMiddleware(_next, _logger, mockApplicationSettings.Object, mockTokenValidationService.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            defaultContext.Request.Headers["Authorization"] = "Token";

            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.AreEqual((int)HttpStatusCode.InternalServerError, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task CustomAuthenticationMiddleware_witherrorCode_InternalServerError()
        {
            //Arrange
            CustomAuthenticationMiddleware middleware = new CustomAuthenticationMiddleware(_next, _logger, _setting, _tokenValidationService);
            DefaultHttpContext defaultContext = new DefaultHttpContext();
            defaultContext.Request.Headers["Authorization"] = "Token";
            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.AreEqual((int)HttpStatusCode.InternalServerError, defaultContext.Response.StatusCode);
        }
    }
}
