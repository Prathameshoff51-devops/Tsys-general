﻿namespace RiskLab.UnitTests.API
{
    using System;
    using System.Collections.Generic;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using NUnit.Framework;
    using RiskLab.API.Controllers;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.UnitTests.Helpers;

    public class IndividualTransactionsControllerTests
    {
        private readonly ILogger<IndividualTransactionsController> logger;
        private readonly IIndividualTransactionsService transactionsService;

        public IndividualTransactionsControllerTests()
        {
            logger = new Mock<ILogger<IndividualTransactionsController>>().Object;
            transactionsService = new Mock<IIndividualTransactionsService>().Object;
        }

        #region GetTransactionsTests

        [Test]
        public async Task GetTransactions_WhenCalledForStatusNew_ReturnNewTransactions()
        {
            //Arrange
            string transactionStatus = RejectStatuses.New.ToString();
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetIndividualTransactionsByStatus(transactionStatus))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, mockTransactionService.Object);

            //Act
            var result = await controller.GetIndividualTransactions(transactionStatus);
            var okResult = result as ObjectResult;

            //Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionViewDto>>(okResult.Value);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, okResult.StatusCode);
        }

        [Test]
        public async Task GetTransactions_WhenCalledForInvalidStatus_ReturnBadRequest()
        {
            //Arrange
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, transactionsService);

            //Act
            var result = await controller.GetIndividualTransactions(It.IsAny<string>());
            var badRequestResult = result as ObjectResult;

            //Assert
            Assert.IsTrue(badRequestResult is BadRequestObjectResult);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
        }

        [Test]
        public async Task GetTransactions_WhenCalled_ReturnInternalServerError()
        {
            //Arrange
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetIndividualTransactionsByStatus(It.IsAny<string>()))
                                  .Throws(new Exception());
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, mockTransactionService.Object);

            //Act
            var result = await controller.GetIndividualTransactions("new") as ObjectResult;

            //Assert
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, result.StatusCode);
        }
        #endregion GetTransactionsTests

        #region UpdateTransactionStatusesTests
        [Test]
        public async Task UpdateTransactionStatus_WhenCalled_ReturnOk()
        {
            //Arrange
            var transactionsToUpdate = IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto();
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.UpdateIndividualTransactionStatus(transactionsToUpdate))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactionsUpdateResult()));
            mockTransactionService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, mockTransactionService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            //Act
            var result = await controller.UpdateTransactionStatuses(transactionsToUpdate);
            var okResult = result as ObjectResult;

            //Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionStatusUpdateResultDto>>(okResult.Value);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, okResult.StatusCode);
        }

        [Test]
        public async Task UpdateTransactionStatus_UserNameTampered_WhenCalledReturn401()
        {
            //Arrange
            var transactionsToUpdate = IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto();
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.UpdateIndividualTransactionStatus(transactionsToUpdate))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactionsUpdateResult()));
            mockTransactionService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, mockTransactionService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "diffrentUser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            //Act
            var result = await controller.UpdateTransactionStatuses(transactionsToUpdate);
            var inValidResult = result as ObjectResult;

            //Assert
            Assert.IsNotNull(inValidResult);
            Assert.IsTrue(inValidResult is UnauthorizedObjectResult);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status401Unauthorized, inValidResult.StatusCode);
        }

        [Test]
        public async Task UpdateTransactionStatus_WhenCalled_ReturnInternalServerError()
        {
            //Arrange
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.UpdateIndividualTransactionStatus(It.IsAny<IndividualTransactionStatusUpdateDto>()))
                                  .Throws(new Exception());
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, mockTransactionService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            //Act
            var result = await controller.UpdateTransactionStatuses(It.IsAny<IndividualTransactionStatusUpdateDto>()) as ObjectResult;

            //Assert
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, result.StatusCode);
        }
        #endregion UpdateTransactionStatusesTests

        #region GetTransactionsCountTests
        [Test]
        public async Task GetTransactionRejectsCount_WhenCalledForValidStatus_ReturnNewTransactions()
        {
            //Arrange
            string transactionStatus = RejectStatuses.New.ToString();
            var mockTransactionService = new Mock<IIndividualTransactionsService>();
            mockTransactionService.Setup(x => x.GetIndividualTransactionsByStatus(transactionStatus))
                                  .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, mockTransactionService.Object);

            //Act
            var result = await controller.GetTransactionRejectsCount(transactionStatus);
            var okResult = result as ObjectResult;

            //Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<RejectsCountDto>(okResult?.Value);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, okResult?.StatusCode);
        }

        [Test]
        public async Task GetTransactionRejectsCount_WhenCalledForInvalidStatus_ReturnBadRequest()
        {
            //Arrange
            IndividualTransactionsController controller = new IndividualTransactionsController(logger, transactionsService);

            //Act
            var result = await controller.GetTransactionRejectsCount(It.IsAny<string>());
            var badRequestResult = result as ObjectResult;

            //Assert
            Assert.IsTrue(badRequestResult is BadRequestObjectResult);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, badRequestResult?.StatusCode);
        }
        #endregion GetTransactionsCountTests
    }
}