using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.API;
using RiskLab.API.Controllers;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    [TestFixture]
    public class ExcelExportControllerTests
    {
        private Mock<ILogger<ExcelExportController>> mockLogger;
        private Mock<IExcelExportService> mockExcelExportService;
        private Mock<IIndividualTransactionsService> mockIndividualTransactionsService;
        private Mock<IBatchRejectsService> mockBatchRejectsService;
        private ExcelExportController controller;

        [SetUp]
        public void SetUp()
        {
            mockLogger = new Mock<ILogger<ExcelExportController>>();
            mockExcelExportService = new Mock<IExcelExportService>();
            mockIndividualTransactionsService = new Mock<IIndividualTransactionsService>();
            mockBatchRejectsService = new Mock<IBatchRejectsService>();

            controller = new ExcelExportController(
                mockLogger.Object,
                mockIndividualTransactionsService.Object,
                mockExcelExportService.Object,
                mockBatchRejectsService.Object);
        }

        [Test]
        public async Task ExportExcelFile_MissingPageNameAndStatus_ReturnsBadRequest()
        {
            // Arrange
            string pageName = null; // Simulate missing pageName
            string status = null;   // Simulate missing status

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidMissingParameters, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_TxnStatusGreaterThanTwo_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "individual";
            var status = "Released"; // Status corresponding to txnStatus > 2

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_ValidIndividualTransaction_ReturnsFileResult()
        {
            // Arrange
            var pageName = "individual";
            var status = "NEW";
            var mockData = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto { IndividualTxnId = 1, MerchantName = "Test" } };
            var mockExcelBytes = new byte[] { 1, 2, 3, 4 };

            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus("New"))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockExcelBytes);

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<FileResult>(result);
            var fileResult = result as FileResult;
            Assert.AreEqual("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileResult.ContentType);
            Assert.That(fileResult.FileDownloadName, Does.Contain("Individual_Transactions_New"));
        }

        [Test]
        public async Task ExportExcelFile_ValidBatchTransaction_ReturnsFileResult()
        {
            // Arrange
            var pageName = "batch";
            var status = "QUEUED";
            var mockData = new List<BatchTransactionRejectByStatusViewDto> { new BatchTransactionRejectByStatusViewDto { BatchTransactionRejectId = 1, MerchantNumber = "TestBatch" } };
            var mockExcelBytes = new byte[] { 1, 2, 3, 4 };

            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            mockBatchRejectsService
                .Setup(x => x.GetBatchTransactionRejectByStatus("Queued"))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockExcelBytes);

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<FileResult>(result);
            var fileResult = result as FileResult;
            Assert.AreEqual("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileResult.ContentType);
            Assert.That(fileResult.FileDownloadName, Does.Contain("Batch_Transactions_Queued"));
        }

        [Test]
        public async Task ExportExcelFile_NullPageName_ReturnsBadRequest()
        {
            // Arrange
            string pageName = null;
            var status = "NEW";

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidPageName, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_EmptyPageName_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "";
            var status = "NEW";

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidPageName, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_NullStatus_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "individual";
            string status = null;

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_EmptyStatus_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "individual";
            var status = "";

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_InvalidPageName_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "invalid";
            var status = "NEW";

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidPageName, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_InvalidStatus_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "individual";
            var status = "INVALID_STATUS";

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_IndividualTransactionServiceReturnsNull_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "individual";
            var status = "NEW";

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus("New"))
                .ReturnsAsync((IEnumerable<IndividualTransactionViewDto>)null);

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.TxnsNotFound, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_BatchRejectsServiceReturnsNull_ReturnsBadRequest()
        {
            // Arrange
            var pageName = "batch";
            var status = "QUEUE";

            mockBatchRejectsService
                .Setup(x => x.GetBatchTransactionRejectByStatus(status))
                .ReturnsAsync((IEnumerable<BatchTransactionRejectByStatusViewDto>)null);

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_ExceptionThrown_ReturnsInternalServerError()
        {
            // Arrange
            var pageName = "individual";
            var status = "NEW";

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus("New")) // Controller calls with enum.ToString() which is "New"
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objectResult = result as ObjectResult;
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, objectResult.StatusCode);
            Assert.AreEqual(Constants.ResponseMessages.ErrorResponseMessage, objectResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_ExcelExportServiceThrowsException_ReturnsTxnsNotFound()
        {
            // Arrange
            var pageName = "individual";
            var status = "NEW";
            var mockData = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto { IndividualTxnId = 1, MerchantName = "Test" } };

            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus(status))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new Exception("Excel export failed"));

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objectResult = result as ObjectResult;
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, objectResult.StatusCode);
            Assert.AreEqual(Constants.ResponseMessages.TxnsNotFound, objectResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_ExcelExportServiceThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            var pageName = "individual";
            var status = "NEW";
            var mockData = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto { IndividualTxnId = 1, MerchantName = "Test" } };

            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus("New"))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new Exception("Excel export failed"));

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objectResult = result as ObjectResult;
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status500InternalServerError, objectResult.StatusCode);
            Assert.AreEqual(Constants.ResponseMessages.ErrorResponseMessage, objectResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_ValidIndividualTransactionWithDifferentStatuses_ReturnsFileResult(
            [Values("NEW", "QUEUED")] string status)
        {
            // Arrange
            var pageName = "individual";
            var expectedEnumValue = GetExpectedEnumValue(status);
            var mockData = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto { IndividualTxnId = 1, MerchantName = status } };
            var mockExcelBytes = new byte[] { 1, 2, 3, 4 };

            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus(expectedEnumValue))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockExcelBytes);

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<FileResult>(result);
            var fileResult = result as FileResult;
            Assert.That(fileResult.FileDownloadName, Does.Contain($"Individual_Transactions_{expectedEnumValue}"));
        }

        [Test]
        public async Task ExportExcelFile_ValidBatchTransactionWithDifferentStatuses_ReturnsFileResult(
            [Values("NEW", "QUEUED")] string status)
        {
            // Arrange
            var pageName = "batch";
            var expectedEnumValue = GetExpectedEnumValue(status);
            var mockData = new List<BatchTransactionRejectByStatusViewDto> { new BatchTransactionRejectByStatusViewDto { BatchTransactionRejectId = 1, MerchantNumber = status } };
            var mockExcelBytes = new byte[] { 1, 2, 3, 4 };

            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            mockBatchRejectsService
                .Setup(x => x.GetBatchTransactionRejectByStatus(expectedEnumValue))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockExcelBytes);

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<FileResult>(result);
            var fileResult = result as FileResult;
            Assert.That(fileResult.FileDownloadName, Does.Contain($"Batch_Transactions_{expectedEnumValue}"));
        }

        [Test]
        public async Task ExportExcelFile_CaseInsensitivePageName_ReturnsFileResult()
        {
            // Arrange
            var pageName = "INDIVIDUALS"; // This should return BadRequest since controller is case-sensitive
            var status = "NEW";

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidPageName, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_CaseInsensitiveStatus_ReturnsFileResult()
        {
            // Arrange
            var pageName = "individual";
            var status = "new";
            var mockData = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto { IndividualTxnId = 1, MerchantName = "Test" } };
            var mockExcelBytes = new byte[] { 1, 2, 3, 4 };

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus("New"))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockExcelBytes);
            // Set up a real HttpContext with mutable Response.Headers
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.Response.Headers.Clear(); // Fix: Ensure httpContext is declared before using it.
            controller.ControllerContext = new ControllerContext { HttpContext = httpContext };

            // Act
            var result = await controller.ExportExcelFile(pageName, status);

            // Assert
            Assert.IsInstanceOf<FileResult>(result);
        }

        [Test]
        public async Task ExportExcelFile_VerifyServiceCallsWithCorrectParameters()
        {
            // Arrange
            var pageName = "individual";
            var status = "NEW";
            var mockData = new List<IndividualTransactionViewDto> { new IndividualTransactionViewDto { IndividualTxnId = 1, MerchantName = "Test" } };
            var mockExcelBytes = new byte[] { 1, 2, 3, 4 };

            mockIndividualTransactionsService
                .Setup(x => x.GetIndividualTransactionsByStatus("New"))
                .ReturnsAsync(mockData);

            mockExcelExportService
                .Setup(x => x.ExportJsonTOExcel(It.IsAny<JsonElement>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockExcelBytes);

            // Act
            await controller.ExportExcelFile(pageName, status);

            // Assert
            mockIndividualTransactionsService.Verify(x => x.GetIndividualTransactionsByStatus("New"), Times.Once);
            mockExcelExportService.Verify(
                x => x.ExportJsonTOExcel(
                It.IsAny<JsonElement>(),
                "Individual_Transactions_New",
                "New"), Times.Once);
        }

        [Test]
        public async Task ExportExcelFile_InvalidStatus_ReturnsBadRequest_Bndividual()
        {
            // Arrange
            var pageName = "individual";
            var invalidStatus = "INVALID_STATUS";

            // Act
            var result = await controller.ExportExcelFile(pageName, invalidStatus);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        [Test]
        public async Task ExportExcelFile_InvalidStatus_ReturnsBadRequest_Batch()
        {
            // Arrange
            var pageName = "batch";
            var invalidStatus = "INVALID_STATUS";

            // Act
            var result = await controller.ExportExcelFile(pageName, invalidStatus);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
            var badRequestResult = result as BadRequestObjectResult;
            Assert.AreEqual(Constants.ResponseMessages.InvalidTransactionStatus, badRequestResult.Value);
        }

        private string GetExpectedEnumValue(string input)
        {
            return input switch
            {
                "NEW" => "New",
                "QUEUED" => "Queued",
                "RELEASED" => "Released",
                "DELETED" => "Deleted",
                _ => input
            };
        }
    }
}
