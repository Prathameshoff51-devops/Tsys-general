﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using RiskLab.API.Middleware;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Settings;
using RiskLab.UnitTests.Helpers;
using System;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    internal class MyAuthorizationMiddlewareResultHandlerTests
    {
        private readonly RequestDelegate _next;
        private readonly IUserRepository _userRepository;
        private readonly ILogger<MyAuthorizationMiddlewareResultHandler> _logger;
        private readonly IRoleRepository _roleRepository;

        public MyAuthorizationMiddlewareResultHandlerTests()
        {
            _next = new Mock<RequestDelegate>().Object;
            _userRepository = new Mock<IUserRepository>().Object;
            _logger = new Mock<ILogger<MyAuthorizationMiddlewareResultHandler>>().Object;
            _roleRepository = new Mock<IRoleRepository>().Object;
        }

        [Test]
        public async Task MyAuthorizationMiddlewareResultHandler_Successful()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockUserRepository = new Mock<IUserRepository>();
            var mockRoleRepository = new Mock<IRoleRepository>();
            User user1 = new User()
            {
                Email = It.IsAny<string>(),
                LoginName = string.Empty,
                Id = 1,
            };
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier", "testuser@e-hps.com"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "RiskLab"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "Fraud Service Details"),
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));
            mockUserRepository.Setup(x => x.GetUserByEmail(It.IsAny<string>()))
                                  .Returns(Task.FromResult(user1));
            mockRoleRepository.Setup(x => x.GetUserRoles(It.IsAny<int>()))
                                  .Returns(Task.FromResult(RoleRepositoryHelper.GetUserRoles()));

            MyAuthorizationMiddlewareResultHandler middleware = new MyAuthorizationMiddlewareResultHandler(_next, _logger, mockUserRepository.Object, mockRoleRepository.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext() { User = user };

            //Act
            await middleware.Invoke(defaultContext);

            // Assert
            Assert.AreEqual((int)HttpStatusCode.OK, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task MyAuthorizationMiddlewareResultHandler_Unauthorized()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockUserRepository = new Mock<IUserRepository>();
            var mockRoleRepository = new Mock<IRoleRepository>();
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier", ""),
            }, "mock"));

            MyAuthorizationMiddlewareResultHandler middleware = new MyAuthorizationMiddlewareResultHandler(_next, _logger, mockUserRepository.Object, mockRoleRepository.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext() { User = user };

            //Act
            await middleware.Invoke(defaultContext);
            // Assert
            Assert.AreEqual((int)HttpStatusCode.Unauthorized, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task MyAuthorizationMiddlewareResultHandler_with_nouser()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockUserRepository = new Mock<IUserRepository>();
            var mockRoleRepository = new Mock<IRoleRepository>();
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier", "testuser@e-hps.com"),
            }, "mock"));
            MyAuthorizationMiddlewareResultHandler middleware = new MyAuthorizationMiddlewareResultHandler(_next, _logger, mockUserRepository.Object, mockRoleRepository.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext() { User = user };

            //Act
            await middleware.Invoke(defaultContext);

            // Assert
            Assert.AreEqual((int)HttpStatusCode.Unauthorized, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task MyAuthorizationMiddlewareResultHandler_Forbidden()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockUserRepository = new Mock<IUserRepository>();
            var mockRoleRepository = new Mock<IRoleRepository>();
            User user1 = new User()
            {
                Email = It.IsAny<string>(),
                LoginName = string.Empty,
                Id = 1,
            };
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier", "testuser@e-hps.com"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "RiskLab"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "Fraud Service Details"),
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));
            mockUserRepository.Setup(x => x.GetUserByEmail(It.IsAny<string>()))
                                  .Returns(Task.FromResult(user1));
            MyAuthorizationMiddlewareResultHandler middleware = new MyAuthorizationMiddlewareResultHandler(_next, _logger, mockUserRepository.Object, mockRoleRepository.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext() { User = user };

            //Act
            await middleware.Invoke(defaultContext);

            // Assert
            Assert.AreEqual((int)HttpStatusCode.Forbidden, defaultContext.Response.StatusCode);
        }

        [Test]
        public async Task MyAuthorizationMiddlewareResultHandler_Exception()
        {
            //Arrange
            ApplicationSettings appSetting = new ApplicationSettings() { Issuer = string.Empty, AuthorizationServer = string.Empty, IntrospectEndPoint = string.Empty };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var mockUserRepository = new Mock<IUserRepository>();
            var mockRoleRepository = new Mock<IRoleRepository>();
            User user1 = new User()
            {
                Email = It.IsAny<string>(),
                LoginName = string.Empty,
                Id = 1,
            };
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier", "testuser@e-hps.com"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "RiskLab"),
                new Claim("http://schemas.microsoft.com/ws/2008/06/identity/claims/role", "Fraud Service Details"),
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));
            mockUserRepository.Setup(x => x.GetUserByEmail(It.IsAny<string>()))
                                  .Throws(new Exception());
            MyAuthorizationMiddlewareResultHandler middleware = new MyAuthorizationMiddlewareResultHandler(_next, _logger, mockUserRepository.Object, mockRoleRepository.Object);
            DefaultHttpContext defaultContext = new DefaultHttpContext() { User = user };

            //Act
            await middleware.Invoke(defaultContext);

            // Assert
            Assert.AreEqual((int)HttpStatusCode.Forbidden, defaultContext.Response.StatusCode);
        }
    }
}
