﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.API.Controllers;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Services;
using RiskLab.UnitTests.Helpers;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.API
{
    public class BatchTransactionRejectsControllerTests
    {
        private readonly ILogger<BatchTransactionRejectsController> logger;
        private readonly IBatchRejectsService batchRejectsService;
        private readonly IUserService userService;

        public BatchTransactionRejectsControllerTests()
        {
            logger = new Mock<ILogger<BatchTransactionRejectsController>>().Object;
            batchRejectsService = new Mock<IBatchRejectsService>().Object;
            userService = new Mock<IUserService>().Object;
        }

        [Test]
        public async Task GetBatchTransactionRejects_WhenCalledForValidBatchRejectId_ReturnBatchTxnRejects()
        {
            // Arrange
            int batchRejectId = 1234;
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.GetBatchTransactionRejects(batchRejectId))
                .Returns(Task.FromResult(BatchTransactionRejectsHelper.GetBatchTransactionRejects(batchRejectId)));
            var batchTxnRejectsController = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, userService);

            // Act
            var result = await batchTxnRejectsController.GetBatchTransactionRejects(batchRejectId);
            var okResult = result as ObjectResult;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<BatchTransactionRejectsViewDto>(okResult.Value);
            Assert.AreEqual(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, okResult.StatusCode);
        }

        [Test]
        public async Task GetBatchTransactionRejects_WhenCalledForInvalidBatchRejectId_ReturnStatusNotFound()
        {
            // Arrange
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.GetBatchTransactionRejects(It.IsAny<int>()))
                .Returns(Task.FromResult(BatchTransactionRejectsHelper.GetBatchTransactionRejects(1)));
            var batchTxnRejectsController = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, userService);

            // Act
            var result = await batchTxnRejectsController.GetBatchTransactionRejects(It.IsAny<int>());
            var notFoundResult = result as NotFoundObjectResult;

            // Assert
            Assert.IsTrue(notFoundResult is NotFoundObjectResult);
            Assert.AreEqual(StatusCodes.Status404NotFound, notFoundResult.StatusCode);
        }

        [Test]
        public async Task GetBatchRejects_WhenCalled_ReturnInternalServerError()
        {
            //Arrange
            var mockBatchRejectsService = new Mock<IBatchRejectsService>();
            mockBatchRejectsService.Setup(x => x.GetBatchTransactionRejects(It.IsAny<int>()))
                                  .Throws(new Exception());
            BatchTransactionRejectsController controller = new BatchTransactionRejectsController(logger, mockBatchRejectsService.Object, userService);

            //Act
            var result = await controller.GetBatchTransactionRejects(It.IsAny<int>()) as ObjectResult;

            //Assert
            Assert.AreEqual(StatusCodes.Status500InternalServerError, result.StatusCode);
        }

        [Test]
        public async Task UpdateBatchTransactionRejectsStatus_WhenCalled_ReturnOk()
        {
            // Arrange
            var batchRejectToUpdate = BatchTransactionRejectsHelper.GetBatchTransactionRejectsUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.UpdateBatchTransactionRejects(batchRejectToUpdate))
                                  .Returns(Task.FromResult(BatchTransactionRejectsHelper.GetBatchTransactionRejectsStatusUpdateResult()));
            mockBatchRejectService.Setup(x => x.GetBatchRejectById(batchRejectToUpdate.BatchRejectId))
                                  .Returns(Task.FromResult(new BatchRejectViewDto() { }));
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            BatchTransactionRejectsController controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            // Act
            var result = await controller.UpdateBatchTransactionsStatus(batchRejectToUpdate);
            var okResult = result as ObjectResult;

            // Assert
            Assert.IsNotNull(okResult);
            Assert.IsTrue(okResult is OkObjectResult);
            Assert.IsInstanceOf<BatchTransactionRejectsStatusUpdateResultDto>(okResult.Value);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);
        }

        [Test]
        public async Task UpdateBatchTransactionRejectsStatus_WhenCalledWithInvalidBatch_ReturnBadRequest()
        {
            // Arrange
            var batchRejectToUpdate = BatchTransactionRejectsHelper.GetBatchTransactionRejectsUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.UpdateBatchTransactionRejects(batchRejectToUpdate))
                                  .Returns(Task.FromResult(BatchTransactionRejectsHelper.GetBatchTransactionRejectsStatusUpdateResult()));
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            BatchTransactionRejectsController controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "testuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            // Act
            var result = await controller.UpdateBatchTransactionsStatus(batchRejectToUpdate);
            var badRequestResult = result as ObjectResult;

            // Assert
            Assert.IsNotNull(badRequestResult);
            Assert.IsTrue(badRequestResult is BadRequestObjectResult);
            Assert.AreEqual(StatusCodes.Status400BadRequest, badRequestResult.StatusCode);
        }

        [Test]
        public async Task UpdateBatchTransactionRejectsStatus_WhenCalledWithTamperedUserName_ReturnUnauthorized()
        {
            // Arrange
            var batchRejectToUpdate = BatchTransactionRejectsHelper.GetBatchTransactionRejectsUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockBatchRejectService.Setup(x => x.UpdateBatchTransactionRejects(batchRejectToUpdate))
                                  .Returns(Task.FromResult(BatchTransactionRejectsHelper.GetBatchTransactionRejectsStatusUpdateResult()));
            mockBatchRejectService.Setup(x => x.GetBatchRejectById(batchRejectToUpdate.BatchRejectId))
                                  .Returns(Task.FromResult(new BatchRejectViewDto() { }));
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .Returns(Task.FromResult(true));
            BatchTransactionRejectsController controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
            {
                new Claim("RiskUserClaimName", "differentuser@e-hps.com"),
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            // Act
            var result = await controller.UpdateBatchTransactionsStatus(batchRejectToUpdate);
            var invalidResult = result as ObjectResult;

            // Assert
            Assert.IsNotNull(invalidResult);
            Assert.IsTrue(invalidResult is UnauthorizedObjectResult);
            Assert.AreEqual(StatusCodes.Status401Unauthorized, invalidResult.StatusCode);
        }

        [Test]
        public async Task UpdateBatchTransactionRejectsStatus_WhenCalled_ReturnInternalServerError()
        {
            // Arrange
            var batchRejectToUpdate = BatchTransactionRejectsHelper.GetBatchTransactionRejectsUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .ThrowsAsync(new Exception("Service error"));
            BatchTransactionRejectsController controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBatchTransactionsStatus(batchRejectToUpdate) as ObjectResult;

            // Assert
            Assert.AreEqual(StatusCodes.Status500InternalServerError, result.StatusCode);
        }

        [Test]
        public async Task UpdateBatchTransactionRejectsStatus_WhenUserIsInvalid_ReturnBadRequest()
        {
            // Arrange
            var batchRejectToUpdate = BatchTransactionRejectsHelper.GetBatchTransactionRejectsUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();
            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                                  .ReturnsAsync(false);
            BatchTransactionRejectsController controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBatchTransactionsStatus(batchRejectToUpdate) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result.StatusCode);
            Assert.AreEqual("Invalid User.", result.Value);
        }

        #region Bulk Update Tests

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenCalled_ReturnOk()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(bulkUpdate.UserName))
                          .ReturnsAsync(true);

            mockBatchRejectService.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                 .ReturnsAsync(new BatchRejectViewDto());

            mockBatchRejectService.Setup(x => x.UpdateBulkBatchTransactionRejects(bulkUpdate))
                                 .ReturnsAsync(GetBulkUpdateResult());

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);
            SetupControllerContext(controller, bulkUpdate.UserName);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status200OK, result.StatusCode);
            Assert.IsInstanceOf<BatchTransactionRejectsStatusUpdateResultDto>(result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenUserIsInvalid_ReturnBadRequest()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                          .ReturnsAsync(false);

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result.StatusCode);
            Assert.AreEqual("Invalid User.", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenBatchTransactionsStatusIsNull_ReturnBadRequest()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            bulkUpdate.BatchTransactionsStatus = null;
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                          .ReturnsAsync(true);

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result.StatusCode);
            Assert.AreEqual("Invalid Transaction Status.", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenBatchTransactionsStatusIsEmpty_ReturnBadRequest()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            bulkUpdate.BatchTransactionsStatus = new List<BatchTransactionStatusUpdate>();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                          .ReturnsAsync(true);

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result.StatusCode);
            Assert.AreEqual("Invalid Transaction Status.", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenBatchRejectNotFound_ReturnBadRequest()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                          .ReturnsAsync(true);

            mockBatchRejectService.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                 .ReturnsAsync((BatchRejectViewDto)null);

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result.StatusCode);
            Assert.AreEqual("Batch Reject not found", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenUserClaimDoesNotMatch_ReturnUnauthorized()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(bulkUpdate.UserName))
                          .ReturnsAsync(true);

            mockBatchRejectService.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                 .ReturnsAsync(new BatchRejectViewDto());

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);
            SetupControllerContext(controller, "differentuser@e-hps.com");

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as UnauthorizedObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status401Unauthorized, result.StatusCode);
            Assert.AreEqual("Invalid User.", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenMultipleBatchRejectIds_ValidatesAll()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdateWithMultipleBatches();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(bulkUpdate.UserName))
                          .ReturnsAsync(true);

            // First batch exists, second doesn't
            mockBatchRejectService.Setup(x => x.GetBatchRejectById(1234))
                                 .ReturnsAsync(new BatchRejectViewDto());
            mockBatchRejectService.Setup(x => x.GetBatchRejectById(1235))
                                 .ReturnsAsync((BatchRejectViewDto)null);

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status400BadRequest, result.StatusCode);
            Assert.AreEqual("Batch Reject not found", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenExceptionThrown_ReturnInternalServerError()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(It.IsAny<string>()))
                          .ThrowsAsync(new Exception("Service error"));

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as ObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status500InternalServerError, result.StatusCode);
            Assert.AreEqual("An exception was encountered while processing your request.  Please contact technical support for more information.", result.Value);
        }

        [Test]
        public async Task UpdateBulkBatchTransactionsStatus_WhenNoClaims_ReturnUnauthorized()
        {
            // Arrange
            var bulkUpdate = GetBulkBatchTransactionRejectsStatusUpdate();
            var mockUserService = new Mock<IUserService>();
            var mockBatchRejectService = new Mock<IBatchRejectsService>();

            mockUserService.Setup(x => x.IsUserValid(bulkUpdate.UserName))
                          .ReturnsAsync(true);

            mockBatchRejectService.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                 .ReturnsAsync(new BatchRejectViewDto());

            var controller = new BatchTransactionRejectsController(logger, mockBatchRejectService.Object, mockUserService.Object);

            // Setup context without the required claim
            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[] { }, "mock"));
            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };

            // Act
            var result = await controller.UpdateBulkBatchTransactionsStatus(bulkUpdate) as UnauthorizedObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(StatusCodes.Status401Unauthorized, result.StatusCode);
            Assert.AreEqual("Invalid User.", result.Value);
        }

        #endregion

        #region Helper Methods

        private BatchTransactionRejectsStatusUpdateDto GetBulkBatchTransactionRejectsStatusUpdate()
        {
            return new BatchTransactionRejectsStatusUpdateDto
            {
                UserName = "testuser@e-hps.com",
                BatchTransactionsStatus = new List<BatchTransactionStatusUpdate>
                {
                    new BatchTransactionStatusUpdate
                    {
                        BatchRejectId = 1234,
                        BatchTransactionRejectId = 1,
                        NewStatus = "Released",
                    },
                    new BatchTransactionStatusUpdate
                    {
                        BatchRejectId = 1234,
                        BatchTransactionRejectId = 2,
                        NewStatus = "Queued",
                    },
                },
            };
        }

        private BatchTransactionRejectsStatusUpdateDto GetBulkBatchTransactionRejectsStatusUpdateWithMultipleBatches()
        {
            return new BatchTransactionRejectsStatusUpdateDto
            {
                UserName = "testuser@e-hps.com",
                BatchTransactionsStatus = new List<BatchTransactionStatusUpdate>
                {
                    new BatchTransactionStatusUpdate
                    {
                        BatchRejectId = 1234,
                        BatchTransactionRejectId = 1,
                        NewStatus = "Released",
                    },
                    new BatchTransactionStatusUpdate
                    {
                        BatchRejectId = 1235,
                        BatchTransactionRejectId = 2,
                        NewStatus = "Queued",
                    },
                },
            };
        }

        private BatchTransactionRejectsStatusUpdateResultDto GetBulkUpdateResult()
        {
            return new BatchTransactionRejectsStatusUpdateResultDto
            {
                BatchRejectId = 1234,
                BatchTransactionRejectUpdateStatuses = new List<BatchTransactionRejectUpdateStatus>
                {
                    new BatchTransactionRejectUpdateStatus
                    {
                        BatchTransactionRejectId = 1,
                        StatusCode = "200",
                        UpdateStatus = "Success",
                    },
                },
            };
        }

        private void SetupControllerContext(BatchTransactionRejectsController controller, string userClaimValue)
        {
            var user = new ClaimsPrincipal(new ClaimsIdentity(
                new Claim[]
                {
                    new Claim("RiskUserClaimName", userClaimValue),
                }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user },
            };
        }

        #endregion
    }
}
