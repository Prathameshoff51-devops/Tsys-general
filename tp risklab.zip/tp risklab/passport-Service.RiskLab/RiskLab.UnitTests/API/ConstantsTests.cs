using Microsoft.AspNetCore.Http;
using NUnit.Framework;
using RiskLab.API;

namespace RiskLab.UnitTests.API
{
    [TestFixture]
    public class ConstantsTests
    {
        [Test]
        public void AppSettings_Constants_AreCorrect()
        {
            Assert.AreEqual("RiskLabApiUrl", Constants.AppSettings.RiskLabApiUrl);
            Assert.AreEqual("RiskLabUrl", Constants.AppSettings.RiskLabUiUrl);
            Assert.AreEqual("RiskLabApiKey", Constants.AppSettings.ApiKey);
            Assert.AreEqual("RiskLabClientId", Constants.AppSettings.AzureADClientId);
            Assert.AreEqual("RiskLabClientSecret", Constants.AppSettings.AzureADSecret);
            Assert.AreEqual("MinimumSearchLength", Constants.AppSettings.MinimumSearchLength);
            Assert.AreEqual("DefaultGridPageSize", Constants.AppSettings.DefaultGridPageSize);
            Assert.AreEqual("DefaultBatchGridPageSize", Constants.AppSettings.DefaultBatchGridPageSize);
            Assert.AreEqual("DefaultBackOfficeGridPageSize", Constants.AppSettings.DefaultBackOfficeGridPageSize);
            Assert.AreEqual("DaysToAct", Constants.AppSettings.DaysToAct);
            Assert.AreEqual("CoreLoggingServiceUrl", Constants.AppSettings.CoreLoggingServiceUrl);
            Assert.AreEqual("RiskLabRabbitMqConnection", Constants.AppSettings.RiskLabRabbitMqConnection);
            CollectionAssert.AreEqual(new[] { "openid", "userInfo" }, Constants.AppSettings.StandardScopes);
        }

        [Test]
        public void OktaSettings_Constants_AreCorrect()
        {
            Assert.AreEqual("Issuer", Constants.OktaSettings.Issuer);
            Assert.AreEqual("Audience", Constants.OktaSettings.Audience);
            Assert.AreEqual("AuthorizationServer", Constants.OktaSettings.AuthorizationServer);
            Assert.AreEqual("IntrospectEndPoint", Constants.OktaSettings.IntrospectEndpoint);
            Assert.AreEqual("Client_Id", Constants.OktaSettings.Client_Id);
        }

        [Test]
        public void Routes_Constants_AreCorrect()
        {
            Assert.AreEqual("api/v1/[controller]", Constants.Routes.DefaultRouteV1);
        }

        [Test]
        public void UserClaim_Constants_AreCorrect()
        {
            Assert.AreEqual("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier", Constants.UserClaim.NameIdentifier);
            Assert.AreEqual("RiskUserClaimName", Constants.UserClaim.RiskUserClaimName);
        }

        [Test]
        public void UserRole_Constants_AreCorrect()
        {
            Assert.AreEqual("RiskLab", Constants.UserRole.RiskLab);
            Assert.AreEqual("Fraud Service Details", Constants.UserRole.FraudServiceDetailsRole);
        }

        [Test]
        public void ResponseMessages_Constants_AreCorrect()
        {
            Assert.AreEqual("An exception was encountered while processing your request.  Please contact technical support for more information.", Constants.ResponseMessages.ErrorResponseMessage);
            Assert.AreEqual("Invalid User.", Constants.ResponseMessages.InvalidUser);
            Assert.AreEqual("Invalid Transaction Status.", Constants.ResponseMessages.InvalidTransactionStatus);
            Assert.AreEqual("Provided merchant number is invalid.", Constants.ResponseMessages.InvalidMerchantNumber);
            Assert.AreEqual("Provided merchant sequence key is invalid.", Constants.ResponseMessages.InvalidMerchantSequenceKey);
            Assert.AreEqual("Rejected transactions not found for the merchant number ", Constants.ResponseMessages.TxnsNotFound);
            Assert.AreEqual("Merchant not Found.", Constants.ResponseMessages.MerchantFound);
            Assert.AreEqual("Invalid batch status.", Constants.ResponseMessages.InvalidBatchStatus);
            Assert.AreEqual("Batch Reject not found", Constants.ResponseMessages.BatchRejectNotFound);
            Assert.AreEqual("Invalid Rejected Refunds Type.", Constants.ResponseMessages.InvalidPageName);
            Assert.AreEqual("Missing Required Parameters.", Constants.ResponseMessages.InvalidMissingParameters);
        }

        // The error CS0200 indicates that the 'Headers' property of 'HttpResponse' is read-only and cannot be directly assigned.
        // To fix this, you need to modify the headers using the appropriate methods or indexers provided by the 'IHeaderDictionary' interface.
        // Below is an example of how to set a header value correctly:

        [Test]
        public void SetResponseHeader_Correctly()
        {
            // Arrange
            var context = new DefaultHttpContext();
            var response = context.Response;

            // Act
            response.Headers["Custom-Header"] = "HeaderValue";

            // Assert
            Assert.AreEqual("HeaderValue", response.Headers["Custom-Header"]);
        }
    }
}
