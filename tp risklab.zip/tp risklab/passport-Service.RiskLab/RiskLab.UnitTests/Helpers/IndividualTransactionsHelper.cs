﻿namespace RiskLab.UnitTests.Helpers
{
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Entities;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class IndividualTransactionsHelper
    {
        public static IEnumerable<IndividualTransactionViewDto> GetTransactions()
        {
            return new List<IndividualTransactionViewDto>()
            {
                new IndividualTransactionViewDto
                {
                    IndividualTxnId = 1,
                    MessageId = Guid.NewGuid(),
                    TxnUuid = 1,
                    TxnDetailId = 1,
                    MerchantNumber = "65002343244",
                    MerchantName = "Test Merchant 1",
                    LegalName = "Test Merchant 1",
                    ChainOID = "34543545",
                    MCC = "1234",
                    Amount = 100,
                    CardNumberMask = "1234************",
                    TxnDateUtc = DateTime.Now.AddDays(-20),
                    FraudRejectReasonCodes = new List<string> { "Fraudulent BIN" },
                    OriginalBatchNumber = "000645",
                    AuthCode = "354354",
                    ExpDate = DateTime.Now.AddDays(100),
                    TxnTypeDescription = "Sale",
                    BatchCloseDate = DateTime.Now.AddDays(-19),
                    SubmitterIDDescription = "HPSE",
                    DaysToAct = 70,
                },
                new IndividualTransactionViewDto
                {
                    IndividualTxnId = 2,
                    MessageId = Guid.NewGuid(),
                    TxnUuid = 2,
                    TxnDetailId = 2,
                    MerchantNumber = "65002343245",
                    MerchantName = "Test Merchant 2",
                    LegalName = "Test Merchant 2",
                    ChainOID = "34543546",
                    MCC = "1235",
                    Amount = 200,
                    CardNumberMask = "1234************",
                    TxnDateUtc = DateTime.Now.AddDays(-20),
                    FraudRejectReasonCodes = new List<string> { "Fraudulent BIN" },
                    OriginalBatchNumber = "000654",
                    AuthCode = "354355",
                    ExpDate = DateTime.Now.AddDays(100),
                    TxnTypeDescription = "Sale",
                    BatchCloseDate = DateTime.Now.AddDays(-19),
                    SubmitterIDDescription = "HPSE",
                    DaysToAct = 70,
                },
            };
        }

        public static IndividualTransactionViewDto GetTransaction()
        {
            return new IndividualTransactionViewDto
            {
                IndividualTxnId = 1,
                MessageId = Guid.NewGuid(),
                TxnUuid = 1,
                TxnDetailId = 1,
                MerchantNumber = "65002343244",
                MerchantName = "Test Merchant 1",
                LegalName = "Test Merchant 1",
                ChainOID = "34543545",
                MCC = "1234",
                Amount = 100,
                CardNumberMask = "1234************",
                TxnDateUtc = DateTime.Now.AddDays(-20),
                FraudRejectReasonCodes = new List<string> { "Fraudulent BIN" },
                OriginalBatchNumber = "000645",
                AuthCode = "354354",
                ExpDate = DateTime.Now.AddDays(100),
                TxnTypeDescription = "Sale",
                BatchCloseDate = DateTime.Now.AddDays(-19),
                SubmitterIDDescription = "HPSE",
                DaysToAct = 70,
            };
        }

        public static IndividualTransactionViewDto GetTransaction_With_status()
        {
            return new IndividualTransactionViewDto
            {
                IndividualTxnId = 1,
                MessageId = Guid.NewGuid(),
                TxnUuid = 1,
                TxnDetailId = 1,
                MerchantNumber = "65002343244",
                MerchantName = "Test Merchant 1",
                LegalName = "Test Merchant 1",
                ChainOID = "34543545",
                MCC = "1234",
                Amount = 100,
                CardNumberMask = "1234************",
                TxnDateUtc = DateTime.Now.AddDays(-20),
                FraudRejectReasonCodes = new List<string> { "Fraudulent BIN" },
                OriginalBatchNumber = "000645",
                AuthCode = "354354",
                ExpDate = DateTime.Now.AddDays(100),
                TxnTypeDescription = "Sale",
                BatchCloseDate = DateTime.Now.AddDays(-19),
                SubmitterIDDescription = "HPSE",
                DaysToAct = 70,
                Status = RejectStatuses.New.ToString(),
            };
        }

        public static IndividualTransactionStatusUpdateDto GetIndividualTransactionStatusUpdateDto()
        {
            return new IndividualTransactionStatusUpdateDto
            {
                UserName = "testuser@e-hps.com",
                TransactionsStatus = new List<TransactionStatus>
                {
                    new TransactionStatus { TransactionId = 1, NewStatus = RejectStatuses.Queued.ToString() },
                    new TransactionStatus { TransactionId = 2, NewStatus = RejectStatuses.Queued.ToString() },
                },
            };
        }

        public static IEnumerable<IndividualTransactionStatusUpdateResultDto> GetTransactionsUpdateResult()
        {
            return new List<IndividualTransactionStatusUpdateResultDto>
            {
                new IndividualTransactionStatusUpdateResultDto { TransactionId = 1, UpdateStatus = "Success", StatusCode = "200" },
                new IndividualTransactionStatusUpdateResultDto { TransactionId = 2, UpdateStatus = "Failed", StatusCode = "400" },
            };
        }

        public static async Task<IEnumerable<MerchantRejects>> GetRejectTxns()
        {
            return new List<MerchantRejects>
           {
               new MerchantRejects
                {
                    Id = 1,
                    MerchantName = "Test Merchant",
                    Amount = 100,
                    BatchNumber = "10",
                    TxnDateUtc = DateTime.Now,
                    CardNumberMask = "6011000000007322",
                    FraudRejectReasonCodes = new List<string> { "Batch threshold exceeded", "Fraudulent BIN" },
                    BusinessDateUtc = DateTime.Now,
                    Status = "Pending Risk Review",
                    StatusDate = DateTime.Now,
                    TxnTypeDescription = "Refund",
                },
           };
        }

        public static Merchant GetMerchantFromSequencekey()
        {
            return new Merchant()
            {
                MerchantName = "Test Merchant",
                MerchantNumber = "650000008840244",
            };
        }

        public static Merchant GetMerchantFromSequencekey(int sequenceKey)
        {
            return null;
        }
    }
}