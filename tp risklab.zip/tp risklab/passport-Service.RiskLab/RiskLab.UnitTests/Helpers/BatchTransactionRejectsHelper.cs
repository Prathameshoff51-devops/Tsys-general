﻿using System;
using System.Collections.Generic;
using System.Linq;
using RiskLab.Core.Dtos;

namespace RiskLab.UnitTests.Helpers
{
    public class BatchTransactionRejectsHelper
    {
        private static List<BatchTransactionRejectsViewDto> batchTransactionRejects = new List<BatchTransactionRejectsViewDto>()
        {
            new BatchTransactionRejectsViewDto()
            {
               BatchRejectId = 1234,
               BatchAmount = 100,
               BatchCloseDateUTC = DateTime.UtcNow,
               MerchantName = "Test Merchant",
               MerchantNumber = "6500000000000",
               OriginalBatchNumber = "012345",
               Status = "New",
               Transactions = new List<BatchTransactionRejectViewDto>()
               {
                    new BatchTransactionRejectViewDto()
                    {
                        BatchTransactionRejectId = 1,
                        BatchRejectId = 1234,
                        CardNumberMasked = "1234********1234",
                        RejectReasons = new List<string>() { "Reason 1", "Reason 2" },
                        Status = "New",
                        TxnAmount = 50,
                        TxnType = "Refund",
                        TxnDateUTC = DateTime.UtcNow,
                    },
                    new BatchTransactionRejectViewDto()
                    {
                        BatchTransactionRejectId = 2,
                        BatchRejectId = 1234,
                        CardNumberMasked = "1234********1234",
                        RejectReasons = new List<string>() { "Reason 1" },
                        Status = "New",
                        TxnAmount = 50,
                        TxnType = "Refund",
                        TxnDateUTC = DateTime.UtcNow,
                    },
               },
            },
            new BatchTransactionRejectsViewDto()
            {
               BatchRejectId = 1235,
               BatchAmount = 200,
               BatchCloseDateUTC = DateTime.UtcNow,
               MerchantName = "Test Merchant",
               MerchantNumber = "6500000000000",
               OriginalBatchNumber = "012346",
               Status = "Queued",
               Transactions = new List<BatchTransactionRejectViewDto>()
               {
                    new BatchTransactionRejectViewDto()
                    {
                        BatchTransactionRejectId = 1,
                        BatchRejectId = 1235,
                        CardNumberMasked = "1234********1234",
                        RejectReasons = new List<string>() { "Reason 1", "Reason 2" },
                        Status = "Released",
                        TxnAmount = 50,
                        TxnType = "Refund",
                        TxnDateUTC = DateTime.UtcNow,
                    },
                    new BatchTransactionRejectViewDto()
                    {
                        BatchTransactionRejectId = 2,
                        BatchRejectId = 1235,
                        CardNumberMasked = "1234********1234",
                        RejectReasons = new List<string>() { "Reason 1", "Reason 2" },
                        Status = "Queued",
                        TxnAmount = 150,
                        TxnType = "Refund",
                        TxnDateUTC = DateTime.UtcNow,
                    },
               },
            },
        };

        public static BatchTransactionRejectsViewDto GetBatchTransactionRejects(int batchRejectId)
        {
            return batchTransactionRejects.Where(x => x.BatchRejectId == batchRejectId).FirstOrDefault();
        }

        public static BatchTransactionRejectsUpdateDto GetBatchTransactionRejectsUpdate()
        {
            return new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                UserName = "testuser@e-hps.com",
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { NewStatus = "2", BatchTransactionRejectId = 12345 },
                    new BatchTransactionStatus() { NewStatus = "3", BatchTransactionRejectId = 12346 },
                },
            };
        }

        public static BatchTransactionRejectsStatusUpdateResultDto GetBatchTransactionRejectsStatusUpdateResult()
        {
            return new BatchTransactionRejectsStatusUpdateResultDto()
            {
                BatchRejectId = 1234,
                BatchTransactionRejectUpdateStatuses = new List<BatchTransactionRejectUpdateStatus>()
                {
                    new BatchTransactionRejectUpdateStatus() { BatchTransactionRejectId = 12345, StatusCode = "200", UpdateStatus = "Success" },
                },
            };
        }
    }
}
