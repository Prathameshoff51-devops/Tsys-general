﻿using RiskLab.Core.Dtos;
using System;
using System.Collections.Generic;

namespace RiskLab.UnitTests.Helpers
{
    public class BatchRejectsHelper
    {
        public static IEnumerable<BatchRejectViewDto> GetBatchRejects()
        {
            return new List<BatchRejectViewDto>()
            {
                new BatchRejectViewDto
                {
                    BatchAmount = 200.00F,
                    BatchCloseDate = DateTime.Now,
                    BatchNumber = "1234",
                    BatchRejectId = 1,
                    DaysToAct = 90,
                    MerchantName = "Test Merchant 1",
                    MerchantNumber = "650000000000",
                    RefundCount = 1,
                    RejectReasons = { },
                    Status = "New",
                    TxnDateUTC = DateTime.Now.AddDays(-2),
                },
                new BatchRejectViewDto
                {
                    BatchAmount = 400.00F,
                    BatchCloseDate = DateTime.Now.AddDays(-1),
                    BatchNumber = "1235",
                    BatchRejectId = 2,
                    DaysToAct = 89,
                    MerchantName = "Test Merchant 2",
                    MerchantNumber = "650000000001",
                    RefundCount = 2,
                    RejectReasons = { },
                    Status = "New",
                    TxnDateUTC = DateTime.Now.AddDays(-2),
                },
            };
        }

        public static BatchRejectUpdateDto GetBatchRejectStatusUpdateDto()
        {
            return new BatchRejectUpdateDto
            {
                UserName = "testuser@e-hps.com",
                BatchRejectId = 1,
                NewStatus = "Queued",
            };
        }

        public static BatchRejectUpdateResultDto GetBatchRejectsUpdateResult()
        {
            return new BatchRejectUpdateResultDto { BatchRejectId = 1, UpdateStatus = "Success", StatusCode = "200" };
        }
    }
}
