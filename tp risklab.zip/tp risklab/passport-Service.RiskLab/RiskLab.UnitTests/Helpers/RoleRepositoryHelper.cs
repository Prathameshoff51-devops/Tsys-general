﻿using RiskLab.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Helpers
{
    internal class RoleRepositoryHelper
    {
        public static IEnumerable<UserRole> GetUserRoles()
        {
            return new List<UserRole>()
            {
                new UserRole()
                {
                    Id = 1,
                    Role = "RiskLab",
                },
            };
        }
    }
}
