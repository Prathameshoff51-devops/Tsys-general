﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Services;
using RiskLab.Core.Settings;
using RiskLab.UnitTests.Helpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Services
{
    public class BatchRejectsServiceTests
    {
    // ...existing code...
        [Test]
        public async Task GetBatchRejectById_ReturnsBatchReject()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto()));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.GetBatchRejectById(It.IsAny<int>());

            // Assert
            Assert.That(result, Is.InstanceOf<BatchRejectViewDto>());
        }

        [Test]
        public async Task GetBatchRejectByStatus_ReturnsBatchRejects()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejects(It.IsAny<string>()))
                                       .Returns(Task.FromResult(BatchRejectsHelper.GetBatchRejects()));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.GetBatchRejectsByStatus(It.IsAny<string>());

            // Assert
            Assert.That(result, Is.InstanceOf<IEnumerable<BatchRejectViewDto>>());
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalledWithInvalidBatchId_ReturnsBadRequest()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto()));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(new BatchRejectUpdateDto() { BatchRejectId = -1, NewStatus = "Queued", UserName = "testuser" });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Failed));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalledWithNonExistingBatchId_ReturnsNotFound()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = RejectStatuses.Queued.ToString(), UserName = "testuser" });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.NotFound).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Failed));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalledWithNonExistingNewStatus_ReturnsBadRequest()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto()));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = "IncorrectStatus", UserName = "testuser" });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Failed));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalledWithInvalidNewStatus_ReturnsBadRequest()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto() { BatchRejectId = 1, Status = BatchRejectStatuses.New.ToString() }));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = BatchRejectStatuses.Purged.ToString(), UserName = "testuser" });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Failed));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalledWithValidNewStatus_ReturnsSuccess()
        {
            // Arrange
            BatchRejectUpdateDto batchReject = new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = BatchRejectStatuses.Queued.ToString(), UserName = "testuser" };
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            ApplicationSettings appSetting = new ApplicationSettings() { RiskLabApiUrl = "apiUrl" };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto() { BatchRejectId = 1, Status = BatchRejectStatuses.New.ToString() }));
            mockBatchRejectsRepository.Setup(x => x.UpdateBatchRejectStatus(batchReject))
                                      .Returns(Task.FromResult(new BatchRejectUpdateResultDto
                                      {
                                          BatchRejectId = 1,
                                          StatusCode = ((int)StatusCodes.Ok).ToString(),
                                          UpdateStatus = UpdateStatuses.Success.ToString(),
                                      }));
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(batchReject);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.Ok).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Success));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenCalledWithValidQueuedStatus_ReturnsSuccess()
        {
            // Arrange
            BatchRejectUpdateDto batchReject = new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = BatchRejectStatuses.Deleted.ToString(), UserName = "testuser" };
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            ApplicationSettings appSetting = new ApplicationSettings() { RiskLabApiUrl = "apiUrl" };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto() { BatchRejectId = 1, Status = BatchRejectStatuses.Queued.ToString() }));
            mockBatchRejectsRepository.Setup(x => x.UpdateBatchRejectStatus(batchReject))
                                      .Returns(Task.FromResult(new BatchRejectUpdateResultDto
                                      {
                                          BatchRejectId = 1,
                                          StatusCode = ((int)StatusCodes.Ok).ToString(),
                                          UpdateStatus = UpdateStatuses.Success.ToString(),
                                      }));
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(batchReject);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.Ok).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Success));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_WhenUpdateFails_ReturnsFailedStatus()
        {
            // Arrange
            BatchRejectUpdateDto batchReject = new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = BatchRejectStatuses.Queued.ToString(), UserName = "testuser" };
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto() { BatchRejectId = 1, Status = BatchRejectStatuses.New.ToString() }));
            mockBatchRejectsRepository.Setup(x => x.UpdateBatchRejectStatus(batchReject))
                                      .Returns(Task.FromResult(new BatchRejectUpdateResultDto
                                      {
                                          BatchRejectId = 1,
                                          StatusCode = ((int)StatusCodes.BadRequest).ToString(),
                                          UpdateStatus = UpdateStatuses.Failed.ToString(),
                                      }));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(batchReject);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Failed));
        }

        [Test]
        public async Task UpdateBatchRejectStatus_ThrowsInternalServerError()
        {
            // Arrange
            BatchRejectUpdateDto batchReject = new BatchRejectUpdateDto() { BatchRejectId = 1, NewStatus = BatchRejectStatuses.Queued.ToString(), UserName = "testuser" };
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchRejectById(It.IsAny<int>()))
                                       .Returns(Task.FromResult(new BatchRejectViewDto() { BatchRejectId = 1, Status = BatchRejectStatuses.New.ToString() }));
            mockBatchRejectsRepository.Setup(x => x.UpdateBatchRejectStatus(batchReject))
                                      .Throws(new System.Exception());
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchRejectStatus(batchReject);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchRejectUpdateResultDto>());
            Assert.That(result.StatusCode, Is.EqualTo(((int)StatusCodes.InternalServerError).ToString()));
            Assert.That(result.UpdateStatus, Is.EqualTo(UpdateStatuses.Failed));
        }

        [Test]
        public async Task GetBatchTransactionRejectById_ReturnBatchTxn()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectViewDto()));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.GetBatchTransactionRejectById(It.IsAny<int>());

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectViewDto>());
        }

        [Test]
        public async Task GetBatchTransactionRejects_ReturnBatchTxns()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejects(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectsViewDto()));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.GetBatchTransactionRejects(It.IsAny<int>());

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsViewDto>());
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_WhenCallaed_UpdateBatchTxnStatus()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            ApplicationSettings appSetting = new ApplicationSettings() { RiskLabApiUrl = "apiUrl" };
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectViewDto()
                                      {
                                          BatchTransactionRejectId = 1234,
                                          BatchRejectId = 1234,
                                          Status = RejectStatuses.New.ToString(),
                                      }));
            mockBatchRejectsRepository.Setup(x => x.UpdateBatchTransactionRejectStatus(It.IsAny<BatchTransactionStatus>(), It.IsAny<string>()))
                                        .Returns(Task.FromResult(new BatchTransactionRejectUpdateStatus()
                                        {
                                            StatusCode = StatusCodes.Ok.ToString(),
                                            UpdateStatus = UpdateStatuses.Success,
                                        }));
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = RejectStatuses.Queued.ToString() },
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1235, NewStatus = RejectStatuses.Queued.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(2));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Success.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.Ok).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_WhenCalledWithInvalidBatchTxnRejectId_ReturnStatusFailed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 0, NewStatus = RejectStatuses.Queued.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_WhenCalledWithNonExistingBatchTxnRejectId_ReturnStatusFailed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult<BatchTransactionRejectViewDto>(null));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = RejectStatuses.Queued.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.NotFound).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_BatchTxnBelongsToDifferentBatch_ReturnStatusFailed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectViewDto
                                      {
                                          BatchRejectId = 12345,
                                          BatchTransactionRejectId = 1234,
                                          Status = RejectStatuses.New.ToString(),
                                      }));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = RejectStatuses.Queued.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_WhenCalledWithNonExistingBatchTxnStatus_ReturnStatusFailed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectViewDto
                                      {
                                          BatchRejectId = 1234,
                                          BatchTransactionRejectId = 1234,
                                          Status = RejectStatuses.New.ToString(),
                                      }));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = "NonExistingStatus" },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_WhenCalledWithInvalidNewBatchTxnStatus_ReturnStatusFailed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectViewDto
                                      {
                                          BatchRejectId = 1234,
                                          BatchTransactionRejectId = 1234,
                                          Status = RejectStatuses.New.ToString(),
                                      }));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = RejectStatuses.Purged.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_WhenUpdateFails_ReturnStatusFailed()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Returns(Task.FromResult(new BatchTransactionRejectViewDto
                                      {
                                          BatchRejectId = 1234,
                                          BatchTransactionRejectId = 1234,
                                          Status = RejectStatuses.New.ToString(),
                                      }));
            mockBatchRejectsRepository.Setup(x => x.UpdateBatchTransactionRejectStatus(It.IsAny<BatchTransactionStatus>(), It.IsAny<string>()))
                                        .Returns(Task.FromResult(new BatchTransactionRejectUpdateStatus()
                                        {
                                            StatusCode = StatusCodes.Ok.ToString(),
                                            UpdateStatus = UpdateStatuses.Failed,
                                        }));
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = RejectStatuses.Released.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.InstanceOf<BatchTransactionRejectsStatusUpdateResultDto>());
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.BadRequest).ToString()));
        }

        [Test]
        public async Task UpdateBatchTransactionRejects_OnException_ReturnsInternalServerError()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockBatchRejectsRepository.Setup(x => x.GetBatchTransactionRejectById(It.IsAny<int>()))
                                      .Throws(new System.Exception());
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = await batchRejectsService.UpdateBatchTransactionRejects(new BatchTransactionRejectsUpdateDto()
            {
                BatchRejectId = 1234,
                BatchTransactionsStatus = new List<BatchTransactionStatus>()
                {
                    new BatchTransactionStatus() { BatchTransactionRejectId = 1234, NewStatus = RejectStatuses.Released.ToString() },
                },
                UserName = "testuser@e-hps.com",
            });

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.BatchTransactionRejectUpdateStatuses.Count, Is.EqualTo(1));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].UpdateStatus, Is.EqualTo(UpdateStatuses.Failed.ToString()));
            Assert.That(result.BatchTransactionRejectUpdateStatuses[0].StatusCode, Is.EqualTo(((int)StatusCodes.InternalServerError).ToString()));
        }

        [Test]
        public void CanUpdateStatus_SameCurrentAndNewStatus_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateStatus(RejectStatuses.Queued.ToString(), RejectStatuses.Queued.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateStatus_NewStatusLessThanCurrentStatus_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateStatus(RejectStatuses.Queued.ToString(), RejectStatuses.New.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateStatus_NewStatusReleasedAndCurrentStatusDeleted_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateStatus(RejectStatuses.Deleted.ToString(), RejectStatuses.Released.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateStatus_NewStatusDeletedAndCurrentStatusReleased_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateStatus(RejectStatuses.Released.ToString(), RejectStatuses.Deleted.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateStatus_InvalidToStatus_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateStatus(RejectStatuses.New.ToString(), "10");

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateBatchStatus_SameCurrentAndNewStatus_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateBatchStatus(BatchRejectStatuses.Queued.ToString(), BatchRejectStatuses.Queued.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateBatchStatus_NewStatusLessThanCurrentStatus_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateBatchStatus(BatchRejectStatuses.Queued.ToString(), BatchRejectStatuses.New.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateBatchStatus_NewStatusReleasedAndCurrentStatusDeleted_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateBatchStatus(BatchRejectStatuses.Deleted.ToString(), BatchRejectStatuses.Released.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateBatchStatus_NewStatusDeletedAndCurrentStatusReleased_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateBatchStatus(BatchRejectStatuses.Released.ToString(), BatchRejectStatuses.Deleted.ToString());

            // Assert
            Assert.That(result, Is.False);
        }

        [Test]
        public void CanUpdateBatchStatus_InvalidToStatus_ReturnFalse()
        {
            // Arrange
            var mockBatchRejectsRepository = new Mock<IBatchRejectsRepository>();
            var mockLogger = new Mock<ILogger<BatchRejectsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            BatchRejectsService batchRejectsService = new BatchRejectsService(mockBatchRejectsRepository.Object, mockLogger.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            // Act
            var result = batchRejectsService.CanUpdateBatchStatus(BatchRejectStatuses.New.ToString(), "10");

            // Assert
            Assert.That(result, Is.False);
        }
    }
}
