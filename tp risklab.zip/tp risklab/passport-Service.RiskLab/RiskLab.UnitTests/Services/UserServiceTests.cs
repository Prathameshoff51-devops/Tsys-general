﻿using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Services;
using System;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Services
{
    internal class UserServiceTests
    {
        private readonly IUserRepository userRepository;
        private readonly ILogger<UserService> logger;

        public UserServiceTests()
        {
            userRepository = new Mock<IUserRepository>().Object;
            logger = new Mock<ILogger<UserService>>().Object;
        }

        [Test]
        public async Task GetUserByEmail()
        {
            // Arrange
            var mockUserRepository = new Mock<IUserRepository>();
            mockUserRepository.Setup(x => x.GetUserByEmail(It.IsAny<string>()))
                                  .Returns(Task.FromResult(It.IsAny<User>()));
            UserService service = new UserService(mockUserRepository.Object, logger);

            // Act
            var result = await service.GetUserByEmail(It.IsAny<string>());

            // Assert
            Assert.IsNull(result);
        }

        [Test]
        public async Task GetUserByLoginName()
        {
            // Arrange
            var mockUserRepository = new Mock<IUserRepository>();
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>()))
                                  .Returns(Task.FromResult(It.IsAny<User>()));
            UserService service = new UserService(mockUserRepository.Object, logger);

            // Act
            var result = await service.GetUserByLoginName(It.IsAny<string>());

            // Assert
            Assert.IsNull(result);
        }

        [Test]
        public async Task GetUserByUserId()
        {
            // Arrange
            var mockUserRepository = new Mock<IUserRepository>();
            mockUserRepository.Setup(x => x.GetUserByUserId(It.IsAny<int>()))
                                  .Returns(Task.FromResult(It.IsAny<User>()));
            UserService service = new UserService(mockUserRepository.Object, logger);

            // Act
            var result = await service.GetUserByUserId(It.IsAny<int>());

            // Assert
            Assert.IsNull(result);
        }

        [Test]
        public async Task IsUserValid()
        {
            // Arrange
            User user = new User()
            {
                Email = It.IsAny<string>(),
                LoginName = string.Empty,
                Id = 1,
            };
            var mockUserRepository = new Mock<IUserRepository>();
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>()))
                                  .Returns(Task.FromResult(user));
            UserService service = new UserService(mockUserRepository.Object, logger);

            // Act
            var result = await service.IsUserValid(It.IsAny<string>());

            // Assert
            Assert.IsTrue(result);
        }

        [Test]
        public async Task IsUserValid_false()
        {
            // Arrange
            var mockUserRepository = new Mock<IUserRepository>();
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>()))
                                  .Returns(Task.FromResult(It.IsAny<User>()));
            UserService service = new UserService(mockUserRepository.Object, logger);

            // Act
            var result = await service.IsUserValid(It.IsAny<string>());

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsUserValid_Exception()
        {
            // Arrange
            var mockUserRepository = new Mock<IUserRepository>();
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>()))
                                  .Throws(new Exception());
            UserService service = new UserService(mockUserRepository.Object, logger);

            // Act
            var result = await service.IsUserValid(It.IsAny<string>());

            // Assert
            Assert.IsFalse(result);
        }
    }
}
