namespace RiskLab.UnitTests.Services
{
    // Test message classes for testing
    public class TestMessage
    {
        public int Id { get; set; }

        public string Data { get; set; }
    }
}
