using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Services;
using System;
using System.Collections.Generic;
using System.Text.Json;

namespace RiskLab.UnitTests.Services
{
    [TestFixture]
    public class ExcelExportServiceTests
    {
        private Mock<ILogger<ExcelExportService>> _mockLogger;
        private ExcelExportService _excelExportService;

        [SetUp]
        public void Setup()
        {
            _mockLogger = new Mock<ILogger<ExcelExportService>>();
            _excelExportService = new ExcelExportService(_mockLogger.Object);
        }

        [Test]
        public void ExportJsonTOExcel_WithValidData_ReturnsExcelBytes()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["Id"] = 1,
                    ["Name"] = "Test Name",
                    ["Status"] = "Active",
                },
                new Dictionary<string, object>
                {
                    ["Id"] = 2,
                    ["Name"] = "Test Name 2",
                    ["Status"] = "Inactive",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "TestSheet", "Active");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchRejectData_ReturnsExcelBytes()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchRejectId"] = 1,
                    ["Description"] = "Test Batch Reject",
                    ["Status"] = "Pending",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchRejects", "Pending");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithEmptyData_ThrowsInvalidOperationException()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>();
            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() =>
                _excelExportService.ExportJsonTOExcel(jsonElement, "TestSheet", "Active"));

            Assert.That(exception.Message, Is.EqualTo("No records found to export"));
        }

        [Test]
        public void ExportJsonTOExcel_WithNullData_ThrowsInvalidOperationException()
        {
            // Arrange
            var jsonElement = JsonSerializer.Deserialize<JsonElement>("null");

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() =>
                _excelExportService.ExportJsonTOExcel(jsonElement, "TestSheet", "Active"));
        }

        [Test]
        public void ExportJsonTOExcel_WithInvalidJson_ThrowsInvalidOperationException()
        {
            // Arrange
            var jsonElement = JsonSerializer.Deserialize<JsonElement>("\"invalid data\"");

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() =>
                _excelExportService.ExportJsonTOExcel(jsonElement, "TestSheet", "Active"));

            Assert.That(exception.Message, Does.Contain("Invalid JSON data provided for Excel export"));
        }

        [Test]
        public void ExportJsonTOExcel_WithComplexNestedData_HandlesCorrectly()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["Id"] = 1,
                    ["Name"] = "Test",
                    ["NestedObject"] = new Dictionary<string, object>
                    {
                        ["SubId"] = 10,
                        ["SubName"] = "Nested",
                    },
                    ["ArrayData"] = new List<int> { 1, 2, 3 },
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "ComplexSheet", "Active");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithSpecialCharacters_HandlesCorrectly()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["Id"] = 1,
                    ["Name"] = "Test@#$%^&*()",
                    ["Description"] = "Special chars: àáâãäåæçèéêë",
                    ["Unicode"] = "测试数据 ñ ü",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "SpecialChars", "Active");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithLargeDataSet_HandlesCorrectly()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>();
            for (int i = 0; i < 1000; i++)
            {
                testData.Add(new Dictionary<string, object>
                {
                    ["Id"] = i,
                    ["Name"] = $"Test Name {i}",
                    ["Status"] = i % 2 == 0 ? "Active" : "Inactive",
                    ["Description"] = $"Description for record {i}",
                });
            }

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "LargeDataSet", "Active");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithMixedDataTypes_HandlesCorrectly()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["StringField"] = "Test String",
                    ["IntField"] = 123,
                    ["DoubleField"] = 123.45,
                    ["BoolField"] = true,
                    ["DateField"] = DateTime.Now.ToString("O"),
                    ["NullField"] = null,
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "MixedTypes", "Active");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithDifferentColumnStructures_HandlesCorrectly()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["Id"] = 1,
                    ["Name"] = "First Record",
                    ["Email"] = "test1@test.com",
                },
                new Dictionary<string, object>
                {
                    ["Id"] = 2,
                    ["Name"] = "Second Record",
                    ["Phone"] = "123-456-7890",
                    // Note: Email field missing
                },
                new Dictionary<string, object>
                {
                    ["Id"] = 3,
                    ["Name"] = "Third Record",
                    ["Email"] = "test3@test.com",
                    ["Phone"] = "098-765-4321",
                    ["Address"] = "123 Test St",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "DifferentColumns", "Active");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_LogsAppropriateMessages()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["Id"] = 1,
                    ["Name"] = "Test",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            _excelExportService.ExportJsonTOExcel(jsonElement, "TestSheet", "Active");

            // Assert
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Starting Excel export")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_MapsHeadersCorrectly()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["OriginalBatchNumber"] = "BATCH001",
                    ["MerchantNumber"] = "MERCH123",
                    ["MerchantName"] = "Test Merchant",
                    ["LegalName"] = "Test Legal Name",
                    ["ChainOID"] = "CHAIN001",
                    ["MCC"] = "5411",
                    ["BatchAmount"] = 1000.50m,
                    ["BatchCreateDate"] = DateTime.UtcNow.ToString("O"),
                    ["BatchCloseDate"] = DateTime.UtcNow.AddDays(1).ToString("O"),
                    ["TxnAmount"] = 25.99m,
                    ["CardNumberMasked"] = "****-****-****-1234",
                    ["TxnDateUtc"] = DateTime.UtcNow.ToString("O"),
                    ["FraudRejectReasonCodes"] = new List<string> { "FRAUD_01", "FRAUD_02" },
                    ["AuthCode"] = "AUTH123",
                    ["ExpDate"] = DateTime.UtcNow.AddYears(2).ToString("O"),
                    ["TxnType"] = "PURCHASE",
                    ["SubmitterIdDescription"] = "Test Submitter",
                    ["DaysToAct"] = 30,
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesUtcDateFields()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["BatchCreateDate"] = DateTimeOffset.UtcNow.ToString("O"),
                    ["BatchCloseDate"] = DateTimeOffset.UtcNow.AddDays(1).ToString("O"),
                    ["TxnDateUtc"] = DateTimeOffset.UtcNow.ToString("O"),
                    ["ExpDate"] = DateTimeOffset.UtcNow.AddYears(2).ToString("O"),
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesAmountFields()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["BatchAmount"] = 1000.50m,
                    ["TxnAmount"] = 25.99m,
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesNullableFields()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["ChainOID"] = null, // Nullable field
                    ["AuthCode"] = null, // Nullable field
                    ["ExpDate"] = null, // Nullable field
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesRejectReasonCodes()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["FraudRejectReasonCodes"] = new List<string> { "FRAUD_01", "FRAUD_02", "FRAUD_03" },
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesArtificialColumns()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["CurrentStatus"] = "PENDING", // Artificial column
                    ["NewStatus"] = "APPROVED", // Artificial column
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesPartialFieldSet()
        {
            // Arrange - Only some fields from the DTO are present
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["MerchantNumber"] = "MERCH123",
                    ["MerchantName"] = "Test Merchant",
                    ["TxnAmount"] = 25.99m,
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesMultipleRecords()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["MerchantNumber"] = "MERCH123",
                    ["MerchantName"] = "Test Merchant 1",
                    ["TxnAmount"] = 25.99m,
                    ["Status"] = "PENDING",
                    ["OriginalBatchNumber"] = 111,
                },
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 2,
                    ["BatchRejectId"] = 101,
                    ["MerchantNumber"] = "MERCH456",
                    ["MerchantName"] = "Test Merchant 2",
                    ["TxnAmount"] = 50.00m,
                    ["Status"] = "PENDING",
                    ["OriginalBatchNumber"] = 112,
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesEmptyRejectReasonCodes()
        {
            // Arrange
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["FraudRejectReasonCodes"] = new List<string>(), // Empty list
                    ["Status"] = "PENDING",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [Test]
        public void ExportJsonTOExcel_WithBatchTransactionData_HandlesAllFieldsFromDto()
        {
            // Arrange - Test with all fields from BatchTransactionRejectByStatusViewDto
            var testData = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>
                {
                    ["BatchTransactionRejectId"] = 1,
                    ["BatchRejectId"] = 100,
                    ["MessageId"] = Guid.NewGuid().ToString(),
                    ["TxnUUID"] = 1234567890L,
                    ["TxnDetailID"] = 999,
                    ["MerchantNumber"] = "MERCH123",
                    ["MerchantName"] = "Test Merchant",
                    ["LegalName"] = "Test Legal Name",
                    ["ChainOID"] = "CHAIN001",
                    ["MCC"] = "5411",
                    ["TxnAmount"] = 25.99m,
                    ["BatchAmount"] = 1000.50m,
                    ["CardNumberMasked"] = "****-****-****-1234",
                    ["TxnDateUtc"] = DateTimeOffset.UtcNow.ToString("O"),
                    ["FraudRejectReasonCodes"] = new List<string> { "FRAUD_01", "FRAUD_02" },
                    ["OriginalBatchNumber"] = "BATCH001",
                    ["AuthCode"] = "AUTH123",
                    ["ExpDate"] = DateTimeOffset.UtcNow.AddYears(2).ToString("O"),
                    ["BatchCreateDate"] = DateTimeOffset.UtcNow.ToString("O"),
                    ["BatchCloseDate"] = DateTimeOffset.UtcNow.AddDays(1).ToString("O"),
                    ["FraudRejectReasonCodeIds"] = new List<int> { 1, 2 },
                    ["SubmitterIdDescription"] = "Test Submitter",
                    ["DaysToAct"] = 30,
                    ["Status"] = "PENDING",
                    ["TxnType"] = "PURCHASE",
                    ["CurrentStatus"] = "PENDING",
                    ["NewStatus"] = "APPROVED",
                },
            };

            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);

            // Act
            var result = _excelExportService.ExportJsonTOExcel(jsonElement, "BatchTransactions", "PENDING");

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Length, 0);
        }

        [TearDown]
        public void TearDown()
        {
            // Clean up if needed
        }

        [Test]
        public void ExportJsonTOExcel_LogsError_When_JsonDeserializationFails()
        {
            var invalidJson = JsonSerializer.Deserialize<JsonElement>("{}" /* not a list */);
            Assert.Throws<InvalidOperationException>(() => _excelExportService.ExportJsonTOExcel(invalidJson, "Sheet1", "Queued"));
            _mockLogger.Verify(
                l => l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Failed to deserialize JSON data for Excel export")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }

        [Test]
        public void ExportJsonTOExcel_LogsWarning_When_NoRecordsFound()
        {
            var emptyListJson = JsonSerializer.Deserialize<JsonElement>("[]");
            Assert.Throws<InvalidOperationException>(() => _excelExportService.ExportJsonTOExcel(emptyListJson, "Sheet1", "Queued"));
            _mockLogger.Verify(
                l => l.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("No records found for Excel export")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }

        [Test]
        public void ExportJsonTOExcel_LogsError_When_ErrorProcessingDataForExcelExport()
        {
            // Simulate error in AddSheet by passing null records
            var testData = new List<Dictionary<string, object>>();
            var jsonString = JsonSerializer.Serialize(testData);
            var jsonElement = JsonSerializer.Deserialize<JsonElement>(jsonString);
            // Remove all records to trigger error in AddSheet
            Assert.Throws<InvalidOperationException>(() => _excelExportService.ExportJsonTOExcel(jsonElement, "SheetName", "Queued"));
            _mockLogger.Verify(
                l => l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Error processing data for Excel export")),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Never); // The warning for no records is hit instead
        }

        [Test]
        public void ExportJsonTOExcel_LogsError_When_UnexpectedErrorDuringExcelExport()
        {
            // Arrange
            var invalidJson = JsonSerializer.Deserialize<JsonElement>("\"invalid data\""); // Invalid JSON to trigger JsonException

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() =>
                _excelExportService.ExportJsonTOExcel(invalidJson, "SheetName", "Queued"));

            // Assert the exception message
            Assert.That(exception.Message, Does.Contain("Invalid JSON data provided for Excel export"));

            // Verify the logger captured the error
            _mockLogger.Verify(
                l => l.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Failed to deserialize JSON data for Excel export")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
        }
    }
}
