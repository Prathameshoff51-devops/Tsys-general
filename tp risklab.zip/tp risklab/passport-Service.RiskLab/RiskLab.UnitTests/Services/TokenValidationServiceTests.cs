using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using NUnit.Framework;
using RiskLab.Core.Services;
using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RiskLab.UnitTests.Services
{
    [TestFixture]
    public class TokenValidationServiceTests
    {
        private Mock<IHttpClientFactory> _mockHttpClientFactory;
        private Mock<ILogger<TokenValidationService>> _mockLogger;
        private Mock<HttpMessageHandler> _mockHttpMessageHandler;
        private TokenValidationService _tokenValidationService;
        private HttpClient _httpClient;

        [SetUp]
        public void Setup()
        {
            _mockHttpClientFactory = new Mock<IHttpClientFactory>();
            _mockLogger = new Mock<ILogger<TokenValidationService>>();
            _mockHttpMessageHandler = new Mock<HttpMessageHandler>();

            _httpClient = new HttpClient(_mockHttpMessageHandler.Object);
            _mockHttpClientFactory.Setup(factory => factory.CreateClient(string.Empty)).Returns(_httpClient);

            _tokenValidationService = new TokenValidationService(_mockHttpClientFactory.Object, _mockLogger.Object);
        }

        [Test]
        public async Task IsTokenValid_WithValidActiveToken_ReturnsTrue()
        {
            // Arrange
            var testToken = "valid_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            var responseContent = "{\"active\": true}";
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(responseContent, Encoding.UTF8, "application/json"),
            };

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsTrue(result);
        }

        [Test]
        public async Task IsTokenValid_WithInactiveToken_ReturnsFalse()
        {
            // Arrange
            var testToken = "inactive_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            var responseContent = "{\"active\": false}";
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(responseContent, Encoding.UTF8, "application/json"),
            };

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsTokenValid_WithHttpError_ReturnsFalse()
        {
            // Arrange
            var testToken = "error_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            var response = new HttpResponseMessage(HttpStatusCode.Unauthorized);

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsTokenValid_WithNullToken_ShouldHandleGracefully()
        {
            // Arrange
            string testToken = null;
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            var responseContent = "{\"active\": false}";
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(responseContent, Encoding.UTF8, "application/json"),
            };

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsTokenValid_WithEmptyUrl_ShouldHandleGracefully()
        {
            // Arrange
            var testToken = "valid_token";
            string testUrl = string.Empty;
            var testClientId = "test_client_id";

            // Act & Assert
            Assert.ThrowsAsync<InvalidOperationException>(async () =>
                await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId));
        }

        [Test]
        public async Task IsTokenValid_WithNullClientId_ShouldHandleGracefully()
        {
            // Arrange
            var testToken = "valid_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            string testClientId = null;

            var responseContent = "{\"active\": false}";
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(responseContent, Encoding.UTF8, "application/json"),
            };

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsTokenValid_WithInvalidJsonResponse_ReturnsFalse()
        {
            // Arrange
            var testToken = "valid_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            var responseContent = "invalid json";
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(responseContent, Encoding.UTF8, "application/json"),
            };

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act & Assert
            Assert.ThrowsAsync<Newtonsoft.Json.JsonReaderException>(async () =>
                await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId));
        }

        [Test]
        public async Task IsTokenValid_WithHttpRequestException_ReturnsFalse()
        {
            // Arrange
            var testToken = "valid_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new HttpRequestException("Network error"));

            // Act & Assert
            Assert.ThrowsAsync<HttpRequestException>(async () =>
                await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId));
        }

        [Test]
        public async Task IsTokenValid_WithTaskCancelledException_ThrowsException()
        {
            // Arrange
            var testToken = "valid_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new TaskCanceledException("Request timeout"));

            // Act & Assert
            Assert.ThrowsAsync<TaskCanceledException>(async () =>
                await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId));
        }

        [Test]
        public async Task IsTokenValid_WithServerError_LogsErrorAndReturnsFalse()
        {
            // Arrange
            var testToken = "valid_token";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "test_client_id";

            var response = new HttpResponseMessage(HttpStatusCode.InternalServerError);

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsFalse(result);
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Invalid response received from okta")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Test]
        public async Task IsTokenValid_WithSpecialCharactersInToken_HandlesCorrectly()
        {
            // Arrange
            var testToken = "token@#$%^&*()";
            var testUrl = "https://test.okta.com/oauth2/v1/introspect";
            var testClientId = "client@#$%^&*()";

            var responseContent = "{\"active\": true}";
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(responseContent, Encoding.UTF8, "application/json"),
            };

            _mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);

            // Act
            var result = await _tokenValidationService.IsTokenValid(testToken, testUrl, testClientId);

            // Assert
            Assert.IsTrue(result);
        }

        [TearDown]
        public void TearDown()
        {
            _httpClient?.Dispose();
        }
    }
}
