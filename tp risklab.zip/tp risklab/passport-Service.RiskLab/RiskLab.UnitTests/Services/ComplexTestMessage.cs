﻿using System;

namespace RiskLab.UnitTests.Services
{
    public class ComplexTestMessage
    {
        public int Id { get; set; }

        public string Data { get; set; }

        public DateTime Timestamp { get; set; }

        public bool IsProcessed { get; set; }

        public System.Collections.Generic.Dictionary<string, object> Metadata { get; set; }
    }
}
