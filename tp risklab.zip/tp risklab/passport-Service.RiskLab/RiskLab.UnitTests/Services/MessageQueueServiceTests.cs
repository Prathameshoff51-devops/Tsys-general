using Moq;
using NUnit.Framework;
using RiskLab.Core.Constants;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Services;
using RiskLab.Infrastructure.Interfaces;
using System;
using System.Text;

namespace RiskLab.UnitTests.Services
{
    [TestFixture]
    public class MessageQueueServiceTests
    {
        private const string TestConnectionString = "host=localhost;virtualHost=/;username=test;password=test";

        private Mock<IRabbitMQSettings> mockRabbitMQSettings;
        private Mock<IMessageProcessor<TestMessage>> mockMessageProcessor;
        private MessageQueueService messageQueueService;

        [SetUp]
        public void SetUp()
        {
            mockRabbitMQSettings = new Mock<IRabbitMQSettings>();
            mockMessageProcessor = new Mock<IMessageProcessor<TestMessage>>();

            mockRabbitMQSettings.Setup(x => x["RiskLabRabbitMqConnection"])
                .Returns(TestConnectionString);

            // Note: MessageQueueService depends on RabbitMQ connection which is hard to mock
            // These tests will focus on the parts that can be tested without actual RabbitMQ
        }

        [Test]
        public void Constructor_WithValidSettings_InitializesSuccessfully()
        {
            // Arrange & Act
            Assert.DoesNotThrow(() => new MessageQueueService(mockRabbitMQSettings.Object));
        }

        [Test]
        public void Constructor_WithNullSettings_ThrowsException()
        {
            // Arrange & Act & Assert
            Assert.Throws<NullReferenceException>(() => new MessageQueueService(null));
        }

        [Test]
        public void Dispose_WhenCalled_DoesNotThrow()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);

            // Act & Assert
            Assert.DoesNotThrow(() => service.Dispose());
        }

        [Test]
        public void Dispose_CalledMultipleTimes_DoesNotThrow()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);

            // Act & Assert
            Assert.DoesNotThrow(() => service.Dispose());
            Assert.DoesNotThrow(() => service.Dispose());
        }

        [Test]
        public void PublishMessage_WithNullMessage_ReturnsFalse()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            TestMessage message = null;
            var payload = Encoding.UTF8.GetBytes("test");

            // Act
            var result = service.PublishMessage(message, payload);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public void PublishMessage_WithNullPayload_ReturnsFalse()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var message = new TestMessage { Id = 1, Data = "test" };
            byte[] payload = null;

            // Act
            var result = service.PublishMessage(message, payload);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public void PublishMessage_WithValidParameters_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var message = new TestMessage { Id = 1, Data = "test" };
            var payload = Encoding.UTF8.GetBytes("test payload");

            // Act
            var result = service.PublishMessage(message, payload);

            // Assert
            // Since we can't actually connect to RabbitMQ in unit tests,
            // we expect this to fail gracefully and return false
            Assert.IsFalse(result);
        }

        [Test]
        public void SubscribeProcessor_WithNullProcessor_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            IMessageProcessor<TestMessage> processor = null;
            Func<TestMessage, Guid> getGuid = msg => Guid.NewGuid();
            var messageIdentifier = MessageIdentifier.Unknown;

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeProcessor(processor, getGuid, messageIdentifier));
        }

        [Test]
        public void SubscribeProcessor_WithNullGetGuidFunction_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            Func<TestMessage, Guid> getGuid = null;
            var messageIdentifier = MessageIdentifier.Unknown;

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeProcessor(mockMessageProcessor.Object, getGuid, messageIdentifier));
        }

        [Test]
        public void SubscribeAdvanced_WithNullQueueName_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            string queueName = null;
            Action<byte[]> process = data => { };

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeAdvanced(queueName, process));
        }

        [Test]
        public void SubscribeAdvanced_WithEmptyQueueName_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var queueName = "";
            Action<byte[]> process = data => { };

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeAdvanced(queueName, process));
        }

        [Test]
        public void SubscribeAdvanced_WithNullProcess_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var queueName = "test-queue";
            Action<byte[]> process = null;

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeAdvanced(queueName, process));
        }

        [Test]
        public void SubscribeAdvanced_WithValidParameters_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var queueName = "test-queue";
            var processCallCount = 0;
            Action<byte[]> process = data => processCallCount++;

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeAdvanced(queueName, process));
        }

        [Test]
        public void PublishMessage_WithComplexMessage_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var complexMessage = new ComplexTestMessage
            {
                Id = 1,
                Data = "complex test data",
                Timestamp = DateTime.UtcNow,
                IsProcessed = false,
                Metadata = new System.Collections.Generic.Dictionary<string, object>
                {
                    { "key1", "value1" },
                    { "key2", 42 },
                },
            };
            var payload = Encoding.UTF8.GetBytes("complex payload");

            // Act
            var result = service.PublishMessage(complexMessage, payload);

            // Assert
            Assert.IsFalse(result); // Expected to fail without actual RabbitMQ
        }

        [Test]
        public void PublishMessage_WithLargePayload_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var message = new TestMessage { Id = 1, Data = "large payload test" };
            var largePayload = new byte[1024 * 1024]; // 1MB payload
            for (int i = 0; i < largePayload.Length; i++)
            {
                largePayload[i] = (byte)(i % 256);
            }

            // Act
            var result = service.PublishMessage(message, largePayload);

            // Assert
            Assert.IsFalse(result); // Expected to fail without actual RabbitMQ
        }

        [Test]
        public void SubscribeProcessor_WithValidProcessor_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            mockMessageProcessor.Setup(x => x.Process(It.IsAny<string>()))
                .ReturnsAsync(MessageStatusIdentifier.Successful);

            Func<TestMessage, Guid> getGuid = msg => Guid.NewGuid();
            var messageIdentifier = MessageIdentifier.Unknown;

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeProcessor(mockMessageProcessor.Object, getGuid, messageIdentifier));
        }

        [Test]
        public void SubscribeProcessor_WithExceptionThrowingProcessor_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            mockMessageProcessor.Setup(x => x.Process(It.IsAny<string>()))
                .ThrowsAsync(new Exception("Test exception"));

            Func<TestMessage, Guid> getGuid = msg => Guid.NewGuid();
            var messageIdentifier = MessageIdentifier.Unknown;

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeProcessor(mockMessageProcessor.Object, getGuid, messageIdentifier));
        }

        [Test]
        public void SubscribeAdvanced_WithExceptionThrowingProcess_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var queueName = "test-queue";
            Action<byte[]> process = data => throw new Exception("Test exception");

            // Act & Assert
            Assert.DoesNotThrow(() => service.SubscribeAdvanced(queueName, process));
        }

        [Test]
        public void PublishMessage_WithDifferentMessageTypes_HandlesGracefully()
        {
            // Arrange
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            var stringMessage = "string message";
            var intMessage = new TestMessage { Id = 42, Data = "test" };
            var objectMessage = new { Property = "value" };
            var payload = Encoding.UTF8.GetBytes("test payload");

            // Act
            var result1 = service.PublishMessage(stringMessage, payload);
            var result2 = service.PublishMessage(intMessage, payload);
            var result3 = service.PublishMessage(objectMessage, payload);

            // Assert
            Assert.IsFalse(result1);
            Assert.IsFalse(result2);
            Assert.IsFalse(result3);
        }

        [TearDown]
        public void TearDown()
        {
            messageQueueService?.Dispose();
        }

        [Test]
        public void Constructor_WithEmptyConnectionString_ThrowsException()
        {
            var badSettings = new Mock<IRabbitMQSettings>();
            badSettings.Setup(x => x["RiskLabRabbitMqConnection"]).Returns("");
            Assert.Throws<ArgumentException>(() => new MessageQueueService(badSettings.Object));
        }

        [Test]
        public void PublishMessage_WithDisposedService_ReturnsFalse()
        {
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            service.Dispose();
            var message = new TestMessage { Id = 1, Data = "test" };
            var payload = Encoding.UTF8.GetBytes("test payload");
            var result = service.PublishMessage(message, payload);
            Assert.IsFalse(result);
        }

        [Test]
        public void SubscribeProcessor_WithDisposedService_DoesNotThrow()
        {
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            service.Dispose();
            Func<TestMessage, Guid> getGuid = msg => Guid.NewGuid();
            Assert.DoesNotThrow(() => service.SubscribeProcessor(mockMessageProcessor.Object, getGuid, MessageIdentifier.Unknown));
        }

        [Test]
        public void SubscribeAdvanced_WithDisposedService_DoesNotThrow()
        {
            var service = new MessageQueueService(mockRabbitMQSettings.Object);
            service.Dispose();
            Assert.DoesNotThrow(() => service.SubscribeAdvanced("test-queue", data => { }));
        }
    }
}
