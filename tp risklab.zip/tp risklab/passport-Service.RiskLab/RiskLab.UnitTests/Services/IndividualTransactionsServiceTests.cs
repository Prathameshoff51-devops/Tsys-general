﻿namespace RiskLab.UnitTests.Services
{
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using NUnit.Framework;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Entities;
    using RiskLab.Core.Interfaces.Repositories;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Core.Services;
    using RiskLab.Core.Settings;
    using RiskLab.UnitTests.Helpers;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Threading.Tasks;

    public class IndividualTransactionsServiceTests
    {
        [Test]
        public async Task GetDeletedIndividualTransactions_WhenCalled_ReturnDeletedTransactions()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetTransactions(RejectStatuses.Deleted.ToString()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.GetDeletedIndividualTransactions();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionViewDto>>(result);
        }

        [Test]
        public async Task GetQueuedIndividualTransactions_WhenCalled_ReturnQueuedTransactions()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetTransactions(RejectStatuses.Queued.ToString()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object,  mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.GetQueuedIndividualTransactions();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionViewDto>>(result);
        }

        [Test]
        public async Task GetReleasedIndividualTransactions_WhenCalled_ReturnReleasedTransactions()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetTransactions(RejectStatuses.Released.ToString()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object,  mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.GetReleasedIndividualTransactions();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionViewDto>>(result);
        }

        [Test]
        public async Task GetNewIndividualTransactions_WhenCalled_ReturnNewTransactions()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetTransactions(RejectStatuses.New.ToString()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object,  mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.GetNewIndividualTransactions();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionViewDto>>(result);
        }

        [Test]
        public async Task GetIndividualTransactionsByStatus_WhenCalledWithStatus_ReturnTransactions()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetTransactions(It.IsAny<RejectStatuses>().ToString()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactions()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object,  mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.GetIndividualTransactionsByStatus(It.IsAny<RejectStatuses>().ToString());

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionViewDto>>(result);
        }

        [Test]
        public async Task UpdateIndividualTransactions_WhenCalled_ReturnUpdateResult()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactionsUpdateResult()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object,  mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto());

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionStatusUpdateResultDto>>(result);
        }

        [Test]
        public async Task UpdateIndividualTransactions_WhenCalled_ReturnUpdateResult_successfully()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactionsUpdateResult()));
            mockTransactionsRepository.Setup(x => x.GetTransaction(It.IsAny<int>()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransaction()));
            ApplicationSettings appSetting = new ApplicationSettings() { RiskLabApiUrl = "apiUrl" };
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto());

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionStatusUpdateResultDto>>(result);
        }

        [Test]
        public async Task UpdateIndividualTransactions_WhenCalled_ReturnUpdateResult_New_successfully()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactionsUpdateResult()));
            mockTransactionsRepository.Setup(x => x.GetTransaction(It.IsAny<int>()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransaction_With_status()));
            ApplicationSettings appSetting = new ApplicationSettings() { RiskLabApiUrl = "apiUrl" };
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto());

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionStatusUpdateResultDto>>(result);
        }

        [Test]
        public async Task UpdateIndividualTransactions_WhenCalled_ReturnUpdateResult_Failed()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransactionsUpdateResult()));
            mockTransactionsRepository.Setup(x => x.GetTransaction(It.IsAny<int>()))
                                      .Returns(Task.FromResult(IndividualTransactionsHelper.GetTransaction()));
            ApplicationSettings appSetting = new ApplicationSettings() { RiskLabApiUrl = "apiUrl" };
            mockApplicationSettings.Setup(ap => ap.Value).Returns(appSetting);
            var getIndividualTransactionStatusUpdateDto = new IndividualTransactionStatusUpdateDto
            {
                UserName = "testuser@e-hps.com",
                TransactionsStatus = new List<TransactionStatus>
                {
                    new TransactionStatus { TransactionId = 1, NewStatus = RejectStatuses.Purged.ToString() },
                },
            };
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.UpdateIndividualTransactionStatus(getIndividualTransactionStatusUpdateDto);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionStatusUpdateResultDto>>(result);
        }

        [Test]
        public async Task UpdateIndividualTransactions_with_Exception()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetTransaction(It.IsAny<int>()))
                                      .Throws(new Exception());
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.UpdateIndividualTransactionStatus(IndividualTransactionsHelper.GetIndividualTransactionStatusUpdateDto());

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<IEnumerable<IndividualTransactionStatusUpdateResultDto>>(result);
        }

        [Test]
        public async Task CanUpdateStatus_false()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = service.CanUpdateStatus(RejectStatuses.Queued.ToString(), RejectStatuses.New.ToString());

            //Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task CanUpdateStatus_with_Deleted_return_false()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = service.CanUpdateStatus(RejectStatuses.Released.ToString(), RejectStatuses.Deleted.ToString());

            //Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task CanUpdateStatus_with_Released_return_false()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = service.CanUpdateStatus(RejectStatuses.Deleted.ToString(), RejectStatuses.Released.ToString());

            //Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task SaveIndividualTransactionFromPassport()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.InsertIndividualTransactionFromPassport(It.IsAny<IndividualTransactionDto>(), It.IsAny<DataTable>()))
                                     .Returns(Task.FromResult(0));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            service.Dispose();
            var result = service.SaveIndividualTransactionFromPassport(It.IsAny<IndividualTransactionDto>(), It.IsAny<DataTable>());

            //Assert
            Assert.IsNotNull(result);
        }

        [Test]
        public async Task IsUserValid_return_true()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            var user = new User()
            {
                FirstName = It.IsAny<string>(),
                LastName = It.IsAny<string>(),
                Email = It.IsAny<string>(),
                GranteeOID = It.IsAny<string>(),
                UserName = It.IsAny<string>(),
            };
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>()))
                                     .Returns(Task.FromResult(user));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.IsUserValid(It.IsAny<string>());

            //Assert
            Assert.IsTrue(result);
        }

        [Test]
        public async Task IsUserValid_return_false()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>()))
                                     .Returns(Task.FromResult(It.IsAny<User>()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.IsUserValid(It.IsAny<string>());

            //Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task IsUserValid_Exception()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockUserRepository.Setup(x => x.GetUserByLoginName(It.IsAny<string>())).Throws(new Exception());
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = await service.IsUserValid(It.IsAny<string>());

            //Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async Task GetRejectsByMerchantNumber()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetRejectsByMerchantNumber(It.IsAny<string>()))
                                     .Returns(Task.FromResult(It.IsAny<IEnumerable<MerchantRejects>>()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = service.GetRejectsByMerchantNumber(It.IsAny<string>());

            //Assert
            Assert.IsNotNull(result);
        }

        [Test]
        public async Task GetMerchantNumberFromSequenceKey()
        {
            //Arrange
            var mockTransactionsRepository = new Mock<IIndividualTransactionsRepository>();
            var mockUserRepository = new Mock<IUserRepository>();
            var mockLogger = new Mock<ILogger<IndividualTransactionsService>>();
            var mockApplicationSettings = new Mock<IOptions<ApplicationSettings>>();
            var mockNotificationService = new Mock<INotificationService>();
            mockTransactionsRepository.Setup(x => x.GetMerchantNumberFromSequenceKey(It.IsAny<int>()))
                                     .Returns(Task.FromResult(It.IsAny<Merchant>()));
            IndividualTransactionsService service = new IndividualTransactionsService(mockTransactionsRepository.Object, mockLogger.Object, mockUserRepository.Object, mockApplicationSettings.Object, mockNotificationService.Object);

            //Act
            var result = service.GetMerchantNumberFromSequenceKey(It.IsAny<int>());

            //Assert
            Assert.IsNotNull(result);
        }
    }
}
