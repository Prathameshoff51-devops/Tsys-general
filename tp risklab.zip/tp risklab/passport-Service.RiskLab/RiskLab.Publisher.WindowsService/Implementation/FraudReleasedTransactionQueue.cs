﻿using Acquisition.Contracts.Risk.Jville;
using EasyNetQ;
using EasyNetQ.Topology;
using Newtonsoft.Json;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure;
using RiskLab.Infrastructure.Interfaces;
using RiskLab.Publisher.WindowsService.Interfaces;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace RiskLab.Publisher.WindowsService.Implementation
{
    public class FraudReleasedTransactionQueue : QueueBasePublish<FraudReleasedTransaction> ,IFraudReleasedTransactionQueue
    {
        private readonly IIndividualTransactionsRepository _individualTransactionsRepository;

        private readonly ILogger<IFraudReleasedTransactionQueue> _logger;

        private readonly IEmailer _emailer;
        public FraudReleasedTransactionQueue(
           string connectionString,
           string exchangeName,
           string queueName,
           string routingKey,
           string deadLetterExchangeName,
           ILogger<IFraudReleasedTransactionQueue> logger, IIndividualTransactionsRepository individualTransactionsRepository,IEmailer emailer)
        {
            _logger = logger;
            QueueName = queueName;
            RoutingKey = routingKey;
            ExchangeName = exchangeName;
            DeadLetterExchangeName = deadLetterExchangeName;
            _individualTransactionsRepository = individualTransactionsRepository;
            Bus = BusFactory.CreateBus(connectionString);
            _emailer = emailer;
        }

        public async Task PublishMessageAsync(CancellationToken stoppingToken)
        {
            try
            {
                FraudReleasedTransaction fraudReleasedTransaction = new FraudReleasedTransaction();
                var releasedTransactions = await _individualTransactionsRepository.GetTransactionsForPassport();
                List<ReleasedIndividualTransactionDto> unAckTransactionsList = new List<ReleasedIndividualTransactionDto>(); 
                if (releasedTransactions != null && releasedTransactions.Count() > 0)
                {
                    _logger.LogInformation("Publisher service::PublishMessageAsync() - Found {0} transactions for processing...", releasedTransactions.Count());

                    foreach (var transactions in releasedTransactions)
                    
                    {
                        try
                        {
                            fraudReleasedTransaction.MessageId = transactions.JvilleMessageId == Guid.Empty ? Guid.NewGuid() : transactions.JvilleMessageId;

                            fraudReleasedTransaction.TxnUuid = transactions.TxnUuid;
                            fraudReleasedTransaction.TxnDetailId = transactions.TxnDetailId;
                            if (await this._individualTransactionsRepository.CheckIfTransactionIsInFlight(fraudReleasedTransaction))
                            {
                                if (transactions.NumberOfAttempts == 5)
                                {
                                    unAckTransactionsList.Add(transactions);
                                    continue;
                                }

                                JsonConvert.DefaultSettings = () => new JsonSerializerSettings
                                {
                                    DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind
                                };
                                var basicProperties = new MessageProperties();
                                basicProperties.Type = typeof(FraudReleasedTransaction).AssemblyQualifiedName;

                                var stringTransaction = JsonConvert.SerializeObject(fraudReleasedTransaction, Formatting.None);
                                var bytes = Encoding.UTF8.GetBytes(stringTransaction);

                                var result = await this._individualTransactionsRepository.InsertReleasedTransactionToPassport(fraudReleasedTransaction, transactions, stringTransaction);
                                if (result.Item1)
                                {
                                    try
                                    {
                                        Bus.Publish(Exchange, RoutingKey, true, basicProperties, bytes);
                                        log4net.LogicalThreadContext.Properties["MessageID"] = fraudReleasedTransaction.MessageId;
                                        _logger.LogInformation($"Transaction released successfully ", fraudReleasedTransaction.MessageId);
                                    }
                                    catch (Exception ex)
                                    {
                                        _logger.LogError("Transaction failed to publish on RMQ: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{2}  ex-{3} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId, ex);
                                    }                                   
                                }
                                else
                                {
                                    _logger.LogError("Transaction failed to publish as Stored Procedure Errors: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{3} ErrorCode-{3} ErrorMessage-{4} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId, result.Item2, result.Item3);
                                }
                            }
                            else
                            {
                                _logger.LogError("Transaction already in process ERRORs: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{3} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId);
                            }
                               
                        }
                        catch (SqlException ex)
                        {
                            if (ex.Number == 1205)
                            {
                                _logger.LogError("Lock wait timeout exceeded: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{2}  ex-{3} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId, ex);
                            }
                            else if (ex.Number == 50000)
                            {
                                _logger.LogError("Violation of PRIMARY KEY constraint 'COMP_KEY'. Cannot insert duplicate key in object 'dbo.InFlightTransactions'.: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{2}  ex-{3} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId, ex);
                            }
                            else
                            {
                                _logger.LogError("Transaction failed to Publish Message as DB failure: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{2}  ex-{3} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId, ex);
                            }
                        }
                        catch (Exception ex)
                        {

                            _logger.LogError("Transaction failed to Publish Message as DB failure: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} TxnDetailId-{2}  ex-{3} ", transactions.JvilleMessageId, transactions.MessageId, fraudReleasedTransaction.TxnUuid, fraudReleasedTransaction.TxnDetailId, ex);
                        }
                        finally
                        {
                            await this._individualTransactionsRepository.ResetInflightFlagForTransaction(fraudReleasedTransaction);
                        }
                    }

                    if(unAckTransactionsList.Count > 0)
                    {
                        _logger.LogInformation("Publisher Service::PublishMessageAsync() - Found {0} unacknowledged transactions.", unAckTransactionsList.Count);

                        if(await TriggerEmailForUnAckTransaction(unAckTransactionsList))
                        {
                            _logger.LogInformation("Publisher Service::PublishMessageAsync() - sent email for unacknowledged transactions.");
                        }
                        else
                        {
                            _logger.LogInformation("Publisher Service::PublishMessageAsync() - Valid txn not found to for sending email.");
                        }
                    }
                }
                else
                {
                    _logger.LogInformation("Publisher Service::PublishMessageAsync() - Transcations not found for processing.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Fetch Transcation from Database Error -{0} ", ex);

            }

        }

        private async Task<bool> TriggerEmailForUnAckTransaction(List<ReleasedIndividualTransactionDto> unAckTransactionsList)
        {
            var result = false;
            try
            {
                //check if notification status got updatd in meantime by another service.
               
                var txnList = await this._individualTransactionsRepository.CheckNotificationStatusForMessageIds(unAckTransactionsList);

                _logger.LogInformation("Publisher service::TriggerEmailForUnAckTransaction() - Valid txn count for email : " + txnList.Count());

                if (txnList.Count() > 0)
                {
                    var finalTxnList = (from originalList in unAckTransactionsList
                                 join latestList in txnList on originalList.JvilleMessageId equals latestList.MessageId
                                 select new ReleasedIndividualTransactionDto { JvilleMessageId = originalList.JvilleMessageId, TxnUuid = originalList.TxnUuid, TxnDetailId = originalList.TxnDetailId, LastRetriedDateUtc = originalList.LastRetriedDateUtc }).ToList();

                    var subject = "Unacknowledged RiskLab messages from Passport";
                    StringBuilder body = new StringBuilder();
                    body.Append("Jville didn't receive acknowledgement for the following messages : ");
                    
                    foreach (var item in finalTxnList)
                    {
                      body.Append("\n" + "MessageId: " + item.JvilleMessageId + ", TxnUUID: "+item.TxnUuid +", TxnDetaiID: "+item.TxnDetailId +", Message Last Sent On(UTC): "+item.LastRetriedDateUtc);
                    }

                    if (await _emailer.SendEmailAsync(subject, body.ToString()))
                    {
                        await _individualTransactionsRepository.UpdateNotificationStatusForMessageIds(finalTxnList);
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Publisher service::TriggerEmailForUnAckTransaction() - Exception caught : " + ex.Message);
                return false;
            }

            return result;
        }
    }
}

