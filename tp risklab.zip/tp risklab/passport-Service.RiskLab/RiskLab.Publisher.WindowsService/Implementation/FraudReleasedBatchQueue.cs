﻿using Acquisition.Contracts.Risk.Jville;
using EasyNetQ;
using Newtonsoft.Json;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure;
using RiskLab.Publisher.WindowsService.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Publisher.WindowsService.Implementation
{
    public class FraudReleasedBatchQueue : QueueBasePublish<FraudReleasedBatch>, IFraudReleasedBatchQueue
    {
        private readonly IBatchRejectsRepository _batchRejectsRepository;

        private readonly ILogger<IFraudReleasedBatchQueue> _logger;

        private readonly IEmailer _emailer;
        public FraudReleasedBatchQueue(
           string connectionString,
           string exchangeName,
           string queueName,
           string routingKey,
           string deadLetterExchangeName,
           ILogger<IFraudReleasedBatchQueue> logger, IBatchRejectsRepository batchRejectsRepository, IEmailer emailer)
        {
            _logger = logger;
            QueueName = queueName;
            RoutingKey = routingKey;
            ExchangeName = exchangeName;
            DeadLetterExchangeName = deadLetterExchangeName;
            _batchRejectsRepository = batchRejectsRepository;
            Bus = BusFactory.CreateBus(connectionString);
            _emailer = emailer;
        }
        public async Task PublishMessageAsync(CancellationToken stoppingToken)
        {
            FraudReleasedBatch fraudReleasedBatch = new FraudReleasedBatch();
            var releasedBatches = await _batchRejectsRepository.GetReleasedBatchesForPassport();

            List<ReleasedBatchDto> unAckBatch = new List<ReleasedBatchDto>();

            if (releasedBatches != null && releasedBatches.Count() > 0)
            {
                _logger.LogInformation("Batch Publisher Service::PublishMessageAsync() - Found {0} batches for processing...", releasedBatches.Count());
                foreach (var batch in releasedBatches)
                {
                    try
                    {
                        if (await this._batchRejectsRepository.CheckIfBatchIsInProcess(batch))
                        {
                            if (batch.NumberOfAttempts == 5)
                            {
                                unAckBatch.Add(batch);
                                continue;
                            }
                            fraudReleasedBatch.MessageId = batch.JvilleMessageId == Guid.Empty ? Guid.NewGuid() : batch.JvilleMessageId;
                            fraudReleasedBatch.TxnUuid = batch.TxnUuid;

                            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
                            {
                                DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind
                            };
                            var basicProperties = new MessageProperties();
                            basicProperties.Type = typeof(FraudReleasedBatch).AssemblyQualifiedName;

                            var stringTransaction = JsonConvert.SerializeObject(fraudReleasedBatch, Formatting.None);
                            var bytes = Encoding.UTF8.GetBytes(stringTransaction);

                            var result = await this._batchRejectsRepository.InsertReleasedBatchToPassport(fraudReleasedBatch, batch, stringTransaction);
                            if (result.Item1)
                            {
                                try
                                {
                                    Bus.Publish(Exchange, RoutingKey, true, basicProperties, bytes);
                                    log4net.LogicalThreadContext.Properties["MessageID"] = fraudReleasedBatch.MessageId;
                                    _logger.LogInformation($"Batch released successfully ", fraudReleasedBatch.MessageId);
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError("Batch Publisher Service::PublishMessageAsync() - failed to publish batch to RMQ: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} ex-{3} ", batch.JvilleMessageId, batch.MessageId, fraudReleasedBatch.TxnUuid, ex);
                                }
                            }
                            else
                            {
                                _logger.LogError("Batch Publisher Service::PublishMessageAsync() - failed to publish batch , Stored Procedure Errors: JvilleMessageId-{0} PassportMessageID-{1} TxnUuid-{2} ErrorCode-{3} ErrorMessage-{4} ", batch.JvilleMessageId, batch.MessageId, fraudReleasedBatch.TxnUuid, result.Item2, result.Item3);
                            }
                        }
                        else
                        {
                            _logger.LogError("Batch Publisher Service::PublishMessageAsync() - batch already in process ERRORs:  TxnUuid-{0} ", batch.TxnUuid);
                        }
                    }
                    catch (SqlException x)
                    {
                        _logger.LogError("Batch Publisher Service::PublishMessageAsync() - Sql exception caught in batch publish: " + x.ToString());
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Batch Publisher Service::PublishMessageAsync() - exception caught in batch publish: " + ex.ToString());
                    }
                    finally
                    {
                        await this._batchRejectsRepository.ResetInFlightBatch(batch);
                    }
                }
                if (unAckBatch.Count > 0)
                {
                    _logger.LogInformation("Batch Publisher Service ::PublishMessageAsync() - Found {0} unacknowledged batches.", unAckBatch.Count);

                    if (await TriggerEmailForUnAckTransaction(unAckBatch))
                    {
                        _logger.LogInformation("Batch Publisher Service::PublishMessageAsync() - sent email for unacknowledged batches.");
                    }
                    else
                    {
                        _logger.LogInformation("Batch Publisher Service::PublishMessageAsync() - Valid txn not found to for sending email.");
                    }
                }
            }
            else
            {
                _logger.LogInformation("Batch Publisher Service::PublishMessageAsync() - No batch found for processing...");
            }
        }

        private async Task<bool> TriggerEmailForUnAckTransaction(List<ReleasedBatchDto> unAckBatch)
        {
            var result = false;
            try
            {
                //check if notification status got updatd in meantime by another service.

                var txnList = await this._batchRejectsRepository.CheckNotificationStatusForMessageIds(unAckBatch);

                _logger.LogInformation("Batch Publisher service::TriggerEmailForUnAckTransaction() - Valid txn count for email : " + txnList.Count());

                if (txnList.Count() > 0)
                {
                    var finalTxnList = (from originalList in unAckBatch
                                        join latestList in txnList on originalList.JvilleMessageId equals latestList.MessageId
                                        select new ReleasedBatchDto { JvilleMessageId = originalList.JvilleMessageId, TxnUuid = originalList.TxnUuid, LastRetriedDateUtc = originalList.LastRetriedDateUtc }).ToList();

                    var subject = "Unacknowledged RiskLab messages from Passport";
                    StringBuilder body = new StringBuilder();
                    body.Append("Jville didn't receive acknowledgement for the following batch messages : ");

                    foreach (var item in finalTxnList)
                    {
                        body.Append("\n" + "MessageId: " + item.JvilleMessageId + ", TxnUUID: " + item.TxnUuid +  ", Message Last Sent On(UTC): " + item.LastRetriedDateUtc);
                    }

                    if (await _emailer.SendEmailAsync(subject, body.ToString()))
                    {
                        await _batchRejectsRepository.UpdateNotificationStatusForMessageIds(finalTxnList);
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Batch Publisher service::TriggerEmailForUnAckTransaction() - Exception caught : " + ex.Message);
                return false;
            }

            return result;
        }
    }
}
