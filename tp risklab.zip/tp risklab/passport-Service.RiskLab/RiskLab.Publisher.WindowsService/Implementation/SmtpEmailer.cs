﻿using Hps.SettingsManagerClient;
using RiskLab.Core.Constants;
using RiskLab.Publisher.WindowsService.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Publisher.WindowsService.Implementation
{
    public class SmtpEmailer : IEmailer
    {
        private readonly ISettingsManager _settingsManager;
        private readonly ILogger<SmtpEmailer> _logger;

        public SmtpEmailer(ISettingsManager settings, ILogger<SmtpEmailer> logger)
        {
            _settingsManager = settings;
            _logger = logger;
        }

        public async Task<bool> SendEmailAsync(string subject, string body)
        {
            bool result = false;
            List<string> emailToList = new List<string>();
            var emailFrom = string.Empty;
            var smtpServer = string.Empty;

            try
            {
                var emailTo = _settingsManager.GetSettingByKey(SettingsManagerKeys.PassportUnAckEmailTo).GetAwaiter().GetResult().Value;

                if (!string.IsNullOrWhiteSpace(emailTo))
                {
                    emailToList = new List<string>(emailTo.Split(',', ';').Select(x => x.Trim()));
                }

                emailFrom = _settingsManager.GetSettingByKey(SettingsManagerKeys.PassportUnAckEmailFrom).GetAwaiter().GetResult().Value;
                smtpServer = _settingsManager.GetSettingByKey(SettingsManagerKeys.HPS_SMTP_MAIL_SERVER).GetAwaiter().GetResult().Value;
            }
            catch (Exception ex)
            {
                _logger.LogError("SmtpEmailer:: SendEmailAsync() - Caught Exception while reading settings " + ex.ToString());

                if(emailToList.Count == 0)
                { 
                    emailToList.Add("mthpsbootstrappersnotifications@tsys.com"); 
                }
                if (string.IsNullOrWhiteSpace(emailFrom))
                { 
                    emailFrom = "DoNotReplyRiskLab@e-hps.com"; 
                }
                if (string.IsNullOrWhiteSpace(smtpServer))
                {
                    smtpServer = "jvl-smtp.e-hps.com";
                }              
            }

            using (var message = new MailMessage())
            {
                message.Subject = subject + (_settingsManager.EnvironmentCode.ToUpper().Trim() == "PRODUCTION" ? "" : " (" + _settingsManager.EnvironmentCode + ")");
                message.Body = body.Replace("\n", "<br/>");
                message.IsBodyHtml = true;
                message.From = new MailAddress(emailFrom);

                foreach (var email in emailToList)
                {
                    message.To.Add(email);
                }

                using (var smtpClient = new SmtpClient(smtpServer))
                {
                    await smtpClient.SendMailAsync(message);
                    result = true;
                }
                
                return result;
            }
        }
    }
}
