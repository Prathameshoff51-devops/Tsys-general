using Hps.SettingsManagerClient;
using RiskLab.Core.Constants;
using RiskLab.Core.Interfaces;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Infrastructure;
using RiskLab.Infrastructure.Dapper;
using RiskLab.Infrastructure.Dapper.Repository;
using RiskLab.Infrastructure.Interfaces;
using RiskLab.Publisher.WindowsService;
using RiskLab.Publisher.WindowsService.Implementation;
using RiskLab.Publisher.WindowsService.Interfaces;

using IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService(options =>
    {
        options.ServiceName = "RiskLab.Publisher";
    }).ConfigureAppConfiguration((hostingContext, config) =>
    {
        config.AddJsonFile("appsettings.json", optional: true);
        config.AddEnvironmentVariables();

    })
    .ConfigureServices((hostContext, services) =>
    {
        var applicationName = hostContext.Configuration["AppSettings:ApplicationName"];
        var environmentCode = hostContext.Configuration["AppSettings:EnvironmentCode"];
        
        var settingsManager = new SettingsManager(applicationName, environmentCode);

        services.AddSingleton<ISettingsManager>(settingsManager);

        services.AddSingleton<ISqlDbConnectionManager, SqlDbConnectionManager>();


        //start - not using it but adding temporary will remove it;
        var settingsManagerWrapper = new SettingsManagerWrapper(
                applicationName,
                environmentCode);
        services.AddSingleton<ISettingsManagerWrapper>(_ => settingsManagerWrapper);  
        //end

       
        //services.AddScoped<IRetryMessageService, RetryMessageService>();
        services.AddTransient<IIndividualTransactionsRepository, IndividualTransactionsRepository>();
        services.AddTransient<IBatchRejectsRepository, BatchRejectsRepository>();
        services.AddTransient<IEmailer, SmtpEmailer>();

        var connectionString = settingsManager.GetSettingByKey(SettingsManagerKeys.RiskLabRabbitMqConnection).GetAwaiter().GetResult();
        string connectionStringValue = connectionString.Value.Replace(@"\", string.Empty);       

        services.AddScoped<IFraudReleasedTransactionQueue>(x => new FraudReleasedTransactionQueue(
            connectionStringValue,
            RabbitMQConfig.ExchangeName,
            RabbitMQConfig.FraudReleasedTransactionQueue,
            RabbitMQConfig.FraudReleasedTransactionRoutingKey,
            RabbitMQConfig.DeadLetterExchangeName,
            x.GetRequiredService<ILogger<IFraudReleasedTransactionQueue>>(),
            x.GetRequiredService<IIndividualTransactionsRepository>(),
            x.GetRequiredService<IEmailer>()));

        services.AddScoped<IFraudReleasedBatchQueue>(x => new FraudReleasedBatchQueue(
            connectionStringValue,
            RabbitMQConfig.ExchangeName,
            RabbitMQConfig.FraudReleasedBatchQueue,
            RabbitMQConfig.FraudReleasedBatchRoutingKey,
            RabbitMQConfig.DeadLetterExchangeName,
            x.GetRequiredService<ILogger<IFraudReleasedBatchQueue>>(),
            //x.GetRequiredService<IIndividualTransactionsRepository>(),
            x.GetRequiredService<IBatchRejectsRepository>(),
            x.GetRequiredService<IEmailer>()));


        services.AddHostedService<Worker>();

    }).ConfigureLogging((hostContext, logging) =>
    {
        logging.AddConfiguration(hostContext.Configuration.GetSection("Logging"));
        logging.AddConsole();
        logging.AddDebug();
        logging.AddLog4Net();
    }).Build();

await host.RunAsync();



