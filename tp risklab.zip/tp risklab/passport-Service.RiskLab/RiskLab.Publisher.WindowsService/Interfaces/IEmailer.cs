﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Publisher.WindowsService.Interfaces
{
    public interface IEmailer
    {
        Task<bool> SendEmailAsync(string subject, string body);
    }
}
