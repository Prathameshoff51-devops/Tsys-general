﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Publisher.WindowsService.Interfaces
{
    public interface IFraudReleasedBatchQueue
    {
        string QueueName { get; set; }
        Task StartAsync();
        Task PublishMessageAsync(CancellationToken stoppingToken);
        void Stop();
    }
}
