﻿using EasyNetQ;
using EasyNetQ.Topology;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Publisher.WindowsService.Interfaces
{
    public interface IFraudReleasedTransactionQueue
    {
            string QueueName { get; set; }
            Task StartAsync();
            Task PublishMessageAsync(CancellationToken stoppingToken);

        void Stop();
        
    }
}
