using Hps.SettingsManagerClient;
using RiskLab.Core.Constants;
using RiskLab.Publisher.WindowsService.Interfaces;

namespace RiskLab.Publisher.WindowsService
{

    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly ISettingsManager _settingsManager;
        private IServiceScope _scope;
        private readonly IServiceProvider _serviceProvider;
        private IFraudReleasedTransactionQueue _fraudReleasedTransactionQueue;
        private IFraudReleasedBatchQueue _fraudReleasedBatchQueue;
        int interval = 60000;
        int failureRetryCount = int.MaxValue;
        public Worker(IServiceProvider serviceProvider, ILogger<Worker> logger, ISettingsManager settingsManager)
        {

            _settingsManager = settingsManager;
            _serviceProvider = serviceProvider;
            _logger = logger;
            _scope = _serviceProvider.CreateScope();
            _fraudReleasedTransactionQueue = _scope.ServiceProvider.GetRequiredService<IFraudReleasedTransactionQueue>();
            _fraudReleasedBatchQueue = _scope.ServiceProvider.GetRequiredService<IFraudReleasedBatchQueue>();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {

            _logger.LogInformation("RiskLab.Publisher windows service starting");
            try
            {
                var res = _settingsManager.GetSettingByKey(SettingsManagerKeys.PublisherJobInterval).GetAwaiter().GetResult().Value;
                interval = Int32.Parse(res);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An exception while reading the PublisherJobInterval from SettingManager - RiskLab.Publisher windows service: {ex.Message}");
            }

            try
            {
                var res = _settingsManager.GetSettingByKey(SettingsManagerKeys.FailureRetryCount).GetAwaiter().GetResult().Value;
                failureRetryCount = Int32.Parse(res);
            }
            catch
            {
                _logger.LogInformation($"Setting the default value for failureRetryCount: {failureRetryCount}");
            }


            bool done = false;
            while (!done && failureRetryCount > 0)
            {
                try
                {
                    await _fraudReleasedTransactionQueue.StartAsync();
                    await _fraudReleasedBatchQueue.StartAsync();
                    done = true;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"An exception occurred while creating RabbitMQ Exchange/Queues for RiskLab.Publisher windows service: {ex.Message}");
                    await Task.Delay(interval, stoppingToken);
                }
                if (done)
                    break;
                failureRetryCount--;
            }

            while (true)
            {
                try
                {
                    //add random delay of 1 - 3 minutes

                    Random rnd = new Random();

                    int MaxDelay = interval * 3;
                    int randomDelay = rnd.Next(interval, MaxDelay);

                    await Task.Delay(randomDelay, stoppingToken);

                    _logger.LogInformation("RiskLab.Publisher ran successfully at: {time} -  after delay of {delay} ms.", DateTimeOffset.Now, randomDelay);

                    _logger.LogInformation("RiskLab.Publisher starting individual txn processing.....");                   

                    await _fraudReleasedTransactionQueue.PublishMessageAsync(stoppingToken);

                    _logger.LogInformation("RiskLab.Publisher completed individual txn processing.....");

                    _logger.LogInformation("RiskLab.Publisher starting batch processing.....");

                    await _fraudReleasedBatchQueue.PublishMessageAsync(stoppingToken);

                    _logger.LogInformation("RiskLab.Publisher completed batch processing.....");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"An exception occurred starting the RiskLab.Publisher windows service: {ex.Message}");
                }
            }
        }
        public override Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("RiskLab.Publisher windows service stopping");
            return base.StopAsync(stoppingToken);
        }
    }
}