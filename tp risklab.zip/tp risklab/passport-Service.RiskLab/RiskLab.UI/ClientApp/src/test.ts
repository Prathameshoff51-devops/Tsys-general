// This file is required by karma.conf.js and loads recursively all the .spec and framework files

import 'zone.js/testing';
import { getTestBed } from '@angular/core/testing';
import {
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting
} from '@angular/platform-browser-dynamic/testing';

// First, initialize the Angular testing environment.
getTestBed().initTestEnvironment(
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting(),
);

// Import all test files manually
import './app/app.component.spec';
import './app/batch-new-txn-rejects/batch-new-txn-rejects.component.spec';
import './app/batch-queued-txn-rejects/batch-queued-txn-rejects.component.spec';
import './app/bulk-refunds/bulk-refunds.component.spec';
import './app/error/error.component.spec';
import './app/export-import/export-import.component.spec';
import './app/fraud-service/fraud-service.component.spec';
import './app/home/home.component.spec';
import './app/individual-refunds/individual-refunds.component.spec';
import './app/logout/logout.component.spec';
import './app/maintenance/maintenance.component.spec';
import './app/merchant-rejectedtxns/merchant-rejectedtxns.component.spec';
import './app/navigation/router-link-renderer/router-link-renderer.component.spec';
import './app/navigation/side-navbar/side-navbar.component.spec';
import './app/navigation/top-navbar/top-navbar.component.spec';
import './app/queued-bulk-refunds/queued-bulk-refunds.component.spec';
import './app/queued-txn-refunds/queued-txn-refunds.component.spec';
import './app/riskrejects/riskrejects.component.spec';
import './app/riskrejects-bulk/riskrejects-bulk.component.spec';
import './app/shared/models/app-config.spec';
import './app/shared/models/menu-item.model.spec';
import './app/shared/services/baseapi.service.spec';
import './app/shared/services/batch-queued-txn-rejects.spec';
import './app/shared/services/batch-refund.service.spec';
import './app/shared/services/configuration.service.spec';
import './app/shared/services/export.service.spec';
import './app/shared/services/idle-timeout.service.spec';
import './app/shared/services/individual-refund.service.spec';
import './app/shared/services/scroll.service.spec';
import './app/ui/alert-dialog/alert-dialog.component.spec';
import './app/ui/drop-down-list-renderer/drop-down-list-renderer.component.spec';
import './app/ui/loader/loader.component.spec';
import './app/ui/loading-dialog/loading-dialog.component.spec';
import './app/ui/menu-list-item/menu-list-item.component.spec';
import './app/ui/service/alert.service.spec';
import './app/ui/service/loader.service.spec';
import './app/ui/service/loading-dialog.service.spec';
import './app/unauthorized/unauthorized.component.spec';
import './app/constant.unit.test';
