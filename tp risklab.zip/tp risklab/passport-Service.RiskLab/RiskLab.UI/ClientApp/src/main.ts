import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { applyPolyfills, defineCustomElements } from '@heartlandone/vega/loader';
import { AppConfig } from './app/shared/models/app-config';
import { OKTA_CONFIG } from '@okta/okta-angular';
import { OktaAuth } from '@okta/okta-auth-js';


if (environment.production) {
  enableProdMode();
}

fetch('./assets/config.json').then(async res => {
  const authConfig = new AppConfig(await res.json());
  platformBrowserDynamic([
    { provide: AppConfig, useValue: authConfig }
  ]).bootstrapModule(AppModule)
    .catch( (err : any) => console.error(err));
}).catch(() => {
  console.log('bootstrapper err');
});



applyPolyfills().then(() => {
  defineCustomElements()
})
