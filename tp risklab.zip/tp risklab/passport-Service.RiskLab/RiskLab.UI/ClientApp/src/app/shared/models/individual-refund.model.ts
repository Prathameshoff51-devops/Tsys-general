import { RejectStatuses } from '../enums';

export interface IndividualRefund {
  action: Number;
  individualTxnId: number;
  messageId: string;
  txnUuid: number;
  txnDetailId: number;
  merchantNumber: string;
  merchantName: string;
  legalName: string;
  chainOID: string;
  mcc: string;
  amount: Number;
  cardNumberMask: string;
  txnDateUtc: string;
  fraudRejectReasonCode: string[];
  originalBatchNumber: string;
  authCode: string;
  expDate: string;
  //ServiceOptionTxnTypeID: string;
  txnTypeDescription: string;
  batchCloseDate: string;
  //SubmitterId:Number;
  submitterIDDescription: string;
  daysToAct: Number;
  userAction: string;
}

export interface TransactionAction {
  transactionsStatus: TransStatus[];
  userName: string;
}

export interface TransStatus {
  TransactionId: number;
  NewStatus: string;
}
export interface RejectsCount {
  Count: number;
  Status: string;
}


export interface Merchant {
  merchantNumber: string;
  merchantName: string;
  merchantRejects: merchantRejects[];
}

export interface merchantRejects {
  id: number;
  businessDateUtc: string;
  amount: Number;
  cardNumberMask: string;
  txnDateUtc: string;
  fraudRejectReasonCodes: string[];
  batchNumber: string;
  txnTypeDescription: string;
  status: string;
  suspensionType: string;
}

