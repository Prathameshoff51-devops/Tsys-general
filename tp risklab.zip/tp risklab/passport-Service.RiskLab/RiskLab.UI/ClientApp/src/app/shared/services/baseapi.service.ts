import { HttpParams, HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Configuration } from '../models/configuration.model';
import { AppConfig } from '../models/app-config';
@Injectable({
  providedIn: 'root'
})
export class BaseApiService {
  
  constructor(
    private httpclient: HttpClient,
    private appConfig: AppConfig
  ) {
  
  }

  get ApiUrl() {
    return this.appConfig.config.apiUrl;
  }
  public getPath<T>(path?: string, params?: HttpParams): Observable<T> {
    return this.get(path, undefined, params);
  }

 

  public get<T>(
    controller?: string,
    actions?: string,
    params?: HttpParams
  ): Observable<T> {
    let url = this.ApiUrl;

    if (controller) url = url.concat(`/${controller}`);

    if (actions) url = url.concat(`/${actions}`);

    return this.httpclient.get<T>(url, {
      withCredentials: true,
      headers: this.getHeaders(),
      params: params || new HttpParams()
    });
  }


  public getMany<T>(
    controller?: string,
    actions?: string,
    params?: HttpParams
  ): Observable<T[]> {
    let url = this.ApiUrl;
    if (controller) url = url.concat(`/${controller}`);

    if (actions) url = url.concat(`/${actions}`);

    return this.httpclient.get<T[]>(url, {
      withCredentials: false,
      headers: this.getHeaders(),
      params: params || new HttpParams()
    });
  }

  public postPath<T>(
    path?: string,
    body?: any,
    params?: HttpParams
  ): Observable<T> {
    return this.post(path, undefined, body, params);
  }

  public post<T>(
    controller?: string,
    actions?: string,
    body?: any,
    params?: HttpParams
  ): Observable<T> {
    let url = this.ApiUrl;
    if (controller) url = url.concat(`/${controller}`);

    if (actions) url = url.concat(`/${actions}`);

    return this.httpclient.post<T>(url, body || {}, {
      withCredentials: false,
      headers: this.getHeaders(),
      params: params || new HttpParams()
    })
  }



  public putPath<T>(
    path?: string,
    params?: HttpParams,
    body?: any
  ): Observable<T> {
    return this.put<T>(path, undefined, params, body);
  }

  public put<T>(
    controller?: string,
    actions?: string,
    params?: HttpParams,
    body?: any
  ): Observable<T> {
    let url = this.ApiUrl;
    if (controller) url = url.concat(`/${controller}`);

    if (actions) url = url.concat(`/${actions}`);

    return this.httpclient.put<T>(url, body || {}, {
      withCredentials: true,
      headers: this.getHeaders(),
      params: params || new HttpParams()
    });
  }

  public downloadFile(
    controller?: string,
    actions?: string,
    params?: HttpParams
  ): Observable<import('@angular/common/http').HttpResponse<Blob>> {
    let url = this.ApiUrl;
    if (controller && controller !== '') url = url.concat(`/${controller}`);
    if (actions) url = url.concat(`/${actions}`);

    return this.httpclient.get(url, {
      withCredentials: true,
      headers: this.getHeaders(),
      params: params || new HttpParams(),
      responseType: 'blob',
      observe: 'response'
    });
  }

  private getHeaders(): HttpHeaders {
    return new HttpHeaders(
      this.appConfig.config.apiHeader
    );
  }
}
