import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { BaseApiService } from './baseapi.service';

@Injectable({
  providedIn: 'root'
})
export class ExportService {

  constructor(private baseService: BaseApiService) {}

  exportToExcel(
    pageName: string,
    status: number
  ): Observable<import('@angular/common/http').HttpResponse<Blob>> {
    const httpParams = new HttpParams()
      .set('pageName', pageName)
      .set('status', status.toString());
    return this.baseService.downloadFile(
      '',
      'ExcelExport',
      httpParams
    ).pipe(
      catchError((e) => {
        console.log('error: ' + e);
        throw e;
      })
    );
  }
}
