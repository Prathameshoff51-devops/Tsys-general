import { ConstantsUnitTest } from "src/app/constant.unit.test";
import { AppConfig } from "./app-config";

describe("AppConfig", () => {
 
  it("should create an instance", () => {
    expect(new AppConfig(ConstantsUnitTest.config)).toBeTruthy();
  });
});
