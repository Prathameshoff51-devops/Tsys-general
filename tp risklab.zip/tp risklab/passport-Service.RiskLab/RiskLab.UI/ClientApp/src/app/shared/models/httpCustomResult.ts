export enum StatusCode {
    Ok = 200,
    ClientError = 400,
    NotFound = 404,
    ServerError = 500
}

export interface HttpCustomResult {
    result: any;
    statusCode: StatusCode;
    messages: string[];
}
