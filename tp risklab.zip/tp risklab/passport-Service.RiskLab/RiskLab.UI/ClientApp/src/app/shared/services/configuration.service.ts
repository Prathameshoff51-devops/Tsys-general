import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Configuration } from '../models/configuration.model';
import { resetFakeAsyncZone } from '@angular/core/testing';
import { MenuItem } from '../models/menu-item.model';
import { environment } from '../../../environments/environment';
import { AppConfig } from '../models/app-config';

type FindMenuCallbackAction = (item: MenuItem) => void;
@Injectable({
  providedIn: 'root',
})
export class ConfigurationService {
  configData!: Configuration;

  constructor(private http: HttpClient, private appconfig: AppConfig) {}

  loadInitialData() {
    return this.loadConfigurationData();
  }

  loadConfigurationData(): Promise<Configuration> {
    let url = this.appconfig.config.apiUrl.concat('/Configurations');
    return this.http
      .get(url)
      .toPromise()
      .then((response: any) => {
        this.configData = response;
        return this.configData;
      });
  }

  get config(): Configuration | any {
    if (this.configData === undefined) {
      return (async () => {
        this.configData = await this.loadConfigurationData();
        return this.configData;
      })();
    } else {
      return this.configData;
    }
  }

  get menu(): Array<MenuItem> | any {
    if (this.configData === undefined) {
      this.loadConfigurationData().then((res) => {
        this.configData = res;
        return this.configData.menu.map((m) => new MenuItem(m));
      });
    } else {
      return this.configData.menu.map((m) => new MenuItem(m));
    }
  }
  existsMenuByField(
    fieldName: string,
    fieldValue: string,
    callback: FindMenuCallbackAction
  ): boolean {
    return this.existsMenuByFieldInSubMenu(
      fieldName,
      fieldValue,
      this.menu,
      callback
    );
  }

  existsMenuByFieldInSubMenu(
    fieldName: string,
    fieldValue: string,
    subMenu: Array<MenuItem>,
    callback: FindMenuCallbackAction
  ): boolean {
    let count: number = subMenu.length;
    let found: boolean = false;
    let i: number = 0;

    while (!found && i < count) {
      let menu = subMenu[i];
      if (
        menu[fieldName] == fieldValue ||
        (menu.childrenMenuItems &&
          menu.childrenMenuItems.length > 0 &&
          this.existsMenuByFieldInSubMenu(
            fieldName,
            fieldValue,
            menu.childrenMenuItems,
            callback
          ))
      ) {
        if (callback) {
          callback(menu);
        }
        found = true;
      }
      i++;
    }
    return found;
  }

  getMenuByField(
    fieldName: string,
    fieldValue: string,
    menu: Array<MenuItem>
  ): MenuItem {
    return this.getMenuByFieldInSubMenu(fieldName, fieldValue, menu);
  }

  getMenuByFieldInSubMenu(
    fieldName: string,
    fieldValue: string,
    subMenu: Array<MenuItem>
  ): MenuItem {
    let count: number = subMenu.length;
    let result: MenuItem;
    let i: number = 0;

    while (!result && i < count) {
      if (subMenu[i][fieldName] == fieldValue) {
        result = subMenu[i];
      } else if (
        subMenu[i].childrenMenuItems &&
        subMenu[i].childrenMenuItems.length > 0
      ) {
        result = this.getMenuByFieldInSubMenu(
          fieldName,
          fieldValue,
          subMenu[i].childrenMenuItems
        );
      }
      i++;
    }
    return result;
  }
}
