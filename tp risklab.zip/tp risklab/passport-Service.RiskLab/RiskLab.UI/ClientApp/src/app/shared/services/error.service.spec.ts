import { ErrorService } from './error.service';

describe('ErrorService', () => {
  let service: ErrorService;

  beforeEach(() => {
    service = new ErrorService();
  });

  it('should emit the correct value when updateMessage is called', (done) => {
    const testMsg = 'Test error message';
    service.update$.subscribe(value => {
      if (value === testMsg) {
        expect(value).toBe(testMsg);
        done();
      }
    });
    service.updateMessage(testMsg);
  });
});
