import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ScrollService {
  private scrollToTopSubject = new Subject<void>();
  scrollToTop$ = this.scrollToTopSubject.asObservable();
  private scrollToBottomSubject = new Subject<void>();
  scrollToBottom$ = this.scrollToBottomSubject.asObservable();

  triggerScrollToTop(): void {
    this.scrollToTopSubject.next();
  }
   triggerScrollToBottom(): void {
    this.scrollToBottomSubject.next();
  }
}
