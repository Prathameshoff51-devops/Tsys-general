import { IMenuItem,MenuItem } from './menu-item.model'

export class Configuration {
  public environment!: string;
  public defaultGridPageSize!: number;
  public defaultBatchGridPageSize!: number;
  public defaultBackOfficeGridPageSize!: number;
  public DefaultGridPageSizeforBatchTxnRejects: number;
  public daysToAct!: number;
  public minimumSearchLength!: number;
  public riskLabApiUrl!: string;
  public username!: string;
  public coreloggingServiceUrl!: string;
  public threadId!: number;
  public riskLabUiUrl!: string;
  public menu:Array<IMenuItem>;
  public isBackOfficeUser!:boolean;
  public isFraudServiceUser!:boolean;
}
