import { Injectable, Inject } from '@angular/core';
import { Observable, Subject, Subscription, BehaviorSubject, timer } from 'rxjs';
import { OKTA_AUTH, OktaAuthStateService } from '@okta/okta-angular';
import { OktaAuth, UserClaims, AuthApiError, AccessToken, Tokens } from '@okta/okta-auth-js';
@Injectable()
export class IdleTimeoutService {
  private _count: number = 0;
  private _timeoutSeconds: number = 30;
  private timerSubscription: Subscription | any;
  private timer: Observable<number> | any;
  private resetOnTrigger: boolean = false;
  public timeoutExpired: Subject<number> = new Subject<number>();
  private _dismissTimer: Observable<number>  | any;
  public _dismissSubscription: Subscription | any;
  public lastTime: number;
  public _sessionMinutes: number = 20;
  public _sessionDismissMinutes: number = 2;
  constructor(@Inject(OKTA_AUTH) private oktaAuth: OktaAuth) {  

    this.timeoutExpired.subscribe(n => {
     // console.log("timeoutExpired subject next.. " + n.toString())
    });

   // this.startTimer();
  }
  public startTimer() {
    
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }

    this.timer = timer(this._timeoutSeconds * 1000);
    this.timerSubscription = this.timer.subscribe((n:any) => {
      this.timerComplete(n);
    });
  }

  public stopTimer() {
    this.timerSubscription.unsubscribe();
  }

  public resetTimer() {
    
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
    }

    this.timer = timer(this._timeoutSeconds * 1000);
    this.timerSubscription = this.timer.subscribe( (n:any) => {
      this.timerComplete(n);
    });
  }

  private timerComplete(n: number) {
    this.timeoutExpired.next(++this._count);

    if (this.resetOnTrigger) {
      this.startTimer();
    }
  }

  public startDismissTimer() {

    if (this._dismissSubscription) {
      this._dismissSubscription.unsubscribe();
    }

    // This needs to come from the config
    let timeout: number = this._sessionDismissMinutes * 60 * 1000;
    /*if (this._configSvc.configData.authSettings.authDismissTimeout) {
      timeout = <number>this._configSvc.configData.authSettings.authDismissTimeout;
    }*/
    this._dismissTimer = timer(timeout);
    this._dismissSubscription = this._dismissTimer.subscribe( (n : any) => {
      this._dismissSubscription.unsubscribe();
      this.oktaAuth.signOut({
        revokeAccessToken: true,
      }).then(() => {
      }).catch((err) => {
        console.log(err);
        alert(err);
      });

      
    });
  }
}

