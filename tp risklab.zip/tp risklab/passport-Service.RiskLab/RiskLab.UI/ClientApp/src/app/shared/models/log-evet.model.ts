export enum Severity {
    Information = 'Information',
    Error = 'Error',
    Warning = 'Warning',
    Trace = 'Trace'
}


export interface LogEventDetails {
  message: string,
  fullText: string,
  exceptionType: string

}
