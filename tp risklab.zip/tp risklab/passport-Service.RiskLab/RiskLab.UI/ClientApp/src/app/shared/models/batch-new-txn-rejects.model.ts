import { RejectStatuses } from "../enums";

export interface BatchtxnRejects {
  originalBatchNumber: string;
  batchCloseDateUTC: string;
  merchantNumber: string;
  merchantName: string;
  batchAmount: string;
  batchRejectId: Number;
  status: string;
  transactions: Transactions[];
}
export interface Transactions {
  txnAmount: Number;
  txnType: string;
  actionDropdown: number;
  cardNumberMasked: string;
  txnDateUTC: string;
  originalBatchNumber: string;
  batchCloseDateUTC: string;
  status: String;
  batchTransactionRejectId: number;
  batchRejectId: number;
  rejectReasons: string[];
  action: number;
  expDate: string;
  authCode: string;
  daysToAct: number;
}


