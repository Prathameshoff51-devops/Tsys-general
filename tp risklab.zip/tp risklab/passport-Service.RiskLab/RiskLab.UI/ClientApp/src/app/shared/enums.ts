
export enum RejectStatuses {
  New = 1,
  Queued = 2,
  Released = 3,
  Deleted = 4,
  Purged = 5
}
