import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import {
  BatchtxnRejects,
  TransactionAction,
  RejectsCount,
  Merchant,
  BatchTransactionAction
} from "../models/batch-queued-txn-rejects.model";
import { BaseApiService } from "./baseapi.service";
import { RejectStatuses } from "../enums";

@Injectable()
export class BatchQueuedtxnservice {
  private readonly CONTROLLER_NAME: string = "BatchTransactionRejects";
  private readonly ACTION_NAME: string = "";
  constructor(private baseService: BaseApiService) {}
  getBatchtxnRejects(batchRejectId: string): Observable<BatchtxnRejects> {
    const httpParams = new HttpParams().set("batchRejectId", batchRejectId);
    return this.baseService.get(
      this.CONTROLLER_NAME,
      this.ACTION_NAME,
      httpParams
    );
  }

  transcationsAction(
    transactions: TransactionAction
  ): Observable<TransactionAction> | any {
    try {
      return this.baseService.postPath(this.CONTROLLER_NAME, transactions);
    } catch (e) {
      console.log("error: " + e);
    }
  }

  bulkBatchTransactionAction(batchTransactionAction: BatchTransactionAction): Observable<BatchTransactionAction>|any {
    try {
      return this.baseService.postPath(this.CONTROLLER_NAME + '/bulk', batchTransactionAction);
    } catch (e) {
      console.log("error: " + e);
    }
  }
}
