import { LoggerService } from './logger.service';
import { ErrorHandler, Injectable, Injector, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { ErrorDialogService } from '../../ui/service/error-dialog.service';
import { HttpErrorResponse } from '@angular/common/http';
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(
    private loggerService: LoggerService,
    private injector: Injector,
    private errorDialogService: ErrorDialogService,
    private zone: NgZone
  ) {}

  handleError(error: any) {
    console.log('handleError::' + error);

    if (!(error instanceof HttpErrorResponse)) {
      error = error.rejection;
    }

    if (error.status !== 401 && error.status !== 403) {
      this.zone.run(() =>
        this.errorDialogService.openDialog(
          error?.message || 'Undefined client error',
          error?.status
        )
      );
    }
    if (!this.loggerService) return;
    //log to corelogging
    this.loggerService.logError(
      error.message.toString(),
      this.getFullError(error)
    );
  }

  //client error should contain:
  //  - name
  //  - message
  getFullError(error: any) {
    let fullError = '';

    if (error.name) fullError += error.name + '\n';
    if (error.message) fullError += error.message + '\n';
    if (error.status) fullError += error.status + '\n';
    if (error.statusText) fullError += error.statusText + '\n';
    if (error.url) fullError += error.url + '\n';

    return fullError;
  }
}
