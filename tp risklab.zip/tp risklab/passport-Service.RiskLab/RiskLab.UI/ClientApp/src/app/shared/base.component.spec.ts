import { Injector } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { Constant } from './constant';
import { MenuItem } from './models/menu-item.model';
import { ConfigurationService } from './services/configuration.service';
import { BaseComponent } from './base.component';

describe('BaseComponent', () => {

  let component: BaseComponent;
  let mockInjector: any;
  let mockActivatedRoute: any;
  let mockConfigService: any;
  let mockLocation: any;
  let configDataPromise: Promise<any>;

  beforeEach(() => {
    mockActivatedRoute = {
      snapshot: { data: { parentRoute: 'parent' } }
    };
    mockConfigService = {
      loadConfigurationData: jasmine.createSpy('loadConfigurationData'),
      existsMenuByFieldInSubMenu: jasmine.createSpy('existsMenuByFieldInSubMenu'),
      getMenuByField: jasmine.createSpy('getMenuByField')
    };
    mockLocation = { path: jasmine.createSpy('path').and.returnValue('locationPath') };
    configDataPromise = Promise.resolve({ menu: [{ label: 'A', link: 'parent' }] });
    mockConfigService.loadConfigurationData.and.returnValue(configDataPromise);
    mockInjector = {
      get: (token: any) => {
        if (token === ActivatedRoute) return mockActivatedRoute;
        if (token === ConfigurationService) return mockConfigService;
        if (token === Location) return mockLocation;
        return null;
      }
    };
    // @ts-ignore: abstract class
    component = new BaseComponent(mockInjector);
  });

  
class TestBaseComponent extends BaseComponent {
  constructor(injector: any) {
    super(injector);
  }
  // Expose protected properties for testing
  get test_activatedRoute() { return this.activatedRoute; }
  get test_configService() { return this.configService; }
  get test_location() { return this.location; }
  get test_configData() { return this.configData; }
  get test_currentRoutePath() { return this.currentRoutePath; }
  set test_currentRoutePath(val: any) { this.currentRoutePath = val; }
}

describe('BaseComponent', () => {
  let component: TestBaseComponent;
  let mockInjector: any;
  let mockActivatedRoute: any;
  let mockConfigService: any;
  let mockLocation: any;
  let configDataPromise: Promise<any>;

  beforeEach(() => {
    mockActivatedRoute = {
      snapshot: { data: { parentRoute: 'parent' } }
    };
    mockConfigService = {
      loadConfigurationData: jasmine.createSpy('loadConfigurationData'),
      existsMenuByFieldInSubMenu: jasmine.createSpy('existsMenuByFieldInSubMenu'),
      getMenuByField: jasmine.createSpy('getMenuByField')
    };
    mockLocation = { path: jasmine.createSpy('path').and.returnValue('locationPath') };
    configDataPromise = Promise.resolve({ menu: [{ label: 'A', link: 'parent' }] });
    mockConfigService.loadConfigurationData.and.returnValue(configDataPromise);
    mockInjector = {
      get: (token: any) => {
        if (token === ActivatedRoute) return mockActivatedRoute;
        if (token === ConfigurationService) return mockConfigService;
        if (token === Location) return mockLocation;
        return null;
      }
    };
    component = new TestBaseComponent(mockInjector);
  });

  it('should construct with injector and set up dependencies', () => {
    expect(component.test_activatedRoute).toBe(mockActivatedRoute);
    expect(component.test_configService).toBe(mockConfigService);
    expect(component.test_location).toBe(mockLocation);
    expect(component.test_configData).toBe(configDataPromise);
  });

  it('should selectItem and call existsMenuByFieldInSubMenu', () => {
    const subMenu = [{}, {}];
    component.selectItem('key', 'val', subMenu as any);
    expect(mockConfigService.existsMenuByFieldInSubMenu).toHaveBeenCalledWith(
      'key', 'val', subMenu, jasmine.any(Function)
    );
  });

  it('should getPageRoutesPath with parentRoute', async () => {
    await component.getPageRoutesPath();
    expect(component.test_currentRoutePath).toBe('parent');
    await configDataPromise;
    expect(component.menus.length).toBe(1);
    expect(mockConfigService.getMenuByField).toHaveBeenCalledWith('link', 'parent', jasmine.any(Array));
  });

  it('should getPageRoutesPath fallback to location.path', async () => {
    component.test_activatedRoute.snapshot.data['parentRoute'] = undefined;
    component.test_currentRoutePath = undefined as any;
    await component.getPageRoutesPath();
    expect(component.test_currentRoutePath).toBe('locationPath');
  });

  it('should getPageRoutesPath fallback to DEFAULT_ROUTE', async () => {
    component.test_activatedRoute.snapshot.data['parentRoute'] = undefined;
    component.test_currentRoutePath = '';
    mockLocation.path.and.returnValue(Constant.BASE_PATH);
    await component.getPageRoutesPath();
    expect(component.test_currentRoutePath).toBe(Constant.DEFAULT_ROUTE);
  });

    it('should set menu.selected and menu.collapsed to true in selectItem callback', () => {
    let callbackFn: (menu: any) => void = () => {};
    mockConfigService.existsMenuByFieldInSubMenu.and.callFake((keyName, keyValue, subMenu, cb) => {
      callbackFn = cb;
    });
    const menuObj = { selected: false, collapsed: false };
    component.selectItem('key', 'val', [menuObj] as any);
    callbackFn(menuObj);
    expect(menuObj.selected).toBeTrue();
    expect(menuObj.collapsed).toBeTrue();
  });
});
});
