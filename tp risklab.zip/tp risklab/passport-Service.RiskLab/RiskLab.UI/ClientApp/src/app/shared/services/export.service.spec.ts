import { TestBed } from '@angular/core/testing';
import { ExportService } from './export.service';
import { BaseApiService } from './baseapi.service';
import { HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { of, throwError } from 'rxjs';

describe('ExportService', () => {
  let service: ExportService;
  let baseServiceSpy: jasmine.SpyObj<BaseApiService>;

  beforeEach(() => {
    baseServiceSpy = jasmine.createSpyObj('BaseApiService', ['downloadFile']);
    TestBed.configureTestingModule({
      providers: [
        ExportService,
        { provide: BaseApiService, useValue: baseServiceSpy }
      ]
    });
    service = TestBed.inject(ExportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call baseService.downloadFile with correct params and return its result as observable', (done) => {
    const blob = new Blob(['test'], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const httpResponse = new HttpResponse({
      body: blob,
      status: 200,
      headers: new HttpHeaders({ 'X-Total-Count': '5' })
    });
    baseServiceSpy.downloadFile.and.returnValue(of(httpResponse));
    const pageName = 'testPage';
    const status = 1;
    service.exportToExcel(pageName, status).subscribe(result => {
      expect(baseServiceSpy.downloadFile).toHaveBeenCalledWith(
        '',
        'ExcelExport',
        jasmine.any(HttpParams)
      );
      expect(result).toBe(httpResponse);
      expect(result.body).toBe(blob);
      expect(result.status).toBe(200);
      expect(result.headers.get('X-Total-Count')).toBe('5');
      done();
    });
  });

  it('should catch and log errors', (done) => {
    spyOn(console, 'log');
    baseServiceSpy.downloadFile.and.returnValue(throwError(() => new Error('fail')));
    service.exportToExcel('page', 2).subscribe({
      next: () => {},
      error: () => {
        expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
        done();
      }
    });
  });
});
