export interface OktaSettings {
  issuer: string;
  clientId: string;
  redirectUri: string;
  apiUrl: string;
  apiHeader: string;
  scopes: string[];
  logoutUrl: string;
}

export class AppConfig {
  constructor(public config: OktaSettings ) {
      }
}
