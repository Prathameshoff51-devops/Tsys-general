import { importProvidersFrom, Injectable } from "@angular/core";
import { HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { BatchAction, BatchRefund } from "../models/batch-refund.model";
import { BaseApiService } from "./baseapi.service";
import { RejectStatuses } from "../enums";

@Injectable()
export class BatchRefundSevice{
  private readonly CONTROLLER_NAME: string = 'BatchRejects';
  private readonly ACTION_NAME: string = '';
  constructor(private baseService: BaseApiService) {}
  getBatchRefunds(status: RejectStatuses): Observable<BatchRefund[]> {
    const httpParams = new HttpParams().set('status', status);
    return this.baseService.getMany(
      this.CONTROLLER_NAME,
      this.ACTION_NAME,
      httpParams
    );
  }

  batchAction(
    batchAction: BatchAction
  ): Observable<BatchAction> | any {
    try {
      return this.baseService.postPath(this.CONTROLLER_NAME, batchAction);
    } catch (e) {
      console.log('error: ' + e);
    }
  }

}
