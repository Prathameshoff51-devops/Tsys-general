import { MenuItem } from "./menu-item.model";

describe("MenuItem", () => {
  let config = {
    name: "RiskRejects",
    displayName: "Risk Rejects",
    link: "/secure/risklab",
    iconName: "fas fa-file-alt fa-lg",
    route: "secure/risklab",
    childrenMenuItems: [
      {
        name: "RiskRejects",
        displayName: "Risk Rejects",
        link: "/secure/risklab",
        iconName: "fas fa-file-alt fa-lg",
        route: "secure/risklab",
        childrenMenuItems: null,
        selected: false,
        collapsed: false,
        isSelected: false
      }
    ]
  };
  it("should create an instance", () => {
    expect(new MenuItem(config)).toBeTruthy();
  });
});
