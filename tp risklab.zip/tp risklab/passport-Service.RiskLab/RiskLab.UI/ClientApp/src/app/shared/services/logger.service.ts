import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { ConfigurationService } from './configuration.service';
import { Severity,LogEventDetails } from '../models/log-evet.model';
import { Configuration } from "../models/configuration.model";

@Injectable({
    providedIn: 'root',
})
export class LoggerService {
    constructor(
        private http: HttpClient,
        private configuration: ConfigurationService
    ) {
    }
  private log(severity: Severity, message: string,
    clientId: number, personId: number, productId: number,
    fullText: string = ''
  ) {
    if (!this.configuration)
      return;
    let username = this.configuration.config.username;
    let environment = this.configuration.config.environment;
    let threadId = this.configuration.config.threadId;
    let eventdetails: LogEventDetails[] = [{ message: '', fullText: '', exceptionType: '' }];
    let logEvent = {
      time: (new Date()).toISOString(),
      severity: severity,
      environment: environment,
      loggerName: 'RiskLab',
      userName: username,
      message: message,
      clientId: clientId,
      personId: personId,
      productId: productId,
      threadId: threadId,
      details: eventdetails
    };
    if (severity == Severity.Error && fullText) {
      logEvent.details = [
        {
          message: message,
          fullText: fullText,
          exceptionType: 'typescript'
        }
      ];
    }
    let coreloggingEndPoint = `${this.configuration.config.coreloggingServiceUrl}/api/v1/Log`;
    this.http.post(coreloggingEndPoint, logEvent).subscribe();
  }
  
    logInformation(message: string, clientId: number = 0, personId: number = 0, productId: number = 0) {
        this.log(Severity.Information, message, clientId, personId, productId);
    }

    logWarning(message: string, clientId: number = 0, personId: number = 0, productId: number = 0) {
        this.log(Severity.Warning, message, clientId, personId, productId)
    }

    logError(message: string, fullText: string = '', clientId: number = 0, personId: number = 0, productId: number = 0) {
        this.log(Severity.Error, message, clientId, personId, productId, fullText);
    }

    logTrace(message: string, clientId: number = 0, personId: number = 0, productId: number = 0) {
        this.log(Severity.Trace, message, clientId, personId, productId);
    }
}
