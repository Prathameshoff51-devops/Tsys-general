import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { HttpClient, HttpResponse, HttpParams, HttpHeaders, provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";
import { AppConfig } from "../models/app-config";
import { BaseApiService } from "./baseapi.service";
import { ConstantsUnitTest } from "src/app/constant.unit.test";


describe("BaseApiService", () => {
  let service: BaseApiService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
 
  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [],
    providers: [
        BaseApiService,
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
});
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);

    service = TestBed.inject(BaseApiService);
  });
  afterEach(() => {
    httpTestingController.verify(); //Verifies that no requests are outstanding.
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });
  it("should called getPath", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.getPath("FraudService", httpParams).subscribe({
      next: emps => expect(emps).toEqual(2),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("GET");
  });
  it("should called putPath", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    let body = {
      action: "GetRejectsByMerchantNumber"
    };
    await service.putPath("FraudService", httpParams, body).subscribe({
      next: emps => expect(emps).toEqual(2),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("PUT");
  });
  it("should called put", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    let body = {
      action: "GetRejectsByMerchantNumber"
    };
    await service
      .put(
        "FraudService",
        "GetRejectsByMerchantNumber",
        httpParams,
        body
      )
      .subscribe({
        next: emps => expect(emps).toEqual(2),
        error: fail
      });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("PUT");
  });
  it("should called post", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    let body = {
      action: "GetRejectsByMerchantNumber"
    };
    await service
      .post(
        "FraudService",
        "GetRejectsByMerchantNumber",
        body,
        httpParams
      )
      .subscribe({
        next: emps => expect(emps).toEqual(2),
        error: fail
      });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("POST");
  });
  it("should call getMany", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.getMany("FraudService", "GetRejectsByMerchantNumber", httpParams).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("GET");
  });

  it("should call postPath", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    let body = {
      action: "GetRejectsByMerchantNumber"
    };
    await service.postPath("FraudService", body, httpParams).subscribe({
      next: emps => expect(emps).toEqual(2),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("POST");
  });

  it("should call downloadFile", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.downloadFile("FraudService", "GetRejectsByMerchantNumber", httpParams).subscribe({
      next: emps => {
        expect(emps).toBeDefined();
        expect(emps instanceof HttpResponse).toBeTrue();
        expect(emps.status).toBe(200);
        expect(emps.body).toBeDefined();
        expect(emps.headers instanceof HttpHeaders).toBeTrue();
      },
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("GET");
    expect(httpRequest.request.responseType).toBe("blob");
    // Simulate a blob response with headers
    const testBlob = new Blob(["test"], { type: "application/octet-stream" });
    httpRequest.flush(testBlob, {
      status: 200,
      statusText: 'OK',
      headers: { 'X-Total-Count': '5' }
    });
  });
  it("should call downloadFile with empty controller and not add extra slash", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.downloadFile("", "GetRejectsByMerchantNumber", httpParams).subscribe({
      next: emps => {
        expect(emps).toBeDefined();
        expect(emps instanceof HttpResponse).toBeTrue();
        expect(emps.status).toBe(200);
        expect(emps.body).toBeDefined();
        expect(emps.headers instanceof HttpHeaders).toBeTrue();
      },
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("GET");
    expect(httpRequest.request.responseType).toBe("blob");
    // Simulate a blob response with headers
    const testBlob = new Blob(["test"], { type: "application/octet-stream" });
    httpRequest.flush(testBlob, {
      status: 200,
      statusText: 'OK',
      headers: { 'X-Total-Count': '5' }
    });
  });

  it("should call get with undefined actions and not add extra slash", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.get("FraudService", undefined, httpParams).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("GET");
  });

  it("should call post with undefined actions and not add extra slash", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.post("FraudService", undefined, { foo: "bar" }, httpParams).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("POST");
  });

  it("should call put with undefined actions and not add extra slash", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.put("FraudService", undefined, httpParams, { foo: "bar" }).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("PUT");
  });

  it("should call getHeaders and return HttpHeaders", () => {
    const headers = service["getHeaders"]();
    // If the header is not set, expect null
    expect(headers.get('Authorization')).toBe(ConstantsUnitTest.config.apiHeader['Authorization'] || null);
  });
  it("should call getHeaders and return empty headers if apiHeader is missing", () => {
    const originalApiHeader = service["appConfig"].config.apiHeader;
    delete service["appConfig"].config.apiHeader;
    const headers = service["getHeaders"]();
    expect(headers.keys().length).toBe(0);
    // Restore
    service["appConfig"].config.apiHeader = originalApiHeader;
  });
  it("should call get with no params and use new HttpParams", async () => {
    await service.get("FraudService").subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService"
    );
    expect(httpRequest.request.method).toBe("GET");
    expect(httpRequest.request.params.keys().length).toBe(0);
  });

  it("should call post with no params and use new HttpParams", async () => {
    await service.post("FraudService", undefined, { foo: "bar" }).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService"
    );
    expect(httpRequest.request.method).toBe("POST");
    expect(httpRequest.request.params.keys().length).toBe(0);
  });

  it("should call put with no params and use new HttpParams", async () => {
    await service.put("FraudService", undefined, undefined, { foo: "bar" }).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService"
    );
    expect(httpRequest.request.method).toBe("PUT");
    expect(httpRequest.request.params.keys().length).toBe(0);
  });

  it("should call downloadFile with no params and use new HttpParams", async () => {
    await service.downloadFile("FraudService", "GetRejectsByMerchantNumber").subscribe({
      next: emps => {
        expect(emps).toBeDefined();
        expect(emps instanceof HttpResponse).toBeTrue();
        expect(emps.status).toBe(200);
        expect(emps.body).toBeDefined();
        expect(emps.headers instanceof HttpHeaders).toBeTrue();
      },
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber"
    );
    expect(httpRequest.request.method).toBe("GET");
    expect(httpRequest.request.responseType).toBe("blob");
    expect(httpRequest.request.params.keys().length).toBe(0);
    // Simulate a blob response with headers
    const testBlob = new Blob(["test"], { type: "application/octet-stream" });
    httpRequest.flush(testBlob, {
      status: 200,
      statusText: 'OK',
      headers: { 'X-Total-Count': '5' }
    });
  });

  it("should call getMany with no params and use new HttpParams", async () => {
    await service.getMany("FraudService", "GetRejectsByMerchantNumber").subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber"
    );
    expect(httpRequest.request.method).toBe("GET");
    expect(httpRequest.request.params.keys().length).toBe(0);
  });

  it("should call getMany with actions and url should concat actions", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.getMany("FraudService", "GetRejectsByMerchantNumber", httpParams).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("GET");
  });

  it("should call post with actions and no body, sending empty object", async () => {
    await service.post("FraudService", "GetRejectsByMerchantNumber").subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber"
    );
    expect(httpRequest.request.method).toBe("POST");
    expect(httpRequest.request.body).toEqual({});
  });

  it("should call put with body undefined and send empty object", async () => {
    const httpParams = new HttpParams().set(
      "merchantNumber",
      "650000004051668"
    );
    await service.put("FraudService", "GetRejectsByMerchantNumber", httpParams, undefined).subscribe({
      next: emps => expect(emps).toBeDefined(),
      error: fail
    });
    const httpRequest = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    expect(httpRequest.request.method).toBe("PUT");
    expect(httpRequest.request.body).toEqual({});
  });
});
