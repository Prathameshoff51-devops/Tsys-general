import { Injector } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Constant } from './constant';
import { Location, PlatformLocation } from '@angular/common';
import { MenuItem } from './models/menu-item.model';
import { ConfigurationService } from './services/configuration.service';
export abstract class BaseComponent {
  protected activatedRoute!: ActivatedRoute;
  protected currentRoutePath: string;
  protected location: Location;
  private currentMenu: MenuItem;
  menus: MenuItem[];
  protected configService: ConfigurationService;
  configData: any;
  menuItems: Array<MenuItem>;
  constructor();
  constructor(injector: Injector);
  constructor(injector?: Injector) {
    if (injector) {
      this.activatedRoute = injector.get(ActivatedRoute);
      this.configService = injector.get(ConfigurationService);
      this.location = injector.get(Location);
      this.configData = this.configService.loadConfigurationData();
      this.getPageRoutesPath();
    }
  }
  selectItem(
    keyName: string,
    keyValue: string,
    subMenu: Array<MenuItem>
  ): void {
    this.configService.existsMenuByFieldInSubMenu(
      keyName,
      keyValue,
      subMenu,
      (menu) => {
        menu.selected = true;
        menu.collapsed = true;
      }
    );
  }
  getPageRoutesPath() {
    if (this.activatedRoute) {
      this.currentRoutePath = this.activatedRoute.snapshot.data['parentRoute'];
    }

    if (!this.currentRoutePath && this.location) {
      this.currentRoutePath = this.location.path();
    }

    if (
      !this.currentRoutePath ||
      this.currentRoutePath.length == 0 ||
      this.currentRoutePath == Constant.BASE_PATH
    ) {
      this.currentRoutePath = Constant.DEFAULT_ROUTE;
    }

    this.configData.then((res) => {
      console.log(res);
      this.menus = res.menu.map((m) => new MenuItem(m));
      this.currentMenu = this.configService.getMenuByField(
        'link',
        this.currentRoutePath,
        this.menus
      );
    });
  }
}
