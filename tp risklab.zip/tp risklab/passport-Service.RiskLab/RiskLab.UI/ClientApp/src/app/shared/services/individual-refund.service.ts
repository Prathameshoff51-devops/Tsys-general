import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  IndividualRefund,
  TransactionAction,
  RejectsCount,
  Merchant,
} from '../models/individual-refund.model';
import { BaseApiService } from './baseapi.service';
import { RejectStatuses } from '../enums';

@Injectable()
export class IndividualRefundservice {
  private readonly CONTROLLER_NAME: string = 'IndividualTransactions';
  private readonly FRAUDSERVICE_CONTROLLER_NAME: string = 'FraudService';
  private readonly ACTION_NAME: string = '';
  constructor(private baseService: BaseApiService) {}
  getIndividualRefunds(status: RejectStatuses): Observable<IndividualRefund[]> {
    const httpParams = new HttpParams().set('status', status);
    return this.baseService.getMany(
      this.CONTROLLER_NAME,
      this.ACTION_NAME,
      httpParams
    );
  }

  transcationsAction(
    transactions: TransactionAction
  ): Observable<TransactionAction> | any {
    try {
      return this.baseService.postPath(this.CONTROLLER_NAME, transactions);
    } catch (e) {
      console.log('error: ' + e);
    }
  }

  getIndividualRefundsCount(
    status: RejectStatuses
  ): Observable<RejectsCount> | any {
    try {
      const httpParams = new HttpParams().set('status', status);
      return this.baseService.get(
        this.CONTROLLER_NAME,
        'GetTransactionRejectsCount',
        httpParams
      );
    } catch (e) {
      console.log('error: ' + e);
    }
  }
  getIndividualRefundTxnsByMerchantSequenceKey(
    sequenceKey: number
  ): Observable<Merchant> | any {
    try {
      const httpParams = new HttpParams().set('sequenceKey', sequenceKey);
      return this.baseService.get(
        this.FRAUDSERVICE_CONTROLLER_NAME,
        this.ACTION_NAME,
        httpParams
      );
    } catch (e) {
      console.log('error: ' + e);
    }
  }

  getRejectsByMerchantNumber(
    MerchantNumber: string
  ): Observable<Merchant> | any {
    try {
      const httpParams = new HttpParams().set('merchantNumber', MerchantNumber);
      return this.baseService.get(
        this.FRAUDSERVICE_CONTROLLER_NAME,
        'GetRejectsByMerchantNumber',
        httpParams
      );
    } catch (e) {
      console.log('error: ' + e);
    }
  }
}
