
export interface QueuedRefund {
  action :Number;
  individualTxnId:number;
  messageId: string;
  txnUuid: number;
  txnDetailId: number;
  merchantNumber: string;
  merchantName: string;
  legalName: string;
  chainOID: string;
  mcc: string;
  amount: Number;
  cardNumberMask: string;
  txnDateUtc: string;
  fraudRejectReasonCode: string[];
  originalBatchNumber: string;
  authCode: string;
  expDate: string;
  txnTypeDescription: string;
  batchCloseDate: string;
  submitterIDDescription: string;
  daysToAct:Number

}
