export interface BatchRefund {
  action: number;
  batchRejectId: number;
  batchNumber: string;
  merchantNumber: string;
  merchantName: string;
  legalName: string;
  chainOID: string;
  mcc: string;
  batchAmount: number;
  refundCount: number;
  txnDateUTC: string;
  rejectReasons: string[];
  batchCloseDate: string;
  daysToAct: number;
  canTakeBatchAction: boolean;
  status: string;
  submitterIDDescription: string;
}

export interface BatchAction {
  batchRejectId: number;
  newStatus: string;
  userName: string;
}
