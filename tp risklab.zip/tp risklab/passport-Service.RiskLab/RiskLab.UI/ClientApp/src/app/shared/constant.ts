export class Constant {
  public static readonly Success = 'Success';
  public static readonly Failed = 'Failed';
  public static readonly DaysToActs = 10;
  public static readonly DefaultGridPageSize = 5;
  public static readonly DefaultBackOfficeGridPageSize = 15;
  public static readonly DefaultGridPageSizeforBatchTxnRejects = 15;

  public static BASE_PATH = '/';
  public static DEFAULT_PATH = 'login';
  public static DEFAULT_ROUTE = '/login';
}
