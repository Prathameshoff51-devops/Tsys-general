import { Inject, Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';

import { Observable, throwError, from } from 'rxjs';
import { tap, finalize, switchMap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { OKTA_AUTH } from '@okta/okta-angular';
import {
  OktaAuth,
  Tokens,
  Token,
  AccessToken,
  TokenParams,
} from '@okta/okta-auth-js';
import { LoadingDialogService } from '../../ui/service/loading-dialog.service';
import { AppConfig } from '../models/app-config';
import { Constants } from '../../Constants';
import { LoaderService } from '../../ui/service/loader.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private router: Router,
    @Inject(OKTA_AUTH) private _oktaAuth: OktaAuth,
    private loadingDialogService: LoadingDialogService,
    private loaderService: LoaderService,
    private activatedRoute: ActivatedRoute,
    private oktaConfig: AppConfig
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    this.loaderService.show();

    return from(this.handleToken(request)).pipe(
      switchMap((modifiedRequest) => {
        return next.handle(modifiedRequest).pipe(
          finalize(() => {
            this.loaderService.hide();
          }),
          tap(
            () => {},
            (err: any) => {
              this.loaderService.hide();

              if (err instanceof HttpErrorResponse) {
                if (err.error instanceof ErrorEvent) {
                  console.error(err);
                } else {
                  console.log(`error status : ${err.status} ${err.statusText}`);
                  switch (err.status) {
                    case 403: //unauthorized
                    case 401: //forbidden
                      this.router.navigateByUrl(Constants.unauthorizedPage);
                      break;
                    default: {
                      console.log(err);
                      break;
                    }
                  }
                }
              }
            }
          )
        );
      })
    );
  }

  private async handleToken(request: HttpRequest<any>): Promise<HttpRequest<any>> {
    try {
      const accessToken = await this._oktaAuth.tokenManager.get('accessToken');
      
      if (accessToken && this._oktaAuth.tokenManager.hasExpired(accessToken)) {
        // Token is expired, refresh it
        const oktaAuthConfig = { ...this.oktaConfig.config };
        const res = await this._oktaAuth.token.getWithoutPrompt(oktaAuthConfig);
        const newAccessToken = res.tokens.accessToken?.accessToken;
        if (newAccessToken) {
          return request.clone({
            setHeaders: { Authorization: `Bearer ${newAccessToken}` },
          });
        }
      } else if (accessToken) {
        // Token is valid, use it
        const authToken = (accessToken as AccessToken).accessToken;
        return request.clone({
          setHeaders: { Authorization: `Bearer ${authToken}` },
        });
      }
    } catch (error) {
      console.log('exception in auth intercept: ', error);
    }

    return request;
  }
}