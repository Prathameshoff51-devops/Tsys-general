import { TestBed } from "@angular/core/testing";
import { IdleTimeoutService } from "./idle-timeout.service";
import { OKTA_AUTH } from "@okta/okta-angular";
import { Subscription } from "rxjs";

describe("IdleTimeoutService", () => {
  let service: IdleTimeoutService;
  const sessionSpy = jasmine.createSpyObj(["exists", "setCookieAndRedirect"]);
  let oktaAuthSpy = jasmine.createSpyObj(
    "OktaAuth",
    ["signInWithCredentials", "signOut"],
    {
      session: sessionSpy
    }
  );
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: OKTA_AUTH, useValue: oktaAuthSpy, multi: false },
        IdleTimeoutService
      ]
    });

    service = TestBed.inject(IdleTimeoutService);
  });

  it('should emit on timeoutExpired and not restart timer if resetOnTrigger is false', () => {
    let emittedValue: number | undefined;
    service.timeoutExpired.subscribe(n => {
      emittedValue = n;
    });
    service['resetOnTrigger'] = false;
    service['timerComplete'](1);
    expect(emittedValue).toBe(1);
  });

  it('should emit on timeoutExpired and restart timer if resetOnTrigger is true', () => {
    let emittedValue: number | undefined;
    service.timeoutExpired.subscribe(n => {
      emittedValue = n;
    });
    spyOn(service, 'startTimer');
    service['resetOnTrigger'] = true;
    service['timerComplete'](1);
    expect(emittedValue).toBe(1);
    expect(service.startTimer).toHaveBeenCalled();
  });

  it('should set timerSubscription and call timerComplete when timer emits in startTimer', (done) => {
    // Arrange
    const timerCompleteSpy = spyOn(service as any, 'timerComplete');
    // Set a short timeout for fast test
    service['_timeoutSeconds'] = 0.001; // 1ms

    // Act
    service.startTimer();

    // Assert
    expect(service['timerSubscription']).toBeTruthy();
    setTimeout(() => {
      expect(timerCompleteSpy).toHaveBeenCalled();
      done();
    }, 10);
  });

  it('should set timerSubscription and call timerComplete when timer emits in resetTimer', (done) => {
    // Arrange
    const timerCompleteSpy = spyOn(service as any, 'timerComplete');
    // Set a short timeout for fast test
    service['_timeoutSeconds'] = 0.001; // 1ms

    // Act
    service.resetTimer();

    // Assert
    expect(service['timerSubscription']).toBeTruthy();
    setTimeout(() => {
      expect(timerCompleteSpy).toHaveBeenCalled();
      done();
    }, 10);
  });

  it("should be created", () => {
    service.startTimer();
    service.startDismissTimer();
    service.stopTimer();
    service.resetTimer();
    expect(service).toBeTruthy();
  });

  it("should startTimer and stopTimer", () => {
    service.startTimer();
    expect(service["timerSubscription"]).toBeTruthy();
    spyOn(service["timerSubscription"], "unsubscribe");
    service.stopTimer();
    expect(service["timerSubscription"].unsubscribe).toHaveBeenCalled();
  });

  it("should resetTimer and unsubscribe previous", () => {
    service.startTimer();
    const oldSub = service["timerSubscription"];
    spyOn(oldSub, "unsubscribe");
    service.resetTimer();
    expect(oldSub.unsubscribe).toHaveBeenCalled();
    expect(service["timerSubscription"]).toBeTruthy();
  });

  it("should call timerComplete and emit timeoutExpired, and restart if resetOnTrigger", () => {
    const nextSpy = spyOn(service.timeoutExpired, "next");
    service["resetOnTrigger"] = false;
    service["timerComplete"](1);
    expect(nextSpy).toHaveBeenCalled();
    service["resetOnTrigger"] = true;
    spyOn(service, "startTimer");
    service["timerComplete"](2);
    expect(service.startTimer).toHaveBeenCalled();
  });

  it("should startDismissTimer and call signOut on timer complete", (done) => {
    oktaAuthSpy.signOut.and.returnValue(Promise.resolve());
    // Set a shorter timeout for testing
    service._sessionDismissMinutes = 0.001; // 0.06 seconds
    service.startDismissTimer();
    // Spy on the new subscription created by startDismissTimer
    spyOn(service._dismissSubscription, "unsubscribe");
    setTimeout(() => {
      expect(service._dismissSubscription.unsubscribe).toHaveBeenCalled();
      expect(oktaAuthSpy.signOut).toHaveBeenCalledWith({ revokeAccessToken: true });
      done();
    }, 100);
  });

  it("should handle signOut error in startDismissTimer", (done) => {
    const rejectedPromise = Promise.reject("err");
    oktaAuthSpy.signOut.and.returnValue(rejectedPromise);
    spyOn(window, "alert");
    spyOn(console, "log");
    // Set a shorter timeout for testing
    service._sessionDismissMinutes = 0.001; // 0.06 seconds
    service.startDismissTimer();
    // Spy on the new subscription created by startDismissTimer
    spyOn(service._dismissSubscription, "unsubscribe");

    // Handle the unhandled promise rejection
    rejectedPromise.catch(() => { });

    setTimeout(() => {
      expect(service._dismissSubscription.unsubscribe).toHaveBeenCalled();
      expect(oktaAuthSpy.signOut).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalledWith("err");
      expect(window.alert).toHaveBeenCalledWith("err");
      done();
    }, 100);
  });
  it('should unsubscribe previous timerSubscription in startTimer', () => {
    // Arrange: set a fake subscription
    const unsubscribeSpy = jasmine.createSpy('unsubscribe');
    service['timerSubscription'] = { unsubscribe: unsubscribeSpy } as unknown as Subscription;

    // Act
    service.startTimer();

    // Assert
    expect(unsubscribeSpy).toHaveBeenCalled();
  });
  it('should unsubscribe previous _dismissSubscription in startDismissTimer', () => {
    // Arrange: set a fake subscription
    const unsubscribeSpy = jasmine.createSpy('unsubscribe');
    service['_dismissSubscription'] = { unsubscribe: unsubscribeSpy } as unknown as Subscription;

    // Act
    service.startDismissTimer();

    // Assert
    expect(unsubscribeSpy).toHaveBeenCalled();
  });
});
