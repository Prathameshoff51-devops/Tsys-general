import { TestBed } from '@angular/core/testing';
import { BatchQueuedtxnservice } from './batch-queued-txn-rejects';
import { BaseApiService } from './baseapi.service';
import { of } from 'rxjs';

describe('BatchQueuedtxnservice', () => {
  let service: BatchQueuedtxnservice;
  let baseServiceSpy: jasmine.SpyObj<BaseApiService>;

  beforeEach(() => {
    baseServiceSpy = jasmine.createSpyObj('BaseApiService', ['get', 'postPath']);
    TestBed.configureTestingModule({
      providers: [
        BatchQueuedtxnservice,
        { provide: BaseApiService, useValue: baseServiceSpy }
      ]
    });
    service = TestBed.inject(BatchQueuedtxnservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getBatchtxnRejects', () => {
    baseServiceSpy.get.and.returnValue(of({}));
    const result = service.getBatchtxnRejects('id');
    expect(baseServiceSpy.get).toHaveBeenCalledWith('BatchTransactionRejects', '', jasmine.anything());
    expect(result).toBeTruthy();
  });

  it('should call transcationsAction', () => {
    baseServiceSpy.postPath.and.returnValue(of({}));
    const txn = { transactionsStatus: [], userName: 'user' };
    const result = service.transcationsAction(txn as any);
    expect(baseServiceSpy.postPath).toHaveBeenCalledWith('BatchTransactionRejects', txn);
    expect(result).toBeTruthy();
  });

  it('should catch and log errors in transcationsAction', () => {
    spyOn(console, 'log');
    baseServiceSpy.postPath.and.callFake(() => { throw new Error('fail'); });
    service.transcationsAction({ transactionsStatus: [], userName: 'user' } as any);
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });

  it('should call bulkBatchTransactionAction', () => {
    baseServiceSpy.postPath.and.returnValue(of({}));
    const batchAction = { batch: true };
    const result = service.bulkBatchTransactionAction(batchAction as any);
    expect(baseServiceSpy.postPath).toHaveBeenCalledWith('BatchTransactionRejects/bulk', batchAction);
    expect(result).toBeTruthy();
  });

  it('should catch and log errors in bulkBatchTransactionAction', () => {
    spyOn(console, 'log');
    baseServiceSpy.postPath.and.callFake(() => { throw new Error('fail'); });
    service.bulkBatchTransactionAction({ batch: true } as any);
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });
});
