import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { AppConfig } from "../models/app-config";
import { IndividualRefundservice } from "./individual-refund.service";
import { ConstantsUnitTest } from "src/app/constant.unit.test";
import { Subscription, of } from 'rxjs';
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("IndividualRefundservice", () => {
  let service: IndividualRefundservice;

  let httpTestingController: HttpTestingController;
 
  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [],
    providers: [
        IndividualRefundservice,
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
});

    httpTestingController = TestBed.inject(HttpTestingController);

    service = TestBed.inject(IndividualRefundservice);
  });
  it("should be created", () => {
    service.getIndividualRefundsCount(2);
    service.getRejectsByMerchantNumber("123456");
    service.getIndividualRefundTxnsByMerchantSequenceKey(123456);
    expect(service).toBeTruthy();
  });
  it('should call getIndividualRefunds', () => {
    const spy = spyOn(service['baseService'], 'getMany').and.returnValue(of([]));
    service.getIndividualRefunds(2);
    expect(spy).toHaveBeenCalledWith('IndividualTransactions', '', jasmine.anything());
  });

  it('should call transcationsAction', () => {
    const spy = spyOn(service['baseService'], 'postPath').and.returnValue(of({}));
    // Provide a valid TransactionAction mock
    const txn = { transactionsStatus: [], userName: 'user' };
    service.transcationsAction(txn as any);
    expect(spy).toHaveBeenCalledWith('IndividualTransactions', txn);
  });

  it('should catch and log errors in transcationsAction', () => {
    spyOn(service['baseService'], 'postPath').and.throwError('fail');
    spyOn(console, 'log');
    const txn = { transactionsStatus: [], userName: 'user' };
    service.transcationsAction(txn as any);
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });

  it('should call getIndividualRefundsCount', () => {
    const spy = spyOn(service['baseService'], 'get').and.returnValue(of({}));
    service.getIndividualRefundsCount(2);
    expect(spy).toHaveBeenCalledWith('IndividualTransactions', 'GetTransactionRejectsCount', jasmine.anything());
  });

  it('should catch and log errors in getIndividualRefundsCount', () => {
    spyOn(service['baseService'], 'get').and.throwError('fail');
    spyOn(console, 'log');
    service.getIndividualRefundsCount(2);
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });

  it('should call getIndividualRefundTxnsByMerchantSequenceKey', () => {
    const spy = spyOn(service['baseService'], 'get').and.returnValue(of({}));
    service.getIndividualRefundTxnsByMerchantSequenceKey(123);
    expect(spy).toHaveBeenCalledWith('FraudService', '', jasmine.anything());
  });

  it('should catch and log errors in getIndividualRefundTxnsByMerchantSequenceKey', () => {
    spyOn(service['baseService'], 'get').and.throwError('fail');
    spyOn(console, 'log');
    service.getIndividualRefundTxnsByMerchantSequenceKey(123);
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });

  it('should call getRejectsByMerchantNumber', () => {
    const spy = spyOn(service['baseService'], 'get').and.returnValue(of({}));
    service.getRejectsByMerchantNumber('123');
    expect(spy).toHaveBeenCalledWith('FraudService', 'GetRejectsByMerchantNumber', jasmine.anything());
  });

  it('should catch and log errors in getRejectsByMerchantNumber', () => {
    spyOn(service['baseService'], 'get').and.throwError('fail');
    spyOn(console, 'log');
    service.getRejectsByMerchantNumber('123');
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });
});
