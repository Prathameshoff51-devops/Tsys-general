import { TestBed } from '@angular/core/testing';
import { BatchRefundSevice } from './batch-refund.service';
import { BaseApiService } from './baseapi.service';
import { of } from 'rxjs';

describe('BatchRefundSevice', () => {
  let service: BatchRefundSevice;
  let baseServiceSpy: jasmine.SpyObj<BaseApiService>;

  beforeEach(() => {
    baseServiceSpy = jasmine.createSpyObj('BaseApiService', ['getMany', 'postPath']);
    TestBed.configureTestingModule({
      providers: [
        BatchRefundSevice,
        { provide: BaseApiService, useValue: baseServiceSpy }
      ]
    });
    service = TestBed.inject(BatchRefundSevice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getBatchRefunds', () => {
    baseServiceSpy.getMany.and.returnValue(of([]));
    const result = service.getBatchRefunds(1);
    expect(baseServiceSpy.getMany).toHaveBeenCalledWith('BatchRejects', '', jasmine.anything());
    expect(result).toBeTruthy();
  });

  it('should call batchAction', () => {
    baseServiceSpy.postPath.and.returnValue(of({}));
    const batchAction = { action: true };
    const result = service.batchAction(batchAction as any);
    expect(baseServiceSpy.postPath).toHaveBeenCalledWith('BatchRejects', batchAction);
    expect(result).toBeTruthy();
  });

  it('should catch and log errors in batchAction', () => {
    spyOn(console, 'log');
    baseServiceSpy.postPath.and.callFake(() => { throw new Error('fail'); });
    service.batchAction({ action: true } as any);
    expect(console.log).toHaveBeenCalledWith(jasmine.stringMatching('error:'));
  });
});
