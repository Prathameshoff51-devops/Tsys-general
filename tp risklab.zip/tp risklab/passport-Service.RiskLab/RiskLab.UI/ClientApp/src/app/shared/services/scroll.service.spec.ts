import { TestBed } from '@angular/core/testing';
import { ScrollService } from './scroll.service';

describe('ScrollService', () => {
  let service: ScrollService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScrollService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should emit on scrollToTop$', (done) => {
    service.scrollToTop$.subscribe(() => {
      expect(true).toBeTrue();
      done();
    });
    service.triggerScrollToTop();
  });

  it('should emit on scrollToBottom$', (done) => {
    service.scrollToBottom$.subscribe(() => {
      expect(true).toBeTrue();
      done();
    });
    service.triggerScrollToBottom();
  });
});
