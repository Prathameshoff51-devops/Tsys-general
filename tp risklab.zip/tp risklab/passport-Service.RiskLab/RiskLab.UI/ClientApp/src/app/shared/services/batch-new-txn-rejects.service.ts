import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  IndividualRefund,
  TransactionAction,
  RejectsCount,
  Merchant,
} from '../models/individual-refund.model';
import { BaseApiService } from './baseapi.service';
import { RejectStatuses } from '../enums';
import { BatchtxnRejects } from '../models/batch-new-txn-rejects.model';

@Injectable()
export class BatchNewtxnRejectsService {
  private readonly CONTROLLER_NAME: string = 'BatchTransactionRejects';
  private readonly FRAUDSERVICE_CONTROLLER_NAME: string = 'FraudService';
  private readonly ACTION_NAME: string = '';
  constructor(private baseService: BaseApiService) { }

  getBatchtxnRejects(batchRejectId: string): Observable<BatchtxnRejects> {
    const httpParams = new HttpParams().set('batchRejectId', batchRejectId);
    return this.baseService.get(
      this.CONTROLLER_NAME,
      this.ACTION_NAME,
      httpParams
    );
  }
}
