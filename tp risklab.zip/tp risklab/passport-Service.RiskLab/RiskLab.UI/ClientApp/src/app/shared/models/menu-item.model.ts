export interface IMenuItem {
  name: string;
  displayName: string;
  link: string;
  iconName: string;
  route: string;
  childrenMenuItems: Array<IMenuItem>;
}

export class MenuItem implements IMenuItem {
  name: string;
  displayName: string;
  link: string;
  childrenMenuItems!: Array<MenuItem>;
  selected: boolean;
  collapsed!: boolean;
  iconName: string;
  route: string;
  isSelected: boolean;
  constructor(menu: IMenuItem) {
    this.name = menu.name;
    this.displayName = menu.displayName;
    this.link = menu.link;
    this.iconName = menu.iconName;
    this.route = menu.route;
    this.selected = false;
    if (menu.childrenMenuItems && menu.childrenMenuItems.length > 0) {
      this.childrenMenuItems = [];
      menu.childrenMenuItems.forEach((m) =>
        this.childrenMenuItems.push(new MenuItem(m))
      );
    }
  }
}
