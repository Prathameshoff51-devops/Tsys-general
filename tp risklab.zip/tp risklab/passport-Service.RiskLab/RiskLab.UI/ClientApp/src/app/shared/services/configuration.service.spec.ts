import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { AppConfig } from "../models/app-config";
import { BaseApiService } from "./baseapi.service";
import { ConfigurationService } from "./configuration.service";
import { MenuItem } from "../models/menu-item.model";
import { ConstantsUnitTest } from "src/app/constant.unit.test";
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("ConfigurationService", () => {
  let service: ConfigurationService;
  let httpTestingController: HttpTestingController;
  

  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [],
    providers: [
        BaseApiService,
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
});

    httpTestingController = TestBed.inject(HttpTestingController);

    service = TestBed.inject(ConfigurationService);
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });
  it("should called loadInitialData", () => {
    service.loadInitialData();
    const req = httpTestingController.expectOne(
      "https://localhost:7247/Configurations"
    );
    req.flush(ConstantsUnitTest.configData);
    expect(service.configData).toBe(undefined);
  });
  it("should called menu", () => {
    service.menu;
    const req = httpTestingController.expectOne(
      "https://localhost:7247/Configurations"
    );
    req.flush(ConstantsUnitTest.configData);
    expect(service.configData).toBe(undefined);
  });
  it("should called config", () => {
    service.config;
    const req = httpTestingController.expectOne(
      "https://localhost:7247/Configurations"
    );
    req.flush(ConstantsUnitTest.configData);
    expect(service.configData).toBe(undefined);
  });
  it("should called else part in config", async () => {
    service.configData = ConstantsUnitTest.configData;
    expect(service.config).toBeTruthy();
  });
  it("should called else part in menu", async () => {
    service.configData = ConstantsUnitTest.configData;
    expect(service.menu).toBeTruthy();
  });
  it("should be called reaming function", async () => {
    let subMenu = ConstantsUnitTest.configData.menu.map(m => new MenuItem(m));
    expect(subMenu.length).toEqual(2);
    service.existsMenuByFieldInSubMenu(
      "link",
      "/secure/risklab ",
      subMenu,
      menu => {
        menu.selected = true;
        menu.collapsed = true;
      }
    );
    let currentMenu = await service.getMenuByField(
      "link",
      "/secure/risklab",
      subMenu
    );
    expect(currentMenu).toBeTruthy();
  });
  it('should call existsMenuByField and execute callback', () => {
    service.configData = ConstantsUnitTest.configData;
    const callback = jasmine.createSpy('callback');
    const found = service.existsMenuByField('link', '/secure/risklab', callback);
    expect(found).toBeTrue();
    expect(callback).toHaveBeenCalled();
  });

  it('should getMenuByFieldInSubMenu search recursively and return child', () => {
    const child = new MenuItem({
      name: 'child',
      displayName: 'Child',
      iconName: 'icon',
      route: '/child',
      link: '/child',
      childrenMenuItems: []
    });
    const parent = new MenuItem({
      name: 'parent',
      displayName: 'Parent',
      iconName: 'icon',
      route: '/parent',
      link: '/parent',
      childrenMenuItems: [child]
    });
    const menu = [parent];
    const found = service.getMenuByFieldInSubMenu('link', '/child', menu);
    expect(found).toEqual(child);
  });
});
