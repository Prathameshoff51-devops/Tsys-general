import { RejectStatuses } from "../enums";

export interface BatchtxnRejects {
  originalBatchNumber: string;
  batchCloseDateUTC: string;
  merchantNumber: string;
  merchantName: string;
  batchAmount: string;
  batchRejectId: Number;
  status: string;
  transactions: Transactions[];
}
export interface Transactions {
  txnAmount: Number;
  txnType: string;
  actionDropdown: number;
  cardNumberMasked: string;
  txnDateUTC: string;
  originalBatchNumber: string;
  batchCloseDateUTC: string;
  status: String;
  batchTransactionRejectId: number;
  batchRejectId: number;
  rejectReasons: string[];
  action: number;
  expDate: string;
  authCode: string;
  daysToAct: number;
}

export interface TransactionAction {
  batchRejectId: Number;
  batchTransactionsStatus: TransStatus[];
  userName: string;
}

export interface TransStatus {
  batchTransactionRejectId: number;
  newStatus: string;
}
export interface RejectsCount {
  Count: number;
  Status: string;
}

export interface Merchant {
  merchantNumber: string;
  merchantName: string;
  merchantTransactions: merchantTransactions[];
}

export interface merchantTransactions {
  IndividualTxnId: number;
  businessDateUtc: Date;
  Amount: Number;
  CardNumberMask: string;
  txnDateUtc: Date;
  FraudRejectReasonCode: string[];
  BatchNumber: string;
  TxnTypeDescription: string;
  status: string;
}

export interface BatchTransactionAction {
  batchTransactionsStatus: BatchTransStatus[];
  userName: string;
}

export interface BatchTransStatus {
  batchTransactionRejectId: number;
  newStatus: string;
  batchRejectId: number;
}
