import { Component, HostListener, Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { OKTA_AUTH, OktaAuthStateService } from '@okta/okta-angular';
import { OktaAuth, UserClaims, AuthApiError, AccessToken, Tokens, SigninOptions } from '@okta/okta-auth-js';
import { Constants } from './Constants';
import { IdleTimeoutService } from './shared/services/idle-timeout.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'RiskLab';
  isAuthenticated?: boolean;
  userName?: string;
  environment!: string;
  constructor(private router: Router, @Inject(OKTA_AUTH) private oktaAuth: OktaAuth, public authService: OktaAuthStateService, private _idleTimeoutSvc: IdleTimeoutService) {
    this._idleTimeoutSvc.lastTime = (new Date()).getTime() + (this._idleTimeoutSvc._sessionMinutes * 60 * 1000);
  }

  @HostListener('document:mousemove')
  @HostListener('document:keypress')
  @HostListener('document:click')
  @HostListener('document:wheel')
  resetTimer() {
    this._idleTimeoutSvc.lastTime = (new Date()).getTime() + (this._idleTimeoutSvc._sessionMinutes * 60 * 1000) - this._idleTimeoutSvc._sessionDismissMinutes * 60 * 1000;
  }
  async ngOnInit() {
    this.authService.authState$.subscribe(
      async (result) => {
        this.isAuthenticated = result.isAuthenticated;
        if (this.isAuthenticated) {
          this.router.navigate([Constants.landingPage]);
        }     
      });
  }

}
