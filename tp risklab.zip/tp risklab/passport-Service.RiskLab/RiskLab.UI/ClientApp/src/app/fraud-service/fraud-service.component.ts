import { Component, Injector, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Constants } from '../Constants';

@Component({
  selector: 'app-fraud-service',
  templateUrl: './fraud-service.component.html',
  styleUrls: ['./fraud-service.component.css'],
})
export class FraudServiceComponent implements OnInit {
  public sequenceKey: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    injector: Injector
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      sessionStorage.setItem('SequenceKey', params.get('SequenceKey'));
      sessionStorage.setItem('FraudServiceRequest', 'true');
      this.router.navigate([Constants.loginPage]);
    });
  }
}
