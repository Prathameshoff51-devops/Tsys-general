import { ComponentFixture, TestBed } from "@angular/core/testing";

import { FraudServiceComponent } from "./fraud-service.component";
import { ActivatedRoute, Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { of } from "rxjs";

describe("FraudServiceComponent", () => {
  let component: FraudServiceComponent;
  let fixture: ComponentFixture<FraudServiceComponent>;

  const mockRouter = {
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };
  const mockFakeActivatedRoute = {
    paramMap: of({
      get: () => "65000000405167"
    })
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [FraudServiceComponent],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockFakeActivatedRoute }
      ]
    }).compileComponents();
  });
  beforeEach(async () => {
    fixture = TestBed.createComponent(FraudServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it("should have SequenceKey stored in sessionStorage", () => {
    expect(sessionStorage.getItem("SequenceKey")).toEqual("65000000405167");
    expect(sessionStorage.getItem("FraudServiceRequest")).toEqual("true");
    sessionStorage.clear();
  });
});
