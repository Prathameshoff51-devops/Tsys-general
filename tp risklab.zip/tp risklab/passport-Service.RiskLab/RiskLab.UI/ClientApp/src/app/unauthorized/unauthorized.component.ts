import { Component, Inject,OnInit, Injector, OnDestroy } from '@angular/core';
import { OKTA_AUTH, OktaAuthStateService } from '@okta/okta-angular';
import { OktaAuth, UserClaims, AuthApiError, AccessToken, Tokens } from '@okta/okta-auth-js';
import { BaseComponent } from '../shared/base.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-unauthorized',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.css']
})
export class UnauthorizedComponent extends BaseComponent implements OnInit, OnDestroy {
  requestedUrl!: string;

  requestedUrlValueChanges!: Subscription;

  constructor(injector: Injector, @Inject(OKTA_AUTH) private oktaAuth: OktaAuth, public authService: OktaAuthStateService,) {
    super(injector);
  }

  ngOnInit() {
    this.requestedUrlValueChanges = this.activatedRoute
      .queryParams
      .subscribe(params => {
        this.requestedUrl = params['requestedUrl'];
      });
   

  }

  ngOnDestroy() {
    if (this.requestedUrlValueChanges)
      this.requestedUrlValueChanges.unsubscribe();
  }

}
