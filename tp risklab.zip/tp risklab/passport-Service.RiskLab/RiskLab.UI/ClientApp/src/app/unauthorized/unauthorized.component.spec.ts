import { provideHttpClientTesting } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ActivatedRoute } from "@angular/router";
import { OktaAuthStateService, OKTA_AUTH } from "@okta/okta-angular";
import { of } from "rxjs";
import { AppConfig } from "../shared/models/app-config";
import { ConfigurationService } from "../shared/services/configuration.service";

import { UnauthorizedComponent } from "./unauthorized.component";
import { ConstantsUnitTest } from "../constant.unit.test";
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("UnauthorizedComponent", () => {
  let component: UnauthorizedComponent;
  let fixture: ComponentFixture<UnauthorizedComponent>;
  const sessionSpy = jasmine.createSpyObj([
    "exists",
    "setCookieAndRedirect",
    "config"
  ]);
  let oktaAuthSpy = jasmine.createSpyObj(
    "OktaAuth",
    ["signInWithCredentials", "signOut", "config"],
    {
      session: sessionSpy
    }
  );
  let authStateSpy = jasmine.createSpyObj<OktaAuthStateService>(
    [],
    ["authState$"]
  );
  const mockFakeActivatedRoute = {
    queryParams: of({
      requestedUrl: "650000004051668"
    }),
    snapshot: {
      data: {}
    }
  };
 
  const mockAppConfig = jasmine.createSpyObj("AppConfig", [
    "AppConfig",
    "OktaSettings",
    "config"
  ]);
  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["existsMenuByField", "loadConfigurationData", "getMenuByField"]
  );

  beforeEach(async () => {
    mockConfigurationService.loadConfigurationData.and.returnValue(
      Promise.resolve(ConstantsUnitTest.configData)
    );
    mockConfigurationService.getMenuByField.and.returnValue(
      Promise.resolve(ConstantsUnitTest.configData.menu[0])
    );
    mockConfigurationService.existsMenuByField.and.returnValue(true);
    await TestBed.configureTestingModule({
    declarations: [UnauthorizedComponent],
    imports: [],
    providers: [
        { provide: OKTA_AUTH, useValue: oktaAuthSpy, multi: false },
        { provide: OktaAuthStateService, useValue: authStateSpy },
        { provide: ActivatedRoute, useValue: mockFakeActivatedRoute },
        {
            provide: AppConfig,
            useValue: mockAppConfig
        },
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnauthorizedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
