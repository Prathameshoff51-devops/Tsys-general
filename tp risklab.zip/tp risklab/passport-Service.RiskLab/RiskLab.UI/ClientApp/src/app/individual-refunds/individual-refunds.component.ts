import { DOCUMENT } from '@angular/common';
import {
  Component,
  HostListener,
  Inject,
  OnDestroy,
  OnInit,
} from '@angular/core';
import {
  GridApi,
  GridOptions,
  GridReadyEvent,
  PaginationChangedEvent,
} from 'ag-grid-community';
import { Observable } from 'rxjs';
import * as signalR from '@microsoft/signalr';
import { Constant } from '../shared/constant';
import { RejectStatuses } from '../shared/enums';
import { Configuration } from '../shared/models/configuration.model';
import {
  IndividualRefund,
  TransactionAction,
  TransStatus,
  RejectsCount,
} from '../shared/models/individual-refund.model';
import { ConfigurationService } from '../shared/services/configuration.service';
import { IndividualRefundservice } from '../shared/services/individual-refund.service';
import { DropDownListRendererComponent } from '../ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { AppConfig } from '../shared/models/app-config';

@Component({
  selector: 'app-individual-refunds',
  templateUrl: './individual-refunds.component.html',
  styleUrls: ['./individual-refunds.component.css'],
  providers: [IndividualRefundservice],
})
export class IndividualRefundsComponent implements OnInit, OnDestroy {
  documentSaveDialog: any;

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    if (localStorage.getItem('IsChanged') == 'true') {
      event.preventDefault();
      event.returnValue = 'Are you sure you want to reset the changes?';
    }
    return event;
  }

  public gridOptions: GridOptions;
  config!: Configuration;
  public paginationPageSize = Constant.DefaultGridPageSize;
  public daysToAct = Constant.DaysToActs;
  public paginationNumberFormatter: any;
  public rowSelection;
  public totalRecords: number | undefined;
  public transactionAction!: TransactionAction;
  disabled: boolean;
  showRefreshButton: boolean = false;
  individualtxn: IndividualRefund[] = null;
  gridApiActive: GridApi;
  totalResults: any;
  rowIndex: any;
  showMsg: boolean = false;
  isSuccess: boolean = true;
  message: string;
  context: any;
  SearchText: any;
  overlayNoRowsTemplate = 'No records to display.';
  configData: any;
  private connection: signalR.HubConnection;
  //public riskLabUrl!:string;
  public signalrNotificationEndpoint!: string;

  constructor(
    private individualRefundsService: IndividualRefundservice,
    @Inject(DOCUMENT) private document: Document,
    public configService: ConfigurationService,
    private _dialogSvc: LoadingDialogService,
    private appconfig: AppConfig
  ) {
    this.disabled = true;

    this.config = this.configService.config;
    if (
      this.config.defaultGridPageSize != undefined &&
      this.config.daysToAct != undefined
    ) {
      this.paginationPageSize = this.config.defaultGridPageSize;
      this.daysToAct = this.config.daysToAct;
    }

    //this.riskLabUrl = this.configService.configData.riskLabApiUrl;
    this.signalrNotificationEndpoint =
      this.appconfig.config.apiUrl.concat('/notification');

    this.gridApiActive = new GridApi();
    this.context = {
      componentParent: this,
      daysToAct: this.daysToAct,
    };

    this.gridOptions = {
      components: {
        DropDownListRenderer: DropDownListRendererComponent,
      },

      columnDefs: [
        {
          headerName: 'Action',
          field: 'actionDropdown',
          editable: false,
          lockPosition: true,
          pinned: 'left',
          lockPinned: true,
          cellRenderer: 'DropDownListRenderer',
          minWidth: 130,
          maxWidth: 130,
          cellRendererParams: {
            values: [
              { id: 1, name: 'Select Action' },
              {
                id: 2,
                name: 'Queue',
              },
              { id: 3, name: 'Release' },
              { id: 4, name: 'Delete' },
            ],
          },
          cellStyle: this.changeRowColor,
        },

        {
          headerName: 'Merchant Number',
          resizable: true,
          width: 130,
          field: 'merchantNumber',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Merchant Name',
          width: 130,
          resizable: true,
          field: 'merchantName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Legal Name',
          width: 150,
          resizable: true,
          field: 'legalName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Processing Chain ID',
          width: 100,
          field: 'chainOID',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'MCC',
          field: 'mcc',
          resizable: true,
          width: 60,
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Amount',
          resizable: true,
          width: 120,
          field: 'amount',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.currencyFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Card Number Masked',
          resizable: true,
          width: 150,
          field: 'cardNumberMask',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Date (UTC)',
          resizable: true,
          width: 150,
          field: 'txnDateUtc',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          sort: 'asc',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Reject Reasons',
          field: 'fraudRejectReasonCodes',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          width: 200,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Original Batch Number',
          resizable: true,
          width: 80,
          field: 'originalBatchNumber',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Close Date (UTC)',
          resizable: true,
          width: 160,
          field: 'batchCloseDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Auth Code',
          width: 80,
          resizable: true,
          field: 'authCode',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Exp Date',
          width: 150,
          resizable: true,
          field: 'expDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Type',
          width: 80,
          resizable: true,
          field: 'txnTypeDescription',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Submitter',
          resizable: true,
          width: 80,
          field: 'submitterIDDescription',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Days to Act',
          width: 90,
          field: 'daysToAct',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'UserAction',
          hide: true,
          field: 'userAction',
          resizable: true,
          editable: false,
          cellStyle: this.changeRowColor,
        },
      ],
    };
    (this.paginationNumberFormatter = function (params: any) {
      return params.value.toLocaleString();
    }),
      (this.rowSelection = 'multiple');

    this.overlayNoRowsTemplate =
      '<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
  }

  ngOnInit() {
    this.connectHub();
    this.fetchData();
    localStorage.setItem('IsChanged', 'false');
  }

  parentMethod() {
    this.DirtyData();
    var flag: boolean = true;
    this.gridApiActive.forEachNode((node) => {
      if (node.selectable && node.displayed) {
        if (!node.data.hasOwnProperty('action')) {
          flag = false;
        } else if (node.data.action == 1) {
          flag = false;
        }
      }
    });
    if (flag == true) {
      this.disabled = false;
    } else {
      this.disabled = true;
    }
  }
  DirtyData() {
    localStorage.setItem('IsNotAllSelected', 'true');
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action') && node.data.action != 1) {
        localStorage.setItem('IsChanged', 'true');
        localStorage.setItem('IsNotAllSelected', 'false');
        return;
      } else if (node.data.action == 1) {
        if (localStorage.getItem('IsChanged') != 'true') {
          localStorage.setItem('IsChanged', 'false');
        } else if (
          localStorage.getItem('IsNotAllSelected') == 'true' &&
          node.data.action == 1
        ) {
          localStorage.setItem('IsChanged', 'false');
        }
      }
    });
  }
  fetchData() {
    this.individualRefundsService
      .getIndividualRefunds(RejectStatuses.New)
      .subscribe((res: IndividualRefund[]) => {
        this.totalRecords = res?.length;
        try {
          this.individualtxn = res;
          this.individualtxn.forEach((x) => {
            x.action = 1;
          });
        } catch (ex) {
          console.log('error');
          console.log(ex);
        }
      });
    this.disabled = true;
    this.showRefreshButton = false;
  }

  FadeOutSuccessMsg() {
    setTimeout(() => {
      this.showMsg = false;
    }, 10000);
  }
  onPageSizeChanged(params: any) {
    if (this.totalResults < this.paginationPageSize) {
      this.paginationPageSize = this.totalResults;
    }

    params.paginationSetPageSize(this.paginationPageSize);
    this.resetPaginationSelection(this);
  }
  changeRowColor(params) {
    if (params.data.daysToAct <= params.context.daysToAct) {
      return { backgroundColor: '#ffe6e6' };
    } else {
      return null;
    }
  }

  countDisplayedRows(params) {
    this.totalResults = params.api.paginationGetRowCount();
  }

  onGridReady(params: any) {
    this.gridOptions.suppressNoRowsOverlay = true;
    this.gridApiActive = params.api;
    params.api.setDomLayout('autoHeight');
    this.gridApiActive.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }
  }

  OnFilterBoxChanged() {
    if (this.SearchText != '') {
      localStorage.setItem('IsChanged', 'true');
    } else {
      localStorage.setItem('IsChanged', 'false');
    }
    //setTimeout((gridApiActive) => {
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        node.data['action'] = 1;
      }
    });
    // }, 500);
    this.gridApiActive.setQuickFilter(this.SearchText);
    this.disabled = true;
    this.gridApiActive.refreshCells({ force: true });

    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }
  }

  ResetSearch() {
    this.gridApiActive.setQuickFilter(null);
    this.SearchText = '';
  }

  dateFormatter(data) {
    return data.value ? data.value.replace('T', ' ').replace('Z', '') : '';
  }

  currencyFormatter(params: any) {
    return '$' + params.value.toFixed(2);
  }

  resetPaginationSelection = (self) => {
    //Deselect previously selected rows to reset selection
    self.gridApiActive.deselectAll();

    //Initialize pagination data
    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    //Calculate current page row indexes
    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount)
      currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage =
        i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.gridApiActive
        .getDisplayedRowAtIndex(i)
        .setRowSelectable(isWithinCurrentPage);
    }
  };

  onSubmit() {
    const options = {
      title: 'Confirm!',
      message: 'Are you sure you want to submit?',
      cancelText: 'No',
      confirmText: 'Yes',
    };
    this.isSuccess = true;
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe(
      (confirmed: any) => {
        if (confirmed) {
          let transactionsStatus: TransStatus[] = [];
          this.gridApiActive.forEachNode((node) => {
            if (node.selectable && node.displayed) {
              const transcation = {
                TransactionId: node.data.individualTxnId,
                NewStatus: node.data.action.toString(),
              };
              transactionsStatus.push(transcation);
            }
          });
          const transactionAction = {
            transactionsStatus: transactionsStatus,
            userName: this.configService.configData.username,
          };
          // add API call to save modified row
          this.individualRefundsService
            .transcationsAction(transactionAction)
            .subscribe((res: any) => {
              let successCount: number = 0;
              let failCount: number = 0;
              let totalCount: number = 0;
              res.forEach((row) => {
                totalCount++;
                if (row.updateStatus == Constant.Success) {
                  successCount = successCount + 1;
                } else if (row.updateStatus == Constant.Failed) {
                  failCount = failCount + 1;
                }
              });
              if (failCount == 0) {
                this.message =
                  successCount +
                  '/' +
                  totalCount +
                  ' records were processed successfully.';
                this.fetchData();
              } else if (successCount > 0) {
                this.message =
                  failCount +
                  '/' +
                  totalCount +
                  ' records were not processed as another user has already worked on the same records.';
                this.fetchData();
                this.isSuccess = false;
              } else {
                this.message = 'Transaction update failed.';
                this.isSuccess = false;
              }
              this.showMsg = true;
              this.FadeOutSuccessMsg();
              this.ResetSearch();
              localStorage.setItem('IsChanged', 'false');
            });
        }
      },
      (reason: any) => {
        console.log('Dismissed ' + reason);
        console.log('redirec to log out');
      }
    );
  }

  onRefreshButtonClick() {
    const options = {
      title: 'Confirm!',
      message: 'Unsaved actions will get reset, continue with refresh?',
      cancelText: 'No',
      confirmText: 'Yes',
    };
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {
        this.fetchData();
        this.ResetSearch();
        this.showRefreshButton = false;
      }
    });
  }

  onFirstDataRendered(params: GridReadyEvent) {
    params.api.paginationGoToPage(0);
  }

  onPaginationChanged(params: PaginationChangedEvent) {
    this.gridApiActive = params.api;
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        node.data['action'] = 1;
        this.disabled = true;
      }
    });
    localStorage.setItem('IsChanged', 'false');
  }

  connectHub() {
    this.disconnectHub();
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.signalrNotificationEndpoint)
        .withAutomaticReconnect()
        .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.on('NotifyIndividualTxnTab', (response) => {
        if (!this.showRefreshButton) this.showRefreshButton = true;
      });

      this.connection
        .start()
        .then(function () {
          console.info('connected to signalr...');
        })
        .catch((err) => console.error(err));
    }
  }

  disconnectHub() {
    if (this.connection) {
      this.connection.stop();
      this.connection = null;
    }
  }

  ngOnDestroy(): void {
    this.disconnectHub();
  }
  receiveData(data: { showMsg: boolean; isSuccess: boolean; message: string }) {
    this.message = data.message;
    this.showMsg = data.showMsg;
    this.isSuccess = data.isSuccess;
    this.fetchData();
    this.FadeOutSuccessMsg();
  }
}
