import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick
} from "@angular/core/testing";

import { IndividualRefundsComponent } from "./individual-refunds.component";
import { ConfigurationService } from "../shared/services/configuration.service";
import { AppConfig } from "../shared/models/app-config";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { BaseApiService } from "../shared/services/baseapi.service";
import { DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import {
  IndividualRefund,
  Merchant
} from "../shared/models/individual-refund.model";
import { AgGridModule } from "ag-grid-angular";
import { IndividualRefundservice } from "../shared/services/individual-refund.service";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { of } from "rxjs";
import { ConstantsUnitTest } from "../constant.unit.test";
import * as signalR from '@microsoft/signalr';
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("IndividualRefundsComponent", () => {
  let component: IndividualRefundsComponent;
  let fixture: ComponentFixture<IndividualRefundsComponent>;
  let el: DebugElement;
  let httpTestingController: HttpTestingController;

  let mockHubConnection: jasmine.SpyObj<signalR.HubConnection>;

  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["config", "configData"]
  );
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const mockAppConfig = jasmine.createSpyObj("AppConfig", [
    "AppConfig",
    "OktaSettings",
    "config"
  ]);

  const apiReponse: IndividualRefund[] = [
    {
      individualTxnId: 318,
      messageId: "e964fdae-323f-4baa-b493-c439cc561fb3",
      txnUuid: 2022092600009335,
      txnDetailId: 3,
      merchantNumber: "650000009987128",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 52,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 319,
      messageId: "781798e0-8bac-4232-8008-1a6bcdb54d3f",
      txnUuid: 2022092600009335,
      txnDetailId: 3,
      merchantNumber: "650000009987128",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 52,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 320,
      messageId: "1976ef0f-2ddb-43f2-a6c0-9c1c8a141067",
      txnUuid: 2022092600009335,
      txnDetailId: 3,
      merchantNumber: "650000009987128",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 55,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 324,
      messageId: "32c43f15-6e8f-4cdb-b516-1fbaa3ca129b",
      txnUuid: 2022092600009330,
      txnDetailId: 3,
      merchantNumber: "650000009987120",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 55,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 325,
      messageId: "bca6ed47-147c-4156-9b76-3ad1ce783f6e",
      txnUuid: 2022092600009330,
      txnDetailId: 3,
      merchantNumber: "650000009987120",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 55,
      userAction: "New",
      action: 1
    }
  ];
  const apiResponsePageChange: IndividualRefund[] = [
    {
      individualTxnId: 318,
      messageId: "e964fdae-323f-4baa-b493-c439cc561fb3",
      txnUuid: 2022092600009335,
      txnDetailId: 3,
      merchantNumber: "650000009987128",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 52,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 319,
      messageId: "781798e0-8bac-4232-8008-1a6bcdb54d3f",
      txnUuid: 2022092600009335,
      txnDetailId: 3,
      merchantNumber: "650000009987128",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 52,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 320,
      messageId: "1976ef0f-2ddb-43f2-a6c0-9c1c8a141067",
      txnUuid: 2022092600009335,
      txnDetailId: 3,
      merchantNumber: "650000009987128",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 55,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 324,
      messageId: "32c43f15-6e8f-4cdb-b516-1fbaa3ca129b",
      txnUuid: 2022092600009330,
      txnDetailId: 3,
      merchantNumber: "650000009987120",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 55,
      userAction: "New",
      action: 1
    },
    {
      individualTxnId: 325,
      messageId: "bca6ed47-147c-4156-9b76-3ad1ce783f6e",
      txnUuid: 2022092600009330,
      txnDetailId: 3,
      merchantNumber: "650000009987120",
      merchantName: "Test KT",
      legalName: "KENNETH M COLLINS D D S P S",
      chainOID: null,
      mcc: "8021",
      amount: 86.1,
      cardNumberMask: "410039******3213",
      txnDateUtc: "2022-11-02T16:30:16",
      fraudRejectReasonCode: [
        "Batch refund threshold limit exceeded",
        "Suspected fraudulent BIN"
      ],
      originalBatchNumber: "000693",
      authCode: "722595",
      expDate: "2022-09-23T16:19:53",
      txnTypeDescription: "Refund",
      batchCloseDate: "2022-11-02T16:30:16",
      submitterIDDescription: "Exchange",
      daysToAct: 55,
      userAction: "New",
      action: 1
    }
  ];
  const bodytranscationsAction = {
    transactionsStatus: [
      { TransactionId: 318, NewStatus: '3' },
      { TransactionId: 319, NewStatus: '3' },
      { TransactionId: 320, NewStatus: '3' },
      { TransactionId: 324, NewStatus: '3' },
      { TransactionId: 325, NewStatus: '3' }
    ],
    userName: "Prathamesh.Andhale"
  };
  const transcationsActionResponse = [
    { transactionId: 318, updateStatus: "Success", statusCode: "200" },
    { transactionId: 319, updateStatus: "Success", statusCode: "200" },
    { transactionId: 320, updateStatus: "Success", statusCode: "200" },
    { transactionId: 324, updateStatus: "Success", statusCode: "200" },
    { transactionId: 325, updateStatus: "Success", statusCode: "200" }
  ];
  const transcationsActionResponseTwoFailed = [
    { transactionId: 318, updateStatus: "Failed", statusCode: "200" },
    { transactionId: 319, updateStatus: "Failed", statusCode: "200" },
    { transactionId: 320, updateStatus: "Success", statusCode: "200" },
    { transactionId: 324, updateStatus: "Success", statusCode: "200" },
    { transactionId: 325, updateStatus: "Success", statusCode: "200" }
  ];
  const transcationsActionResponseAllFailed = [
    { transactionId: 318, updateStatus: "Failed", statusCode: "200" },
    { transactionId: 319, updateStatus: "Failed", statusCode: "200" },
    { transactionId: 320, updateStatus: "Failed", statusCode: "200" },
    { transactionId: 324, updateStatus: "Failed", statusCode: "200" },
    { transactionId: 325, updateStatus: "Failed", statusCode: "200" }
  ];
  beforeEach(async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    mockHubConnection = jasmine.createSpyObj('HubConnection', ['start', 'stop', 'on']);
    // Ensure .start always returns a Promise to avoid TypeError on .then
    mockHubConnection.start.and.returnValue(Promise.resolve());



    // Mock the builder chain using prototype spies
    spyOn(signalR.HubConnectionBuilder.prototype, 'withUrl').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'withAutomaticReconnect').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'configureLogging').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'build').and.returnValue(mockHubConnection);

    await TestBed.configureTestingModule({
    declarations: [IndividualRefundsComponent],
    imports: [AgGridModule],
    providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        IndividualRefundservice,
        {
            provide: LoadingDialogService,
            useValue: mockLoadingDialogService
        },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualRefundsComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    el = fixture.debugElement;

    // mockAppConfig.AppConfig.and.returnValue(of(config))
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it(`should have config paginationPageSize be 5`, () => {
    localStorage.setItem("IsChanged", "true");
    var event = { preventDefault: jasmine.createSpy() };
    component.beforeunloadHandler(event);
    component.config.defaultGridPageSize = 5;
    component.config.daysToAct = 10;
    expect(component.daysToAct).toEqual(10);
    expect(component.paginationPageSize).toEqual(5);
  });
  it(`should have called changeRowColor`, () => {
    let params = {
      data: {
        daysToAct: 10
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color.backgroundColor).toEqual('#ffe6e6' );
  });
  it("should called fetchData ", async () => {
    const req = httpTestingController.expectOne(
      "https://localhost:7247/IndividualTransactions?status=1"
    );
    req.flush(apiReponse); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(5);
  });
  
  it("should be called resetPaginationSelection ", async () => {
    apiResponsePageChange.push(apiResponsePageChange[0]);
    component.individualtxn = apiResponsePageChange;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(0);
    component.gridApiActive.paginationGoToNextPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.onRefreshButtonClick();
    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(1);
    expect(component.gridApiActive.paginationGetTotalPages()).toEqual(2);
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(6);
    expect(component.showRefreshButton).toEqual(false);
  });
  it("should be All transcations successfully update ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 3;
    }
    component.configService.configData.username = "Prathamesh.Andhale";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/IndividualTransactions"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponse);
    expect(component.message).toEqual(
      "5/5 records were processed successfully."
    );
  });
  it("should be some transcations successfully update ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 3;
    }
    component.configService.configData.username = "Prathamesh.Andhale";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/IndividualTransactions"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseTwoFailed);
    expect(component.message).toEqual(
      "2/5 records were not processed as another user has already worked on the same records."
    );
  });
  it("should be All transcations failed update ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 3;
    }
    component.configService.configData.username = "Prathamesh.Andhale";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/IndividualTransactions"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseAllFailed);
    expect(component.message).toEqual("Transaction update failed.");
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should be transcations failed ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 3;
    }
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component.onSubmit();
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should getDisplayedRowCount be 2 after SearchText ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "650000009987120";
    jasmine.clock().install();
    component.OnFilterBoxChanged();
    jasmine.clock().tick(500);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
    jasmine.clock().uninstall();
  });

  it("should getDisplayedRowCount be 5 after SearchText empty", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "";
    component.OnFilterBoxChanged();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(5);
  });
  it("should be disabled  ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 1;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should be !disabled  ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 1;
    }
    apiReponse[0].action = 3;
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should be not disabled  ", async () => {
    component.individualtxn = JSON.parse(JSON.stringify(apiReponse));;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.individualtxn) {
      res.action = 2;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeFalse();
  });
  it("should be parentMethod return disabled  ", async () => {
    component.individualtxn = apiReponse;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse) {
      res.action = 1;
    }
    localStorage.setItem("IsChanged", "true");
    await component.parentMethod();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should set disabled to true if a node does not have action property", async () => {
    // Simulate gridApiActive with a node missing action property
    component.gridApiActive = {
      forEachNode: (cb) => {
        cb({ selectable: true, displayed: true, data: { merchantNumber: '123' } });
      }
    } as any;
    component.disabled = false;
    await component.parentMethod();
    expect(component.disabled).toBeTrue();
  });
  it('should set disabled to false if all nodes have action property and at least one action != 1', async () => {
    // Simulate gridApiActive with nodes, one with action != 1
    component.gridApiActive = {
      forEachNode: (cb) => {
        cb({ selectable: true, displayed: true, data: { action: 1 } });
        cb({ selectable: true, displayed: true, data: { action: 2 } });
      }
    } as any;
    component.disabled = true;
    await component.parentMethod();
    expect(component.disabled).toBeTrue();
  });
  it(
    `should have called FadeOutSuccessMsg`,
    fakeAsync(() => {
      component.FadeOutSuccessMsg();
      tick(10000);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.showMsg).toEqual(false);
      });
    })
  );
  it('should update state and call fetchData and FadeOutSuccessMsg in receiveData', () => {
    const data = { showMsg: true, isSuccess: false, message: 'Test message' };
    spyOn(component, 'fetchData');
    spyOn(component, 'FadeOutSuccessMsg');
    component.receiveData(data);
    expect(component.message).toBe('Test message');
    expect(component.showMsg).toBeTrue();
    expect(component.isSuccess).toBeFalse();
    expect(component.fetchData).toHaveBeenCalled();
    expect(component.FadeOutSuccessMsg).toHaveBeenCalled();
  });
  it('should handle onPageSizeChanged and set paginationPageSize if totalResults < paginationPageSize', () => {
    component.totalResults = 3;
    component.paginationPageSize = 5;
    const params = {
      paginationSetPageSize: jasmine.createSpy('paginationSetPageSize'),
    };
    spyOn(component, 'resetPaginationSelection');
    component.onPageSizeChanged(params);
    expect(component.paginationPageSize).toBe(3);
    expect(params.paginationSetPageSize).toHaveBeenCalledWith(3);
    expect(component.resetPaginationSelection).toHaveBeenCalledWith(component);
  });

  it('should handle onPageSizeChanged and not change paginationPageSize if totalResults >= paginationPageSize', () => {
    component.totalResults = 10;
    component.paginationPageSize = 5;
    const params = {
      paginationSetPageSize: jasmine.createSpy('paginationSetPageSize'),
    };
    spyOn(component, 'resetPaginationSelection');
    component.onPageSizeChanged(params);
    expect(component.paginationPageSize).toBe(5);
    expect(params.paginationSetPageSize).toHaveBeenCalledWith(5);
    expect(component.resetPaginationSelection).toHaveBeenCalledWith(component);
  });
  it('should set totalResults in countDisplayedRows', () => {
    const params = { api: { paginationGetRowCount: () => 7 } };
    component.countDisplayedRows(params);
    expect(component.totalResults).toBe(7);
  });

  it('should call showNoRowsOverlay in onGridReady when no rows are displayed', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const setDomLayout = jasmine.createSpy('setDomLayout');
    const addEventListener = jasmine.createSpy('addEventListener');
    const params = {
      api: {
        setDomLayout,
        addEventListener,
        getDisplayedRowCount: () => 0,
        showNoRowsOverlay,
        hideOverlay
      }
    };
    component.onGridReady(params);
    expect(showNoRowsOverlay).toHaveBeenCalled();
    expect(hideOverlay).not.toHaveBeenCalled();
  });

  it('should call hideOverlay in onGridReady when rows are displayed', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const setDomLayout = jasmine.createSpy('setDomLayout');
    const addEventListener = jasmine.createSpy('addEventListener');
    const params = {
      api: {
        setDomLayout,
        addEventListener,
        getDisplayedRowCount: () => 2,
        showNoRowsOverlay,
        hideOverlay
      }
    };
    component.onGridReady(params);
    expect(hideOverlay).toHaveBeenCalled();
    expect(showNoRowsOverlay).not.toHaveBeenCalled();
  });

  it('should call showNoRowsOverlay in OnFilterBoxChanged when no rows are displayed', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const refreshCells = jasmine.createSpy('refreshCells');
    const setQuickFilter = jasmine.createSpy('setQuickFilter');
    const forEachNode = jasmine.createSpy('forEachNode');
    const getDisplayedRowCount = jasmine.createSpy('getDisplayedRowCount').and.returnValue(0);
    component.gridApiActive = {
      forEachNode,
      setQuickFilter,
      refreshCells,
      getDisplayedRowCount,
      showNoRowsOverlay,
      hideOverlay
    } as any;
    component.SearchText = 'test';
    component.OnFilterBoxChanged();
    expect(showNoRowsOverlay).toHaveBeenCalled();
    expect(hideOverlay).not.toHaveBeenCalled();
  });

  it('should call hideOverlay in OnFilterBoxChanged when rows are displayed', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const refreshCells = jasmine.createSpy('refreshCells');
    const setQuickFilter = jasmine.createSpy('setQuickFilter');
    const forEachNode = jasmine.createSpy('forEachNode');
    const getDisplayedRowCount = jasmine.createSpy('getDisplayedRowCount').and.returnValue(2);
    component.gridApiActive = {
      forEachNode,
      setQuickFilter,
      refreshCells,
      getDisplayedRowCount,
      showNoRowsOverlay,
      hideOverlay
    } as any;
    component.SearchText = '';
    component.OnFilterBoxChanged();
    expect(hideOverlay).toHaveBeenCalled();
    expect(showNoRowsOverlay).not.toHaveBeenCalled();
  });

  it('should format date correctly in dateFormatter', () => {
    expect(component.dateFormatter({ value: '2022-11-02T16:30:16Z' })).toBe('2022-11-02 16:30:16');
    expect(component.dateFormatter({ value: '2022-11-02T16:30:16' })).toBe('2022-11-02 16:30:16');
    expect(component.dateFormatter({ value: null })).toBe('');
    expect(component.dateFormatter({})).toBe('');
    expect(component.dateFormatter({ value: undefined })).toBe('');
    expect(component.dateFormatter({ value: '' })).toBe('');
    expect(component.dateFormatter({ value: null })).not.toBeNull();
    expect(component.dateFormatter({})).not.toBeNull();
  });

  it('should call builder chain and connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyIndividualTxnTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
  }));

  it('should set showRefreshButton to true when NotifyIndividualTxnTab event is received', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    let notifyHandler: ((response: any) => void) | undefined;
    mockHubConnection.on.and.callFake((event, handler) => {
      if (event === 'NotifyIndividualTxnTab') {
        notifyHandler = handler;
      }
    });
    component.showRefreshButton = false;
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyIndividualTxnTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    // Act: simulate event received
    if (notifyHandler) {
      notifyHandler({});
    }
    // Assert
    expect(component.showRefreshButton).toBeTrue();
  }));
  it('should call catch and log error if SignalR connection fails in connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    const error = new Error('Connection failed');
    spyOn(console, 'error');
    mockHubConnection.start.and.returnValue(Promise.reject(error));
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyIndividualTxnTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    expect(console.error).toHaveBeenCalledWith(error);
  }));
   it('should call catch block and log error in fetchData when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    const faultyRes = [{ action: 1 }];
    spyOn(component['individualRefundsService'], 'getIndividualRefunds').and.returnValue({
      subscribe: (success) => {
        success(faultyRes);
      }
    } as any);
    // Patch forEach to throw
    spyOn(faultyRes, 'forEach').and.callFake(() => { throw errorObj; });
    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchData();
    // Assert
    expect(console.log).toHaveBeenCalledWith('error');
    expect(console.log).toHaveBeenCalledWith(errorObj);
  });
  it('should call catch block and log error in fetchData when undefined throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new TypeError(`Cannot read properties of undefined (reading 'forEach')`);
    const faultyRes = [{ action: 1 }];
    spyOn(component['individualRefundsService'], 'getIndividualRefunds').and.returnValue({
      subscribe: (success) => {
        success(undefined);
      }
    } as any);
    // Patch forEach to throw
    spyOn(faultyRes, 'forEach').and.callFake(() => { throw errorObj; });
    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchData();
    // Assert
    expect(console.log).toHaveBeenCalledWith('error');
    expect(console.log).toHaveBeenCalledWith(jasmine.any(TypeError));
  });
  it('should log error and redirect to logout if dialogSvc.confirmed emits error in onSubmit', () => {
    // Arrange: get the dialog service from TestBed
    const dialogSvc = TestBed.inject(LoadingDialogService) as jasmine.SpyObj<LoadingDialogService>;
    dialogSvc.openDialog.and.stub();
    dialogSvc.confirmed.and.returnValue({
      subscribe: (success, error) => {
        if (error) error('some error reason');
      }
    } as any);
    spyOn(console, 'log');
    // Act
    component.onSubmit();
    // Assert
    expect(console.log).toHaveBeenCalledWith('Dismissed some error reason');
    //expect(console.log).toHaveBeenCalledWith('redirec to log out');
  });
});
