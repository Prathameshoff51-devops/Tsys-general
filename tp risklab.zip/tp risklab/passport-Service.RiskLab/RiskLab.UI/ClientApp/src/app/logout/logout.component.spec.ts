import { of } from 'rxjs';
import { NavigationEnd } from '@angular/router';
import { OktaAuth } from '@okta/okta-auth-js';

import { ComponentFixture, TestBed } from "@angular/core/testing";
import { Router } from "@angular/router";
import { OKTA_AUTH } from "@okta/okta-angular";
import { LogoutComponent } from "./logout.component";
import { ConstantsUnitTest } from "../constant.unit.test";

describe("LogoutComponent", () => {
  let component: LogoutComponent;
  let fixture: ComponentFixture<LogoutComponent>;

  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LogoutComponent],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: OKTA_AUTH, useValue: new OktaAuth(ConstantsUnitTest.config), multi: false }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it('should cover catch block in ngOnInit', () => {
    // Arrange
    const error = new Error('tokenManager.clear failed');
    const mockOktaAuth = {
      tokenManager: {
        clear: jasmine.createSpy('clear').and.throwError(error)
      }
    };
    // Replace the oktaAuth instance on the component
    (component as any).oktaAuth = mockOktaAuth;
    spyOn(sessionStorage, 'clear');
    spyOn(localStorage, 'clear');
    spyOn(console, 'log');
    // Act
    component.ngOnInit();
    // Assert
    expect(console.log).toHaveBeenCalledWith(error);
  });
});
