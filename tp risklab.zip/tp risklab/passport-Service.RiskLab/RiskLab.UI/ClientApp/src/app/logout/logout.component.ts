import {
  Component,
  Inject,
  Input,
  OnInit,
  ViewEncapsulation,
} from '@angular/core';
import { Router } from '@angular/router';
import { OKTA_AUTH } from '@okta/okta-angular';
import { OktaAuth, AccessToken } from '@okta/okta-auth-js';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css'],
})
export class LogoutComponent implements OnInit {
  userName?: string;
  isAuthenticated?: boolean;
  constructor(
    private router: Router,
    @Inject(OKTA_AUTH) private oktaAuth: OktaAuth
  ) {
    this.isAuthenticated = false;
  }

  ngOnInit(): void {
    try {
      this.oktaAuth.tokenManager.clear();
      sessionStorage.clear();
      localStorage.clear();
    } catch (ex) {
      console.log(ex);
    }
  }
}
