export class ConstantsUnitTest {
   
       public static  configData = {
        environment: "UT",
        defaultBatchGridPageSize: 15,
        DefaultGridPageSizeforBatchTxnRejects: 15,
        scaPersonInfoUrl: null,
        defaultGridPageSize: 5,
        defaultBackOfficeGridPageSize: 15,
        daysToAct: 10,
        minimumSearchLength: 0,
        riskLabApiUrl: "https://risklabsbx.heartlandapps.net/api",
        riskLabUiUrl: "https://risklabsbx.heartlandapps.net",
        username: "Nikhil.Akole",
        coreloggingServiceUrl: "https://coreloggingservicesbx.heartlandapps.net",
        jwtClaimsToken: null,
        isSuperAdmin: false,
        isBackOfficeUser: false,
        menu: [
          {
            name: "RiskRejects",
            displayName: "Risk Rejects",
            link: "/secure/risklab",
            iconName: "fas fa-file-alt fa-lg",
            route: "secure/risklab",
            childrenMenuItems: [
              {
                name: "RiskRejectsDetails",
                displayName: "Risk Rejects Details",
                link: "/secure/risklab/details",
                iconName: "fas fa-info-circle",
                route: "secure/risklab/details",
                selected: false,
                childrenMenuItems: null
              },
              {
                name: "RiskRejectsSummary",
                displayName: "Risk Rejects Summary",
                link: "/secure/risklab/summary",
                iconName: "fas fa-list-alt",
                route: "secure/risklab/summary",
                selected: false,
                childrenMenuItems: []
              }
            ],
            selected: false
          },
          {
            name: "FraudServiceDetails",
            displayName: "Fraud Service Details",
            link: "/secure/merchantrejectedtxns",
            iconName: "fas fa-copy",
            route: "secure/merchantrejectedtxns",
            childrenMenuItems: null
          }
        ],
        threadId: 1442308064,
        isFraudServiceUser: true,
        isRiskLabUser: true
      };
     
      public static  config = {
        apiUrl: "https://localhost:7247",
        apiHeader: "string",
        clientId: "0oa1579unoi9zvZCw0h8",
        issuer:
          "https://apis-dev.globalpay.com/okta-mfa/authorization/oauth2/aus16azw0f8RGsLqb0h8",
        redirectUri: "http://localhost:4200/login/callback",
        scopes: ["openid", "profile", "email", "offline_access"],
        logoutUrl: "http://localhost:4200/logout"
      };
}