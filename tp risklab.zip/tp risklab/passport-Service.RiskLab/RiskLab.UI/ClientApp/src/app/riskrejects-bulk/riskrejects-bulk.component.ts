import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTabGroup } from '@angular/material/tabs';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';

@Component({
  selector: 'app-riskrejects-bulk',
  templateUrl: './riskrejects-bulk.component.html',
  styleUrls: ['./riskrejects-bulk.component.css'],
})
export class RiskrejectsBulkComponent implements OnInit {
  isSuccess: boolean = true;
  private currentTabIndex = 0;
  @ViewChild(MatTabGroup) tabs?: MatTabGroup;

  constructor(private _dialogSvc: LoadingDialogService) { }

  ngOnInit(): void { }

  ngAfterViewInit() {
    this.registerTabClick();
    if (sessionStorage.getItem("batchQueuedRejects")) {
      this.tabs.selectedIndex = 1;
      sessionStorage.removeItem("batchQueuedRejects");
    }
    else {
      this.tabs.selectedIndex = 0;
    }    
  }
  registerTabClick(): void {
    const handleTabClick = this.tabs._handleClick;
    this.tabs._handleClick = (tab, header, index) => {
      const tabContent = this.getTabContentElement(this.currentTabIndex);

      if (localStorage.getItem('IsChanged') != 'true') {
        handleTabClick.apply(this.tabs, [tab, header, index]);
      } else {
        const options = {
          title: 'Leave this page?',
          message: 'Changes you made may not be saved.',
          cancelText: 'Stay',
          confirmText: 'Leave',
        };
        this.isSuccess = true;
        this._dialogSvc.openDialog(options);
        this._dialogSvc.confirmed().subscribe((confirmed: any) => {
          if (confirmed) {
            handleTabClick.apply(this.tabs, [tab, header, index]);
            localStorage.setItem('IsChanged', 'false');
          } else {
            localStorage.setItem('IsChanged', 'true');
          }
        });
      }

      this.currentTabIndex = index;
    };
  }
  private getTabContentElement(tabIndex: number) {
    return document.getElementsByClassName('mat-tab-body-content')[tabIndex];
  }
}
