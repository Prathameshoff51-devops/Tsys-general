import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from "@angular/common";
import { DebugElement } from "@angular/core";

import { MatTabGroup, MatTabsModule } from "@angular/material/tabs";
import { By } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { of } from 'rxjs';

import { RiskrejectsBulkComponent } from './riskrejects-bulk.component';

describe('RiskrejectsBulkComponent', () => {
  let component: RiskrejectsBulkComponent;
  let fixture: ComponentFixture<RiskrejectsBulkComponent>;
  let el: DebugElement;
  let compiled: any;
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MatTabsModule, CommonModule, BrowserAnimationsModule],
      declarations: [ RiskrejectsBulkComponent ],
      providers: [
        {
          provide: LoadingDialogService,
          useValue: mockLoadingDialogService
        },
        MatTabGroup
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RiskrejectsBulkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call registerTabClick and set selectedIndex to 1 if batchQueuedRejects exists', () => {
    const fakeTabs: any = { selectedIndex: 0, _handleClick: jasmine.createSpy('_handleClick') };
    component['tabs'] = fakeTabs;
    spyOn(sessionStorage, 'getItem').and.returnValue('1');
    const removeSpy = spyOn(sessionStorage, 'removeItem');
    const regSpy = spyOn(component, 'registerTabClick');
    component.ngAfterViewInit();
    expect(regSpy).toHaveBeenCalled();
    expect(fakeTabs.selectedIndex).toBe(1);
    expect(removeSpy).toHaveBeenCalledWith('batchQueuedRejects');
  });

  it('should call registerTabClick and set selectedIndex to 0 if batchQueuedRejects does not exist', () => {
    const fakeTabs: any = { selectedIndex: 5, _handleClick: jasmine.createSpy('_handleClick') };
    component['tabs'] = fakeTabs;
    spyOn(sessionStorage, 'getItem').and.returnValue(null);
    const regSpy = spyOn(component, 'registerTabClick');
    component.ngAfterViewInit();
    expect(regSpy).toHaveBeenCalled();
    expect(fakeTabs.selectedIndex).toBe(0);
  });

  it('should call handleTabClick when IsChanged is not true', () => {
    const originalHandleClick = jasmine.createSpy('_handleClick');
    const fakeTabs: any = { _handleClick: originalHandleClick };
    component['tabs'] = fakeTabs;
    spyOn(localStorage, 'getItem').and.returnValue('false');
    component['currentTabIndex'] = 0;
    component.registerTabClick();
    // The new _handleClick is not a spy, but should call the original spy
    expect(typeof fakeTabs._handleClick).toBe('function');
    fakeTabs._handleClick('tab', 'header', 1);
    expect(originalHandleClick).toHaveBeenCalledWith('tab', 'header', 1);
  });

  it('should open dialog and handle confirm true', () => {
    const fakeTabs: any = { _handleClick: jasmine.createSpy('_handleClick') };
    component['tabs'] = fakeTabs;
    spyOn(localStorage, 'getItem').and.returnValue('true');
    const setItemSpy = spyOn(localStorage, 'setItem');
    mockLoadingDialogService.openDialog.and.callThrough();
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    component['currentTabIndex'] = 0;
    component.registerTabClick();
    fakeTabs._handleClick('tab', 'header', 1);
    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(setItemSpy).toHaveBeenCalledWith('IsChanged', 'false');
  });

  it('should open dialog and handle confirm false', () => {
    const fakeTabs: any = { _handleClick: jasmine.createSpy('_handleClick') };
    component['tabs'] = fakeTabs;
    spyOn(localStorage, 'getItem').and.returnValue('true');
    const setItemSpy = spyOn(localStorage, 'setItem');
    mockLoadingDialogService.openDialog.and.callThrough();
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component['currentTabIndex'] = 0;
    component.registerTabClick();
    fakeTabs._handleClick('tab', 'header', 1);
    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(setItemSpy).toHaveBeenCalledWith('IsChanged', 'true');
  });

  it('should get tab content element', () => {
    const fakeDiv = document.createElement('div');
    const fakeCollection = {
      0: fakeDiv,
      length: 1,
      item: (index: number) => index === 0 ? fakeDiv : null,
      namedItem: () => null
    } as unknown as HTMLCollectionOf<Element>;
    spyOn(document, 'getElementsByClassName').and.returnValue(fakeCollection);
    const result = (component as any).getTabContentElement(0);
    expect(result).toBe(fakeDiv);
  });
});
