import { DOCUMENT } from '@angular/common';
import { Component, HostListener, Inject, OnDestroy, OnInit, Output } from '@angular/core';
import {  GridApi, GridOptions, GridReadyEvent, PaginationChangedEvent } from 'ag-grid-community';
import { max, Observable } from 'rxjs';
import * as signalR from '@microsoft/signalr'
import { Constant } from '../shared/constant';
import { Configuration } from '../shared/models/configuration.model';
import { BatchtxnRejects,Transactions } from '../shared/models/batch-new-txn-rejects.model';
import { ConfigurationService } from '../shared/services/configuration.service';
import { DropDownListRendererComponent } from '../ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { TransStatus } from '../shared/models/batch-queued-txn-rejects.model';
import { BatchQueuedtxnservice } from '../shared/services/batch-queued-txn-rejects';
import { Router } from '@angular/router';
import { Constants } from '../Constants';

@Component({
  selector: 'app-new-batch-txn-rejects',
  templateUrl: './batch-new-txn-rejects.component.html',
  styleUrls: ['./batch-new-txn-rejects.component.css'],
  providers: [BatchQueuedtxnservice],
})
export class BatchNewtxnRejectsComponent implements OnInit, OnDestroy {
  documentSaveDialog: any;
  style: { [klass: string]: any; };

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    if (localStorage.getItem("IsChanged") == 'true') {
      event.preventDefault();
      event.returnValue = 'Are you sure you want to reset the changes?';
    }
    return event;
  }

  public gridOptions: GridOptions;
  config!: Configuration
  public paginationPageSize = Constant.DefaultGridPageSizeforBatchTxnRejects;
  public daysToAct = Constant.DaysToActs;
  public paginationNumberFormatter: any;
  public rowSelection;
  public totalRecords: number | undefined;
  disabled: boolean;
  showRefreshButton: boolean = false;
  batchtxnRejects: BatchtxnRejects = null;
  transactions: Transactions[] = null;
  originalBatchNumber: string = '';
  displayMerchantData: boolean = false;
  showErrMsg: boolean = false;
  gridApiActive: GridApi;
  totalResults: any;
  showMsg: boolean = false;
  isSuccess: boolean = true;
  message: string;
  context: any;
  SearchText: any;
  overlayNoRowsTemplate = "No records to display.";
  configData: any;
  private connection: signalR.HubConnection;
  public riskLabUrl!: string;
  public signalrNotificationEndpoint!: string;
  @Output() sideNavBarFlag: false;
  constructor(
    private batchtxnRejectsService: BatchQueuedtxnservice,
    @Inject(DOCUMENT) private document: Document,
    public configService: ConfigurationService,
    private _dialogSvc: LoadingDialogService,
    private router: Router
  ) {
    this.disabled = true;

    this.config = this.configService.config;
    if (this.config.DefaultGridPageSizeforBatchTxnRejects != undefined && this.config.daysToAct != undefined) {
      this.paginationPageSize = this.config.DefaultGridPageSizeforBatchTxnRejects = this.config.daysToAct;;
    }

    this.riskLabUrl = this.configService.configData.riskLabApiUrl;
    this.signalrNotificationEndpoint = this.riskLabUrl + "/notification";

    this.gridApiActive = new GridApi();
    this.context = {
      componentParent: this,
      daysToAct: this.daysToAct
    };

    this.gridOptions = {
      components: {
        DropDownListRenderer: DropDownListRendererComponent,
      },

      columnDefs: [
        {
          headerName: 'Action',
          field: 'actionDropdown',
          editable: false,
          lockPosition: true,
          pinned: 'left',
          lockPinned: true,
          cellRenderer: 'DropDownListRenderer',
          minWidth: 130,
          maxWidth:130,
          cellStyle: this.changeRowColor,
          cellRendererParams: params => {
            let disableDropdrown = false;
            let values = [
              { id: 1, name: 'Select Action' },
              { id: 2, name: 'Queue', },
              { id: 3, name: 'Release' },
              { id: 4, name: 'Delete' },
            ];
            if (params.data.status !== "New") {
              disableDropdrown = true;
            }
            return {
              values: values,
              disableDropdrown: disableDropdrown
            };
          },        
        },
        {
          headerName: 'Txn Amount',
          minWidth: 200,
          maxWidth:200,
          resizable: true,
          cellStyle: this.changeRowColor,
          field: 'txnAmount',
          sortable: true,
          valueFormatter: this.currencyFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },        

        {
          headerName: 'Card Number Masked',
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 200,
          maxWidth:200,
          field: 'cardNumberMasked',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Date (UTC)',
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 200,
          maxWidth:200,
          field: 'txnDateUTC',
          sortable: true,
          valueFormatter: this.dateFormatter,
          sort: 'asc',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Original Batch Number',
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 200,
          maxWidth:200,
          field: 'originalBatchNumber',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },       
        {
          headerName: 'Reject Reasons',
          field: 'rejectReasons',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 265,
          maxWidth:265,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Auth Code',
          minWidth: 150,
          maxWidth:150,
          resizable: true,
          cellStyle: this.changeRowColor,
          field: 'authCode',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Exp Date',
          minWidth: 230,
          maxWidth:230,
          resizable: true,
          field: 'expDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Type',
          minWidth: 200,
          maxWidth:200,
          resizable: true,
          cellStyle: this.changeRowColor,
          field: 'txnType',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },      
        {
          headerName: 'Days to Act',
          minWidth: 120,
          maxWidth:120,
          field: 'daysToAct',
          sortable: true,
          resizable: true,
            cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
      ],
    };
    (this.paginationNumberFormatter = function (params: any) {
      return params.value.toLocaleString();
    }),
      (this.rowSelection = 'multiple');
      
  this.overlayNoRowsTemplate =
  '<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
  }

  ngOnInit() {
    this.connectHub();
    this.fetchData();
    localStorage.setItem("IsChanged", 'false');
  }
  changeRowColor(params) {
    if (
      params.data.daysToAct <= params.context.daysToAct &&
      params.data.status !== "New"
    ) {
      return { "background-color": "#dee2e6" };
    } else if (params.data.status !== "New") {
      return { "background-color": "#dee2e6" };
    } else if (params.data.daysToAct <= params.context.daysToAct) {
      return { backgroundColor: '#ffe6e6' };
    } else {
      return null;
    }
  }


  parentMethod() {
    this.DirtyData();
    var flag: boolean = true;
    this.gridApiActive.forEachNode((node) => {
      if (!node.data.hasOwnProperty('action') || node.data.action == 1) {
        flag = false;
      }
    });
    this.disabled = !flag;
  }

  onPaginationChanged(params: PaginationChangedEvent) {
    this.gridApiActive = params.api;
  }

  resetPaginationSelection = (self) => {
    //Deselect previously selected rows to reset selection

    //Initialize pagination data
    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    this.setDomLayouts();
    //Calculate current page row indexes
    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount)
      currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage =
        i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.gridApiActive
        .getDisplayedRowAtIndex(i)
        .setRowSelectable(isWithinCurrentPage);
    }
  };

  DirtyData() {
    localStorage.setItem("IsNotAllSelected", 'true');
    this.gridApiActive.forEachNode((node) => {
      if ((node.data.hasOwnProperty('action')) && (node.data.action != 1)) {
        localStorage.setItem("IsChanged", 'true');
        localStorage.setItem("IsNotAllSelected", 'false');
        return;
      }

      else if ((node.data.action == 1)) {
        if (localStorage.getItem("IsChanged") != 'true') {
          localStorage.setItem("IsChanged", 'false');
        }
        else if ((localStorage.getItem("IsNotAllSelected") == 'true') && (node.data.action == 1)) {
          localStorage.setItem("IsChanged", 'false');
        }
      }
    });
  }
  fetchData() {
    const batchRejectId = localStorage.getItem(Constants.batchRejectIdforNewDrillDown);
    this.batchtxnRejectsService.getBatchtxnRejects(batchRejectId).subscribe(
      (res: BatchtxnRejects) => {
        this.totalRecords = res?.transactions.length;
        try {
          this.batchtxnRejects = res;

          this.batchtxnRejects.batchAmount = this.currencyFormatter({
            value: Number(this.batchtxnRejects.batchAmount)
          })

          this.transactions = res.transactions;
          this.transactions.forEach(x => {
            x.action = 1
            x.originalBatchNumber = res.originalBatchNumber;
            x.batchCloseDateUTC = res.batchCloseDateUTC;
          })

          this.displayMerchantData = true;
          localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);

        } catch (ex) {
          console.log('error');
          console.log(ex);
        }
      },
      (error) => {
        this.displayMerchantData = false;
        this.showErrMsg = true;
        this.message = error.error;
        this.displayMerchantData = true;
      });
    this.disabled = true;
    this.showRefreshButton = false;
  }
  onSubmit() {
    const options = {
      title: "Confirm!",
      message: "Are you sure you want to submit?",
      cancelText: "No",
      confirmText: "Yes"
    };
    this.isSuccess = true;
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe(
      (confirmed: any) => {
        if (confirmed) {
          let transactionsStatus: TransStatus[] = [];
          this.gridApiActive.forEachNode(node => {
            if (node.data.hasOwnProperty("action") && node.data.action > 1) {
              const transcation = {
                batchTransactionRejectId: node.data.batchTransactionRejectId,
                newStatus: node.data.action.toString()
              };
              transactionsStatus.push(transcation);
            }
          });
          const transactionAction = {
            batchRejectId: this.batchtxnRejects.batchRejectId,
            batchTransactionsStatus: transactionsStatus,
            userName: this.configService.configData.username
          };                   
          localStorage.setItem(
            Constants.batchRejectIdforNewDrillDown,
            this.batchtxnRejects.batchRejectId.toString()
          );
          this.message =" records were processed successfully.";
          this.showMsg = true;
          
          // add API call to save modified row
          const res = this.batchtxnRejectsService
            .transcationsAction(transactionAction)
            .subscribe((res: any) => {
              let successCount: number = 0;
              let failCount: number = 0;
              let totalCount: number = 0;
              res.batchTransactionRejectUpdateStatuses.forEach(row => {
                totalCount++;
                if (row.updateStatus == Constant.Success) {
                  successCount = successCount + 1;
                } else if (row.updateStatus == Constant.Failed) {
                  failCount = failCount + 1;
                }
              });
              if (failCount == 0) {
                this.message =
                  successCount +
                  "/" +
                  totalCount +
                  " records were processed successfully.";
                this.fetchData();
              } else if (successCount > 0) {
                this.message =
                  failCount +
                  "/" +
                  totalCount +
                  " records were not processed as another user has already worked on the same records.";
                this.fetchData();
                this.isSuccess = false;
              } else {
                this.message = "Transaction(s) update failed.";
                this.isSuccess = false;
                this.fetchData();
              }
              this.showMsg = true;
              this.FadeOutSuccessMsg();
              this.ResetSearch();
              localStorage.setItem("IsChanged", "false");
            });
        } else {
          console.log("No");
        }
      },
      (reason: any) => {
        console.log("Dismissed " + reason);
        console.log("redirec to log out");
      }
    );
  }
  FadeOutSuccessMsg() {
    setTimeout(() => {
    this.showMsg = false;
    sessionStorage.setItem('batchrejects','true');
    this.router.navigate([Constant.BASE_PATH]);
    }, 5000);
  }
  onPageSizeChanged(e: any) {
    if (this.totalResults < this.paginationPageSize) {
      this.paginationPageSize = this.totalResults;
    }

    this.setDomLayouts();
    this.gridApiActive.paginationSetPageSize(e.value);
    this.resetPaginationSelection(this);
  }

  countDisplayedRows(params) {
    this.totalResults = params.api.paginationGetRowCount();
  }

  onGridReady(params: any) {
   // this.gridOptions.api.sizeColumnsToFit();
    this.gridOptions.suppressNoRowsOverlay = true;
    this.gridApiActive = params.api;
   
    this.gridApiActive.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {      
      this.gridApiActive.showNoRowsOverlay();
    }
    else {
      this.setDomLayouts();
      this.gridApiActive.hideOverlay();
    }
  }

  // autoSizeAll(skipHeader: boolean | undefined) {
  //   const allColumnIds: any[] = [];
  //   this.gridOptions.columnApi?.getAllColumns()?.forEach((column) => {
  //     allColumnIds.push(column.getId());
  //   });
  // }
  
  OnFilterBoxChanged() {
    if (this.SearchText != "") {
      localStorage.setItem("IsChanged", 'true');
    }
    else {
      localStorage.setItem("IsChanged", 'false');
    }
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        node.data['action'] = 1;
      }
    });

    this.gridApiActive.setQuickFilter(this.SearchText);
    this.disabled = true;
    this.gridApiActive.refreshCells({ force: true });

    if (this.gridApiActive.getDisplayedRowCount() == 0) {     
      this.gridApiActive.showNoRowsOverlay();
    }
    else {
      this.gridApiActive.hideOverlay();
    }
    this.setDomLayouts();
  }

  ResetSearch() {
    this.gridApiActive.setQuickFilter(null);
    this.SearchText = '';
  }

  dateFormatter(data) {
    return data.value ? data.value.replace('T', ' ').replace('Z', '') : '';
  }

  currencyFormatter(params: any) {
    return '$' + params.value.toFixed(2);
  }
  onRefreshButtonClick() {
    const options = {
      title: "Confirm!",
      message: "Unsaved actions will get reset, continue with refresh?",
      cancelText: "No",
      confirmText: "Yes"
    };
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {       
        this.ResetSearch();
        sessionStorage.setItem('batchrejects','true');
        this.router.navigate([Constant.BASE_PATH]);
        this.showRefreshButton = false;
      }
    });
  }
  setDomLayouts() {
    let paginationSize = this.gridApiActive.paginationGetPageSize();
    let currentPageNum = this.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = this.gridApiActive.getDisplayedRowCount();

    const startResult = currentPageNum * paginationSize;
    const endResult = Math.min(
      startResult + paginationSize - 1,
      totalRowsCount
    );
    if (endResult - startResult + 1 >= this.paginationPageSize) {
      this.style = {
        height: "520px"
      };
      this.gridApiActive.setGridOption("domLayout", "normal");
    } else {
      this.style = {
      height: "auto"
    };
      this.gridApiActive.setGridOption("domLayout", "autoHeight");
    }
  }

  connectHub() {
    this.disconnectHub();
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.signalrNotificationEndpoint)
        .withAutomaticReconnect()
        .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.on("NotifyNewBatchTxnRejectsTab", (response) => {
        if(response == this.batchtxnRejects.batchRejectId.toString() && !this.showRefreshButton)
          this.showRefreshButton = true;
      });

      this.connection
        .start().then(function () {
          console.info("connected to signalr...")
        })
        .catch(err => console.error(err));
    }
  }

  disconnectHub() {
    if (this.connection) {
      this.connection.stop();
      this.connection = null;
    }
  }

  ngOnDestroy(): void {
    this.disconnectHub();
  }
}
