import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick
} from "@angular/core/testing";

import { BatchNewtxnRejectsComponent } from "./batch-new-txn-rejects.component";
import { BatchtxnRejects } from "../shared/models/batch-new-txn-rejects.model";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { DebugElement } from "@angular/core";
import { of } from "rxjs";
import { throwError } from 'rxjs';
import { AgGridModule } from "ag-grid-angular";
import { ConfigurationService } from "../shared/services/configuration.service";
import { BatchQueuedtxnservice } from "../shared/services/batch-queued-txn-rejects";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { AppConfig } from "../shared/models/app-config";
import { ConstantsUnitTest } from "../constant.unit.test";
import { Router } from "@angular/router";
import { Constants } from "../Constants";
import * as signalR from '@microsoft/signalr';
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";
describe("BatchTxnRejects1Component", () => {
  let component: BatchNewtxnRejectsComponent;
  let fixture: ComponentFixture<BatchNewtxnRejectsComponent>;
  let el: DebugElement;
  let httpTestingController: HttpTestingController;
  let mockHubConnection: jasmine.SpyObj<signalR.HubConnection>;

  // Define the config property ONCE here to avoid TypeError
  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["configData"]
  );
  Object.defineProperty(mockConfigurationService, 'config', {
    get: () => {
      return {
        DefaultGridPageSizeforBatchTxnRejects: 10,
        daysToAct: 10
      };
    },
    configurable: true
  });
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const mockRouter = {
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };
  let apiReponse: BatchtxnRejects = {
    batchRejectId: 16,
    originalBatchNumber: "102030",
    merchantNumber: "650000012036045",
    merchantName: "ANTHONY JACKSON",
    batchAmount: "200",
    batchCloseDateUTC: "2023-01-12T08:22:26.047",
    status: "New",
    transactions: [
      {
        batchTransactionRejectId: 698707,
        batchRejectId: 16,
        status: "New",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-12T08:22:26.05",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 1,
        daysToAct: 0,
        authCode: "02649Z",
        expDate: "2022-09-23T16:19:53",
        rejectReasons: ["Merchant refund threshold limit exceeded"]
      },
      {
        batchTransactionRejectId: 698734,
        batchRejectId: 16,
        status: "New",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-16T07:52:21.117",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 1,
        daysToAct: 0,
        authCode: "02649Z",
        expDate: "2022-09-23T16:19:53",
        rejectReasons: ["Merchant refund threshold limit exceeded"]
      },
      {
        batchTransactionRejectId: 698735,
        batchRejectId: 16,
        status: "Queued",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-16T07:52:32.22",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 1,
        daysToAct: 0,
        authCode: "02649Z",
        expDate: "2022-09-23T16:19:53",
        rejectReasons: [
          "Merchant refund threshold limit exceeded",
          "Suspected fraudulent BIN",
          "Batch refund threshold limit exceeded - PIN Debit transactions excluded"
        ]
      }
    ]
  };
  const bodytranscationsAction = {
    batchRejectId: 16,
    batchTransactionsStatus: [
      { batchTransactionRejectId: 698707, newStatus: "3" },
      { batchTransactionRejectId: 698734, newStatus: "3" },
      { batchTransactionRejectId: 698735, newStatus: "3" }
    ],
    userName: "Nikhil.Akole"
  };
  const transcationsActionResponse = {
    batchTransactionRejectUpdateStatuses: [
      {
        batchTransactionRejectId: 698707,
        updateStatus: "Success",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698734,
        updateStatus: "Success",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698735,
        updateStatus: "Success",
        statusCode: "200"
      }
    ]
  };
  const transcationsActionResponseTwoFailed = {
    batchTransactionRejectUpdateStatuses: [
      {
        batchTransactionRejectId: 698707,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698734,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698735,
        updateStatus: "Success",
        statusCode: "200"
      }
    ]
  };
  const transcationsActionResponseAllFailed = {
    batchTransactionRejectUpdateStatuses: [
      {
        batchTransactionRejectId: 698707,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698734,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698735,
        updateStatus: "Failed",
        statusCode: "200"
      }
    ]
  };

  beforeEach(async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    mockHubConnection = jasmine.createSpyObj('HubConnection', ['start', 'stop', 'on']);
    // Ensure .start always returns a Promise to avoid TypeError on .then
    mockHubConnection.start.and.returnValue(Promise.resolve());



    // Mock the builder chain using prototype spies
    spyOn(signalR.HubConnectionBuilder.prototype, 'withUrl').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'withAutomaticReconnect').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'configureLogging').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'build').and.returnValue(mockHubConnection);
    await TestBed.configureTestingModule({
    declarations: [BatchNewtxnRejectsComponent],
    imports: [AgGridModule],
    providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        BatchQueuedtxnservice,
        {
            provide: LoadingDialogService,
            useValue: mockLoadingDialogService
        },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        { provide: Router, useValue: mockRouter },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
  });
  beforeEach(() => {
    localStorage.setItem(Constants.batchRejectIdforNewDrillDown, "16");
    fixture = TestBed.createComponent(BatchNewtxnRejectsComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    el = fixture.debugElement;

    // mockAppConfig.AppConfig.and.returnValue(of(config))
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it(`should have config paginationPageSize be 15`, () => {
    localStorage.setItem("IsChanged", "true");
    component.config.defaultGridPageSize = 15;
    var event = { preventDefault: jasmine.createSpy() };
    component.beforeunloadHandler(event);
    localStorage.removeItem("IsChanged");
    component.config.daysToAct = 10;
    expect(component.daysToAct).toEqual(10);
    expect(component.paginationPageSize).toEqual(10);
  });
  it(`should have called changeRowColor`, () => {
    let params = {
      data: {
        daysToAct: 10,
        status: "New"
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color.backgroundColor).toEqual('#ffe6e6' );
  });
  it(`should changeRowColor and backgroundColor`, () => {
    let params = {
      data: {
        daysToAct: 10,
        status: "Deleted"
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color["background-color"]).toEqual("#dee2e6");
  });
  it('should return { "background-color": "#dee2e6" } from changeRowColor when daysToAct <= context.daysToAct and status is not "New"', () => {
    const params = {
      data: {
        daysToAct: 10,
        status: 'Queued'
      },
      context: {
        daysToAct: 5
      }
    };
    const result = component.changeRowColor(params);
    expect(result).toEqual({ 'background-color': '#dee2e6' });
  });
  it(`should be return null from changeRowColor`, () => {
    let params = {
      data: {
        status: "New"
      },
      context: {}
    };
    let color = component.changeRowColor(params);
    expect(color).toEqual(null);
  });
  it("should be No data ", async () => {
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.showRefreshButton).toBeFalse();
  });

  it("should called fetchData ", async () => {
    localStorage.setItem(Constants.batchRejectIdforNewDrillDown, "16");
    const req = httpTestingController.expectOne(
      "https://localhost:7247/BatchTransactionRejects?batchRejectId=16"
    );
    req.flush(apiReponse); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(3);
  });
  it('should handle error in fetchData() error block', () => {
    spyOn(component['batchtxnRejectsService'], 'getBatchtxnRejects').and.returnValue(throwError(() => ({ error: 'Some error' })));
    component.fetchData();
    expect(component.displayMerchantData).toBe(true);
    expect(component.showErrMsg).toBe(true);
    expect(component.message).toBe('Some error');
  });
  it("should be called resetPaginationSelection ", async () => {
    let apiResponsePageChange = JSON.parse(JSON.stringify(apiReponse));
    for (let i = 0; i < 15; i++) {
      apiResponsePageChange.transactions.push(
        apiResponsePageChange.transactions[0]
      );
    }
    component.transactions = apiResponsePageChange.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(0);
    component.gridApiActive.paginationGoToNextPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(1);
    expect(component.gridApiActive.paginationGetTotalPages()).toEqual(2);
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(18);
    expect(component.showRefreshButton).toEqual(false);
  });
  it("should be called onPageSizeChanged ", async () => {
    let e = {
      value: 20
    };
    component.batchtxnRejects = apiReponse;
    component.transactions = [
      ...apiReponse.transactions,
      ...apiReponse.transactions,
      ...apiReponse.transactions,
      ...apiReponse.transactions
    ];
    component.displayMerchantData = true;

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.onPageSizeChanged(e);

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(12);
  });
  it("should be All transcations successfully update ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    component.configService.configData.username = "Nikhil.Akole";

    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchTransactionRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponse);
    expect(component.message).toEqual(
      "3/3 records were processed successfully."
    );
  });
  it("should be some transcations successfully update ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchTransactionRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseTwoFailed);
    expect(component.message).toEqual(
      "2/3 records were not processed as another user has already worked on the same records."
    );
  });
  it("should be All transcations failed update ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchTransactionRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseAllFailed);
    expect(component.message).toEqual("Transaction(s) update failed.");
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should be transcations failed ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component.onSubmit();
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should getDisplayedRowCount be 2 after SearchText ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "102030";
    jasmine.clock().install();
    component.OnFilterBoxChanged();
    jasmine.clock().tick(500);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(3);
    jasmine.clock().uninstall();
  });
  it("should getDisplayedRowCount be 0 after SearchText ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    // Set a search text that should yield 0 results
    component.SearchText = "650000009987129";
    component.OnFilterBoxChanged();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    // Assert that no rows are displayed
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(0);
    // Assert that the overlay message is correct
    /*expect(component.gridOptions.overlayNoRowsTemplate).toEqual(
      '<span style="color:black;font-size:15px;height:35px;margin-top: 1%;">No records to display.</span>'
    );*/
    // Additional assertion: showRefreshButton should be false when no data
    expect(component.showRefreshButton).toBeFalse();
  });
  it("should getDisplayedRowCount be 5 after SearchText empty", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "";
    component.OnFilterBoxChanged();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(3);
  });
  it("should be disabled  ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeFalse();
  });
  it("should be !disabled  ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    apiReponse.transactions[0].action = 3;
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeFalse();
  });
  it("should be parentMethod return disabled  ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    localStorage.setItem("IsChanged", "true");
    await component.parentMethod();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeFalse();
  });
  it("should be parentMethod return   ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 1;
    }
    localStorage.setItem("IsChanged", "true");
    localStorage.setItem("IsNotAllSelected", "true");
    await component.parentMethod();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });

  it(
    `should have called FadeOutSuccessMsg`,
    fakeAsync(() => {
      component.FadeOutSuccessMsg();
      tick(10000);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.showMsg).toEqual(false);
      });
    })
  );
  it("should have called onRefreshButtonClick", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    component.onRefreshButtonClick();
    expect(component.showRefreshButton).toBeFalse();
  });
  it('should format date correctly in dateFormatter', () => {
    expect(component.dateFormatter({ value: '2022-11-02T16:30:16Z' })).toBe('2022-11-02 16:30:16');
    expect(component.dateFormatter({ value: '2022-11-02T16:30:16' })).toBe('2022-11-02 16:30:16');
    expect(component.dateFormatter({ value: null })).toBe('');
    expect(component.dateFormatter({})).toBe('');
    expect(component.dateFormatter({ value: undefined })).toBe('');
    expect(component.dateFormatter({ value: '' })).toBe('');
    expect(component.dateFormatter({ value: null })).not.toBeNull();
    expect(component.dateFormatter({})).not.toBeNull();
  });
  it('should set paginationPageSize to totalResults if totalResults < paginationPageSize in onPageSizeChanged', () => {
    component.paginationPageSize = 20;
    component.totalResults = 10;
    const e = { value: 10 };
    // gridApiActive and other dependencies can be stubbed if needed
    component.gridApiActive = {
      paginationSetPageSize: jasmine.createSpy('paginationSetPageSize'),
      refreshCells: jasmine.createSpy('refreshCells'),
      getDisplayedRowCount: () => 10
    } as any;
    spyOn(component, 'setDomLayouts');
    spyOn(component, 'resetPaginationSelection');
    component.onPageSizeChanged(e);
    expect(component.paginationPageSize).toBe(10);
    expect(component.gridApiActive.paginationSetPageSize).toHaveBeenCalledWith(10);
    expect(component.setDomLayouts).toHaveBeenCalled();
    expect(component.resetPaginationSelection).toHaveBeenCalledWith(component);
  });
  it('should set totalResults to the value returned by params.api.paginationGetRowCount in countDisplayedRows', () => {
    const mockApi = {
      paginationGetRowCount: () => 42
    };
    const params = { api: mockApi };
    component.totalResults = 0;
    component.countDisplayedRows(params);
    expect(component.totalResults).toBe(42);
  });
  it('should call builder chain and connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyNewBatchTxnRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
  }));

  it('should set showRefreshButton to true when NotifyNewBatchTxnRejectsTab event is received', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    let notifyHandler: ((response: any) => void) | undefined;
    mockHubConnection.on.and.callFake((event, handler) => {
      if (event === 'NotifyNewBatchTxnRejectsTab') {
        notifyHandler = handler;
      }
    });
    component.showRefreshButton = false;
    component.batchtxnRejects = apiReponse;
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyNewBatchTxnRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    // Act: simulate event received with value 16
    if (notifyHandler) {
      notifyHandler(16);
    }
    // Assert
    expect(component.showRefreshButton).toBeTrue();
  }));
  it('should call catch and log error if SignalR connection fails in connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    const error = new Error('Connection failed');
    spyOn(console, 'error');
    mockHubConnection.start.and.returnValue(Promise.reject(error));
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyNewBatchTxnRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    expect(console.error).toHaveBeenCalledWith(error);
  }));

  it('should log error and redirect to logout if dialogSvc.confirmed emits error in onSubmit', () => {
    // Arrange: get the dialog service from TestBed
    const dialogSvc = TestBed.inject(LoadingDialogService) as jasmine.SpyObj<LoadingDialogService>;
    dialogSvc.openDialog.and.stub();
    dialogSvc.confirmed.and.returnValue({
      subscribe: (success, error) => {
        if (error) error('some error reason');
      }
    } as any);
    spyOn(console, 'log');
    // Act
    component.onSubmit();
    // Assert
    expect(console.log).toHaveBeenCalledWith('Dismissed some error reason');
    expect(console.log).toHaveBeenCalledWith('redirec to log out');
  });
  it('should call catch block and log error in fetchData when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    spyOn(component['batchtxnRejectsService'], 'getBatchtxnRejects').and.returnValue({
      subscribe: (success) => {
        success(apiReponse);
      }
    } as any);
    spyOn(localStorage, 'getItem').and.returnValue('16');
    spyOn(localStorage, 'removeItem');
    spyOn(apiReponse.transactions, 'forEach').and.callFake(() => { throw errorObj; });
    //spyOn(console, 'log');

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchData();
    // Assert
    expect(console.log).toHaveBeenCalledWith('error');
    expect(console.log).toHaveBeenCalledWith(errorObj);
  });
  it('should call catch block and log error in fetchData when undefined throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    spyOn(component['batchtxnRejectsService'], 'getBatchtxnRejects').and.returnValue({
      subscribe: (success) => {
        success(undefined);
      }
    } as any);
    spyOn(localStorage, 'getItem').and.returnValue('16');
    spyOn(localStorage, 'removeItem');
    spyOn(apiReponse.transactions, 'forEach').and.callFake(() => { throw errorObj; });
    //spyOn(console, 'log');

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchData();
    // Assert
    expect(console.log).toHaveBeenCalledWith('error');
    expect(console.log).toHaveBeenCalledWith(jasmine.any(Error));
  });
});
