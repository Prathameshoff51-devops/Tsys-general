import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatTab,
  MatTabChangeEvent,
  MatTabGroup,
  MatTabHeader,
} from '@angular/material/tabs';
import { IndividualRefundsComponent } from '../individual-refunds/individual-refunds.component';
import { BulkRefundsComponent } from '../bulk-refunds/bulk-refunds.component';
import { QueuedTxnRefundsComponent } from '../queued-txn-refunds/queued-txn-refunds.component';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { QueuedBulkRefundsComponent } from '../queued-bulk-refunds/queued-bulk-refunds.component';
import { Router } from '@angular/router';
import { Constants } from '../Constants';

@Component({
  selector: 'app-riskrejects',
  templateUrl: './riskrejects.component.html',
  styleUrls: ['./riskrejects.component.css'],
})
export class RiskrejectsComponent implements OnInit {
  @ViewChild(IndividualRefundsComponent)
  private individualRefundsComponent: IndividualRefundsComponent;
  @ViewChild(QueuedTxnRefundsComponent)
  private queuedTxnRefundsComponent: QueuedTxnRefundsComponent;
  @ViewChild(BulkRefundsComponent)
  private bulkRefundComponent: BulkRefundsComponent;
  @ViewChild(QueuedBulkRefundsComponent)
  private queuedBulkRefundsComponent: QueuedBulkRefundsComponent;
  @ViewChild(MatTabGroup) tabs?: MatTabGroup;

  isSuccess: boolean = true;
  constructor(
    private _dialogSvc: LoadingDialogService,
    private router: Router
  ) {}
  private currentTabIndex = 0;
  //private router: Router;

  ngAfterViewInit() {
    this.registerTabClick();
  }
  ngOnInit() {}
  registerTabClick(): void {
    // Get the handler reference
    const handleTabClick = this.tabs._handleClick;
    this.tabs._handleClick = (tab, header, index) => {
      // Get tab content reference for the current Tab -> currentTabIndex
      // since index here is already the "new" tab index
      const tabContent = this.getTabContentElement(this.currentTabIndex);
      // If you want to prevent the user to navigate to the new tab,
      // you can avoid invoking the 'apply' method below
      if (localStorage.getItem('IsChanged') != 'true') {
        handleTabClick.apply(this.tabs, [tab, header, index]);
      } else {
        const options = {
          title: 'Leave this page?',
          message: 'Changes you made may not be saved.',
          cancelText: 'Stay',
          confirmText: 'Leave',
        };
        this.isSuccess = true;
        this._dialogSvc.openDialog(options);
        this._dialogSvc.confirmed().subscribe((confirmed: any) => {
          if (confirmed) {
            handleTabClick.apply(this.tabs, [tab, header, index]);
            localStorage.setItem('IsChanged', 'false');
          } else {
            localStorage.setItem('IsChanged', 'true');
          }
        });
      } // We update the currentIndex, as we need it again when
      // another tab is clicked
      this.currentTabIndex = index;
    };
  }
  // Returns the <mat-tab-body-content> with the tab content scroll
  // position given the target tab index
  private getTabContentElement(tabIndex: number) {
    return document.getElementsByClassName('mat-tab-body-content')[tabIndex];
  }
}
