import { CommonModule } from "@angular/common";
import { DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { MatTabGroup, MatTabsModule } from "@angular/material/tabs";
import { By } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { RiskrejectsComponent } from "./riskrejects.component";
import { NavigationEnd, Router } from "@angular/router";
import { of } from "rxjs";

describe("RiskrejectsComponent", () => {
  let component: RiskrejectsComponent;
  let fixture: ComponentFixture<RiskrejectsComponent>;
  let el: DebugElement;
  let compiled: any;
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MatTabsModule, CommonModule, BrowserAnimationsModule],
      declarations: [RiskrejectsComponent],
      providers: [
        {
          provide: LoadingDialogService,
          useValue: mockLoadingDialogService
        },
        MatTabGroup,
        { provide: Router, useValue: mockRouter },
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RiskrejectsComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    compiled = fixture.nativeElement;
    fixture.detectChanges();
  });

  it("should create", async () => {
    compiled = fixture.nativeElement;
    fixture.debugElement.queryAll(By.css(".mat-tab "));
    expect(component).toBeTruthy();
  });

  it('should call registerTabClick in ngAfterViewInit', () => {
    const spy = spyOn(component, 'registerTabClick');
    component.ngAfterViewInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should call handleTabClick when IsChanged is not true', () => {
    const originalHandleClick = jasmine.createSpy('_handleClick');
    const fakeTabs: any = { _handleClick: originalHandleClick };
    component['tabs'] = fakeTabs;
    spyOn(localStorage, 'getItem').and.returnValue('false');
    component['currentTabIndex'] = 0;
    component.registerTabClick();
    // The new _handleClick is not a spy, but should call the original spy
    expect(typeof fakeTabs._handleClick).toBe('function');
    fakeTabs._handleClick('tab', 'header', 1);
    expect(originalHandleClick).toHaveBeenCalledWith('tab', 'header', 1);
  });

  it('should open dialog and handle confirm true', () => {
    const fakeTabs: any = {
      _handleClick: jasmine.createSpy('_handleClick'),
    };
    component['tabs'] = fakeTabs;
    spyOn(localStorage, 'getItem').and.returnValue('true');
    const setItemSpy = spyOn(localStorage, 'setItem');
    mockLoadingDialogService.openDialog.and.callThrough();
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    component['currentTabIndex'] = 0;
    component.registerTabClick();
    fakeTabs._handleClick('tab', 'header', 1);
    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(setItemSpy).toHaveBeenCalledWith('IsChanged', 'false');
  });

  it('should open dialog and handle confirm false', () => {
    const fakeTabs: any = {
      _handleClick: jasmine.createSpy('_handleClick'),
    };
    component['tabs'] = fakeTabs;
    spyOn(localStorage, 'getItem').and.returnValue('true');
    const setItemSpy = spyOn(localStorage, 'setItem');
    mockLoadingDialogService.openDialog.and.callThrough();
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component['currentTabIndex'] = 0;
    component.registerTabClick();
    fakeTabs._handleClick('tab', 'header', 1);
    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(setItemSpy).toHaveBeenCalledWith('IsChanged', 'true');
  });

  it('should get tab content element', () => {
    const fakeDiv = document.createElement('div');
    const fakeCollection = {
      0: fakeDiv,
      length: 1,
      item: (index: number) => index === 0 ? fakeDiv : null,
      namedItem: () => null
    } as unknown as HTMLCollectionOf<Element>;
    spyOn(document, 'getElementsByClassName').and.returnValue(fakeCollection);
    const result = (component as any).getTabContentElement(0);
    expect(result).toBe(fakeDiv);
  });
});
