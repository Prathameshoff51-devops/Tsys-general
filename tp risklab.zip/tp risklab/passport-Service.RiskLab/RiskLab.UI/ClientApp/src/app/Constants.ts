export class Constants {
  public static errorPage: string = "secure/error";

  public static unauthorizedPage: string = "secure/unauthorized";
  public static landingPage: string = "secure";
  public static riskLabPage: string = "secure/risklab";
  public static maintenancePage: string = "secure/maintenance";
  public static merchantTxnPage: string = "secure/merchantrejectedtxns";
  public static loginPage: string = "";
  public static batchQueuedTxnRejectsPage: string = "secure/batchQueuedTxnRejects";
  public static batchNewTxnRejectsPage: string = "secure/batchNewTxnRejects";
  public static batchrejectsPage: string = "secure/batchrejects";
  public static batchRejectIdforNewDrillDown: string = "batchRejectIdforNewDrillDown";
  public static batchRejectIdforQueuedDrillDown: string = "batchRejectIdforQueuedDrillDown";
}
