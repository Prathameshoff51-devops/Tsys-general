import { ActivatedRoute, ParamMap, Params, Router } from '@angular/router';
import { BaseComponent } from '../shared/base.component';
import { MenuItem } from '../shared/models/menu-item.model';
import { DOCUMENT } from '@angular/common';
import {
  Component,
  HostListener,
  Inject,
  OnDestroy,
  OnInit,
} from '@angular/core';
import {
  GridApi,
  GridOptions,
  GridReadyEvent,
  PaginationChangedEvent,
} from 'ag-grid-community';
import { Observable } from 'rxjs';
import { Constant } from '../shared/constant';
import { RejectStatuses } from '../shared/enums';
import { Configuration } from '../shared/models/configuration.model';
import {
  IndividualRefund,
  TransactionAction,
  TransStatus,
  RejectsCount,
  Merchant,
  merchantRejects,
} from '../shared/models/individual-refund.model';
import { ConfigurationService } from '../shared/services/configuration.service';
import { IndividualRefundservice } from '../shared/services/individual-refund.service';
import { DropDownListRendererComponent } from '../ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { AlertService } from '../ui/service/alert.service';
@Component({
  selector: 'app-merchant-rejectedtxns',
  templateUrl: './merchant-rejectedtxns.component.html',
  styleUrls: ['./merchant-rejectedtxns.component.css'],
  providers: [IndividualRefundservice],
})
export class MerchantRejectedtxnsComponent implements OnInit, OnDestroy {
  panelOpenState = true;
  sequenceKey: number;
  merchantNumber: string = '';
  isReadOnly = true;
  isHidden = true;
  isDisabled = true;
  public gridOptions: GridOptions;
  config!: Configuration;
  public paginationPageSize = Constant.DefaultBackOfficeGridPageSize;
  public paginationNumberFormatter: any;
  public totalRecords: number | undefined;
  public transactionAction!: TransactionAction;
  merchanttxn: merchantRejects[] = null;
  merchant: Merchant = null;
  gridApiActive: GridApi;
  totalResults: any;
  rowIndex: any;
  displayMerchantData: boolean = false;
  showErrMsg: boolean = false;
  isSuccess: boolean = false;
  message: string;
  context: any;
  SearchText: any;
  configData: any;
  totalcnt: any;
  // gridApiActive: any;
  // rowData: any[];

  public overlayNoRowsTemplate;
  constructor(
    private individualRefundsService: IndividualRefundservice,
    @Inject(DOCUMENT) private document: Document,
    public configService: ConfigurationService,
    private _dialogSvc: AlertService
  ) {
    this.config = this.configService.config;
    if (this.config.defaultBackOfficeGridPageSize != undefined) {
      this.paginationPageSize = this.config.defaultBackOfficeGridPageSize;
    }

    this.gridApiActive = new GridApi();
    this.context = {
      componentParent: this,
    };

    this.gridOptions = {
      columnDefs: [
        {
          headerName: 'Fraud Service Suspension Date (UTC)',
          resizable: true,
          width: 250,
          field: 'businessDateUtc',
          valueFormatter: this.dateFormatter,
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Fraud Service Suspension Reason',
          width: 250,
          resizable: true,
          field: 'fraudRejectReasonCodes',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Suspension Type',
          resizable: true,
          width: 180,
          field: 'suspensionType',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Original Batch Number',
          resizable: true,
          width: 180,
          field: 'batchNumber',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Type',
          width: 160,
          resizable: true,
          field: 'txnTypeDescription',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Amount',
          resizable: true,
          width: 180,
          field: 'amount',
          sortable: true,
          valueFormatter: this.currencyFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Date (UTC)',
          resizable: true,
          width: 250,
          field: 'txnDateUtc',
          sortable: true,
          valueFormatter: this.dateFormatter,
          sort: 'asc',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Masked Card Number',
          resizable: true,
          width: 250,
          field: 'cardNumberMask',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Fraud Service Status',
          field: 'status',
          sortable: true,
          resizable: true,
          width: 240,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Status Date (UTC)',
          width: 260,
          resizable: true,
          field: 'statusDate',
          sortable: true,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
      ],
    };
    this.paginationNumberFormatter = function (params: any) {

      if (params.api.paginationProxy.bottomDisplayedRowIndex == -1)
        return 0;
      else
        return params.value.toLocaleString();
    };
    this.overlayNoRowsTemplate =
      '<span style="color:black;font-size:15px;height:20px; bottom:15px">No records to display.</span>';
  }
  ngOnDestroy(): void {
    sessionStorage.clear();
  }

  ngOnInit(): void {
    this.sequenceKey = Number(sessionStorage.getItem('SequenceKey'));
    if (this.sequenceKey == 0) {
      this.sequenceKey = null;
      this.merchantNumber = null;
    } else {
      this.fetchDataUsingSequenceKey(this.sequenceKey);
    }
    localStorage.setItem("IsChanged", 'false');
  }

  onPageSizeChanged() {
    if (this.totalResults < this.paginationPageSize) {
      this.paginationPageSize = this.totalResults;
    }

    this.gridApiActive.paginationSetPageSize(this.paginationPageSize);
    this.resetPaginationSelection(this);
  }

  countDisplayedRows(params) {
    this.totalResults = params.api.paginationGetRowCount();
  }

  onGridReady(params: any) {
    this.gridOptions.suppressNoRowsOverlay = true;
    this.gridApiActive = params.api;
    params.api.setDomLayout('autoHeight');
    this.gridApiActive.addEventListener('paginationChanged', (e) => {

      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {

      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }

    this.gridApiActive.sizeColumnsToFit();
  }
  dateFormatter(data) {
    return data.value ? data.value.replace('T', ' ').replace('Z', '') : '';
  }

  currencyFormatter(params: any) {
    return '$' + params.value.toFixed(2);
  }

  resetPaginationSelection = (self) => {
    //Deselect previously selected rows to reset selection
    self.gridApiActive.deselectAll();

    //Initialize pagination data
    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    //Calculate current page row indexes
    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount)
      currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage =
        i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.gridApiActive
        .getDisplayedRowAtIndex(i)
        .setRowSelectable(isWithinCurrentPage);
    }
  };

  onFirstDataRendered(params: GridReadyEvent) {
    params.api.paginationGoToPage(0);
  }

  fetchDataUsingSequenceKey(sequenceKey: Number) {
    this.individualRefundsService
      .getIndividualRefundTxnsByMerchantSequenceKey(this.sequenceKey)
      .subscribe(
        (res: Merchant) => {
          console.log(res);
          this.totalRecords = res?.merchantRejects.length;
          try {
            this.merchant = res;
            this.merchantNumber = res.merchantNumber;
            this.merchanttxn = res.merchantRejects;
            this.displayMerchantData = true;
          } catch (ex) {
            console.log('error:' + ex);
          }
        },
        (error) => {
          this.displayMerchantData = false;
          this.showErrMsg = true;
          this.message = error.error;
          this.fadeOutMessage();
          this.displayMerchantData = true;
          this.resetMerchanData();
        }
      );
  }

  fetchDataUsingMerchantNumber(merchantNumber: string) {
    this.individualRefundsService
      .getRejectsByMerchantNumber(merchantNumber)
      .subscribe(
        (res: Merchant) => {
          this.totalRecords = res?.merchantRejects.length;
          try {
            this.merchant = res;
            this.merchantNumber = res.merchantNumber;
            this.merchanttxn = res.merchantRejects;
            this.displayMerchantData = true;
          } catch (ex) {
            console.log('error:' + ex);
          }
        },
        (error) => {
          this.displayMerchantData = true;
          this.showErrMsg = true;
          this.message = error.error;
          this.fadeOutMessage();
          this.resetMerchanData();
          this.showNoRecordMessage();
        }
      );
  }

  getMerchantData(): void {
    this.hideErrorMessage();
    if (this.merchantNumber != null) {
      this.merchantNumber = this.merchantNumber.trim();
    }
    if (this.merchantNumber == null || this.merchantNumber === '') {
      this.validationAlert('Please enter the Merchant Number.');
    } else if (isNaN(+this.merchantNumber)) {
      this.validationAlert('Merchant Number can only contain numbers.');
    } else {
      this.fetchDataUsingMerchantNumber(this.merchantNumber.trim());
    }
  }

  validationAlert(message: string) {
    const options = {
      title: 'Alert!',
      message: message,
      okText: 'OK',
    };
    this._dialogSvc.openDialog(options);
  }

  fadeOutMessage() {
    setTimeout(() => {
      this.showErrMsg = false;
      this.message = '';
    }, 5000);
  }

  hideErrorMessage() {
    this.showErrMsg = false;
    this.message = '';
  }

  resetMerchanData() {
    this.merchanttxn = null;
    this.merchant = null;
  }

  showNoRecordMessage() {
    const rowData: any[] = [];
    this.gridApiActive.forEachNode(function (node) {
      rowData.push(node.data);
    });
    const res = this.gridApiActive.applyTransaction({
      remove: rowData,

    })!;

    this.gridApiActive.showNoRowsOverlay();

  }
}
