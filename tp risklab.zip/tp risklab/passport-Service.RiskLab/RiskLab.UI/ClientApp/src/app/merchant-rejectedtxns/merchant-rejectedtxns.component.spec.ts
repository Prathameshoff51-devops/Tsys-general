import {
  ComponentFixture,
  TestBed,
  //async,
  fakeAsync,
  tick
} from "@angular/core/testing";

import { MerchantRejectedtxnsComponent } from "./merchant-rejectedtxns.component";
import { ConfigurationService } from "../shared/services/configuration.service";
import { AlertService } from "../ui/service/alert.service";
import { AppConfig } from "../shared/models/app-config";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { BaseApiService } from "../shared/services/baseapi.service";
import { DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { Merchant } from "../shared/models/individual-refund.model";
import { AgGridModule } from "ag-grid-angular";
import { of } from "rxjs";
import { ConstantsUnitTest } from "../constant.unit.test";
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("MerchantRejectedtxnsComponent", () => {
  let component: MerchantRejectedtxnsComponent;
  let fixture: ComponentFixture<MerchantRejectedtxnsComponent>;
  let el: DebugElement;
  let httpTestingController: HttpTestingController;

  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["config"]
  );

  const mockAlertService = jasmine.createSpyObj("AlertService", ["openDialog"]);

  const mockAppConfig = jasmine.createSpyObj("AppConfig", [
    "AppConfig",
    "OktaSettings",
    "config"
  ]);

  let apiResponse: Merchant = {
    merchantNumber: "650000011921668",
    merchantName: "DEES QUIK MART",
    merchantRejects: [
      {
        id: 278,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-10T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],

        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      },
      {
        id: 279,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-11T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      },
      {
        id: 280,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-12T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      },
      {
        id: 281,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-13T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      }
    ]
  };
  let apiResponsePageChange: Merchant = {
    merchantNumber: "650000011921668",
    merchantName: "DEES QUIK MART",
    merchantRejects: [
      {
        id: 278,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-10T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      },
      {
        id: 279,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-11T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      },
      {
        id: 280,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-12T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      },
      {
        id: 281,
        businessDateUtc: "2022-10-13T12:11:02.21",
        batchNumber: "000475",
        txnTypeDescription: "Refund",
        amount: 63.49,
        txnDateUtc: "2022-08-13T20:03:26",
        cardNumberMask: "523782******0701",
        fraudRejectReasonCodes: ["Risk Reject"],
        status: "Rejected - Will Not Be Funded",
        suspensionType : "Batch"
      }
    ]
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
    declarations: [MerchantRejectedtxnsComponent],
    imports: [AgGridModule],
    providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        {
            provide: AlertService,
            useValue: mockAlertService
        },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
  });

  beforeEach(async () => {
    fixture = TestBed.createComponent(MerchantRejectedtxnsComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    component.ngOnInit();
    fixture.detectChanges();
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it(`should have as title 'Merchant Search'`, () => {
    let app = el.nativeElement;
    expect(app.querySelector("mat-panel-title").textContent).toContain(
      "Merchant Search"
    );
  });
  it(`should have disabled button`, () => {
    let button = el.query(By.css(".searchButton"));
    expect(button.nativeElement.disabled).toBeTrue();
  });

  it(`should have called AlertService`, () => {
    component.getMerchantData();

    expect(mockAlertService.openDialog).toHaveBeenCalled();
  });
  it(`should have called AlertService if input not in number format`, () => {
    component.merchantNumber = "Xyz";
    component.getMerchantData();
    expect(mockAlertService.openDialog).toHaveBeenCalled();
  });
  it(`should have called ngOnDestroy`, () => {
    sessionStorage.setItem("SequenceKey", "650000004051668");
    component.ngOnDestroy();
    let sequenceKey = Number(sessionStorage.getItem("SequenceKey"));
    expect(sequenceKey).toEqual(0);
  });
  it(`should have called fetchDataUsingSequenceKey`, () => {
    const fun = spyOn(component, "fetchDataUsingSequenceKey");
    sessionStorage.setItem("SequenceKey", "650000004051668");
    component.ngOnInit();
    expect(component.fetchDataUsingSequenceKey).toHaveBeenCalled();
  });
  it(`should be null merchantNumber and sequenceKey after ngOnInit `, () => {
    component.ngOnInit();
    expect(component.merchantNumber).toEqual(null);
    expect(component.sequenceKey).toEqual(null);
  });
  it(`should have called fetchDataUsingSequenceKey api`, async () => {
    sessionStorage.setItem("SequenceKey", "650000004051668");
    component.ngOnInit();
    const req = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?sequenceKey=650000004051668"
    );
    req.flush(apiResponse); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(4);
  });
  it(`should have called fetchDataUsingSequenceKey if error in api`, async () => {
    mockAppConfig.AppConfig.and.returnValue(of(ConstantsUnitTest.config));
    // (config as AppConfig)
    sessionStorage.setItem("SequenceKey", "6500000040516");
    component.ngOnInit();
    const req = httpTestingController.expectOne(
      "https://localhost:7247/FraudService?sequenceKey=6500000040516"
    );
    req.flush(
      "Rejected transactions not found for the merchant number 6500000040516",
      { status: 404, statusText: "Not Found" }
    ); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.displayMerchantData).toBeTrue();
  });
  it(`should have called fetchDataUsingMerchantNumber function`, () => {
    const fun = spyOn(component, "fetchDataUsingMerchantNumber");
    component.merchantNumber = "650000004051668";
    component.getMerchantData();
    expect(component.fetchDataUsingMerchantNumber).toHaveBeenCalledOnceWith(
      component.merchantNumber
    );
  });
  it("should have called fetchDataUsingMerchantNumber api  ", async () => {
    component.merchantNumber = "650000004051668";
    component.getMerchantData();
    const req = httpTestingController.expectOne(
      "https://localhost:7247/FraudService/GetRejectsByMerchantNumber?merchantNumber=650000004051668"
    );
    req.flush(apiResponse); // Respond with empty search results

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(4);
  });

  it(
    `should have called fadeOutMessage`,
    fakeAsync(() => {
      component.fadeOutMessage();
      tick(5000);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(component.showErrMsg).toEqual(false);
        expect(component.message).toEqual("");
      });
    })
  );

  it(`should have called dateFormatter function `, () => {
    const data = { value: "2022-11-02T16:30:16" };
    const dateFormatter = component.dateFormatter(data);
    expect(dateFormatter).toEqual("2022-11-02 16:30:16");
  });
  it(`should have paginationPageSize be 15`, () => {
    expect(component.paginationPageSize).toEqual(15);
  });
  it(`should have config paginationPageSize be 15`, () => {
    component.config.defaultBackOfficeGridPageSize = 15;
    expect(component.paginationPageSize).toEqual(15);
  });
  it(`should have resetMerchanData called `, () => {
    component.resetMerchanData();
    expect(component.merchanttxn).toEqual(null);
    expect(component.merchant).toEqual(null);
  });
  it('should set totalResults in countDisplayedRows', () => {
    const params = { api: { paginationGetRowCount: () => 7 } };
    component.countDisplayedRows(params);
    expect(component.totalResults).toBe(7);
  });
  it("should grid API is not available until  `detectChanges`", () => {
    // Flush any pending HTTP requests to avoid afterEach errors
    const reqs = httpTestingController.match(() => true);
    reqs.forEach(req => req.flush({}));
    expect(component.gridOptions.api).not.toBeTruthy();
  });
  it("should DisplayedRowCount be 4 ", async () => {
    component.merchant = apiResponse;
    component.merchantNumber = apiResponse.merchantNumber;
    component.merchanttxn = apiResponse.merchantRejects;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(4);
  });
  it("should be called resetPaginationSelection ", async () => {
    for (let i = 0; i < 15; i++) {
      apiResponsePageChange.merchantRejects.push(
        apiResponsePageChange.merchantRejects[0]
      );
    }
    component.merchant = apiResponsePageChange;
    component.merchantNumber = apiResponsePageChange.merchantNumber;
    component.merchanttxn = apiResponsePageChange.merchantRejects;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(0);
    component.gridApiActive.paginationGoToNextPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(1);
    expect(component.gridApiActive.paginationGetTotalPages()).toEqual(2);
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(19);
  });
  it('should call onPageSizeChanged and set paginationPageSize correctly', () => {
    component.totalResults = 5;
    component.paginationPageSize = 10;
    // Mock gridApiActive
    component.gridApiActive = {
      paginationSetPageSize: jasmine.createSpy('paginationSetPageSize'),
    } as any;
    // Mock resetPaginationSelection
    const resetSpy = spyOn(component, 'resetPaginationSelection');
    component.onPageSizeChanged();
    expect(component.paginationPageSize).toBe(5);
    expect(component.gridApiActive.paginationSetPageSize).toHaveBeenCalledWith(5);
    expect(resetSpy).toHaveBeenCalledWith(component);
  });

  it('should call showNoRecordMessage and remove all rows, then show overlay', () => {
    // Mock gridApiActive
    const rowData = [
      { id: 1 },
      { id: 2 }
    ];
    const forEachNodeSpy = jasmine.createSpy('forEachNode').and.callFake((cb) => {
      rowData.forEach((d) => cb({ data: d }));
    });
    const applyTransactionSpy = jasmine.createSpy('applyTransaction').and.returnValue({});
    const showNoRowsOverlaySpy = jasmine.createSpy('showNoRowsOverlay');
    component.gridApiActive = {
      forEachNode: forEachNodeSpy,
      applyTransaction: applyTransactionSpy,
      showNoRowsOverlay: showNoRowsOverlaySpy
    } as any;
    component.showNoRecordMessage();
    expect(forEachNodeSpy).toHaveBeenCalled();
    expect(applyTransactionSpy).toHaveBeenCalledWith({ remove: rowData });
    expect(showNoRowsOverlaySpy).toHaveBeenCalled();
  });

  it('should handle error in fetchDataUsingMerchantNumber and show error message', () => {
    // Arrange
    const errorResponse = { error: 'Some error occurred' };
    // Spy on fadeOutMessage, resetMerchanData, showNoRecordMessage
    const fadeOutSpy = spyOn(component, 'fadeOutMessage');
    const resetSpy = spyOn(component, 'resetMerchanData');
    const showNoRecordSpy = spyOn(component, 'showNoRecordMessage');
    // Mock service to return error
    spyOn(component['individualRefundsService'], 'getRejectsByMerchantNumber').and.returnValue({
      subscribe: (success, error) => error(errorResponse)
    } as any);
    // Act
    component.fetchDataUsingMerchantNumber('123456');
    // Assert
    expect(component.displayMerchantData).toBeTrue();
    expect(component.showErrMsg).toBeTrue();
    expect(component.message).toBe('Some error occurred');
    expect(fadeOutSpy).toHaveBeenCalled();
    expect(resetSpy).toHaveBeenCalled();
    expect(showNoRecordSpy).toHaveBeenCalled();
  });
  it('should call resetPaginationSelection and set row selectable for current page', () => {
    // Arrange
    const paginationSize = 2;
    const currentPageNum = 1;
    const totalRowsCount = 5;
    const mockRows = [
      { setRowSelectable: jasmine.createSpy('setRowSelectable') },
      { setRowSelectable: jasmine.createSpy('setRowSelectable') },
      { setRowSelectable: jasmine.createSpy('setRowSelectable') },
      { setRowSelectable: jasmine.createSpy('setRowSelectable') },
      { setRowSelectable: jasmine.createSpy('setRowSelectable') }
    ];
    const gridApiActive = {
      deselectAll: jasmine.createSpy('deselectAll'),
      paginationGetPageSize: () => paginationSize,
      paginationGetCurrentPage: () => currentPageNum,
      getDisplayedRowCount: () => totalRowsCount,
      getDisplayedRowAtIndex: (i) => mockRows[i]
    };
    component.gridApiActive = gridApiActive as any;
    // Act
    component.resetPaginationSelection(component);
    // Assert
    expect(gridApiActive.deselectAll).toHaveBeenCalled();
    // Only rows 2 and 3 (indexes 2,3) should be selectable for page 1
    for (let i = 0; i < totalRowsCount; i++) {
      const isWithinCurrentPage = i >= 2 && i < 4;
      expect(mockRows[i].setRowSelectable).toHaveBeenCalledWith(isWithinCurrentPage);
    }
  });
  it('should call catch block and log error in fetchDataUsingSequenceKey when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    Object.defineProperty(component, 'merchant', {
      set() {
        throw errorObj;
      },get() {
        return [];
      }
    });
    
    spyOn(component['individualRefundsService'], 'getIndividualRefundTxnsByMerchantSequenceKey').and.returnValue(of(apiResponse));

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchDataUsingSequenceKey(123456);
    // Assert
    expect(console.log).toHaveBeenCalledWith(apiResponse);
    expect(console.log).toHaveBeenCalledWith('error:' + errorObj);
  });
  it('should call catch block and log error in fetchDataUsingMerchantNumber when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    Object.defineProperty(component, 'merchant', {
      set() {
        throw errorObj;
      },get() {
        return [];
      }
    });
    
    spyOn(component['individualRefundsService'], 'getRejectsByMerchantNumber').and.returnValue(of(apiResponse));

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchDataUsingMerchantNumber('123456');
    // Assert
    expect(console.log).toHaveBeenCalledWith('error:' + errorObj);
  });
    it('should call catch block and log error in fetchDataUsingSequenceKey when undefined throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    Object.defineProperty(component, 'merchant', {
      set() {
        throw errorObj;
      },get() {
        return [];
      }
    });
    
    spyOn(component['individualRefundsService'], 'getIndividualRefundTxnsByMerchantSequenceKey').and.returnValue(of(undefined));

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchDataUsingSequenceKey(123456);
    // Assert
    expect(console.log).toHaveBeenCalledWith(undefined);
    expect(console.log).toHaveBeenCalledWith('error:' + errorObj);
  });
  it('should call catch block and log error in fetchDataUsingMerchantNumber when undefined throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    Object.defineProperty(component, 'merchant', {
      set() {
        throw errorObj;
      },get() {
        return [];
      }
    });
    
    spyOn(component['individualRefundsService'], 'getRejectsByMerchantNumber').and.returnValue(of(undefined));

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchDataUsingMerchantNumber('123456');
    // Assert
    expect(console.log).toHaveBeenCalledWith('error:' + errorObj);
  });
  it('should set currentPageRowLastIndex to totalRowsCount if it exceeds in resetPaginationSelection', () => {
    // Arrange
    const paginationSize = 2;
    const currentPageNum = 1;
    const totalRowsCount = 3;
    const mockRows = [
      { setRowSelectable: jasmine.createSpy('setRowSelectable') },
      { setRowSelectable: jasmine.createSpy('setRowSelectable') },
      { setRowSelectable: jasmine.createSpy('setRowSelectable') }
    ];
    const gridApiActive = {
      deselectAll: jasmine.createSpy('deselectAll'),
      paginationGetPageSize: () => paginationSize,
      paginationGetCurrentPage: () => currentPageNum,
      getDisplayedRowCount: () => totalRowsCount,
      getDisplayedRowAtIndex: (i) => mockRows[i]
    };
    component.gridApiActive = gridApiActive as any;
    // Act
    component.resetPaginationSelection(component);
    // Assert
    expect(gridApiActive.deselectAll).toHaveBeenCalled();
    // Only row 2 (index 2) should be selectable for page 1, since last index is capped at totalRowsCount
    for (let i = 0; i < totalRowsCount; i++) {
      const isWithinCurrentPage = i >= 2 && i < 3;
      expect(mockRows[i].setRowSelectable).toHaveBeenCalledWith(isWithinCurrentPage);
    }
  });
});
