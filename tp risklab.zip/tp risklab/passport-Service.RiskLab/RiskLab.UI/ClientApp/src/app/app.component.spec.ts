import { TestBed } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { AppComponent } from "./app.component";
import {
  OKTA_CONFIG,
  OktaAuthModule,
  OKTA_AUTH,
  OktaAuthStateService
} from "@okta/okta-angular";
import { AppConfig } from "./shared/models/app-config";
import {
  AuthState,
  IDToken,
  UserClaims,
  OktaAuth,
  OktaAuthOptions
} from "@okta/okta-auth-js";
import { provideHttpClientTesting } from "@angular/common/http/testing";
import { IdleTimeoutService } from "./shared/services/idle-timeout.service";
import { of } from "rxjs";
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("AppComponent", () => {
  const sessionSpy = jasmine.createSpyObj([
    "exists",
    "setCookieAndRedirect",
    "config"
  ]);
  let oktaAuthSpy = jasmine.createSpyObj(
    "OktaAuth",
    ["signInWithCredentials", "signOut", "config"],
    {
      session: sessionSpy
    }
  );
  const claims: UserClaims = {
    sub: "sub",
    name: "Test Name"
  };

  const idToken: IDToken = {
    idToken: "token",
    clientId: "client",
    issuer: "issuer",
    authorizeUrl: "authorize",
    expiresAt: 123,
    scopes: [],
    claims
  };

  const authState: AuthState = {
    isAuthenticated: true,
    idToken
  };
  let authStateSpy = jasmine.createSpyObj<OktaAuthStateService>(
    [],
    ["authState$"]
  );
  let mockIdleTimeoutService = new IdleTimeoutService(oktaAuthSpy);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
    declarations: [AppComponent],
    imports: [RouterTestingModule],
    providers: [
        { provide: OKTA_AUTH, useValue: oktaAuthSpy, multi: false },
        { provide: OktaAuthStateService, useValue: authStateSpy },
        { provide: IdleTimeoutService, useValue: mockIdleTimeoutService },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
    (Object.getOwnPropertyDescriptor(authStateSpy, 'authState$')?.get as jasmine.Spy).and.returnValue(of(authState));
  });

  it("should create the app", () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'ClientApp'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual("RiskLab");
  });
  it(`should called ngOnInit`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    fixture.detectChanges();
    app.resetTimer();
    expect(app.isAuthenticated).toBeTrue();
  });
});
