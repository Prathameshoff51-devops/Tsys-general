import { provideHttpClientTesting } from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NavigationEnd, Router } from "@angular/router";
import { OktaAuthStateService, OKTA_AUTH } from "@okta/okta-angular";
import { AuthState, IDToken, UserClaims } from "@okta/okta-auth-js";
import { of, Subscription, throwError } from "rxjs";
import { AppConfig } from "../shared/models/app-config";
import { ConfigurationService } from "../shared/services/configuration.service";
import { ErrorService } from "../shared/services/error.service";
import { IdleTimeoutService } from "../shared/services/idle-timeout.service";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { MediaObserver, MediaChange } from '@angular/flex-layout';
import { ScrollService } from '../shared/services/scroll.service';
import { ElementRef, NO_ERRORS_SCHEMA } from '@angular/core';

import { HomeComponent } from "./home.component";
import { ConstantsUnitTest } from "../constant.unit.test";
import { Constants } from "../Constants";
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("HomeComponent", () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let mockMediaObserver: jasmine.SpyObj<MediaObserver>;
  let mockScrollService: jasmine.SpyObj<ScrollService>;
  
  const sessionSpy = jasmine.createSpyObj([
    "exists",
    "setCookieAndRedirect",
    "config"
  ]);
  let oktaAuthSpy = jasmine.createSpyObj(
    "OktaAuth",
    ["signInWithCredentials", "signOut", "config", "getUser"],
    {
      session: sessionSpy
    }
  );
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };
  const claims: UserClaims = {
    sub: "sub",
    name: "Test Name"
  };

  const idToken: IDToken = {
    idToken: "token",
    clientId: "client",
    issuer: "issuer",
    authorizeUrl: "authorize",
    expiresAt: 123,
    scopes: [],
    claims
  };

  const authState: AuthState = {
    isAuthenticated: true,
    idToken
  };
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  let authStateSpy = jasmine.createSpyObj<OktaAuthStateService>(
    [],
    ["authState$"]
  );
  let mockIdleTimeoutService = jasmine.createSpyObj(
    "IdleTimeoutService",
    [
      "startTimer",
      "timeoutExpired",
      "lastTime",
      "startDismissTimer",
      "_dismissSubscription",
      "stopTimer",
      "unsubscribe",
      "resetTimer"
    ]
  );
  let mockErrorService = jasmine.createSpyObj("ErrorService", ["updateMessage"]);

  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["existsMenuByField", "loadConfigurationData", "getMenuByField"]
  );

  beforeEach(async () => {
    mockMediaObserver = jasmine.createSpyObj('MediaObserver', ['asObservable', 'isActive']);
    mockScrollService = jasmine.createSpyObj('ScrollService', [], {
      scrollToTop$: of({}),
      scrollToBottom$: of({})
    });

    oktaAuthSpy.signOut.and.returnValue(Promise.resolve(true));
    oktaAuthSpy.getUser.and.returnValue(Promise.resolve(claims));
    
    // Setup media observer mock
    const mockMediaChange: MediaChange = {
      mqAlias: 'xs',
      mediaQuery: '(max-width: 599px)',
      matches: true,
      suffix: 'xs',
      priority: 0,
      property: 'screen',
      value: '(max-width: 599px)',
      clone: function() { return this; }
    };
    mockMediaObserver.asObservable.and.returnValue(of([mockMediaChange]));
    mockMediaObserver.isActive.and.returnValue(false);

    await TestBed.configureTestingModule({
    declarations: [HomeComponent],
    schemas: [NO_ERRORS_SCHEMA],
    imports: [],
    providers: [
        { provide: Router, useValue: mockRouter },
        { provide: OKTA_AUTH, useValue: oktaAuthSpy, multi: false },
        { provide: OktaAuthStateService, useValue: authStateSpy },
        { provide: IdleTimeoutService, useValue: mockIdleTimeoutService },
        { provide: MediaObserver, useValue: mockMediaObserver },
        { provide: ScrollService, useValue: mockScrollService },
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        { provide: ErrorService, useValue: mockErrorService },
        {
            provide: LoadingDialogService,
            useValue: mockLoadingDialogService
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    mockIdleTimeoutService.timeoutExpired = of(1678078717185);
    mockIdleTimeoutService.lastTime = 1678078717185;
    mockIdleTimeoutService._dismissSubscription = new Subscription();
    mockConfigurationService.loadConfigurationData.and.returnValue(Promise.resolve(ConstantsUnitTest.configData));
    spyOn(
      mockIdleTimeoutService._dismissSubscription,
      "unsubscribe"
    ).and.callThrough();
    (Object.getOwnPropertyDescriptor(authStateSpy, 'authState$')?.get as jasmine.Spy).and.returnValue(of(authState));
    component.configData = Promise.resolve(ConstantsUnitTest.configData);
    fixture.detectChanges();
  });

  it("should create", () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    expect(component).toBeTruthy();
  });

  it("should handle media change for small screens", () => {
    const mockMediaChange: MediaChange = {
      mqAlias: 'xs',
      mediaQuery: '(max-width: 599px)',
      matches: true,
      suffix: 'xs',
      priority: 0,
      property: 'screen',
      value: '(max-width: 599px)',
      clone: function() { return this; }
    };
    mockMediaObserver.isActive.and.returnValue(true);
    
    component['handleMediaChange'](mockMediaChange);
    
    expect(component.opened).toBe(false);
  });

  it("should handle media change for large screens", () => {
    const mockMediaChange: MediaChange = {
      mqAlias: 'lg',
      mediaQuery: '(min-width: 960px)',
      matches: true,
      suffix: 'lg',
      priority: 0,
      property: 'screen',
      value: '(min-width: 960px)',
      clone: function() { return this; }
    };
    mockMediaObserver.isActive.and.returnValue(false);
    
    component['handleMediaChange'](mockMediaChange);
    
    expect(component.opened).toBe(true);
  });

  it("should unsubscribe media watcher on destroy", () => {
    spyOn(component.mediaWatcher, 'unsubscribe');
    
    component.ngOnDestroy();
    
    expect(component.mediaWatcher.unsubscribe).toHaveBeenCalled();
  });

  it("should scroll to top when scroll service emits", () => {
    const mockElement = {
      scrollTo: jasmine.createSpy('scrollTo')
    };
    component.scrollContainer = new ElementRef(mockElement as unknown) as ElementRef<HTMLDivElement>;
    
    component.scrollToTop();
    
    expect(mockElement.scrollTo).toHaveBeenCalledWith({top: 0, behavior: "smooth"});
  });

  it("should scroll to bottom when scroll service emits", () => {
    const mockElement = {
      scrollTo: jasmine.createSpy('scrollTo'),
      scrollHeight: 1000
    };
    component.scrollContainer = new ElementRef(mockElement as unknown) as ElementRef<HTMLDivElement>;
    
    component.scrollToBottom();
    
    expect(mockElement.scrollTo).toHaveBeenCalledWith({top: 1000, behavior: "smooth"});
  });

  it("should handle scroll to top when scrollContainer is undefined", () => {
    component.scrollContainer = undefined as any;
    
    expect(() => component.scrollToTop()).not.toThrow();
  });

  it("should handle scroll to bottom when scrollContainer is undefined", () => {
    component.scrollContainer = undefined as any;
    
    expect(() => component.scrollToBottom()).not.toThrow();
  });

  it("should handle confirmed dialog with reset timer", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    mockIdleTimeoutService.lastTime = new Date().getTime() - 50000;
    
    await component.ngOnInit();
    
    expect(mockIdleTimeoutService.resetTimer).toHaveBeenCalled();
  });

  it("should handle rejected dialog with sign out", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    mockIdleTimeoutService.lastTime = new Date().getTime() - 50000;
    
    await component.ngOnInit();
    
    expect(oktaAuthSpy.signOut).toHaveBeenCalledWith({ revokeAccessToken: true });
  });

  it("should handle dialog dismissed reason", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(throwError('dismissed'));
    mockIdleTimeoutService.lastTime = new Date().getTime() - 50000;
    spyOn(console, 'log');
    
    await component.ngOnInit();
    
    expect(console.log).toHaveBeenCalledWith('Dismissed dismissed');
  });

  it("should handle fraud service user navigation", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    const fraudConfig = { ...ConstantsUnitTest.configData, isFraudServiceUser: true };
    component.configData = Promise.resolve(fraudConfig);
    sessionStorage.setItem('FraudServiceRequest', 'true');
    
    await component.ngOnInit();
    
    expect(mockRouter.navigate).toHaveBeenCalledWith([Constants.merchantTxnPage]);
  });

  it("should handle non-fraud service user with no special flags", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    const normalConfig = { ...ConstantsUnitTest.configData, isFraudServiceUser: false };
    component.configData = Promise.resolve(normalConfig);
    sessionStorage.removeItem('FraudServiceRequest');
    localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);
    localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
    sessionStorage.removeItem('batchrejects');
    sessionStorage.removeItem('batchQueuedRejects');
    
    await component.ngOnInit();
    
    expect(mockRouter.navigate).toHaveBeenCalledWith([Constants.riskLabPage]);
  });

  it("should handle unauthenticated state", async () => {
    const unauthenticatedState: AuthState = {
      isAuthenticated: false,
      idToken: undefined
    };
    (Object.getOwnPropertyDescriptor(authStateSpy, 'authState$')?.get as jasmine.Spy).and.returnValue(of(unauthenticatedState));
    
    await component.ngOnInit();
    
    expect(component.isAuthenticated).toBe(false);
  });

  it("should set environment and username from config", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    const configWithEnv = { 
      ...ConstantsUnitTest.configData, 
      environment: 'TEST_ENV',
      username: 'TEST_USER'
    };
    component.configData = Promise.resolve(configWithEnv);
    
    await component.ngOnInit();
    
    expect(component.environment).toBe('TEST_ENV');
    expect(component.userName).toBe('TEST_USER');
  });

  // Keep existing tests
  it("should be navigate to secure/risklab", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    sessionStorage.removeItem("FraudServiceRequest");
    localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);
    localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
    sessionStorage.removeItem("batchrejects");
    sessionStorage.removeItem("batchQueuedRejects");
    component.configData = Promise.resolve(ConstantsUnitTest.configData);
    await component.ngOnInit();
    expect(mockRouter.navigate).toHaveBeenCalledWith(["secure/risklab"]);
  });

  it("should be navigate to secure/batchNewTxnRejects", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    sessionStorage.removeItem("FraudServiceRequest");
    localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
    sessionStorage.removeItem("batchrejects");
    sessionStorage.removeItem("batchQueuedRejects");
    localStorage.setItem(Constants.batchRejectIdforNewDrillDown, "true");

    component.configData = Promise.resolve(ConstantsUnitTest.configData);
    await component.ngOnInit();
    localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);
    expect(mockRouter.navigate).toHaveBeenCalledWith([
      "secure/batchNewTxnRejects"
    ]);
  });

  it("should be navigate to secure/batchQueuedTxnRejects", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    sessionStorage.removeItem("FraudServiceRequest");
    localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);
    sessionStorage.removeItem("batchrejects");
    sessionStorage.removeItem("batchQueuedRejects");
    localStorage.setItem(Constants.batchRejectIdforQueuedDrillDown, "true");
    component.configData = Promise.resolve(ConstantsUnitTest.configData);
    await component.ngOnInit();
    localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
    expect(mockRouter.navigate).toHaveBeenCalledWith([
      "secure/batchQueuedTxnRejects"
    ]);
  });

  it("should be navigate to secure/batchrejects", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    sessionStorage.removeItem("FraudServiceRequest");
    localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);
    localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
    sessionStorage.setItem("batchrejects", "true");
    sessionStorage.removeItem("batchQueuedRejects");
    component.configData = Promise.resolve(ConstantsUnitTest.configData);

    await component.ngOnInit();

    expect(mockRouter.navigate).toHaveBeenCalledWith(["secure/batchrejects"]);
  });

  it("should be navigate to batchQueuedRejects", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    sessionStorage.removeItem("FraudServiceRequest");
    localStorage.removeItem(Constants.batchRejectIdforNewDrillDown);
    localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
    sessionStorage.removeItem("batchrejects");
    sessionStorage.setItem("batchQueuedRejects", "true");
    component.configData = Promise.resolve(ConstantsUnitTest.configData);
    await component.ngOnInit();
    sessionStorage.removeItem("batchQueuedRejects");
    expect(mockRouter.navigate).toHaveBeenCalledWith(["secure/batchrejects"]);
  });

  it("should be navigate to secure/merchantrejectedtxns", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    component.configData = Promise.resolve(ConstantsUnitTest.configData);
    sessionStorage.setItem("FraudServiceRequest", "true");
    await component.ngOnInit();
    expect(mockRouter.navigate).toHaveBeenCalledWith([
      "secure/merchantrejectedtxns"
    ]);
  });

  it("should called resetTimer", async () => {
    mockIdleTimeoutService.lastTime = new Date().getTime() + 50000;
    mockLoadingDialogService.confirmed.and.returnValue(of(false));

    await component.ngOnInit();
    expect(mockIdleTimeoutService.resetTimer).toHaveBeenCalled();
  });

  it("should be error 403", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    oktaAuthSpy.getUser.and.returnValue(Promise.resolve({ name: "nikhil" }));
    component.configData = Promise.reject({
      transactionId: 318,
      updateStatus: "Failed",
      status: 401
    });
    await component.ngOnInit();
    expect(component.sideNavBarFlag).toBeTrue();
  });
  it("should be error 500", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    oktaAuthSpy.getUser.and.returnValue(Promise.resolve({ name: "nikhil" }));
    component.configData = Promise.reject({
      transactionId: 318,
      updateStatus: "Failed",
      status: 500
    });
    await component.ngOnInit();
    expect(component.sideNavBarFlag).toBeTrue();
  });
  it("should be error ", async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    oktaAuthSpy.getUser.and.returnValue(Promise.resolve({ name: "nikhil" }));
    component.configData = Promise.reject({
      transactionId: 318,
      updateStatus: "Failed",
      status: 404
    });
    await component.ngOnInit();
    expect(component.sideNavBarFlag).toBeTrue();
  });
});
