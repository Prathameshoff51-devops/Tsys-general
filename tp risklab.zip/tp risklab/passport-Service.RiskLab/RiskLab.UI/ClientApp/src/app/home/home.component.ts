import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { Router } from '@angular/router';
import { Subscription, throwError } from 'rxjs';
import { menu } from '../ui/model/menu';
import { NavItem } from '../ui/model/nav-item';
import { ConfigurationService } from '../shared/services/configuration.service';
import { Subject } from 'rxjs';
import { filter, map, takeUntil } from 'rxjs/operators';
import {
  OktaAuth,
  UserClaims,
  AuthApiError,
  AccessToken,
  Tokens,
} from '@okta/okta-auth-js';
import { Configuration } from '../shared/models/configuration.model';
import { OKTA_AUTH, OktaAuthStateService } from '@okta/okta-angular';
import { ErrorService } from '../shared/services/error.service';
import { Constants } from '../Constants';
import { IdleTimeoutService } from '../shared/services/idle-timeout.service';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { Constant } from '../shared/constant';
import { ScrollService } from '../shared/services/scroll.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  @ViewChild('scrollContainer') scrollContainer:ElementRef<HTMLDivElement>;
  public opened: boolean = true;
  sideNavBarFlag = true;
  isAuthenticated?: boolean;
  public mediaWatcher: Subscription;
  public menu: NavItem[] = menu;
  userName?: string;
  environment!: string;
  configData: any;
  private _idleTimerSubscription: Subscription | any;
  constructor(
    private router: Router,
    private media: MediaObserver,
    @Inject(OKTA_AUTH) private oktaAuth: OktaAuth,
    public authService: OktaAuthStateService,
    public configService: ConfigurationService,
    private errorService: ErrorService,
    private _idleTimeoutSvc: IdleTimeoutService,
    private _dialogSvc: LoadingDialogService,
    private scrollservice:ScrollService
  ) {
    this.mediaWatcher = this.media
      .asObservable()
      .pipe(
        filter((changes: MediaChange[]) => changes.length > 0),
        map((changes: MediaChange[]) => changes[0])
      )
      .subscribe((mediaChange: MediaChange) => {
        this.handleMediaChange(mediaChange);
        this.configData = configService.loadConfigurationData();
      });
  }
  private handleMediaChange(mediaChange: MediaChange) {
    if (this.media.isActive('lt-md')) {
      this.opened = false;
    } else {
      this.opened = true;
    }
  }
  ngOnDestroy() {
    this.mediaWatcher.unsubscribe();
  }
  async ngOnInit() {    
    //start
    this._idleTimeoutSvc.startTimer();
    this.scrollservice.scrollToTop$.subscribe(()=> {
      this.scrollToTop();
  });
    this.scrollservice.scrollToBottom$.subscribe(()=> {
        this.scrollToBottom();
    });
    const options = {
      title: 'Session expiring!',
      message: 'Your session is about to expire, do you need more time?',
      cancelText: 'No',
      confirmText: 'Yes',
    };
    this._idleTimerSubscription = this._idleTimeoutSvc.timeoutExpired.subscribe(
      (res: any) => {
        let currentTime: number = new Date().getTime();
        if (this._idleTimeoutSvc.lastTime < currentTime) {
          this._idleTimeoutSvc.startDismissTimer();
          this._dialogSvc.openDialog(options);
          this._dialogSvc.confirmed().subscribe(
            (confirmed: any) => {
              this._idleTimeoutSvc._dismissSubscription.unsubscribe();
              if (confirmed) {
                this._idleTimeoutSvc.resetTimer();
              } else {
                localStorage.removeItem('IsChanged');
                this._idleTimeoutSvc.stopTimer();
                this.oktaAuth
                  .signOut({
                    revokeAccessToken: true,
                  })
                  .then(() => { })
                  .catch((err) => {
                    console.log(err);
                    alert(err);
                  });
              }
            },
            (reason: any) => {
              console.log('Dismissed ' + reason);
              this._idleTimeoutSvc._dismissSubscription.unsubscribe();
            }
          );
        } else {
          this._idleTimeoutSvc.resetTimer();
        }
      }
    );

    //end
    this.authService.authState$.subscribe(async (result) => {
      this.isAuthenticated = result.isAuthenticated;

      if (this.isAuthenticated) {
        this.configData
          .then((config: any) => {
            this.environment = config.environment;
            this.userName = config.username;
            if (config.isFraudServiceUser && sessionStorage.getItem('FraudServiceRequest') === 'true') {
              this.router.navigate([Constants.merchantTxnPage]);
            }
            else{
              if (localStorage.getItem(Constants.batchRejectIdforNewDrillDown)) {
                this.sideNavBarFlag = false;
                this.router.navigate([Constants.batchNewTxnRejectsPage]);
              }
              else if (localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)) {
                this.sideNavBarFlag = false;
                this.router.navigate([Constants.batchQueuedTxnRejectsPage]);
              }
              else if (sessionStorage.getItem('batchrejects')) {  
                sessionStorage.removeItem('batchrejects');
                this.sideNavBarFlag = true;
                this.router.navigate([Constants.batchrejectsPage]);
              }
              else if (sessionStorage.getItem('batchQueuedRejects')) {  
                this.sideNavBarFlag = true;
                this.router.navigate([Constants.batchrejectsPage]);
              }
               else{
              this.router.navigate([Constants.riskLabPage]);
              }
            }
          })
     
          .catch((err: any) => {
            console.log(err);
            this.oktaAuth.getUser().then((userClaims) => {
              this.userName = userClaims.name;
            });
            if (err.status === 401 || err.status === 403) {
              this.sideNavBarFlag = false;
              this.router.navigate([Constants.unauthorizedPage]);
            } else if (err.status === 500) {
              this.sideNavBarFlag = false;
              this.errorService.updateMessage(err.error);
              this.router.navigate([Constants.errorPage]);
            } else {
              this.sideNavBarFlag = false;
              this.errorService.updateMessage(err.message);
              this.router.navigate([Constants.errorPage]);
            }
          });    
      }
    });
  }
  scrollToTop(){
      if(this.scrollContainer?.nativeElement){
      this.scrollContainer.nativeElement.scrollTo({top:0,behavior:"smooth"});
      }
  }
  scrollToBottom(){
      if(this.scrollContainer?.nativeElement){
      this.scrollContainer.nativeElement.scrollTo({top: this.scrollContainer.nativeElement.scrollHeight, behavior: "smooth"});
      }
  }
}
