import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick
} from "@angular/core/testing";

import { QueuedBulkRefundsComponent } from "./queued-bulk-refunds.component";
import { ConfigurationService } from "../shared/services/configuration.service";
import { AppConfig } from "../shared/models/app-config";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { DebugElement } from "@angular/core";
import { AgGridModule } from "ag-grid-angular";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { of, throwError } from "rxjs";
import { BatchRefundSevice } from "../shared/services/batch-refund.service";
import { NavigationEnd, Router } from "@angular/router";
import { BatchRefund } from "../shared/models/batch-refund.model";
import { ConstantsUnitTest } from "../constant.unit.test";
import * as signalR from '@microsoft/signalr';
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("QueuedBulkRefundsComponent", () => {
  let component: QueuedBulkRefundsComponent;
  let fixture: ComponentFixture<QueuedBulkRefundsComponent>;
  let el: DebugElement;
  let httpTestingController: HttpTestingController;
  let mockHubConnection: jasmine.SpyObj<signalR.HubConnection>;
  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["config", "configData"]
  );
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };

  const apiReponse: BatchRefund[] = [
    {
      batchRejectId: 16,
      batchNumber: "000172",
      merchantNumber: "650000002446493",
      merchantName: "GENEROUS JOES DELI",
      batchAmount: 120.234,
      refundCount: 0,
      txnDateUTC: "2022-09-08T00:00:00",
      daysToAct: -47,
      batchCloseDate: "2022-09-08T00:00:00",
      status: "Queued",
      mcc: "5814",
      submitterIDDescription: "Exchange",
      canTakeBatchAction: true,
      rejectReasons: [
        "Batch refund threshold limit exceeded",
        "Merchant refund threshold limit exceeded"
      ],
      legalName: "NATOLI ENTERPRISES INC.",
      chainOID: null,
      action: 2
    },
    {
      action: 2,
      batchRejectId: 53,
      batchNumber: "102030",
      merchantNumber: "650000012036045",
      merchantName: "ANTHONY JACKSON",
      batchAmount: 200,
      refundCount: 2,
      txnDateUTC: "2023-01-12T08:22:26.047",
      daysToAct: -13,
      batchCloseDate: "2023-01-12T08:22:26.047",
      status: "Queued",
      mcc: "5814",
      submitterIDDescription: "Exchange",
      canTakeBatchAction: false,
      rejectReasons: ["Merchant refund threshold limit exceeded"],
      legalName: "NATOLI ENTERPRISES INC.",
      chainOID: null
    }
  ];
  const bodytranscationsAction = {
    batchRejectId: 53,
    newStatus: "3",
    userName: "Nikhil.Akole"
  };
  const transcationsActionResponse = {
    batchRejectId: 53,
    updateStatus: "Success",
    statusCode: "200"
  };
  const transcationsActionResponseAllFailed = {
    batchRejectId: 53,
    updateStatus: "Failed",
    statusCode: "200"
  };

  beforeEach(async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    mockHubConnection = jasmine.createSpyObj('HubConnection', ['start', 'stop', 'on']);
    // Ensure .start always returns a Promise to avoid TypeError on .then
    mockHubConnection.start.and.returnValue(Promise.resolve());



    // Mock the builder chain using prototype spies
    spyOn(signalR.HubConnectionBuilder.prototype, 'withUrl').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'withAutomaticReconnect').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'configureLogging').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'build').and.returnValue(mockHubConnection);
    await TestBed.configureTestingModule({
    declarations: [QueuedBulkRefundsComponent],
    imports: [AgGridModule],
    providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        BatchRefundSevice,
        {
            provide: LoadingDialogService,
            useValue: mockLoadingDialogService
        },
        { provide: Router, useValue: mockRouter },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();

    fixture = TestBed.createComponent(QueuedBulkRefundsComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should return anchorTagBlue in cellClass when daysToAct > context.daysToAct', () => {
    const params = {
      data: { daysToAct: 15 },
      context: { daysToAct: 10 }
    };
    // cellClass is a function, so call it directly
    const colDef: any = component.gridOptions.columnDefs[1];
    const result = typeof colDef.cellClass === 'function' ? colDef.cellClass(params) : undefined;
    expect(result).toBe('anchorTagBlue');
  });

  it('should return null in countDisplayedRows', () => {
    const params = { api: { paginationGetRowCount: () => 5 } };
    expect(component.countDisplayedRows(params)).toBeUndefined();
    expect(component.recordCount).toBe(5);
  });

  it('should set currentPageRowLastIndex to totalRowsCount if it exceeds', () => {
    const mockApi = {
      deselectAll: jasmine.createSpy('deselectAll'),
      paginationGetPageSize: () => 10,
      paginationGetCurrentPage: () => 1,
      getDisplayedRowCount: () => 15,
      getDisplayedRowAtIndex: (i) => ({ setRowSelectable: jasmine.createSpy('setRowSelectable') })
    };
    const self: any = { gridApiActive: mockApi };
    component.resetPaginationSelection(self);
    expect(mockApi.deselectAll).toHaveBeenCalled();
  });

  it('should set disabled to false if flag is true in parentMethod', () => {
    component.gridApiActive = {
      forEachNode: (cb) => {
        cb({ selectable: true, displayed: true, data: { action: 1 } });
      }
    } as any;
    component.disabled = true;
    component.parentMethod();
    expect(component.disabled).toBe(false);
  });

  it('should call showNoRowsOverlay if getDisplayedRowCount is 0 in onGridReady', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const sizeColumnsToFit = jasmine.createSpy('sizeColumnsToFit');
    const params = {
      api: {
        setDomLayout: jasmine.createSpy('setDomLayout'),
        addEventListener: jasmine.createSpy('addEventListener'),
        getDisplayedRowCount: () => 0,
        showNoRowsOverlay,
        hideOverlay,
        sizeColumnsToFit
      }
    };
    component.onGridReady(params);
    expect(showNoRowsOverlay).toHaveBeenCalled();
  });

  it('should call fetchBatchRejects, ResetSearch, and set showRefreshButton to false on onRefreshButtonClick', () => {
    spyOn(component, 'fetchBatchRejects');
    spyOn(component, 'ResetSearch');
    component.showRefreshButton = true;
    // Set up dialogService spies directly
    const dialogService = component['dialogService'];
    dialogService.openDialog = jasmine.createSpy('openDialog');
    dialogService.confirmed = jasmine.createSpy('confirmed').and.returnValue(of(true));
    component.onRefreshButtonClick();
    expect(component.fetchBatchRejects).toHaveBeenCalled();
    expect(component.ResetSearch).toHaveBeenCalled();
    expect(component.showRefreshButton).toBe(false);
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it(`should have config paginationPageSize be 1`, () => {
    component.config.defaultGridPageSize = 1;
    component.config.daysToAct = 10;
    expect(component.daysToAct).toEqual(10);
    expect(component.paginationPageSize).toEqual(1);
  });
  it(`should have beforeunloadHandler`, () => {
    localStorage.setItem("IsChanged", "true");
    let event = {
      returnValue: "abc",
      preventDefault() { }
    };
    component.beforeunloadHandler(event);
    expect(event.returnValue).toBe(
      "Are you sure you want to reset the changes?"
    );
  });
  it(`should have called changeRowColor as null`, () => {
    let params = {
      data: {
        daysToAct: 20,
        canTakeBatchAction: true
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color).toBeNull();
  });
  it(`should return gray background color when canTakeBatchAction is false`, () => {
    let params = {
      data: {
        daysToAct: 20,
        canTakeBatchAction: false
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

     expect(color.backgroundColor).toEqual('#dee2e6' );
  });
  it(`should have called changeRowColor`, () => {
    let params = {
      data: {
        daysToAct: 10
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color.backgroundColor).toEqual('#ffe6e6' );
  });
  it("should called fetchData ", async () => {
    const req = httpTestingController.expectOne(
      "https://localhost:7247/BatchRejects?status=2"
    );
    req.flush(apiReponse); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
  });
  
  it("should be called resetPaginationSelection ", async () => {
    component.config.defaultGridPageSize = 1;
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToFirstPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToLastPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
  });
  it("should be transcations successfully update ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToNextPage();
    component.batchRefund[1].action = 3;

    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponse);
    expect(component.message).toEqual("Batch updated successfully.");
  });
  it("should be transcations failed update ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToNextPage();
    component.batchRefund[1].action = 3;
    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseAllFailed);
    expect(component.message).toEqual("Batch update failed.");
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should be transcations failed ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.batchRefund[1].action = 3;
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component.onSubmit();
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should getDisplayedRowCount be 1 after SearchText ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "102030";
    jasmine.clock().install();
    component.OnFilterBoxChanged();
    jasmine.clock().tick(500);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(1);
    jasmine.clock().uninstall();
  });
  it("should getDisplayedRowCount be 2 after SearchText empty", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "";
    component.OnFilterBoxChanged();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
  });
  it("should be disabled  ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.batchRefund) {
      res.action = 2;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should be parentMethod return disabled  ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.batchRefund) {
      res.action = 2;
    }
    component.batchRefund[1].action = 3;
    localStorage.setItem("IsChanged", "true");
    await component.parentMethod();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it(
    `should have called FadeOutSuccessMsg`,
    fakeAsync(() => {
      component.FadeOutSuccessMsg();
      tick(10000);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.showMsg).toEqual(false);
      });
    })
  );
  it('should update state and call fetchData and FadeOutSuccessMsg in receiveData', () => {
    const data = { showMsg: true, isSuccess: false, message: 'Test message' };
    spyOn(component, 'fetchBatchRejects');
    spyOn(component, 'FadeOutSuccessMsg');
    component.receiveData(data);
    expect(component.message).toBe('Test message');
    expect(component.showMsg).toBeTrue();
    expect(component.isSuccess).toBeFalse();
    expect(component.fetchBatchRejects).toHaveBeenCalled();
    expect(component.FadeOutSuccessMsg).toHaveBeenCalled();
  });


  it('should set paginationPageSize and daysToAct from config if defined', () => {
    const mockConfig = {
      defaultGridPageSize: 10,
      daysToAct: 5,
      defaultBatchGridPageSize: 20,
    };
    const mockConfigService: any = {
      config: mockConfig,
      configData: { riskLabApiUrl: 'http://test', username: 'testuser' }
    };
    const component = new QueuedBulkRefundsComponent(
      mockConfigService,
      jasmine.createSpyObj('BatchRefundSevice', ['getBatchRefunds', 'batchAction']),
      jasmine.createSpyObj('LoadingDialogService', ['openDialog', 'confirmed'])
    );
    expect(component.paginationPageSize).toBe(mockConfig.defaultBatchGridPageSize);
    expect(component.daysToAct).toBe(mockConfig.daysToAct);
  });
  it('should return null from dateFormatter if data.value is falsy', () => {
    expect(component.dateFormatter({ value: null })).toBe('');
    expect(component.dateFormatter({})).toBe('');
  });
  it('should return formatted date from dateFormatter if data.value is truthy', () => {
    expect(component.dateFormatter({ value: "2022-11-02T16:30:16" })).toBe('2022-11-02 16:30:16');
  });

  it('should set flag to false in parentMethod if node has no action', () => {
    component.gridApiActive = {
      forEachNode: (cb) => {
        cb({ selectable: true, displayed: true, data: {} });
      }
    } as any;
    component.disabled = true;
    component.parentMethod();
    expect(component.disabled).toBe(true);
  });

  it('should call showNoRowsOverlay in OnFilterBoxChanged when no rows are displayed', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const refreshCells = jasmine.createSpy('refreshCells');
    const setQuickFilter = jasmine.createSpy('setQuickFilter');
    const forEachNode = jasmine.createSpy('forEachNode');
    const getDisplayedRowCount = jasmine.createSpy('getDisplayedRowCount').and.returnValue(0);
    component.gridApiActive = {
      forEachNode,
      setQuickFilter,
      refreshCells,
      getDisplayedRowCount,
      showNoRowsOverlay,
      hideOverlay
    } as any;
    component.SearchText = 'test';
    component.OnFilterBoxChanged();
    expect(showNoRowsOverlay).toHaveBeenCalled();
    expect(hideOverlay).not.toHaveBeenCalled();
  });
  it('should call builder chain and connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyQueueBatchRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
  }));

  it('should set showRefreshButton to true when NotifyQueueBatchRejectsTab event is received', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    let notifyHandler: ((response: any) => void) | undefined;
    mockHubConnection.on.and.callFake((event, handler) => {
      if (event === 'NotifyQueueBatchRejectsTab') {
        notifyHandler = handler;
      }
    });
    component.showRefreshButton = false;
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyQueueBatchRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    // Act: simulate event received
    if (notifyHandler) {
      notifyHandler({});
    }
    // Assert
    expect(component.showRefreshButton).toBeTrue();
  }));
  it('should call catch and log error if SignalR connection fails in connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    const error = new Error('Connection failed');
    spyOn(console, 'error');
    mockHubConnection.start.and.returnValue(Promise.reject(error));
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyQueueBatchRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    expect(console.error).toHaveBeenCalledWith(error);
  }));
  it('should call catch block and log error in fetchData when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    Object.defineProperty(component, 'batchRefund', {
      set() {
        throw errorObj;
      },get() {
        return [];
      }
    });
    
    spyOn(component['batchRefundService'], 'getBatchRefunds').and.returnValue(of(apiReponse));

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchBatchRejects();
    // Assert
    expect(console.log).toHaveBeenCalledWith('Error : ' + errorObj);
  });
  it('should call catch block and log error in fetchData when undefined throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    Object.defineProperty(component, 'batchRefund', {
      set() {
        throw errorObj;
      },get() {
        return [];
      }
    });
    
    spyOn(component['batchRefundService'], 'getBatchRefunds').and.returnValue(of(undefined));

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchBatchRejects();
    // Assert
    expect(console.log).toHaveBeenCalledWith('Error : Error: forEach error');
  });
   it('should handle API error in onSubmit and log error', async () => {
      // Arrange
      component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
       fixture.detectChanges();
      await fixture.whenStable();
      fixture.detectChanges();
      component.batchRefund[1].action = 3;
      component.configService.configData.username = "Nikhil.Akole";
      const apiError = new Error('API error');
      spyOn(console, 'error');
      // Simulate API error on POST
      spyOn(component['batchRefundService'], 'batchAction').and.returnValue(throwError(() => (apiError)));
       mockLoadingDialogService.confirmed.and.returnValue(of(true));
      // Act
      component.onSubmit();
      // Assert
      expect(console.error).toHaveBeenCalled();
  
    });
    it('should log error and redirect to logout if dialogSvc.confirmed emits error in onSubmit', () => {
      // Arrange: get the dialog service from TestBed
      const dialogSvc = TestBed.inject(LoadingDialogService) as jasmine.SpyObj<LoadingDialogService>;
      dialogSvc.openDialog.and.stub();
      dialogSvc.confirmed.and.returnValue({
        subscribe: (success, error) => {
          if (error) error('some error reason');
        }
      } as any);
      spyOn(console, 'log');
      // Act
      component.onSubmit();
      // Assert
      expect(console.log).toHaveBeenCalledWith('Dismissed some error reason');
      //expect(console.log).toHaveBeenCalledWith('redirec to log out');
    });

});
