import {
  Component,
  HostListener,
  Injectable,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { BatchRefundSevice } from '../shared/services/batch-refund.service';
import { BatchRefund } from '../shared/models/batch-refund.model';
import { RejectStatuses } from '../shared/enums';
import {
  GridApi,
  GridOptions,
  GridReadyEvent,
  PaginationChangedEvent,
} from 'ag-grid-community';
import { DropDownListRendererComponent } from '../ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { Configuration } from '../shared/models/configuration.model';
import { Constant } from '../shared/constant';
import { ConfigurationService } from '../shared/services/configuration.service';
import { RouterLinkRendererComponent } from '../navigation/router-link-renderer/router-link-renderer.component';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import * as signalR from '@microsoft/signalr';
import { Constants } from '../Constants';

@Component({
  selector: 'app-queued-bulk-refunds',
  templateUrl: './queued-bulk-refunds.component.html',
  styleUrls: ['./queued-bulk-refunds.component.css'],
  providers: [BatchRefundSevice],
})
@Injectable()
export class QueuedBulkRefundsComponent implements OnInit, OnDestroy {
  documentSaveDialog: any;
  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    if (localStorage.getItem('IsChanged') == 'true') {
      event.preventDefault();
      event.returnValue = 'Are you sure you want to reset the changes?';
    }
    return event;
  }
  batchRefund: BatchRefund[];
  recordCount: number;
  gridApiActive: GridApi;
  public gridOptions: GridOptions;
  SearchText: string;
  rowSelection;
  public paginationPageSize = 1;
  public paginationNumberFormatter: any;
  context: any;
  config!: Configuration;
  public daysToAct = Constant.DaysToActs;
  overlayNoRowsTemplate = 'No records to display.';
  disabled: boolean;
  showMsg: boolean = false;
  isSuccess: boolean = true;
  message: string;
  showRefreshButton: boolean = false;
  public riskLabUrl!: string;
  public signalrNotificationEndpoint!: string;
  private connection: signalR.HubConnection;


  constructor(
    public configService: ConfigurationService,
    private batchRefundService: BatchRefundSevice,
    private dialogService: LoadingDialogService
  ) {
    this.disabled = true;
    this.config = this.configService.config;

    this.riskLabUrl = this.configService.configData.riskLabApiUrl;
    this.signalrNotificationEndpoint = this.riskLabUrl + "/notification";

    if (
      this.config.defaultGridPageSize != undefined &&
      this.config.daysToAct != undefined
    ) {
      this.paginationPageSize = this.config.defaultBatchGridPageSize;
      this.daysToAct = this.config.daysToAct;
    }
    this.gridApiActive = new GridApi();
    this.context = {
      componentParent: this,
      daysToAct: this.daysToAct,
    };

    this.gridOptions = {
      components: {
        DropDownListRenderer: DropDownListRendererComponent,
      },
      enableBrowserTooltips: true,
      tooltipShowDelay: 0,

      columnDefs: [
        {
          headerName: 'Action',
          field: 'actionDropdown',
          editable: false,
          lockPosition: true,
          pinned: 'left',
          lockPinned: true,
          cellRenderer: 'DropDownListRenderer',
          minWidth: 130,
          maxWidth: 130,
          cellStyle: this.changeRowColor,
          tooltipValueGetter: function (params) {
            if (!params.data.canTakeBatchAction) {
              return 'Batch level action is not available on a partially worked on batch.';
            } else {
              return null;
            }
          },
          cellRendererParams: (params) => {
            if (params.data.canTakeBatchAction === true) {
              params.data.action = 2;
              return {
                values: [
                  { id: 2, name: 'Select Action' },
                  { id: 3, name: 'Release' },
                  { id: 4, name: 'Delete' },
                ],
              };
            }
            else {
              params.data.action = -1;
              return { values: [{ id: -1, name: 'Not Available' }] };
            }
          },
        },
        {
          headerName: 'Original Batch Number',
          resizable: true,
          cellClass: function (params) {
            if (params.data.daysToAct <= params.context.daysToAct) {
              return '#ffe6e6';
            } else {
              return 'anchorTagBlue';
            }
          },
          cellStyle: this.changeRowColor,

          minWidth: 160,
          field: 'batchNumber',
          sortable: true,
          cellRenderer: RouterLinkRendererComponent,
          cellRendererParams: {
            inRouterLink: Constants.batchQueuedTxnRejectsPage,
          },
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Merchant Number',
          resizable: true,
          minWidth: 130,
          field: 'merchantNumber',
          cellStyle: this.changeRowColor,
          sortable: true,

          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Merchant Name',
          minWidth: 130,
          resizable: true,
          field: 'merchantName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Legal Name',
          minWidth: 150,
          resizable: true,
          field: 'legalName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Processing Chain ID',
          minWidth: 174,
          field: 'chainOID',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'MCC',
          field: 'mcc',
          resizable: true,
          minWidth: 60,
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Amount',
          resizable: true,
          minWidth: 110,
          field: 'batchAmount',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.currencyFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Count',
          minWidth: 90,
          resizable: true,
          field: 'refundCount',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Create Date (UTC)',
          resizable: true,
          minWidth: 150,
          field: 'txnDateUTC',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          sort: 'asc',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Reject Reasons',
          field: 'rejectReasons',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 200,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Close Date (UTC)',
          resizable: true,
          minWidth: 160,
          field: 'batchCloseDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },


        {
          headerName: 'Submitter',
          minWidth: 100,
          field: 'submitterIdDescription',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Days to Act',
          minWidth: 100,
          field: 'daysToAct',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
      ],
    };
    this.paginationNumberFormatter = function (params: any) {
      return params.value.toLocaleString();
    };

    
  this.overlayNoRowsTemplate =
'<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
  }

  ngOnInit(): void {
    this.connectHub();
    this.fetchBatchRejects();
  }

  dateFormatter(data) {
    return data.value ? data.value.replace('T', ' ').replace('Z', '') : '';
  }

  currencyFormatter(params: any) {
    return "$" + params.value.toFixed(2);
  }

  changeRowColor(params) {
    if (params.data.daysToAct <= params.context.daysToAct) {
     return { backgroundColor: '#ffe6e6' };
    } else if (!params.data.canTakeBatchAction) {
          return {
            backgroundColor: '#dee2e6',
          };
    } else {
      return null;
    }
  }

  countDisplayedRows(params) {
    this.recordCount = params.api.paginationGetRowCount();
  }
  onFirstDataRendered(params: GridReadyEvent) {
    params.api.paginationGoToPage(0);
  }
  resetPaginationSelection = (self) => {
    self.gridApiActive.deselectAll();

    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount)
      currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      let isWithinCurrentPage =
        i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.gridApiActive
        .getDisplayedRowAtIndex(i)
        .setRowSelectable(isWithinCurrentPage);
    }
  };

  parentMethod() {
    this.PendingChangesCheck();
    var flag: boolean = true;
    this.gridApiActive.forEachNode((node) => {
      if (node.selectable && node.displayed) {
        if (!node.data.hasOwnProperty('action')) {
          flag = false;
        } else if (node.data.action == 2) {
          flag = false;
        }
      }
    });
    if (flag == true) {
      this.disabled = false;
    } else {
      this.disabled = true;
    }
  }

  onPaginationChanged(params: PaginationChangedEvent) {
    this.gridApiActive = params.api;
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        //delete node.data['action'];
        if (node.data.canTakeBatchAction === true) {
          node.data['action'] = 2;
        } else {
          node.data['action'] = -1;
        }
        this.disabled = true;
      }
    });
    if (typeof this.SearchText !== 'undefined' && this.SearchText) {
      localStorage.setItem('IsChanged', 'true');
    } else {
      localStorage.setItem('IsChanged', 'false');
    }
  }

  ResetSearch() {
    this.gridApiActive.setQuickFilter(null);
    this.SearchText = '';
  }

  OnFilterBoxChanged() {
    if (typeof this.SearchText !== 'undefined' && this.SearchText) {
      localStorage.setItem('IsChanged', 'true');
    } else {
      localStorage.setItem('IsChanged', 'false');
    }

    // setTimeout((gridApiActive) => {
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        if (node.data.canTakeBatchAction === true) {
          node.data['action'] = 2;
        } else {
          node.data['action'] = -1;
        }
      }
    });
    //}, 500);
    this.gridApiActive.setQuickFilter(this.SearchText);
    this.disabled = true;
    this.gridApiActive.refreshCells({ force: true });

    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }  
  }

  onGridReady(params: any) {
    this.gridOptions.suppressNoRowsOverlay = true;
    this.gridApiActive = params.api;
    params.api.setDomLayout('autoHeight');
    this.gridApiActive.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {     
      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }
    this.gridApiActive.sizeColumnsToFit();
  }

  onSubmit() {
    const options = {
      title: 'Confirm!',
      message: 'Are you sure you want to submit?',
      cancelText: 'No',
      confirmText: 'Yes',
    };
    this.isSuccess = true;
    this.dialogService.openDialog(options);
    this.dialogService.confirmed().subscribe(
      (confirmed: any) => {
        if (confirmed) {
          let batchAction;
          this.gridApiActive.forEachNode((node) => {
            if (node.selectable && node.displayed) {
              batchAction = {
                batchRejectId: node.data.batchRejectId,
                newStatus: node.data.action.toString(),
              };
            }
          });
          (batchAction.userName = this.configService.configData.username),
            //  API call to save modified row
            this.batchRefundService.batchAction(batchAction).subscribe(
              (response: any) => {
                if (response.updateStatus === Constant.Success) {
                  this.message = 'Batch updated successfully.';
                  this.fetchBatchRejects();
                } else {
                  console.log(response);
                  this.message = 'Batch update failed.';
                  this.isSuccess = false;
                  this.fetchBatchRejects();
                }

                this.showMessage();
              },
              (error) => {
                console.error('error caught in /batch post' + error);
              }
            );
        }
      },
      (reason: any) => {
        console.log('Dismissed ' + reason);
      }
    );
  }

  fetchBatchRejects() {
    this.batchRefundService
      .getBatchRefunds(RejectStatuses.Queued)
      .subscribe((response: BatchRefund[]) => {
        this.recordCount = response?.length;
        console.log(response);
        try {
          this.batchRefund = response;
        } catch (ex) {
          console.log('Error : ' + ex);
        }
      });
    this.disabled = true;
    this.showRefreshButton = false;
  }

  private showMessage() {
    this.showMsg = true;
    this.FadeOutSuccessMsg();
    this.ResetSearch();
  }

  FadeOutSuccessMsg() {
    setTimeout(() => {
      this.showMsg = false;
    }, 10000);
  }

  PendingChangesCheck() {
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action') && node.data.action != 2) {
        localStorage.setItem('IsChanged', 'true');
        console.log(node.data.action);
        return;
      } else if (node.data.action == 2) {
        localStorage.setItem('IsChanged', 'false');
      }
    });
  }

  onRefreshButtonClick() {
    const options = {
      title: "Confirm!",
      message: "Unsaved actions will get reset, continue with refresh?",
      cancelText: "No",
      confirmText: "Yes"
    };
    this.dialogService.openDialog(options);
    this.dialogService.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {
        this.fetchBatchRejects();
        this.ResetSearch();
        this.showRefreshButton = false;
      }
    });
  }
  connectHub() {
    this.disconnectHub();
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.signalrNotificationEndpoint)
        .withAutomaticReconnect()
        .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.on("NotifyQueueBatchRejectsTab", (response) => {
        if (!this.showRefreshButton)
          this.showRefreshButton = true;
      });

      this.connection
        .start().then(function () {
          console.info("connected to signalr...")
        })
        .catch(err => console.error(err));
    }
  }

  disconnectHub() {
    if (this.connection) {
      this.connection.stop();
      this.connection = null;
    }
  }

  
  receiveData(data: { showMsg: boolean; isSuccess: boolean; message: string }) {
    this.message = data.message;
    this.showMsg = data.showMsg;
    this.isSuccess = data.isSuccess;
    this.fetchBatchRejects(); // Refresh the data after import/export
    this.FadeOutSuccessMsg();
  }

  ngOnDestroy(): void {
    this.disconnectHub();
  }
}
