import { Component, EventEmitter, HostListener, Input, OnDestroy, OnInit, Output } from '@angular/core';
import {
  IndividualRefund,
} from '../shared/models/individual-refund.model';
import { QueuedRefund } from '../shared/models/queued-refund.model';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { LoaderService } from '../ui/service/loader.service';
import * as XLSX from 'xlsx';
import { IndividualRefundservice } from '../shared/services/individual-refund.service';
import { ExportService } from '../shared/services/export.service';
import { ConfigurationService } from '../shared/services/configuration.service';
import { Constant } from '../shared/constant';
import { ScrollService } from '../shared/services/scroll.service';
import { BatchRefund } from '../shared/models/batch-refund.model';
import { BatchQueuedtxnservice } from '../shared/services/batch-queued-txn-rejects';

// Constants for better maintainability
const DEFAULT_ITEMS_PER_LOAD = 20;
const MIN_TABLE_WIDTH = 600;
const LAYOUT_WIDTH_PERCENTAGE = 0.8;
const PADDING_MARGINS_TOTAL = 120;
const TABLE_BUFFER = 20;
const SCROLL_THRESHOLD = 5;

// File validation constants
const ALLOWED_FILE_TYPES = ['.xlsx'] as const;
const REQUIRED_IMPORT_FIELDS = ['merchantNumber', 'merchantName', 'mcc'] as const;

// Status constants
const STATUS_VALUES = {
  NEW: '1',
  QUEUE: '2',
  RELEASE: '3',
  DELETE: '4'
} as const;

// Response message templates
const RESPONSE_MESSAGES = {
  SUCCESS: (success: number, total: number) => 
    `${success}/${total} records were processed successfully.`,
  PARTIAL_FAILURE: (failed: number, total: number) => 
    `${failed}/${total} records couldn't be processed as they were already updated by another user or previous import.`,
  FAILURE: 'Import failed. Please try again.'
} as const;

type ImportEmitData = {
  showMsg: boolean;
  isSuccess: boolean;
  message: string;
};

type StatusString = 'new' | 'queue' | 'release' | 'delete';

// API Response interfaces for better type safety
interface ApiResponseItem {
  updateStatus: string;
  [key: string]: any;
}

interface BatchApiResponse {
  batchTransactionRejectUpdateStatuses: ApiResponseItem[];
}

interface ProcessingResult {
  message: string;
  isSuccess: boolean;
}

@Component({
  selector: 'app-export-import',
  templateUrl: './export-import.component.html',
  styleUrls: ['./export-import.component.css'],
  providers: [IndividualRefundservice, BatchQueuedtxnservice],
})
export class ExportImportComponent implements OnInit, OnDestroy {
  @Input() gridData: IndividualRefund[] | QueuedRefund[] | BatchRefund[] = [];
  @Input() pageType: 'new' | 'queue' = 'new';
  @Input() individualOrBatch: 'individual' | 'batch' = 'individual';

  @Output() valueEmitter: EventEmitter<ImportEmitData> = new EventEmitter();

  selectedFile: File | null = null;
  importData: any[] = [];
  showImportPreview: boolean = false;
  keys: string[] = [];
  individualOrBatchFullName: string = '';
  nonEmptyNewStatusCount: number = 0;
  records: string = '';

  // Screen width calculation properties
  screenWidth: number = 0;
  usedWidth: number = 0;
  remainingWidth: number = 0;
  tableWidth: number = 0;

  // Lazy loading properties
  visibleItems: any[] = [];
  startIndex: number = 0;
  endIndex: number = DEFAULT_ITEMS_PER_LOAD;
  itemsPerLoad: number = DEFAULT_ITEMS_PER_LOAD;

  constructor(
    private individualRefundservice: IndividualRefundservice,
    private exportService: ExportService,
    public configService: ConfigurationService,
    private _dialogSvc: LoadingDialogService,
    private scrollservice: ScrollService,
    private batchQueuedtxnservice: BatchQueuedtxnservice,
    private loaderService: LoaderService
  ) {
  }

  ngOnInit(): void {
    this.validateInputs();
    this.calculateScreenWidth();
    this.setIndividualOrBatchFullName();
  }

  ngOnDestroy(): void {
    // HostListener automatically handles cleanup, but this is good practice
    // for any other cleanup if needed in the future
  }

  private validateInputs(): void {
    if (!this.pageType || !this.individualOrBatch) {
      console.warn('ExportImportComponent: Required inputs (pageType, individualOrBatch) are missing');
    }
  }

  @HostListener('window:resize', [])
  onWindowResize(): void {
    this.calculateScreenWidth();
  }

  private setIndividualOrBatchFullName(): void {
    this.individualOrBatchFullName = this.individualOrBatch === 'individual' 
      ? 'individual refunds' 
      : 'batch refunds transactions';
  }

  private calculateScreenWidth(): void {
    this.screenWidth = window.innerWidth;

    // Calculate layout width (80% of screen width)
    const layoutWidth = this.screenWidth * LAYOUT_WIDTH_PERCENTAGE;

    // Container padding, preview section padding, margins and borders
    this.usedWidth = PADDING_MARGINS_TOTAL;

    // Calculate remaining width for table
    this.remainingWidth = layoutWidth - this.usedWidth;

    // Set table width with minimum constraint and buffer
    this.tableWidth = Math.max(MIN_TABLE_WIDTH, this.remainingWidth - TABLE_BUFFER);
  }

  get tableWidthPx(): string {
    return `${this.tableWidth}px`;
  }

  onExportToExcel(): void {
    if (!this.gridData?.length) {
      this.showMessage('No data available to export.', false);
      return;
    }

    const status = this.pageType === 'new' ? 1 : 2;

    this.exportService.exportToExcel(this.individualOrBatch, status).subscribe({
      next: (response: any) => {
        // If using HttpResponse, get count from headers
        let recordCount = this.gridData.length;
        let fileData = response;
        console.log('Export response:', response);
        if (response && response.headers && response.body) {
          // Angular HttpResponse
          const countHeader = response.headers.get('X-TotalTransactions-Count') || response.headers.get('x-TotalTransactions-count');
          console.log('Record count from headers:', countHeader);
          if (countHeader && !isNaN(Number(countHeader))) {
            recordCount = Number(countHeader);
          }
          fileData = response.body;
        }
        this.handleExportSuccess(fileData, recordCount);
      },
      error: (error) => {
        this.handleExportError(error);
      },
    });
  }

  private handleExportSuccess(response: Blob, recordCount: number): void {
    const blob = new Blob([response], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    
    const fileName = this.generateExportFileName();
    this.downloadFile(blob, fileName);

    this.showMessage(
      `${recordCount} transactions exported successfully.`,
      true
    );
  }

  private downloadFile(blob: Blob, fileName: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', fileName);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  private handleExportError(error: any): void {
    this._dialogSvc.hideDialog();
    console.error('Export failed:', error);
    this.showMessage('Export failed. Please try again.', false);
  }

  private generateExportFileName(): string {
    const dateString = new Date().toISOString().split('T')[0];
    return `${this.individualOrBatch}_refunds_${this.pageType}_${dateString}.xlsx`;
  }

  onFileSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const file = target.files?.[0];
    
    if (file) {
      this.selectedFile = file;
      if (this.validateFileType(file)) {
        this.onImportData();
      }
    }
  }

  onImportData(): void {
    if (!this.selectedFile) {
      this.showMessage('Please select a file to import.', false);
      return;
    }

    this.loaderService.show();

    if (this.selectedFile.name.endsWith('.xlsx')) {
      this.processExcelFile();
    }
  }

  private processExcelFile(): void {
    const reader = new FileReader();

    reader.onload = (e: ProgressEvent<FileReader>) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const jsonData = this.extractDataFromWorkbook(workbook);
        this.processImportData(jsonData);
      } catch (error) {
        this.handleFileReadError();
      }
    };
    
    reader.onerror = () => {
      this.handleFileReadError();
    };
    
    reader.readAsArrayBuffer(this.selectedFile!);
  }

  private extractDataFromWorkbook(workbook: XLSX.WorkBook): any[] {
    let jsonData: any[] = [];
    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      // Get the range of the worksheet
      const range = XLSX.utils.decode_range(worksheet['!ref'] || '');
      // If there are at least 2 rows (note + header)
      if (range.e.r >= 1) {
        // Adjust the range to start from the second row (row 1, 0-based)
        const newRange = Object.assign({}, range, { s: { c: range.s.c, r: range.s.r + 1 } });
        // Convert the new range back to Excel ref format
        const newRef = XLSX.utils.encode_range(newRange);
        // Use sheet_to_json with the adjusted range
        const options = { range: newRef };
        jsonData = [...jsonData, ...XLSX.utils.sheet_to_json(worksheet, options)];
      }
    }
    return jsonData;
  }

  private handleFileReadError(): void {
    this.loaderService.hide();
    this.showMessage('Error reading the file. Please try again.', false);
  }

  onConfirmImport(): void {
    const options = {
      title: 'Confirm Import',
      message: `Are you sure you want to import ${this.nonEmptyNewStatusCount} ${this.records}? ${this.importData.length - this.nonEmptyNewStatusCount} records will be skipped due to missing new status.<br/><br/>This action cannot be undone.`,
      cancelText: 'Cancel',
      confirmText: 'Import',
    };

    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {
        this.performImport();
      }
    });
  }

  onCancelImport(): void {
    this.gotoTop();
    this.clearImportData();
    this.loaderService.hide();
  }

  private processImportData(data: any[]): void {
    if (!data?.length) {
      this.loaderService.hide();
      this.showMessage('No valid data found in the file.', false);
      return;
    }

    const processedData = this.convertJsonToCamelCase(data);
    const validData = this.validateImportData(processedData);

    if (!validData.length) {
      this.loaderService.hide();
      this.showMessage(
        'No valid records found. Please check the file format.',
        false
      );
      return;
    }

    this.setupImportPreview(processedData);
  }

  private validateImportData(data: any[]): any[] {
    return data.filter((row) =>
      REQUIRED_IMPORT_FIELDS.every(
        (field) => row[field] || row[field.replace(/([A-Z])/g, ' $1').trim()]
      )
    );
  }

  private setupImportPreview(validData: any[]): void {
    this.importData = validData;
    this.keys = Object.keys(validData[0]);
    this.nonEmptyNewStatusCount = this.importData.filter(
      (item) => item.newStatus && item.newStatus.trim() !== ''
    ).length;
    this.records = this.nonEmptyNewStatusCount > 1 ? 'records' : 'record';

    this.initializeLazyLoading();
    this.showImportPreview = true;

    // Ensure DOM is updated before scrolling
    setTimeout(() => {
      this.scrollservice.triggerScrollToBottom();
    }, 100);
  }

  private validateFileType(file: File): boolean {
    const fileExtension = file.name.toLowerCase().substr(file.name.lastIndexOf('.'));
    
    if (!ALLOWED_FILE_TYPES.includes(fileExtension as any)) {
      this.onCancelImport();
      this.showMessage('Please select a valid Excel file.', false);
      return false;
    }
    
    const fileName = file.name.toLowerCase();
    if (!fileName.includes(this.individualOrBatch) || !fileName.includes(this.pageType)) {
      this.onCancelImport();
      this.showMessage('Please select a valid Excel file.', false);
      return false;
    }
    
    localStorage.setItem('IsChanged', 'true');
    return true;
  }

  private performImport(): void {
    switch (this.individualOrBatch) {
      case 'individual':
        this.onSubmitIndividual();
        break;
      case 'batch':
        this.onSubmitBatch();
        break;
      default:
        console.warn('Unknown import type:', this.individualOrBatch);
        break;
    }
  }

  private showMessage(message: string, isSuccess: boolean): void {
    const data: ImportEmitData = {
      showMsg: true,
      isSuccess: isSuccess,
      message: message,
    };
    this.valueEmitter.emit(data);
    this.gotoTop();
    if(!isSuccess) {
      this.clearImportData();
    }
  }

  private onSubmitIndividual(): void {
    const transactionsStatus = this.buildTransactionStatusArray();

    const transactionAction = {
      transactionsStatus: transactionsStatus,
      userName: this.configService.configData.username,
    };

    this.individualRefundservice
      .transcationsAction(transactionAction)
      .subscribe({
        next: (res: ApiResponseItem[]) => {
          const result = this.processApiResponse(res);
        this.showMessage(result.message, result.isSuccess);
          this.clearImportData();
        },
        error: (error) => {
          console.error('Individual refund submission failed:', error);
          this.showMessage(RESPONSE_MESSAGES.FAILURE, false);
          this.loaderService.hide();
        }
      });
  }

  private onSubmitBatch(): void {
    const batchTransactionsStatus = this.buildTransactionStatusArray();

    const batchTransactionAction = {
      batchTransactionsStatus: batchTransactionsStatus,
      userName: this.configService.configData.username,
    };

    this.batchQueuedtxnservice
      .bulkBatchTransactionAction(batchTransactionAction)
      .subscribe({
        next: (res: BatchApiResponse) => {
          const result = this.processApiResponse(res);
          this.showMessage(result.message, result.isSuccess);
          this.clearImportData();
        },
        error: (error) => {
          console.error('Batch transaction submission failed:', error);
          this.showMessage(RESPONSE_MESSAGES.FAILURE, false);
          this.loaderService.hide();
        }
      });
  }
  private statusStringToNumberString(status: StatusString | string): string {
    const statusMap: Record<string, string> = {
      'new': STATUS_VALUES.NEW,
      'queue': STATUS_VALUES.QUEUE,
      'release': STATUS_VALUES.RELEASE,
      'delete': STATUS_VALUES.DELETE
    };
    
    return statusMap[status?.toString().toLowerCase()] || '';
  }

  // Helper methods to reduce redundancy in onSubmit functions
  private buildTransactionStatusArray(): any[] {
    const transactionsStatus: any[] = [];
    
    this.importData.forEach((node) => {
      const newStatus = this.statusStringToNumberString(
        node.newStatus ? node.newStatus : ''
      );
      
      const shouldProcess = this.shouldProcessTransaction(newStatus);
      if (shouldProcess) {
        const transaction = this.createTransactionObject(node, newStatus);
        transactionsStatus.push(transaction);
      }
    });
    
    return transactionsStatus;
  }

  private shouldProcessTransaction(newStatus: string): boolean {
    return (newStatus !== '' && newStatus !== STATUS_VALUES.NEW && this.pageType === 'new') ||
           (newStatus !== '' && newStatus !== STATUS_VALUES.QUEUE && this.pageType === 'queue');
  }

  private createTransactionObject(node: any, newStatus: string): any {
    if (this.individualOrBatch === 'individual') {
      return {
        TransactionId: node.individualTxnId,
        NewStatus: newStatus,
      };
    } else {
      return {
        batchTransactionRejectId: node.batchTransactionRejectId,
        newStatus: newStatus,
        batchRejectId: node.batchRejectId
      };
    }
  }

  private processApiResponse(res: ApiResponseItem[] | BatchApiResponse): ProcessingResult {
    let successCount = 0;
    let failCount = 0;
    let totalCount = 0;
    
    // Handle different response structures
    const responseArray: ApiResponseItem[] = Array.isArray(res) 
      ? res 
      : res.batchTransactionRejectUpdateStatuses;
    
    if (!responseArray || !Array.isArray(responseArray)) {
      console.error('Invalid API response structure:', res);
      return {
        message: 'Import failed. Please try again.',
        isSuccess: false
      };
    }
    
    responseArray.forEach((row: ApiResponseItem) => {
      totalCount++;
      if (row.updateStatus === Constant.Success) {
        successCount++;
      } else if (row.updateStatus === Constant.Failed) {
        failCount++;
      }
    });

    return this.buildResponseMessage(successCount, failCount, totalCount);
  }

  private buildResponseMessage(successCount: number, failCount: number, totalCount: number): ProcessingResult {
    if (failCount === 0) {
      const successMessage = RESPONSE_MESSAGES.SUCCESS(successCount, totalCount);
      return {
        message: successMessage,
        isSuccess: true
      };
    } else if (successCount > 0) {
      const partialFailureMessage = RESPONSE_MESSAGES.PARTIAL_FAILURE(failCount, totalCount);
      return {
        message: partialFailureMessage,
        isSuccess: false
      };
    } else {
      return {
        message: RESPONSE_MESSAGES.FAILURE,
        isSuccess: false
      };
    }
  }

  splitCamelCaseToTitle(input: string): string {
    // Special cases for specific terms
    if (input.toLowerCase() === 'mcc') return 'MCC';
    if (input.toLowerCase() === 'id') return 'ID';
    
    // Handle (utc) or (UTC) formatting
    if (/\(utc\)/i.test(input)) {
      let formatted = input.replace(/\(utc\)/i, ' (UTC)');
      formatted = formatted.replace(/([a-z0-9])([A-Z])/g, '$1 $2');
      return formatted.replace(/^./, (str) => str.toUpperCase());
    }
    
    return input
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2') // insert space before uppercase
      .replace(/([A-Z])([A-Z][a-z])/g, '$1 $2') // handle acronyms
      .replace(/^./, (str) => str.toUpperCase()); // capitalize first letter
  }

  private toCamelCase(input: string): string {
    return input
      .toLowerCase()
      .split(/[\s_]+/)
      .map((word, index) =>
        index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)
      )
      .join('');
  }

  private convertJsonToCamelCase(input: Array<Record<string, any>>): Array<Record<string, any>> {
    return input.map((item) => {
      const newItem: Record<string, any> = {};
      for (const key in item) {
        const camelKey = this.toCamelCase(key);
        newItem[camelKey] = item[key];
      }
      return newItem;
    });
  }
  private clearImportData(): void {
    this.importData = [];
    this.visibleItems = [];
    this.startIndex = 0;
    this.endIndex = DEFAULT_ITEMS_PER_LOAD;
    this.keys = [];
    this.showImportPreview = false;
    this.selectedFile = null;
    
    this.resetFileInput();
    localStorage.setItem('IsChanged', 'false');
  }

  private resetFileInput(): void {
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
  }

  private gotoTop(): void {
    this.scrollservice.triggerScrollToTop();
  }

  // Lazy loading methods
  private updateVisibleItems(): void {
    this.visibleItems = this.importData.slice(this.startIndex, this.endIndex);
  }

  onTableScroll(event: Event): void {
    const target = event.target as HTMLElement;
    const scrollTop = target.scrollTop;
    const scrollHeight = target.scrollHeight;
    const clientHeight = target.clientHeight;

    // Load more items when scrolled near bottom
    if (scrollTop + clientHeight >= scrollHeight - SCROLL_THRESHOLD) {
      this.loadMoreItems();
    }
  }

  private loadMoreItems(): void {
    if (this.endIndex < this.importData.length) {
      this.endIndex = Math.min(this.endIndex + this.itemsPerLoad, this.importData.length);
      this.updateVisibleItems();
    }
  }

  private initializeLazyLoading(): void {
    this.startIndex = 0;
    this.endIndex = Math.min(this.itemsPerLoad, this.importData.length);
    this.updateVisibleItems();
    
    // Hide global loader once table is ready
    this.loaderService.hide();
  }
}