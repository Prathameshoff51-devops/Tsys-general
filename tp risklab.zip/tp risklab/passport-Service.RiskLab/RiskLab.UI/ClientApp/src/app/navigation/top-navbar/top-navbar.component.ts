import { Component, HostListener, Inject, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ConfigurationService } from '../../shared/services/configuration.service';
import { OKTA_AUTH } from '@okta/okta-angular';
import { OktaAuth, AccessToken } from '@okta/okta-auth-js';
import { IndividualRefundsComponent } from '../../individual-refunds/individual-refunds.component';
import { LoadingDialogService } from '../../ui/service/loading-dialog.service';
@Component({
  selector: 'app-top-navbar',
  templateUrl: './top-navbar.component.html',
  styleUrls: ['./top-navbar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TopNavbarComponent implements OnInit { 
  
  @Input() userName?: string;
  @Input() isAuthenticated?: boolean;   
  isSuccess: boolean = true; 
  risklab_header =false;
  constructor(private router: Router, @Inject(OKTA_AUTH) private oktaAuth: OktaAuth,private _dialogSvc: LoadingDialogService){

   }
  ngOnInit(): void {
  }  
  @HostListener("document:scroll")
  scrollfunction()
  {
    if(document.documentElement.scrollTop >0)
    {  
    this.risklab_header = true;   
    }
}
  Dirtychk(e)
  {
    if(localStorage.getItem("IsChanged") == 'true')
    {
      localStorage.removeItem("IsChanged");
      localStorage.getItem("IsChanged") == 'false'
      const options = {
        title: 'Leave this page?',
        message: 'Changes you made may not be saved.',
        cancelText: 'Stay',
        confirmText: 'Leave',
      };
      this.isSuccess = true;
      this._dialogSvc.openDialog(options);     
      e.preventDefault();    
      this._dialogSvc.confirmed().subscribe(
        (confirmed: any) => {
          if (confirmed) {
        localStorage.removeItem("IsChanged");
        localStorage.setItem("IsChanged",'false');
        // Refresh the current route using Angular Router
        this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
          this.router.navigate([this.router.url]);
        });
        }
        else
        {
          localStorage.setItem("IsChanged",'true');
        }      
      });       
    }    
  }
  

  async logout() {  
      
    await this.oktaAuth.signOut({
      revokeAccessToken: true,        
    }).then(() => {
      localStorage.removeItem('IsChanged');      
    }
    ).catch((err) => {
      console.log(err);
      alert(err);
    }
    );
    
  }
  
}
