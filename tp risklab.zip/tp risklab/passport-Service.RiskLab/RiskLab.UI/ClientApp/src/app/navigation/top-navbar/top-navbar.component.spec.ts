import { ComponentFixture, TestBed } from "@angular/core/testing";
import { MatMenuModule } from "@angular/material/menu";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { OKTA_AUTH } from "@okta/okta-angular";
import { of } from "rxjs";
import { ConfigurationService } from "src/app/shared/services/configuration.service";
import { LoadingDialogService } from "src/app/ui/service/loading-dialog.service";

import { TopNavbarComponent } from "./top-navbar.component";

describe("TopNavbarComponent", () => {
  let component: TopNavbarComponent;
  let fixture: ComponentFixture<TopNavbarComponent>;
  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["existsMenuByField", "loadConfigurationData", "getMenuByField"]
  );
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation"),
    navigateByUrl: jasmine.createSpy("navigateByUrl"),
    url: "/secure"
  };
  const mockFakeActivatedRoute = {
    snapshot: {
      data: {}
    }
  };

  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const sessionSpy = jasmine.createSpyObj(["exists", "setCookieAndRedirect"]);
  let oktaAuthSpy = jasmine.createSpyObj(
    "OktaAuth",
    ["signInWithCredentials", "signOut"],
    {
      session: sessionSpy
    }
  );

  beforeEach(async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    await TestBed.configureTestingModule({
      imports: [MatMenuModule],
      declarations: [TopNavbarComponent],
      providers: [
        {
          provide: ConfigurationService,
          useValue: mockConfigurationService
        },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockFakeActivatedRoute },
        { provide: OKTA_AUTH, useValue: oktaAuthSpy, multi: false },
        {
          provide: LoadingDialogService,
          useValue: mockLoadingDialogService
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TopNavbarComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it("should create", () => {
    component.scrollfunction();
    expect(component).toBeTruthy();
  });
  it("should Called Dirtychk", () => {
    let e = jasmine.createSpyObj("e", ["preventDefault"]);
    localStorage.setItem("IsChanged", "true");
    component.Dirtychk(e);
    expect(localStorage.getItem("IsChanged")).toEqual("true");
  });
  it("should Called logout", async () => {
    oktaAuthSpy.signOut.and.returnValue(Promise.resolve(true));
    await component.logout();
    expect(localStorage.getItem("IsChanged")).toEqual(null);
  });
  it("should Called logout", async () => {
    spyOn(window, "alert");
    oktaAuthSpy.signOut.and.returnValue(Promise.reject(false));
    await component.logout();
    expect(alert).toHaveBeenCalledOnceWith(false);
  });
  it("should not set risklab_header if scrollTop is 0", () => {
    const originalScrollTop = Object.getOwnPropertyDescriptor(document.documentElement, 'scrollTop');
    Object.defineProperty(document.documentElement, 'scrollTop', { value: 0, configurable: true });
    component.risklab_header = false;
    component.scrollfunction();
    expect(component.risklab_header).toBe(false);
    // Restore original property
    if (originalScrollTop) {
      Object.defineProperty(document.documentElement, 'scrollTop', originalScrollTop);
    }
  });
  it("should set risklab_header if scrollTop is greater than 0", () => {
    const originalScrollTop = Object.getOwnPropertyDescriptor(document.documentElement, 'scrollTop');
    Object.defineProperty(document.documentElement, 'scrollTop', { value: 10, configurable: true });
    component.risklab_header = false;
    component.scrollfunction();
    expect(component.risklab_header).toBe(true);
    // Restore original property
    if (originalScrollTop) {
      Object.defineProperty(document.documentElement, 'scrollTop', originalScrollTop);
    }
  });

  it("should not call dialog if IsChanged is not true in Dirtychk", () => {
    let e = jasmine.createSpyObj("e", ["preventDefault"]);
    localStorage.setItem("IsChanged", "false");
    mockLoadingDialogService.openDialog.calls.reset();
    component.Dirtychk(e);
    expect(mockLoadingDialogService.openDialog).not.toHaveBeenCalled();
    expect(e.preventDefault).not.toHaveBeenCalled();
  });

  it("should handle Dirtychk dialog confirmed false", () => {
    let e = jasmine.createSpyObj("e", ["preventDefault"]);
    localStorage.setItem("IsChanged", "true");
    mockLoadingDialogService.openDialog.calls.reset();
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component.Dirtychk(e);
    expect(localStorage.getItem("IsChanged")).toBe("true");
    expect(e.preventDefault).toHaveBeenCalled();
  });
  
it("should navigate to refresh route when Dirtychk dialog confirmed true", (done) => {
  let e = jasmine.createSpyObj("e", ["preventDefault"]);
  localStorage.setItem("IsChanged", "true");
  mockLoadingDialogService.openDialog.calls.reset();
  mockLoadingDialogService.confirmed.and.returnValue(of(true));
  mockRouter.navigateByUrl.and.returnValue(Promise.resolve(true));
  mockRouter.navigate.and.returnValue(Promise.resolve(true));

  component.Dirtychk(e);

  setTimeout(() => {
    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(e.preventDefault).toHaveBeenCalled();
    expect(mockRouter.navigateByUrl).toHaveBeenCalledWith('/', { skipLocationChange: true });
    expect(mockRouter.navigate).toHaveBeenCalledWith([mockRouter.url]);
    done();
  }, 0);
});

});
