import { Component, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { AgRendererComponent } from 'ag-grid-angular';
import { Constants } from 'src/app/Constants';

@Component({
  template:
  '<a [routerLink]="[\'/\']" target="_blank" (contextmenu)="onRightClick(params.inRouterLink)" (click)="navigate(params.inRouterLink)">{{params.value}}</a>',
})
export class RouterLinkRendererComponent implements AgRendererComponent {
  params: any;

  constructor(private ngZone: NgZone, private router: Router) { }

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params: any): boolean {
    return false;
  }


  navigate(link) {

    if (link === Constants.batchNewTxnRejectsPage) {
      localStorage.setItem(Constants.batchRejectIdforNewDrillDown, this.params.data.batchRejectId.toString());
    }

   else if (link === Constants.batchQueuedTxnRejectsPage) {
      localStorage.setItem(Constants.batchRejectIdforQueuedDrillDown, this.params.data.batchRejectId.toString());
    }
  }
  onRightClick(link) {
    if (link === Constants.batchNewTxnRejectsPage) {
      localStorage.setItem(Constants.batchRejectIdforNewDrillDown, this.params.data.batchRejectId.toString());
    }
  
   else if (link === Constants.batchQueuedTxnRejectsPage) {
      localStorage.setItem(Constants.batchRejectIdforQueuedDrillDown, this.params.data.batchRejectId.toString());
    }
  
    setTimeout(function() { localStorage.removeItem(Constants.batchRejectIdforNewDrillDown); 
      localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown); }, (10000));
  }
}
