import {
  Component,
  Injector,
  Input,
  OnInit,
  ViewEncapsulation,
} from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { NavItem } from '../../ui/model/nav-item';
import { menu } from '../../ui/model/menu';
import { BaseComponent } from '../../shared/base.component';
import { MenuItem } from '../../shared/models/menu-item.model';
import { flatMap, filter } from 'rxjs/operators';

@Component({
  selector: 'app-side-navbar',
  templateUrl: './side-navbar.component.html',
  styleUrls: ['./side-navbar.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class SideNavbarComponent extends BaseComponent implements OnInit {
  @Input() isAuthenticated?: boolean;
  @Input() sideNavBarFlag?: boolean;
  @Input() environment?: string;
  
  isOpen: boolean = true;
  constructor(private router: Router, injector: Injector) {
    super(injector);
  }
  ngOnInit(): void {
    this.configData.then((res) => {
      this.menuItems = res.menu.map((m) => new MenuItem(m));
      this.menuItems.forEach((x) => {
        x.childrenMenuItems?.forEach((y, index) => { });
      });
      console.log(this.currentRoutePath);
      if (
        this.configService.existsMenuByField(
          'link',
          this.currentRoutePath,
          null
        )
      ) {
        this.selectItem('link', this.currentRoutePath, this.menuItems);
      }
    });
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((val: NavigationEnd) => {
        this.currentRoutePath = val.url;
        this.configData.then((res) => {
          this.menuItems = res.menu.map((m) => new MenuItem(m));
          this.menuItems.forEach((x) => {
            x.childrenMenuItems?.forEach((y, index) => { });
          });

          if (
            this.configService.existsMenuByField(
              'link',
              this.currentRoutePath,
              null
            )
          ) {
            this.selectItem('link', this.currentRoutePath, this.menuItems);
          }
        });
      });
  }

  onItemSelected(item: MenuItem) {
    event?.preventDefault();
    if (!item.childrenMenuItems || !item.childrenMenuItems.length) {
      this.router.navigate([item.route]);
    }
  }
  toggleNav() {
    this.isOpen = !this.isOpen;
  }
}
