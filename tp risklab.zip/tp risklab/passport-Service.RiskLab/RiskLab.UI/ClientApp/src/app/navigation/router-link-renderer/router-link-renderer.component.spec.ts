import { RouterLinkRendererComponent } from './router-link-renderer.component';
import { Constants } from 'src/app/Constants';

describe('RouterLinkRendererComponent', () => {
  let component: RouterLinkRendererComponent;
  let mockRouter: any;
  let mockNgZone: any;

  beforeEach(() => {
    mockRouter = {};
    mockNgZone = { run: (fn: Function) => fn() };
    component = new RouterLinkRendererComponent(mockNgZone, mockRouter);
    component.params = { data: { batchRejectId: 123 } };
    localStorage.clear();
    jasmine.clock().install();
  });

  afterEach(() => {
    jasmine.clock().uninstall();
    localStorage.clear();
  });

  it('should Called (batchQueuedTxnRejectsPage)', () => {
    component.navigate(Constants.batchQueuedTxnRejectsPage);
    expect(localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)).toBe('123');
    expect(localStorage.getItem(Constants.batchRejectIdforNewDrillDown)).toBeNull();
    
  });

  it('should Called (batchNewTxnRejectsPage)', () => {
    component.navigate(Constants.batchNewTxnRejectsPage);
    expect(localStorage.getItem(Constants.batchRejectIdforNewDrillDown)).toBe('123');
    expect(localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)).toBeNull();
  });

  it('should set and remove localStorage items after 10 seconds on right click (batchQueuedTxnRejectsPage)', () => {
    component.onRightClick(Constants.batchQueuedTxnRejectsPage);
    expect(localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)).toBe('123');
    expect(localStorage.getItem(Constants.batchRejectIdforNewDrillDown)).toBeNull();
    jasmine.clock().tick(10000);
    expect(localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)).toBeNull();
    expect(localStorage.getItem(Constants.batchRejectIdforNewDrillDown)).toBeNull();
  });

  it('should set and remove localStorage items after 10 seconds on right click (batchNewTxnRejectsPage)', () => {
    component.onRightClick(Constants.batchNewTxnRejectsPage);
    expect(localStorage.getItem(Constants.batchRejectIdforNewDrillDown)).toBe('123');
    expect(localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)).toBeNull();
    jasmine.clock().tick(10000);
    expect(localStorage.getItem(Constants.batchRejectIdforNewDrillDown)).toBeNull();
    expect(localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown)).toBeNull();
  });
});
