import {
  HttpClientTestingModule,
  HttpTestingController
} from "@angular/common/http/testing";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { ConfigurationService } from "src/app/shared/services/configuration.service";
import { of } from "rxjs";
import { SideNavbarComponent } from "./side-navbar.component";
import { MenuItem } from "src/app/shared/models/menu-item.model";
import { ConstantsUnitTest } from "src/app/constant.unit.test";
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("SideNavbarComponent", () => {
  let component: SideNavbarComponent;
  let fixture: ComponentFixture<SideNavbarComponent>;
  let httpTestingController: HttpTestingController;
  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["existsMenuByField", "loadConfigurationData", "getMenuByField", "existsMenuByFieldInSubMenu"]
  );
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };
  const mockFakeActivatedRoute = {
    snapshot: {
      data: {}
    }
  };
  
  beforeEach(async () => {
    mockConfigurationService.loadConfigurationData.and.returnValue(
      Promise.resolve(ConstantsUnitTest.configData)
    );
    mockConfigurationService.getMenuByField.and.returnValue(
      Promise.resolve(ConstantsUnitTest.configData.menu[0])
    );
    mockConfigurationService.existsMenuByField.and.returnValue(true);
    mockConfigurationService.existsMenuByFieldInSubMenu.and.returnValue(true);
    
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [SideNavbarComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockFakeActivatedRoute },
        provideHttpClient(withInterceptorsFromDi()),
    ]
}).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SideNavbarComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  // Test for @Input properties
  it('should accept isAuthenticated input', () => {
    component.isAuthenticated = true;
    expect(component.isAuthenticated).toBe(true);
    
    component.isAuthenticated = false;
    expect(component.isAuthenticated).toBe(false);
  });

  it('should accept sideNavBarFlag input', () => {
    component.sideNavBarFlag = true;
    expect(component.sideNavBarFlag).toBe(true);
    
    component.sideNavBarFlag = false;
    expect(component.sideNavBarFlag).toBe(false);
  });

  it('should accept environment input', () => {
    const testEnvironment = 'Production';
    component.environment = testEnvironment;
    expect(component.environment).toBe(testEnvironment);
  });

  // Test for isOpen property
  it('should initialize isOpen as true', () => {
    expect(component.isOpen).toBe(true);
  });

  // Test toggleNav functionality
  it('should toggle isOpen from true to false', () => {
    component.isOpen = true;
    component.toggleNav();
    expect(component.isOpen).toBe(false);
  });

  it('should toggle isOpen from false to true', () => {
    component.isOpen = false;
    component.toggleNav();
    expect(component.isOpen).toBe(true);
  });

  // Test onItemSelected functionality
  it('should navigate when item has no children', () => {
    mockRouter.navigate.calls.reset();
    const item = new MenuItem(ConstantsUnitTest.configData.menu[1]);
    item.childrenMenuItems = undefined;
    item.route = '/test-route';
    
    component.onItemSelected(item);
    
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/test-route']);
  });

  it('should navigate when item has empty children array', () => {
    mockRouter.navigate.calls.reset();
    const item = new MenuItem(ConstantsUnitTest.configData.menu[1]);
    item.childrenMenuItems = [];
    item.route = '/test-route';
    
    component.onItemSelected(item);
    
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/test-route']);
  });

  it('should not navigate when item has children', () => {
    mockRouter.navigate.calls.reset();
    const item = new MenuItem(ConstantsUnitTest.configData.menu[1]);
    item.childrenMenuItems = [new MenuItem(ConstantsUnitTest.configData.menu[0])];
    
    component.onItemSelected(item);
    
    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });

  it('should call preventDefault if event is present in onItemSelected', () => {
    const item = new MenuItem(ConstantsUnitTest.configData.menu[1]);
    const event = { preventDefault: jasmine.createSpy('preventDefault') };
    // @ts-ignore
    window.event = event;
    
    component.onItemSelected(item);
    
    expect(event.preventDefault).toHaveBeenCalled();
    // Clean up
    // @ts-ignore
    window.event = undefined;
  });

  // Test ngOnInit functionality
  it('should load menu items and set current route path on ngOnInit', async () => {
    const selectSpy = spyOn(component, 'selectItem');
    await component.ngOnInit();
    
    expect(component.menuItems).toBeDefined();
    expect(component.menuItems.length).toBeGreaterThan(0);
    expect(selectSpy).toHaveBeenCalled();
  });

  it('should not call selectItem if existsMenuByField returns false', async () => {
    mockConfigurationService.existsMenuByField.and.returnValue(false);
    const selectSpy = spyOn(component, 'selectItem');
    
    await component.ngOnInit();
    
    expect(selectSpy).not.toHaveBeenCalled();
  });

  it('should handle router navigation events', async () => {
    const selectSpy = spyOn(component, 'selectItem');
    await component.ngOnInit();
    
    // Router events should trigger selectItem
    expect(selectSpy).toHaveBeenCalled();
  });

  // Test component lifecycle
  it('should implement OnInit interface', () => {
    expect(component.ngOnInit).toBeDefined();
    expect(typeof component.ngOnInit).toBe('function');
  });

  // Test error handling
  it('should handle null menu items gracefully', async () => {
    mockConfigurationService.loadConfigurationData.and.returnValue(
      Promise.resolve({ menu: null })
    );
    
    expect(() => component.ngOnInit()).not.toThrow();
  });

  it('should handle items without childrenMenuItems property', () => {
    const item = new MenuItem(ConstantsUnitTest.configData.menu[1]);
    delete item.childrenMenuItems;
    
    expect(() => component.onItemSelected(item)).not.toThrow();
  });
});
