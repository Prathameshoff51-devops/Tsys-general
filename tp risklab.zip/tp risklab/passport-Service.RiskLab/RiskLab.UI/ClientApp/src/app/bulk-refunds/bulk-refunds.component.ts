import { HttpStatusCode } from '@angular/common/http';
import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import {
  GridApi,
  GridOptions,
  GridReadyEvent,
  PaginationChangedEvent,
} from 'ag-grid-community';
import { Observable } from 'rxjs';
import { RouterLinkRendererComponent } from '../navigation/router-link-renderer/router-link-renderer.component';
import { Constant } from '../shared/constant';
import { RejectStatuses } from '../shared/enums';
import { BatchRefund } from '../shared/models/batch-refund.model';
import { Configuration } from '../shared/models/configuration.model';
import { BatchRefundSevice } from '../shared/services/batch-refund.service';
import { ConfigurationService } from '../shared/services/configuration.service';
import { DropDownListRendererComponent } from '../ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import * as signalR from '@microsoft/signalr';
import { Constants } from '../Constants';

@Component({
  selector: 'app-bulk-refunds',
  templateUrl: './bulk-refunds.component.html',
  styleUrls: ['./bulk-refunds.component.css'],
  providers: [BatchRefundSevice],
})
export class BulkRefundsComponent implements OnInit, OnDestroy {
  documentSaveDialog: any; 
  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    if (localStorage.getItem('IsChanged') == 'true') {
      event.preventDefault();
      event.returnValue = 'Are you sure you want to reset the changes?';
    }
    return event;
  }

  batchRefund: BatchRefund[] = null;
  recordCount: number;
  showRefreshButton: boolean = false;
  context: any;
  SearchText: any;
  public gridOptions: GridOptions;
  gridApiActive: GridApi;
  public rowSelection;
  public paginationPageSize = 1;
  public paginationNumberFormatter: any;
  config!: Configuration;
  public daysToAct = Constant.DaysToActs;
  overlayNoRowsTemplate = 'No records to display.';
  disabled: boolean;
  showMsg: boolean = false;
  isSuccess: boolean = true;
  message: string;
  public riskLabUrl!: string;
  public signalrNotificationEndpoint!: string;
  private connection: signalR.HubConnection;

  constructor(
    public configService: ConfigurationService,
    private batchRefundSrvice: BatchRefundSevice,
    private dialogService: LoadingDialogService  
  ) {
    this.disabled = true;
    this.config = this.configService.config;
    this.riskLabUrl = this.configService.configData.riskLabApiUrl;
    this.signalrNotificationEndpoint = this.riskLabUrl + "/notification";
    if (
      this.config.defaultGridPageSize != undefined &&
      this.config.daysToAct != undefined
    ) {
      this.paginationPageSize = this.config.defaultBatchGridPageSize;
      this.daysToAct = this.config.daysToAct;
    }
    this.gridApiActive = new GridApi();
    this.context = {
      componentParent: this,
      daysToAct: this.daysToAct,
    };

    this.gridOptions = {
      components: {
        DropDownListRenderer: DropDownListRendererComponent,
      },


      columnDefs: [
        {
          headerName: 'Action',
          field: 'actionDropdown',
          editable: false,
          lockPosition: true,
          pinned: 'left',
          lockPinned: true,
          cellRenderer: 'DropDownListRenderer',
          minWidth: 130,
          maxWidth:130,
          cellStyle: this.changeRowColor,
          cellRendererParams: {
            values: [
              { id: 1, name: 'Select Action' },
              {
                id: 2,
                name: 'Queue',
              },
              { id: 3, name: 'Release' },
              { id: 4, name: 'Delete' },
            ],
          },
        },
        {
          headerName: 'Original Batch Number',
          resizable: true,
          minWidth: 160,
          field: 'batchNumber',
          sortable: true,
          cellRenderer: RouterLinkRendererComponent,
          cellRendererParams: {
            inRouterLink: Constants.batchNewTxnRejectsPage,
          },
          cellStyle: this.changeRowColor,
          cellClass: function (params) {
            if (params.data.daysToAct <= params.context.daysToAct) {
              return '#ffe6e6';
            } else {
              return 'anchorTagBlue';
            }
          },
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Merchant Number',
          resizable: true,
          minWidth: 140,
          field: 'merchantNumber',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Merchant Name',
          minWidth: 135,
          resizable: true,
          field: 'merchantName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Legal Name',
          minWidth: 150,
          resizable: true,
          field: 'legalName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Processing Chain ID',
          minWidth: 175,
          field: 'chainOID',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'MCC',
          field: 'mcc',
          resizable: true,
          minWidth: 60,
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Batch Amount',
          resizable: true,
          minWidth: 110,
          field: 'batchAmount',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.currencyFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Count',
          minWidth: 110,
          resizable: true,
          field: 'refundCount',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Create Date (UTC)',
          resizable: true,
          minWidth: 154,
          field: 'txnDateUTC',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          sort: 'asc',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Reject Reasons',
          field: 'rejectReasons',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 200,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Close Date (UTC)',
          resizable: true,
          minWidth: 150,
          field: 'batchCloseDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Submitter',
          resizable: true,
          minWidth: 80,
          field: 'submitterIdDescription',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },

        {
          headerName: 'Days to Act',
          minWidth: 90,
          field: 'daysToAct',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
      ],
    };
    this.paginationNumberFormatter = function (params: any) {
      return params.value.toLocaleString();
    };

    
this.overlayNoRowsTemplate =
'<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
  }

  parentMethod() {
    this.PendingChangesCheck();
    var flag: boolean = true;
    this.gridApiActive.forEachNode((node) => {
      if (node.selectable && node.displayed) {
        if (!node.data.hasOwnProperty('action')) {
          flag = false;
        } else if (node.data.action == 1) {
          flag = false;
        }
      }
    });
    if (flag == true) {
      this.disabled = false;
    } else {
      this.disabled = true;
    }
  }

  ngOnInit(): void {
    this.connectHub();
    this.fetchBatchRejects();
  }

  dateFormatter(data) {
    return data.value ? data.value.replace('T', ' ').replace('Z', '') : '';
  }

  currencyFormatter(params: any) {
    return "$" + params.value.toFixed(2);
  }
  
  changeRowColor(params) {
    if (params.data.daysToAct <= params.context.daysToAct) {
     return { backgroundColor: '#ffe6e6' };
    } else {
      return null;
    }
  }
  countDisplayedRows(params) {
    this.recordCount = params.api.paginationGetRowCount();
  }
  onFirstDataRendered(params: GridReadyEvent) {
    params.api.paginationGoToPage(0);
  }
  resetPaginationSelection = (self) => {
    self.gridApiActive.deselectAll();

    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount)
      currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      let isWithinCurrentPage =
        i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.gridApiActive
        .getDisplayedRowAtIndex(i)
        .setRowSelectable(isWithinCurrentPage);
    }
  };

  ResetSearch() {
    this.gridApiActive.setQuickFilter(null);
    this.SearchText = '';
  }

  onPaginationChanged(params: PaginationChangedEvent) {
    this.gridApiActive = params.api;
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
         node.data['action'] = 1;
        this.disabled = true;
      }
    });
    if (typeof this.SearchText !== 'undefined' && this.SearchText) {
      localStorage.setItem('IsChanged', 'true');
    } else {
      localStorage.setItem('IsChanged', 'false');
    }
  }

  OnFilterBoxChanged() {
  //  setTimeout((gridApiActive) => {
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
          node.data['action'] = 1;
      }
    });
  //  }, 500);
    this.gridApiActive.setQuickFilter(this.SearchText);
    this.disabled = true;
    this.gridApiActive.refreshCells({ force: true });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {      
      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }
  }

  onGridReady(params: any) {
    this.gridOptions.suppressNoRowsOverlay = true;
    this.gridApiActive = params.api;
    params.api.setDomLayout('autoHeight');
    this.gridApiActive.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {     
      this.gridApiActive.showNoRowsOverlay();
    } else {
      this.gridApiActive.hideOverlay();
    }
    this.gridApiActive.sizeColumnsToFit();
  }

  fetchBatchRejects() {
    this.batchRefundSrvice
      .getBatchRefunds(RejectStatuses.New)
      .subscribe((response: BatchRefund[]) => {
        this.recordCount = response?.length;
        try {
          this.batchRefund = response;
          this.batchRefund.forEach(x => {
            x.action = 1;
          });
        } catch (ex) {
          console.log('error : ' + ex);
        }
      });
    this.disabled = true;
    this.showRefreshButton = false;
  }

  onSubmit() {
    const options = {
      title: 'Confirm!',
      message: 'Are you sure you want to submit?',
      cancelText: 'No',
      confirmText: 'Yes',
    };
    this.isSuccess = true;
    this.dialogService.openDialog(options);
    this.dialogService.confirmed().subscribe(
      (confirmed: any) => {
        if (confirmed) {
          let batchAction;
          this.gridApiActive.forEachNode((node) => {
            if (node.selectable && node.displayed) {
              batchAction = {
                batchRejectId: node.data.batchRejectId,
                newStatus: node.data.action.toString(),
              };
            }
          });
          (batchAction.userName = this.configService.configData.username),
            //  API call to save modified row
            this.batchRefundSrvice.batchAction(batchAction).subscribe(
              (response: any) => {
                if (response.updateStatus === Constant.Success) {
                  this.message = 'Batch updated successfully.';
                  this.fetchBatchRejects();
                } else {
                  console.log(response);
                  this.message = 'Batch update failed.';
                  this.isSuccess = false;
                  this.fetchBatchRejects();
                }

                this.showMessage();
                localStorage.setItem('IsChanged', 'false');
              },
              (error) => {
                console.error('error caught in /batch post' + error);
              }
            );
        }
      },
      (reason: any) => {
        console.log('Dismissed ' + reason);
      }
    );
  }
  private showMessage() {
    this.showMsg = true;
    this.FadeOutSuccessMsg();
    this.ResetSearch();
  }

  FadeOutSuccessMsg() {
    setTimeout(() => {
      this.showMsg = false;
    }, 10000);
  }
  PendingChangesCheck() {
    localStorage.setItem("IsNotAllSelected",'true');
    this.gridApiActive.forEachNode((node) => {
      if ((node.data.hasOwnProperty('action'))&& (node.data.action != 1)){
        localStorage.setItem("IsChanged",'true');
        localStorage.setItem("IsNotAllSelected",'false');
        return;
      }

     else if((node.data.action == 1))
      {
        if(localStorage.getItem("IsChanged")!= 'true')
        {
        localStorage.setItem("IsChanged",'false');
        }
        else if((localStorage.getItem("IsNotAllSelected") == 'true') && (node.data.action == 1))
        {
          localStorage.setItem("IsChanged",'false');
        }
      }
    });
  }
  onRefreshButtonClick() {
    const options = {
      title: "Confirm!",
      message: "Unsaved actions will get reset, continue with refresh?",
      cancelText: "No",
      confirmText: "Yes"
    };
    this.dialogService.openDialog(options);
    this.dialogService.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {
        this.fetchBatchRejects();
        this.ResetSearch();
        this.showRefreshButton = false;
      }
    });
  }
  connectHub() {
    this.disconnectHub();
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.signalrNotificationEndpoint)
        .withAutomaticReconnect()
        .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.on("NotifyNewBatchRejectsTab", (response) => {

      if(!this.showRefreshButton)
        this.showRefreshButton = true;
      });

      this.connection
        .start().then(function () {
          console.info("connected to signalr...")
        })
        .catch(err => console.error(err));
    }
  }

  disconnectHub() {
    if (this.connection) {
      this.connection.stop();
      this.connection = null;
    }
  }

  ngOnDestroy(): void {
    this.disconnectHub();
  }

  receiveData(data: { showMsg: boolean; isSuccess: boolean; message: string }) {
    this.message = data.message;
    this.showMsg = data.showMsg;
    this.isSuccess = data.isSuccess;
    this.fetchBatchRejects(); // Refresh the data after import/export
    this.FadeOutSuccessMsg();
  }
}
