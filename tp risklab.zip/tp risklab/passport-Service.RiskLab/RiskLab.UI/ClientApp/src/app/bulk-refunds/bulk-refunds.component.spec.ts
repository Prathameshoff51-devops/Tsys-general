
import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick
} from "@angular/core/testing";

import { BulkRefundsComponent } from "./bulk-refunds.component";
import { ConfigurationService } from "../shared/services/configuration.service";
import { AppConfig } from "../shared/models/app-config";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { DebugElement } from "@angular/core";
import { AgGridModule } from "ag-grid-angular";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { of, throwError } from "rxjs";
import { BatchRefundSevice } from "../shared/services/batch-refund.service";
import { NavigationEnd, Router } from "@angular/router";
import { BatchRefund } from "../shared/models/batch-refund.model";
import { ConstantsUnitTest } from "../constant.unit.test";
import * as signalR from '@microsoft/signalr';
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("BulkRefundsComponent", () => {
  let component: BulkRefundsComponent;
  let fixture: ComponentFixture<BulkRefundsComponent>;
  let el: DebugElement;
  let httpTestingController: HttpTestingController;
  let mockHubConnection: jasmine.SpyObj<signalR.HubConnection>;
  let batchRefundService: BatchRefundSevice;
  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["configData"]
  );
  Object.defineProperty(mockConfigurationService, 'config', {
    get: () => {
      return {
        DefaultGridPageSizeforBatchTxnRejects: 10,
        daysToAct: 10,
        defaultGridPageSize : 1,
        defaultBatchGridPageSize:1
      };
    },
    configurable: true
  });
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };

  // Mock Configuration object for tests
  const mockConfig = {
    environment: 'test',
    defaultGridPageSize: 10,
    defaultBatchGridPageSize: 10,
    defaultBackOfficeGridPageSize: 10,
    apiUrl: 'http://localhost',
    apiHeader: 'header',
    clientId: 'client',
    issuer: 'issuer',
    redirectUri: 'redirect',
    scopes: ['scope1'],
    logoutUrl: 'logout',
    daysToAct: 5,
    defaultGridPageSizeOptions: [10, 20, 50],
    username: 'test',
    riskLabApiUrl: 'http://localhost',
    config: {},
    configData: {},
    DefaultGridPageSizeforBatchTxnRejects: 10,
    minimumSearchLength: 3,
    coreloggingServiceUrl: 'http://localhost/log',
    threadId: 1,
    appInsightsKey: 'key',
    appVersion: '1.0.0',
    appName: 'RiskLab',
    riskLabUiUrl: 'http://localhost/ui',
    menu: [],
    isBackOfficeUser: false,
    isFraudServiceUser: false,
  };
  const apiReponse: BatchRefund[] = [
    {
      batchRejectId: 17,
      batchNumber: "1234",
      merchantNumber: "650000002446493",
      merchantName: "Test Merchant",
      batchAmount: 120.234,
      refundCount: 0,
      txnDateUTC: "2022-09-08T00:00:00",
      daysToAct: -39,
      batchCloseDate: "2022-09-08T00:00:00",
      status: "New",
      canTakeBatchAction: true,
      mcc: "5814",
      submitterIDDescription: "Exchange",
      rejectReasons: [
        "Batch refund threshold limit exceeded",
        "Merchant refund threshold limit exceeded"
      ],
      legalName: "NATOLI ENTERPRISES INC.",
      chainOID: null,
      action: 2
    },
    {
      batchRejectId: 54,
      batchNumber: "102030",
      merchantNumber: "650000012036045",
      merchantName: "ANTHONY JACKSON",
      batchAmount: 200,
      refundCount: 2,
      txnDateUTC: "2023-01-12T08:22:26.047",
      daysToAct: 50,
      batchCloseDate: "2023-01-12T08:22:26.047",
      status: "New",
      mcc: "5814",
      submitterIDDescription: "Exchange",
      canTakeBatchAction: false,
      rejectReasons: ["Merchant refund threshold limit exceeded"],
      legalName: "NATOLI ENTERPRISES INC.",
      chainOID: null,
      action: 2
    }
  ];
  const bodytranscationsAction = {
    batchRejectId: 54,
    newStatus: "3",
    userName: "Nikhil.Akole"
  };
  const transcationsActionResponse = {
    batchRejectId: 54,
    updateStatus: "Success",
    statusCode: "200"
  };
  const transcationsActionResponseAllFailed = {
    batchRejectId: 54,
    updateStatus: "Failed",
    statusCode: "200"
  };

  beforeEach(async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    mockHubConnection = jasmine.createSpyObj('HubConnection', ['start', 'stop', 'on']);
    // Ensure .start always returns a Promise to avoid TypeError on .then
    mockHubConnection.start.and.returnValue(Promise.resolve());



    // Mock the builder chain using prototype spies
    spyOn(signalR.HubConnectionBuilder.prototype, 'withUrl').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'withAutomaticReconnect').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'configureLogging').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'build').and.returnValue(mockHubConnection);
    await TestBed.configureTestingModule({
    declarations: [BulkRefundsComponent],
    imports: [AgGridModule],
    providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        BatchRefundSevice,
        {
            provide: LoadingDialogService,
            useValue: mockLoadingDialogService
        },
        { provide: Router, useValue: mockRouter },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();

    fixture = TestBed.createComponent(BulkRefundsComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    batchRefundService = TestBed.inject(BatchRefundSevice);
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it(`should have config paginationPageSize be 1`, () => {
    component.config.defaultGridPageSize = 1;
    component.config.daysToAct = 10;
    expect(component.daysToAct).toEqual(10);
    expect(component.paginationPageSize).toEqual(1);
  });
  it(`should have beforeunloadHandler`, () => {
    localStorage.setItem("IsChanged", "true");
    let event = {
      returnValue: "abc",
      preventDefault() { }
    };
    component.beforeunloadHandler(event);
    expect(event.returnValue).toBe(
      "Are you sure you want to reset the changes?"
    );
  });
  it(`should have called changeRowColor`, () => {
    let params = {
      data: {
        daysToAct: 10
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color.backgroundColor).toEqual('#ffe6e6' );
  });
  it("should called fetchData ", async () => {
    const req = httpTestingController.expectOne(
      "https://localhost:7247/BatchRejects?status=1"
    );
    req.flush(apiReponse); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
  });
  it("should be called resetPaginationSelection ", async () => {
    component.config.defaultGridPageSize = 1;
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToFirstPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToNextPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
  });
  it("should be transcations successfully update ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToNextPage();
    component.batchRefund[1].action = 3;

    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponse);
    expect(component.message).toEqual("Batch updated successfully.");
  });
  it("should be transcations failed update ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.gridApiActive.paginationGoToNextPage();
    component.batchRefund[1].action = 3;
    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseAllFailed);
    expect(component.message).toEqual("Batch update failed.");
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should be transcations failed ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.batchRefund[1].action = 3;
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component.onSubmit();
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should getDisplayedRowCount be 1 after SearchText ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "102030";
    jasmine.clock().install();
    component.OnFilterBoxChanged();
    jasmine.clock().tick(500);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(1);
    jasmine.clock().uninstall();
  });
  it("should getDisplayedRowCount be 2 after SearchText empty", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.SearchText = "";
    component.OnFilterBoxChanged();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(2);
  });
  it("should be disabled  ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.batchRefund) {
      res.action = 1;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should be !disabled  ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.batchRefund) {
      res.action = 2;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeFalse();
  });
  it("should be !action  ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.batchRefund) {
      delete res.action;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should be parentMethod return disabled  ", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of component.batchRefund) {
      res.action = 1;
    }
    component.batchRefund[1].action = 3;
    localStorage.setItem("IsChanged", "true");
    await component.parentMethod();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it(
    `should have called FadeOutSuccessMsg`,
    fakeAsync(() => {
      component.FadeOutSuccessMsg();
      tick(10000);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.showMsg).toEqual(false);
      });
    })
  );
  it("should have called onRefreshButtonClick", async () => {
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    component.onRefreshButtonClick();
    expect(component.showRefreshButton).toBeFalse();
  });
  it('should update state and call fetchBatchRejects and FadeOutSuccessMsg in receiveData', fakeAsync(() => {
    // Arrange
    const data = { showMsg: true, isSuccess: false, message: 'Test message' };
    spyOn(component, 'fetchBatchRejects');
    spyOn(component, 'FadeOutSuccessMsg');
    // Act
    component.receiveData(data);
    // Assert
    expect(component.message).toBe('Test message');
    expect(component.showMsg).toBeTrue();
    expect(component.isSuccess).toBeFalse();
    expect(component.fetchBatchRejects).toHaveBeenCalled();
    expect(component.FadeOutSuccessMsg).toHaveBeenCalled();
  }));

  it('should format date correctly in dateFormatter', () => {
    const input = { value: '2023-07-25T12:34:56Z' };
    expect(component.dateFormatter(input)).toBe('2023-07-25 12:34:56');
  });

  it('should return empty string in dateFormatter for falsy value', () => {
    expect(component.dateFormatter({ value: null })).toBe('');
  });

  it('should set recordCount in countDisplayedRows', () => {
    const params = { api: { paginationGetRowCount: () => 5 } };
    component.countDisplayedRows(params);
    expect(component.recordCount).toBe(5);
  });

  it('should set currentPageRowLastIndex to totalRowsCount if it exceeds in resetPaginationSelection', () => {
    const setRowSelectableSpy = jasmine.createSpy();
    const mockApi = {
      deselectAll: jasmine.createSpy(),
      paginationGetPageSize: () => 2,
      paginationGetCurrentPage: () => 1,
      getDisplayedRowCount: () => 3,
      getDisplayedRowAtIndex: () => ({ setRowSelectable: setRowSelectableSpy }),
    };
    component.gridApiActive = mockApi as any;
    component.resetPaginationSelection(component);
    expect(mockApi.deselectAll).toHaveBeenCalled();
    expect(setRowSelectableSpy).toHaveBeenCalled();
  });

  it('should show no rows overlay if getDisplayedRowCount is 0 in OnFilterBoxChanged', () => {
    const mockApi = {
      forEachNode: jasmine.createSpy(),
      setQuickFilter: jasmine.createSpy(),
      refreshCells: jasmine.createSpy(),
      getDisplayedRowCount: () => 0,
      showNoRowsOverlay: jasmine.createSpy(),
      hideOverlay: jasmine.createSpy(),
    };
    component.gridApiActive = mockApi as any;
    component.OnFilterBoxChanged();
    expect(mockApi.showNoRowsOverlay).toHaveBeenCalled();
  });

  it('should show no rows overlay if getDisplayedRowCount is 0 in onGridReady', () => {
    const showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    const hideOverlay = jasmine.createSpy('hideOverlay');
    const sizeColumnsToFit = jasmine.createSpy('sizeColumnsToFit');
    const addEventListener = jasmine.createSpy('addEventListener');
    const params = {
      api: {
        setDomLayout: jasmine.createSpy('setDomLayout'),
        getDisplayedRowCount: () => 0,
        showNoRowsOverlay,
        hideOverlay,
        sizeColumnsToFit,
        addEventListener
      }
    };
    component.gridOptions = {} as any;
    component.resetPaginationSelection = jasmine.createSpy('resetPaginationSelection');
    component.onGridReady(params);
    expect(params.api.showNoRowsOverlay).toHaveBeenCalled();
    expect(params.api.hideOverlay).not.toHaveBeenCalled();
    expect(params.api.setDomLayout).toHaveBeenCalledWith('autoHeight');
    expect(params.api.addEventListener).toHaveBeenCalledWith('paginationChanged', jasmine.any(Function));
    expect(params.api.sizeColumnsToFit).toHaveBeenCalled();
  });

  it('should call builder chain and connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyNewBatchRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
  }));

  it('should set showRefreshButton to true when NotifyNewBatchRejectsTab event is received', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    let notifyHandler: ((response: any) => void) | undefined;
    mockHubConnection.on.and.callFake((event, handler) => {
      if (event === 'NotifyNewBatchRejectsTab') {
        notifyHandler = handler;
      }
    });
    component.showRefreshButton = false;
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyNewBatchRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    // Act: simulate event received
    if (notifyHandler) {
      notifyHandler({});
    }
    // Assert
    expect(component.showRefreshButton).toBeTrue();
  }));
  it('should call catch and log error if SignalR connection fails in connectHub', fakeAsync(() => {
    // The builder chain methods are already spied in beforeEach
    const error = new Error('Connection failed');
    spyOn(console, 'error');
    mockHubConnection.start.and.returnValue(Promise.reject(error));
    component.connectHub();
    tick(); // Flush microtasks to resolve the Promise
    expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
    expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
    expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyNewBatchRejectsTab', jasmine.any(Function));
    expect(mockHubConnection.start).toHaveBeenCalled();
    expect(console.error).toHaveBeenCalledWith(error);
  }));
  it('should call catch block and log error in fetchData when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    const faultyRes = [{ action: 1 }];
    spyOn(component['batchRefundSrvice'], 'getBatchRefunds').and.returnValue({
      subscribe: (success) => {
        success(faultyRes);
      }
    } as any);

    spyOn(faultyRes, 'forEach').and.callFake(()=>{ throw errorObj; });

       // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchBatchRejects();
    // Assert
    expect(console.log).toHaveBeenCalledWith('error : ' + errorObj);
  });
  it('should call catch block and log error in fetchData when undefined throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    const faultyRes = [{ action: 1 }];
    spyOn(component['batchRefundSrvice'], 'getBatchRefunds').and.returnValue({
      subscribe: (success) => {
        success(undefined);
      }
    } as any);

    //spyOn(faultyRes, 'forEach').and.callFake(()=>{ throw errorObj; });

       // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchBatchRejects();
    // Assert
    expect(console.log).toHaveBeenCalledWith( `error : TypeError: Cannot read properties of undefined (reading 'forEach')`);
  });
  
  
  it('should handle API error in onSubmit and log error', async () => {
    // Arrange
    component.batchRefund = JSON.parse(JSON.stringify(apiReponse));
     fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.batchRefund[1].action = 3;
    component.configService.configData.username = "Nikhil.Akole";
    const apiError = new Error('API error');
    spyOn(console, 'error');
    // Simulate API error on POST
    spyOn(component['batchRefundSrvice'], 'batchAction').and.returnValue(throwError(() => (apiError)));
     mockLoadingDialogService.confirmed.and.returnValue(of(true));
    // Act
    component.onSubmit();
    // Assert
    expect(console.error).toHaveBeenCalled();

  });
  it('should log error and redirect to logout if dialogSvc.confirmed emits error in onSubmit', () => {
    // Arrange: get the dialog service from TestBed
    const dialogSvc = TestBed.inject(LoadingDialogService) as jasmine.SpyObj<LoadingDialogService>;
    dialogSvc.openDialog.and.stub();
    dialogSvc.confirmed.and.returnValue({
      subscribe: (success, error) => {
        if (error) error('some error reason');
      }
    } as any);
    spyOn(console, 'log');
    // Act
    component.onSubmit();
    // Assert
    expect(console.log).toHaveBeenCalledWith('Dismissed some error reason');
    //expect(console.log).toHaveBeenCalledWith('redirec to log out');
  });
});
