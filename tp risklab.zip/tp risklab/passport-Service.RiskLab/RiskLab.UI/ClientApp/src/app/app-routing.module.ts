import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OktaAuthGuard, OktaCallbackComponent } from '@okta/okta-angular';
import { AppComponent } from './app.component';
import { BatchNewtxnRejectsComponent } from './batch-new-txn-rejects/batch-new-txn-rejects.component';
import { BatchQueuedTxnRejectsComponent } from './batch-queued-txn-rejects/batch-queued-txn-rejects.component';
import { ErrorComponent } from './error/error.component';
import { FraudServiceComponent } from './fraud-service/fraud-service.component';
import { HomeComponent } from './home/home.component';
import { IndividualRefundsComponent } from './individual-refunds/individual-refunds.component';
import { LogoutComponent } from './logout/logout.component';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { MerchantRejectedtxnsComponent } from './merchant-rejectedtxns/merchant-rejectedtxns.component';
import { RiskrejectsBulkComponent } from './riskrejects-bulk/riskrejects-bulk.component';
import { RiskrejectsComponent } from './riskrejects/riskrejects.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';

const routes: Routes = [
  {
    path: '',
    component: AppComponent,
    canActivate: [OktaAuthGuard],
  },
  {
    path: 'login/callback',
    component: OktaCallbackComponent,
  },
  {
    path: 'logout',
    component: LogoutComponent,
  },
  {
    path: 'fraudservicedetails/:SequenceKey',
    component: FraudServiceComponent,
  }, 
  {
    path: 'secure',
    component: HomeComponent,
    canActivate: [OktaAuthGuard],
    children: [
      {
        path: 'risklab',
        component: RiskrejectsComponent,
        canActivate: [OktaAuthGuard],
      },
      {
        path: 'batchrejects',
        component: RiskrejectsBulkComponent,
        canActivate: [OktaAuthGuard],
      },
      {
        path: 'maintenance',
        component: MaintenanceComponent,
        canActivate: [OktaAuthGuard],
      },
      {
        path: 'unauthorized',
        component: UnauthorizedComponent,
      },
      {
        path: 'error',
        component: ErrorComponent,
      },
      {
        path: 'merchantrejectedtxns',
        component: MerchantRejectedtxnsComponent,
        canActivate: [OktaAuthGuard],
      },
      {
        path: 'batchNewTxnRejects',
        component: BatchNewtxnRejectsComponent,
        canActivate: [OktaAuthGuard],
      },
      {
        path: 'batchQueuedTxnRejects',
        component: BatchQueuedTxnRejectsComponent,
        canActivate: [OktaAuthGuard]
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
