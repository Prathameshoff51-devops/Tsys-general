import { ComponentFixture, TestBed } from "@angular/core/testing";

import { of, Subject } from "rxjs";
import { LoaderService } from "./loader.service";

describe("LoaderService", () => {
  let component: LoaderService;
  it("should create", () => {
    component = new LoaderService();
    component.isLoading = new Subject();
    component.show();
    component.hide();
    expect(component).toBeTruthy();
  });
});
