import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.css'],
})
export class AlertDialogComponent implements OnInit {
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: {
      okText: string;
      message: string;
      title: string;
    },
    private mdDialogRef: MatDialogRef<AlertDialogComponent>
  ) {}
  public cancel() {
    this.close(true);
  }
  public close(value: any) {
    this.mdDialogRef.close(value);
  }

  ngOnInit(): void {}
}
