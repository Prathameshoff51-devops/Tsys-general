import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NavigationEnd, Router } from "@angular/router";
import { of } from "rxjs";
import { NavItem } from "../model/nav-item";
import { NavService } from "../service/nav.service";

import { MenuListItemComponent } from "./menu-list-item.component";

describe("MenuListItemComponent", () => {
  let component: MenuListItemComponent;
  let fixture: ComponentFixture<MenuListItemComponent>;
  const mockRouter = {
    events: of(new NavigationEnd(2, "/secure", "/secure/risklab")),
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation"),
    isActive: jasmine.createSpy("isActive")
  };
  let item: NavItem = {
    displayName: "Risk Rejects",
    iconName: "fas fa-file-alt fa-lg",
    route: "secure/risklab",
    isSelected: false
  };
  beforeEach(async () => {
    return await TestBed.configureTestingModule({
      declarations: [MenuListItemComponent],
      providers: [
        { provide: Router, useValue: mockRouter }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuListItemComponent);
    component = fixture.componentInstance;
    component.item = item;
    fixture.detectChanges();
  });

  it("should create", () => {
    component.onItemSelected(item);
    expect(component).toBeTruthy();
  });

  it("should call router.navigate if item has no children", () => {
    mockRouter.navigate.calls.reset();
    const navItem: NavItem = { ...item, children: [] };
    component.onItemSelected(navItem);
    expect(mockRouter.navigate).toHaveBeenCalledWith([navItem.route]);
  });

  it("should toggle expanded if item has children", () => {
    const navItem: NavItem = { ...item, children: [{} as NavItem] };
    component.expanded = false;
    component.onItemSelected(navItem);
    expect(component.expanded).toBe(true);
    component.onItemSelected(navItem);
    expect(component.expanded).toBe(false);
  });

  it("should set expanded and ariaExpanded true if route matches in ngOnInit", () => {
    component.item = { ...item, route: "secure/risklab" };
    component.navService = {
      currentUrl: of("/secure/risklab")
    } as any;
    component.expanded = false;
    component.ariaExpanded = false;
    component.ngOnInit();
    expect(component.expanded).toBe(true);
    expect(component.ariaExpanded).toBe(true);
  });

  it("should set expanded and ariaExpanded false if route does not match in ngOnInit", () => {
    component.item = { ...item, route: "secure/other" };
    component.navService = {
      currentUrl: of("/secure/risklab")
    } as any;
    component.expanded = true;
    component.ariaExpanded = true;
    component.ngOnInit();
    expect(component.expanded).toBe(false);
    expect(component.ariaExpanded).toBe(false);
  });
});
