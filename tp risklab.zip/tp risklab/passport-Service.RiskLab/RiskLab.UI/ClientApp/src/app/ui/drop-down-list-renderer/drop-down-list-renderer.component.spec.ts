import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';

import { DropDownListRendererComponent } from './drop-down-list-renderer.component';

describe('DropDownListRendererComponent', () => {
  let component: DropDownListRendererComponent;
  let fixture: ComponentFixture<DropDownListRendererComponent>;
  let mockParams: any;
  let mockComponentParent: jasmine.SpyObj<any>;
  let overlayContainer: OverlayContainer;
  let overlayContainerElement: HTMLElement;

  beforeEach(async () => {
    mockComponentParent = jasmine.createSpyObj('ComponentParent', ['parentMethod']);
    
    // Create mock params that match the expected structure
    mockParams = {
      data: {
        action: 2,
        status: 'Active'
      },
      context: {
        componentParent: mockComponentParent
      },
      values: [
        { id: 1, name: 'Option 1' },
        { id: 2, name: 'Option 2' },
        { id: 3, name: 'Option 3' }
      ],
      disableDropdrown: false
    };

    await TestBed.configureTestingModule({
      declarations: [DropDownListRendererComponent],
      imports: [
        ReactiveFormsModule,
        MatSelectModule,
        MatOptionModule,
        BrowserAnimationsModule
      ],
      providers: [OverlayContainer]
    }).compileComponents();

    fixture = TestBed.createComponent(DropDownListRendererComponent);
    component = fixture.componentInstance;
    overlayContainer = TestBed.inject(OverlayContainer);
    overlayContainerElement = overlayContainer.getContainerElement();
    
    // Setup console.log spy
    spyOn(console, 'log');
  });

  afterEach(() => {
    fixture.destroy();
    overlayContainer.ngOnDestroy();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with default values', () => {
    expect(component.disableDropdrown).toBe(false);
    expect(component.status).toBe('');
    expect(component.renderActionList).toBeUndefined();
    expect(component.renderActionsControl).toBeInstanceOf(FormControl);
  });

  it('should initialize component with provided params', () => {
    component.agInit(mockParams);

    expect(component.componentParent).toBe(mockComponentParent);
    expect(component.renderActionsControl.value).toBe(2);
    expect(component.status).toBe('Active');
    expect(component.renderActionList).toEqual(mockParams.values);
    expect(component.disableDropdrown).toBe(false);
    expect(component.formControl).toBeInstanceOf(FormControl);
    expect(component.formControl.value).toBe(2);
  });

  it('should set disableDropdrown to true when params.disableDropdrown is true', () => {
    mockParams.disableDropdrown = true;
    
    component.agInit(mockParams);

    expect(component.disableDropdrown).toBe(true);
  });

  it('should set disableDropdrown to false when params.disableDropdrown is false', () => {
    mockParams.disableDropdrown = false;
    
    component.agInit(mockParams);

    expect(component.disableDropdrown).toBe(false);
  });

  it('should set disableDropdrown to false when params.disableDropdrown is undefined', () => {
    mockParams.disableDropdrown = undefined;
    
    component.agInit(mockParams);

    expect(component.disableDropdrown).toBe(false);
  });

  it('should set disableDropdrown to false when params.disableDropdrown is null', () => {
    mockParams.disableDropdrown = null;
    
    component.agInit(mockParams);

    expect(component.disableDropdrown).toBe(false);
  });

  it('should handle params with different action values', () => {
    mockParams.data.action = 5;
    
    component.agInit(mockParams);

    expect(component.renderActionsControl.value).toBe(5);
    expect(component.formControl.value).toBe(5);
  });

  it('should handle params with different status values', () => {
    mockParams.data.status = 'Inactive';
    
    component.agInit(mockParams);

    expect(component.status).toBe('Inactive');
  });

  it('should handle empty renderActionList', () => {
    mockParams.values = [];
    
    component.agInit(mockParams);

    expect(component.renderActionList).toEqual([]);
  });

  it('should handle undefined renderActionList', () => {
    mockParams.values = undefined;
    
    component.agInit(mockParams);

    expect(component.renderActionList).toBeUndefined();
  });

  it('should call getValue method', () => {
    spyOn(component, 'getValue');
    component.agInit(mockParams);
    
    component.ngOnInit();

    expect(component.getValue).toHaveBeenCalled();
  });

  it('should return the action value from params.data', () => {
    component.agInit(mockParams);
    
    const result = component.getValue();

    expect(result).toBe(2);
  });

  it('should return different action values', () => {
    mockParams.data.action = 7;
    component.agInit(mockParams);
    
    const result = component.getValue();

    expect(result).toBe(7);
  });

  it('should return undefined when action is undefined', () => {
    mockParams.data.action = undefined;
    component.agInit(mockParams);
    
    const result = component.getValue();

    expect(result).toBeUndefined();
  });

  it('should update params.data.action with the new value', () => {
    component.agInit(mockParams);
    const mockEvent = { value: 3 };
    
    component.onChangeClick(mockEvent);

    expect(mockParams.data.action).toBe(3);
  });

  it('should log the new value to console', () => {
    component.agInit(mockParams);
    const mockEvent = { value: 3 };
    
    component.onChangeClick(mockEvent);

    expect(console.log).toHaveBeenCalledWith(3);
  });

  it('should call componentParent.parentMethod when value is truthy', () => {
    component.agInit(mockParams);
    const mockEvent = { value: 1 };
    
    component.onChangeClick(mockEvent);

    expect(mockComponentParent.parentMethod).toHaveBeenCalled();
  });

  it('should call componentParent.parentMethod when value is a truthy string', () => {
    component.agInit(mockParams);
    const mockEvent = { value: 'test' };
    
    component.onChangeClick(mockEvent);

    expect(mockComponentParent.parentMethod).toHaveBeenCalled();
  });

  it('should not call componentParent.parentMethod when value is falsy (0)', () => {
    component.agInit(mockParams);
    const mockEvent = { value: 0 };
    
    component.onChangeClick(mockEvent);

    expect(mockComponentParent.parentMethod).not.toHaveBeenCalled();
  });

  it('should not call componentParent.parentMethod when value is falsy (null)', () => {
    component.agInit(mockParams);
    const mockEvent = { value: null };
    
    component.onChangeClick(mockEvent);

    expect(mockComponentParent.parentMethod).not.toHaveBeenCalled();
  });

  it('should not call componentParent.parentMethod when value is falsy (undefined)', () => {
    component.agInit(mockParams);
    const mockEvent = { value: undefined };
    
    component.onChangeClick(mockEvent);

    expect(mockComponentParent.parentMethod).not.toHaveBeenCalled();
  });

  it('should not call componentParent.parentMethod when value is falsy (empty string)', () => {
    component.agInit(mockParams);
    const mockEvent = { value: '' };
    
    component.onChangeClick(mockEvent);

    expect(mockComponentParent.parentMethod).not.toHaveBeenCalled();
  });

  it('should handle multiple consecutive changes', () => {
    component.agInit(mockParams);
    const mockEvent1 = { value: 1 };
    const mockEvent2 = { value: 2 };
    const mockEvent3 = { value: 3 };
    
    component.onChangeClick(mockEvent1);
    component.onChangeClick(mockEvent2);
    component.onChangeClick(mockEvent3);

    expect(mockParams.data.action).toBe(3);
    expect(mockComponentParent.parentMethod).toHaveBeenCalledTimes(3);
    expect(console.log).toHaveBeenCalledWith(1);
    expect(console.log).toHaveBeenCalledWith(2);
    expect(console.log).toHaveBeenCalledWith(3);
  });

  it('should render mat-select when disableDropdrown is false', () => {
    component.agInit(mockParams);
    fixture.detectChanges();

    const matSelect = fixture.debugElement.query(By.css('mat-select'));
    const statusDiv = fixture.debugElement.query(By.css('div:not([class])'));

    expect(matSelect).toBeTruthy();
    expect(statusDiv).toBeFalsy();
  });

  it('should render status div when disableDropdrown is true', () => {
    mockParams.disableDropdrown = true;
    component.agInit(mockParams);
    fixture.detectChanges();

    const matSelect = fixture.debugElement.query(By.css('mat-select'));
    const statusDiv = fixture.debugElement.query(By.css('div:not([class])'));

    expect(matSelect).toBeFalsy();
    expect(statusDiv).toBeTruthy();
    expect(statusDiv.nativeElement.textContent).toBe('Active');
  });

  it('should render correct number of options', () => {
    component.agInit(mockParams);
    fixture.detectChanges();
    
    // Test the data binding instead of DOM rendering
    expect(component.renderActionList).toBeDefined();
    expect(component.renderActionList.length).toBe(3);
    expect(component.renderActionList).toEqual([
      { id: 1, name: 'Option 1' },
      { id: 2, name: 'Option 2' },
      { id: 3, name: 'Option 3' }
    ]);
  });

  it('should display correct option text', () => {
    component.agInit(mockParams);
    fixture.detectChanges();
    
    // Test the data that would be displayed in options
    expect(component.renderActionList[0].name).toBe('Option 1');
    expect(component.renderActionList[1].name).toBe('Option 2');
    expect(component.renderActionList[2].name).toBe('Option 3');
    
    expect(component.renderActionList[0].id).toBe(1);
    expect(component.renderActionList[1].id).toBe(2);
    expect(component.renderActionList[2].id).toBe(3);
  });

  it('should have correct initial selected value', () => {
    component.agInit(mockParams);
    fixture.detectChanges();

    const matSelect = fixture.debugElement.query(By.css('mat-select'));
    expect(matSelect.componentInstance.value).toBe(2);
  });

  it('should trigger onChangeClick when option is selected', async () => {
    component.agInit(mockParams);
    fixture.detectChanges();
    spyOn(component, 'onChangeClick');
    
    const matSelect = fixture.debugElement.query(By.css('mat-select'));
    
    // Simulate selection change directly on the mat-select component
    matSelect.componentInstance.value = 1;
    matSelect.componentInstance.selectionChange.emit({ value: 1 });
    fixture.detectChanges();

    expect(component.onChangeClick).toHaveBeenCalledWith({ value: 1 });
  });

  it('should set renderActionsControl value without emitting event', () => {
    component.agInit(mockParams);
    fixture.detectChanges();
    const controlSpy = spyOn(component.renderActionsControl, 'setValue').and.callThrough();
    
    component.agInit(mockParams);

    expect(controlSpy).toHaveBeenCalledWith(2, { emitEvent: false });
  });

  it('should create formControl with correct initial value', () => {
    component.agInit(mockParams);
    fixture.detectChanges();

    expect(component.formControl.value).toBe(2);
  });

  it('should update formControl when renderActionsControl changes', () => {
    component.agInit(mockParams);
    fixture.detectChanges();
    component.renderActionsControl.setValue(5);
    expect(component.renderActionsControl.value).toBe(5);
  });

  it('should handle params without data object', () => {
    const badParams = {
      context: { componentParent: mockComponentParent },
      values: [],
      disableDropdrown: false
    } as any;

    expect(() => component.agInit(badParams)).toThrow();
  });

  it('should handle params without context object', () => {
    const badParams = {
      data: { action: 1, status: 'test' },
      values: [],
      disableDropdrown: false
    } as any;

    expect(() => component.agInit(badParams)).toThrow();
  });

  it('should handle params without componentParent', () => {
    const badParams = {
      data: { action: 1, status: 'test' },
      context: {},
      values: [],
      disableDropdrown: false
    } as any;

    component.agInit(badParams);
    expect(component.componentParent).toBeUndefined();
  });

  it('should handle onChangeClick when componentParent is undefined', () => {
    const badParams = {
      data: { action: 1, status: 'test' },
      context: {},
      values: [],
      disableDropdrown: false
    } as any;

    component.agInit(badParams);
    
    const mockEvent = { value: 1 };
    expect(() => component.onChangeClick(mockEvent)).toThrow();
  });

  it('should handle different status values in disabled state', () => {
    mockParams.data.status = 'Pending';
    mockParams.disableDropdrown = true;
    
    component.agInit(mockParams);
    fixture.detectChanges();

    const statusDiv = fixture.debugElement.query(By.css('div:not([class])'));
    expect(statusDiv.nativeElement.textContent).toBe('Pending');
  });

  it('should handle empty status in disabled state', () => {
    mockParams.data.status = '';
    mockParams.disableDropdrown = true;
    
    component.agInit(mockParams);
    fixture.detectChanges();

    const statusDiv = fixture.debugElement.query(By.css('div:not([class])'));
    expect(statusDiv.nativeElement.textContent).toBe('');
  });

  it('should complete full initialization lifecycle', () => {
    spyOn(component, 'getValue').and.callThrough();
    
    component.agInit(mockParams);
    component.ngOnInit();

    expect(component.getValue).toHaveBeenCalled();
    expect(component.componentParent).toBe(mockComponentParent);
    expect(component.renderActionsControl.value).toBe(2);
    expect(component.formControl.value).toBe(2);
  });

  it('should handle component destroy gracefully', () => {
    component.agInit(mockParams);
    fixture.detectChanges();
    
    expect(() => fixture.destroy()).not.toThrow();
  });

  it('should implement ICellEditorAngularComp interface', () => {
    expect(component.agInit).toBeDefined();
    expect(component.getValue).toBeDefined();
    expect(typeof component.agInit).toBe('function');
    expect(typeof component.getValue).toBe('function');
  });

  it('should correctly implement getValue method for ag-grid', () => {
    component.agInit(mockParams);
    
    const gridValue = component.getValue();
    expect(gridValue).toBe(mockParams.data.action);
  });
});
