import { Component, OnInit, Inject, HostListener } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.scss'],
})
export class ErrorDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { message: string; status?: number },
    public dialogRef: MatDialogRef<ErrorDialogComponent>
  ) { }
  @HostListener('window:click')
  onNoClick(): void {
      this.dialogRef.close();
  }
}
