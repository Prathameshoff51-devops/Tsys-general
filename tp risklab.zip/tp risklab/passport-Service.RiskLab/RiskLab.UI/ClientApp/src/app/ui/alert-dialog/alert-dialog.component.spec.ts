import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ActivatedRoute, Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { of } from "rxjs";
import { AlertDialogComponent } from "./alert-dialog.component";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

describe("AlertDialogComponent", () => {
  let component: AlertDialogComponent;
  let fixture: ComponentFixture<AlertDialogComponent>;
  const model = {
    okText: "Delete",
    message: "Are you sure?",
    title: "Are you sure?"
  };
  const dialogMock = {
    close: () => {}
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AlertDialogComponent],

      providers: [
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: dialogMock }
      ]
    }).compileComponents();
  });
  beforeEach(async () => {
    fixture = TestBed.createComponent(AlertDialogComponent);
    component = fixture.componentInstance;
    component.data = model;
    component.cancel();
    component.ngOnInit();
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
