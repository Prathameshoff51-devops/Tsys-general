import { Constants } from 'src/app/Constants';
import { NavItem } from './nav-item';

export let menu: NavItem[] = [
  {
    displayName: 'Risk Rejects',
    iconName: 'fas fa-file-alt fa-lg',
    route: Constants.riskLabPage,
    isSelected: true,
  },
  {
    displayName: 'Back Office',
    iconName: 'fas fa-copy',
    route: Constants.merchantTxnPage,
    isSelected: false,
  },
];
