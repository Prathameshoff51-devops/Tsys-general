import { Injectable } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';

import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';

@Injectable()
export class AlertService {
  private opened = false;
  private dialogRef!: MatDialogRef<AlertDialogComponent>;
  constructor(private dialog: MatDialog) {}

  openDialog(options: any) {
    this.dialogRef = this.dialog.open(AlertDialogComponent, {
      data: {
        title: options.title,
        message: options.message,
        okText: options.okText,
      },
      hasBackdrop: true,
    });
  }
  hideDialog() {
    this.dialogRef.close();
  }
}
