import { Component, OnInit } from "@angular/core";
import { ICellEditorAngularComp } from "ag-grid-angular";
import { ICellEditorParams } from "ag-grid-community";
import { FormControl } from "@angular/forms";
import { Output, EventEmitter } from "@angular/core";
@Component({
  selector: "app-drop-down-list-renderer",
  templateUrl: "./drop-down-list-renderer.component.html",
  styleUrls: ["./drop-down-list-renderer.component.css"]
})
export class DropDownListRendererComponent implements ICellEditorAngularComp {
  private params: any;
  private value: any;
  componentParent: any;

  @Output() newItemEvent = new EventEmitter<string>();
  renderActionsControl = new FormControl();
  disableDropdrown = false;
  status = "";
  renderActionList: any;
  formControl: FormControl<any>;

  constructor() {}

  agInit(params: ICellEditorParams): void {
    this.params = params;
    this.componentParent = this.params.context.componentParent;
    this.renderActionsControl.setValue(this.params.data.action, {
      emitEvent: false
    });
    this.status = this.params.data.status;
    this.renderActionList = this.params.values;
    this.disableDropdrown = this.params.disableDropdrown
      ? this.params.disableDropdrown
      : false;
    this.formControl = new FormControl(this.params.data.action);
  }

  ngOnInit(): void {
    this.getValue();
  }

  getValue() {
    return this.params.data.action;
  }

  onChangeClick(e: any) {
    this.params.data.action = e.value;
    console.log(e.value);
    if (e.value) {
      this.componentParent.parentMethod();
    }
  }
}
