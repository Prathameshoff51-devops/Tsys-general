import { TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { of } from 'rxjs';

import { LoadingDialogService } from './loading-dialog.service';
import { LoadingDialogComponent } from '../loading-dialog/loading-dialog.component';

describe('LoadingDialogService', () => {
  let service: LoadingDialogService;
  let mockDialog: jasmine.SpyObj<MatDialog>;
  let mockDialogRef: jasmine.SpyObj<MatDialogRef<LoadingDialogComponent>>;

  beforeEach(() => {
    mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['afterClosed', 'close']);
    mockDialog = jasmine.createSpyObj('MatDialog', ['open']);
    
    // Setup default return values
    mockDialog.open.and.returnValue(mockDialogRef);
    mockDialogRef.afterClosed.and.returnValue(of(true));

    TestBed.configureTestingModule({
      providers: [
        LoadingDialogService,
        { provide: MatDialog, useValue: mockDialog },
      ]
    });

    service = TestBed.inject(LoadingDialogService);
  });

  afterEach(() => {
    // Clean up any opened dialogs
    if ((service as any).dialogRef) {
      (service as any).dialogRef = null;
    }
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('openDialog', () => {
    it('should open dialog with provided options', () => {
      const options = {
        title: 'Test Title',
        message: 'Test Message',
        cancelText: 'Cancel',
        confirmText: 'Confirm'
      };

      service.openDialog(options);

      expect(mockDialog.open).toHaveBeenCalledWith(LoadingDialogComponent, {
        data: {
          title: 'Test Title',
          message: 'Test Message',
          cancelText: 'Cancel',
          confirmText: 'Confirm'
        },
        hasBackdrop: true
      });
      expect((service as any).dialogRef).toBe(mockDialogRef);
    });

    it('should open dialog with partial options', () => {
      const options = {
        title: 'Test Title',
        message: 'Test Message'
      };

      service.openDialog(options);

      expect(mockDialog.open).toHaveBeenCalledWith(LoadingDialogComponent, {
        data: {
          title: 'Test Title',
          message: 'Test Message',
          cancelText: undefined,
          confirmText: undefined
        },
        hasBackdrop: true
      });
    });

    it('should open dialog with empty options', () => {
      const options = {};

      service.openDialog(options);

      expect(mockDialog.open).toHaveBeenCalledWith(LoadingDialogComponent, {
        data: {
          title: undefined,
          message: undefined,
          cancelText: undefined,
          confirmText: undefined
        },
        hasBackdrop: true
      });
    });

    it('should store dialog reference', () => {
      const options = { title: 'Test' };
      
      service.openDialog(options);
      
      expect((service as any).dialogRef).toBe(mockDialogRef);
    });
  });

  describe('confirmed', () => {
    beforeEach(() => {
      // Setup spy for console.log
      spyOn(console, 'log');
    });

    it('should return observable from dialogRef.afterClosed()', () => {
      const options = { title: 'Test' };
      const expectedResult = true;
      
      mockDialogRef.afterClosed.and.returnValue(of(expectedResult));
      service.openDialog(options);

      const result = service.confirmed();

      expect(result).toBeTruthy();
      expect(mockDialogRef.afterClosed).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalledWith('loading-dialog confirm');
    });

    it('should log the result from dialog', (done) => {
      const options = { title: 'Test' };
      const expectedResult = 'test-result';
      
      mockDialogRef.afterClosed.and.returnValue(of(expectedResult));
      service.openDialog(options);

      service.confirmed().subscribe(result => {
        expect(result).toBe(expectedResult);
        expect(console.log).toHaveBeenCalledWith('loading-dialog confirm');
        expect(console.log).toHaveBeenCalledWith(expectedResult);
        done();
      });
    });

    it('should handle dialog closed with false result', (done) => {
      const options = { title: 'Test' };
      const expectedResult = false;
      
      mockDialogRef.afterClosed.and.returnValue(of(expectedResult));
      service.openDialog(options);

      service.confirmed().subscribe(result => {
        expect(result).toBe(false);
        expect(console.log).toHaveBeenCalledWith(expectedResult);
        done();
      });
    });

    it('should handle dialog closed with undefined result', (done) => {
      const options = { title: 'Test' };
      const expectedResult = undefined;
      
      mockDialogRef.afterClosed.and.returnValue(of(expectedResult));
      service.openDialog(options);

      service.confirmed().subscribe(result => {
        expect(result).toBe(undefined);
        expect(console.log).toHaveBeenCalledWith(expectedResult);
        done();
      });
    });

    it('should handle dialog closed with null result', (done) => {
      const options = { title: 'Test' };
      const expectedResult = null;
      
      mockDialogRef.afterClosed.and.returnValue(of(expectedResult));
      service.openDialog(options);

      service.confirmed().subscribe(result => {
        expect(result).toBe(null);
        expect(console.log).toHaveBeenCalledWith(expectedResult);
        done();
      });
    });

    it('should take only 1 result from afterClosed observable', (done) => {
      const options = { title: 'Test' };
      let callCount = 0;
      
      // Create a custom observable that would emit multiple times
      mockDialogRef.afterClosed.and.returnValue(of(true, false, true));
      service.openDialog(options);

      service.confirmed().subscribe(result => {
        callCount++;
        expect(result).toBe(true); // Should only get the first emission
        
        // Use setTimeout to ensure no more emissions
        setTimeout(() => {
          expect(callCount).toBe(1);
          done();
        }, 10);
      });
    });
  });

  describe('hideDialog', () => {
    it('should close the dialog', () => {
      const options = { title: 'Test' };
      
      service.openDialog(options);
      service.hideDialog();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });

    it('should handle hideDialog when no dialog is open', () => {
      // Don't open dialog first, so dialogRef should be undefined
      expect(() => service.hideDialog()).toThrow();
    });
  });

  describe('Integration Tests', () => {
    it('should handle complete dialog flow', (done) => {
      const options = {
        title: 'Confirmation',
        message: 'Are you sure?',
        cancelText: 'Cancel',
        confirmText: 'OK'
      };

      mockDialogRef.afterClosed.and.returnValue(of(true));

      // Open dialog
      service.openDialog(options);
      expect(mockDialog.open).toHaveBeenCalled();

      // Get confirmation
      service.confirmed().subscribe(result => {
        expect(result).toBe(true);
        
        // Close dialog
        service.hideDialog();
        expect(mockDialogRef.close).toHaveBeenCalled();
        
        done();
      });
    });

    it('should handle dialog cancellation flow', (done) => {
      const options = {
        title: 'Confirmation',
        message: 'Are you sure?',
        cancelText: 'Cancel',
        confirmText: 'OK'
      };

      mockDialogRef.afterClosed.and.returnValue(of(false));

      // Open dialog
      service.openDialog(options);

      // Get confirmation (user cancelled)
      service.confirmed().subscribe(result => {
        expect(result).toBe(false);
        done();
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle dialog open errors gracefully', () => {
      const options = { title: 'Test' };
      
      mockDialog.open.and.throwError('Dialog error');
      
      expect(() => service.openDialog(options)).toThrowError('Dialog error');
    });

    it('should handle afterClosed errors gracefully', () => {
      const options = { title: 'Test' };
      
      mockDialogRef.afterClosed.and.throwError('AfterClosed error');
      service.openDialog(options);

      expect(() => service.confirmed()).toThrowError('AfterClosed error');
    });
  });
});
