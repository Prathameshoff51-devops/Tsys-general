import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { LoadingDialogComponent } from '../loading-dialog/loading-dialog.component';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
@Injectable()
export class LoadingDialogService {
  private opened = false;
  private dialogRef!: MatDialogRef<LoadingDialogComponent>;
  constructor(private dialog: MatDialog) {}

 
  openDialog(options: any) {
     
    this.dialogRef = this.dialog.open(LoadingDialogComponent, {
      data: {
        title: options.title,
        message: options.message,
        cancelText: options.cancelText,
        confirmText: options.confirmText
      }, hasBackdrop: true
    });
  

  }
  public confirmed(): Observable<any> {
    console.log('loading-dialog confirm');
    return this.dialogRef.afterClosed().pipe(take(1), map(res => {
      console.log(res);
      return res;
    }
    ));
  }
  hideDialog() {
    this.dialogRef.close();
  }
}
