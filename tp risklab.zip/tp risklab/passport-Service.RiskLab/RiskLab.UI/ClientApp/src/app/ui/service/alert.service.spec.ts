import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ActivatedRoute, Router } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";
import { of } from "rxjs";

import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from "@angular/material/dialog";
import { AlertService } from "./alert.service";

describe("AlertService", () => {
  let component: AlertService;
  let matDialogService: jasmine.SpyObj<MatDialog>;
  matDialogService = jasmine.createSpyObj<MatDialog>("MatDialog", ["open"]);

  const model = {
    okText: "Delete",
    message: "Are you sure?",
    title: "Are you sure?"
  };
  const dialogMock = {
    close: () => {}
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: MatDialog,
          useValue: matDialogService
        },
        { provide: MatDialogRef, useValue: dialogMock }
      ]
    }).compileComponents();
  });

  it("should create", () => {
    let fixture = TestBed.inject(MatDialog);
    component = new AlertService(fixture);
    component.openDialog(model);
    expect(component).toBeTruthy();
  });

  it('should call close on dialogRef when hideDialog is called', () => {
    let fixture = TestBed.inject(MatDialog);
    component = new AlertService(fixture);
    const closeSpy = jasmine.createSpy('close');
    // @ts-ignore
    component.dialogRef = { close: closeSpy };
    component.hideDialog();
    expect(closeSpy).toHaveBeenCalled();
  });
});
