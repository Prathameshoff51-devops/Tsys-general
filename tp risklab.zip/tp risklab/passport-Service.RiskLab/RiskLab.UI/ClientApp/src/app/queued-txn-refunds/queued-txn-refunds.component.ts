import { Component, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@microsoft/signalr'
import { QueuedRefund } from '../shared/models/queued-refund.model';
import { IndividualRefundservice } from '../shared/services/individual-refund.service';
import { RejectStatuses } from '../shared/enums';
import { ConfigurationService } from '../shared/services/configuration.service';
import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import {
  DropDownListRendererComponent
} from '../ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { GridOptions, PaginationChangedEvent } from 'ag-grid-community';
import { LoadingDialogService } from '../ui/service/loading-dialog.service';
import { IndividualRefund, TransStatus, RejectsCount } from '../shared/models/individual-refund.model';
import { Constant } from '../shared/constant';
import { Configuration } from '../shared/models/configuration.model';
import { AppConfig } from '../shared/models/app-config';

@Component({
  selector: 'app-queued-txn-refunds',
  templateUrl: './queued-txn-refunds.component.html',
  styleUrls: ['./queued-txn-refunds.component.css'],
  providers: [IndividualRefundservice],
})
export class QueuedTxnRefundsComponent implements OnInit, OnDestroy {

  public gridOptions: GridOptions;
  config!: Configuration
  queuedtxn: QueuedRefund[] = null;
  gridApiActive: any;
  public paginationPageSize = Constant.DefaultGridPageSize;
  public daysToAct = Constant.DaysToActs;
  disabled: boolean;
  showRefreshButton: boolean = false;
  totalResults: any;
  context: any;
  public rowSelection;
  public paginationNumberFormatter: any;
  public totalRecords: number | undefined;
  showMsg: boolean = false;
  isSuccess: boolean = true;
  message: string;
  configData: any;
  private connection: signalR.HubConnection;
  //public riskLabUrl!:string;
  public signalrNotificationEndpoint!: string;
  public overlayNoRowsTemplate;

  constructor(private individualRefundsService: IndividualRefundservice,
    @Inject(DOCUMENT) private document: Document,
    public configService: ConfigurationService,
    private _dialogSvc: LoadingDialogService,
    private appconfig: AppConfig) {
    this.disabled = true;
    this.config = this.configService.config;
    if (this.config.defaultGridPageSize != undefined && this.config.daysToAct != undefined) {
      this.paginationPageSize = this.config.defaultGridPageSize;
      this.daysToAct = this.config.daysToAct;
    }

    //this.riskLabUrl = this.configService.configData.riskLabApiUrl;
    this.signalrNotificationEndpoint = this.appconfig.config.apiUrl.concat("/notification");

    this.context = {
      componentParent: this,
      daysToAct: this.daysToAct
    }

    this.gridOptions = {
      components: {
        DropDownListRenderer: DropDownListRendererComponent
      },
      columnDefs: [
        {
          headerName: 'Action',
          field: 'actionDropdown',
          editable: false,
          lockPinned: true,
          lockPosition: true,
          pinned: 'left',
          cellRenderer: 'DropDownListRenderer',
          minWidth: 130,
          maxWidth: 130,
          cellRendererParams: {
            values: [
              { id: 2, name: 'Select Action' },
              { id: 3, name: 'Release' },
              { id: 4, name: 'Delete' }
            ]
          },
          cellStyle: this.changeRowColor
        },
        {
          headerName: 'Merchant Number',
          width: 130,
          field: 'merchantNumber',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Merchant Name',
          width: 130,
          resizable: true,
          field: 'merchantName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Legal Name',
          width: 150,
          resizable: true,
          field: 'legalName',
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Processing Chain ID',
          width: 100,
          field: 'chainOID',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'MCC',
          field: 'mcc',
          width: 60,
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Amount',
          width: 120,
          field: 'amount',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          valueFormatter: this.currencyFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Card Number Masked',
          width: 150,
          field: 'cardNumberMask',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Date (UTC)',
          width: 150,
          field: 'txnDateUtc',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          resizable: true,
          sort: 'asc',
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Reject Reasons',
          field: 'fraudRejectReasonCodes',
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          width: 200,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Original Batch Number',
          width: 80,
          field: 'originalBatchNumber',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Batch Close Date (UTC)',
          width: 160,
          field: 'batchCloseDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Auth Code',
          width: 80,
          field: 'authCode',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Exp Date',
          width: 150,
          field: 'expDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Type',
          width: 80,
          field: 'txnTypeDescription',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Submitter',
          width: 80,
          field: 'submitterIDDescription',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Days to Act',
          width: 90,
          field: 'daysToAct',
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
      ]

    }

    this.paginationNumberFormatter = function (params: any) {
      return params.value.toLocaleString();
    }
    this.rowSelection = 'multiple';

    this.overlayNoRowsTemplate =
      '<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
  }



  ngOnInit() {
    this.connectHub();
    this.fetchData();
  }

  currencyFormatter(params: any) {
    return '$' + params.value.toFixed(2);
  }

  fetchData() {
    this.individualRefundsService.getIndividualRefunds(RejectStatuses.Queued).subscribe((res: IndividualRefund[]) => {
      this.totalRecords = res?.length;
      try {
        this.queuedtxn = res;
        this.queuedtxn.forEach(x => {
          x.action = 2;
        });
        console.log('response');
        console.log(this.queuedtxn);
      } catch (ex) {
        console.log('error');
        console.log(ex);
      }
    }

    );
    this.disabled = true;
    this.showRefreshButton = false;
  }

  onPageSizeChanged() {
    if (this.totalResults < this.paginationPageSize) {
      this.paginationPageSize = this.totalResults;
    }

    this.gridApiActive.paginationSetPageSize(this.paginationPageSize);
    this.resetPaginationSelection(this);
  }

  changeRowColor(params) {

    if (params.data.daysToAct <= params.context.daysToAct) {
     return { backgroundColor: '#ffe6e6' };
    } else {
      return null;
    }
  }

  onSubmit() {
    const options = {
      title: 'Confirm!',
      message: 'Are you sure you want to submit?',
      cancelText: 'No',
      confirmText: 'Yes'
    };
    this.isSuccess = true;
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {
        let transactionsStatus: TransStatus[] = [];
        this.gridApiActive.forEachNode((node) => {
          console.log(node);
          if (node.alreadyRendered && node.selectable && node.displayed) {
            if (node.data.hasOwnProperty('action') && node.data.action > 2) {
              const transcation = {
                TransactionId: node.data.individualTxnId,
                NewStatus: node.data.action.toString(),
              }
              transactionsStatus.push(transcation);
            }
          }
        }

        );

        const transactionAction = {
          transactionsStatus: transactionsStatus,
          userName: this.configService.configData.username
        }

        // add API call to save modified row
        const res = this.individualRefundsService.transcationsAction(transactionAction).subscribe((res: any) => {
          let successCount: number = 0;
          let failCount: number = 0;
          let totalCount: number = 0;
          res.forEach((row) => {
            totalCount++;
            if (row.updateStatus == Constant.Success) {
              successCount = successCount + 1;
            }
            else if (row.updateStatus == Constant.Failed) {
              failCount = failCount + 1;
            }
          })
          if (failCount == 0) {
            this.message = successCount + '/' + totalCount + ' records were processed successfully.'
            this.fetchData();
          }
          else if (successCount > 0) {
            this.message = failCount + '/' + totalCount + ' records were not processed as another user has already worked on the same records.'
            this.fetchData();
            this.isSuccess = false;
          }
          else {
            this.message = 'Transaction update failed.'
            this.isSuccess = false;
          }
          this.showMsg = true;
          this.FadeOutSuccessMsg();
          this.ResetSearch();
          localStorage.setItem("IsChanged", 'false');
        });
      }
      else {
        console.log('No');


      }
    },
      (reason: any) => {
        console.log("Dismissed " + reason);
        console.log('redirec to log out')
      });
  }
  countDisplayedRows(params) {
    this.totalResults = params.api.paginationGetRowCount();
  }
  resetPaginationSelection = (self) => {
    console.log('resetPaginationSelection');
    //Deselect previously selected rows to reset selection
    self.gridApiActive.deselectAll();

    //Initialize pagination data
    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    //Calculate current page row indexes
    let currentPageRowStartIndex = (currentPageNum * paginationSize);
    let currentPageRowLastIndex = (currentPageRowStartIndex + paginationSize);
    if (currentPageRowLastIndex > totalRowsCount) currentPageRowLastIndex = (totalRowsCount);

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage = (i >= currentPageRowStartIndex && i < currentPageRowLastIndex);
      self.gridApiActive.getDisplayedRowAtIndex(i).setRowSelectable(isWithinCurrentPage);
    }
  };
  parentMethod() {
    this.DirtyData();
    var flag: boolean = false;
    this.gridApiActive.forEachNode((node) => {
      if (node.alreadyRendered && node.selectable && node.displayed) {
        if (node.data.hasOwnProperty('action') && node.data.action > 2) {
          flag = true;
        }
        //else if (node.data.action == 2) {
        //  flag = false;
        //}
      }
    }

    );
    if (flag) {
      this.disabled = false;
    }
    else {
      this.disabled = true;
    }
  }

  DirtyData() {
    localStorage.setItem("IsNotAllSelected", 'true');
    this.gridApiActive.forEachNode((node) => {
      if ((node.data.hasOwnProperty('action')) && (node.data.action != 2)) {
        localStorage.setItem("IsChanged", 'true');
        localStorage.setItem("IsNotAllSelected", 'false');
        console.log(node.data.hasOwnProperty('action'), node.data.action)
        return;
      }
      else if ((node.data.action == 2)) {
        if (localStorage.getItem("IsChanged") != 'true') {
          console.log("action", node.data.action)
          localStorage.removeItem("IsChanged");
          localStorage.setItem("IsChanged", 'false');
        }
        else if ((localStorage.getItem("IsNotAllSelected") == 'true') && (node.data.action == 2)) {
          localStorage.removeItem("IsChanged");
          localStorage.setItem("IsChanged", 'false');
        }
      }
    });
  }

  onGridReady(params: any) {
    this.gridApiActive = params.api;
    params.api.setDomLayout('autoHeight');
    this.gridApiActive.addEventListener('paginationChanged', (e) => {
      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      this.gridApiActive.api.showNoRowsOverlay();
    }
    else {
      this.gridApiActive.api.hideOverlay();

    }

  }

  SearchText: any;
  OnFilterBoxChanged() {
    if (this.SearchText != "") {
      localStorage.setItem("IsChanged", 'true');
    }
    else if (this.SearchText == "") {
      localStorage.setItem("IsChanged", 'false');
    }
    // setTimeout((gridApiActive) => {
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        node.data['action'] = 2;
      }
    });
    // }, 500);
    this.gridApiActive.setQuickFilter(this.SearchText);
    this.gridApiActive.refreshCells({ force: true })

    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      // this.gridOptions.suppressNoRowsOverlay = false;
      // this.gridOptions.overlayNoRowsTemplate = '<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
      this.gridApiActive.api.showNoRowsOverlay();
    }
    else {
      this.gridApiActive.api.hideOverlay();
    }
    this.disabled = true;
  }

  dateFormatter(data) {
    return data.value ? data.value.replace('T', ' ').replace('Z', '') : '';
  }
  FadeOutSuccessMsg() {
    setTimeout(() => {
      this.showMsg = false;
    }, 10000);
  }

  ResetSearch() {
    this.gridApiActive.setQuickFilter(null);
    this.SearchText = '';
  }

  onPaginationChanged(params: PaginationChangedEvent) {
    this.gridApiActive = params.api;
    this.gridApiActive.forEachNode((node) => {
      if (node.data.hasOwnProperty('action')) {
        node.data['action'] = 2;
        this.disabled = true;
      }
    });
    localStorage.setItem("IsChanged", 'false');
  }

  onRefreshButtonClick() {
    const options = {
      title: 'Confirm!',
      message: 'Unsaved actions will get reset, continue with refresh?',
      cancelText: 'No',
      confirmText: 'Yes',
    };
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe(
      (confirmed: any) => {
        if (confirmed) {
          this.fetchData();
          this.ResetSearch();
          this.showRefreshButton = false;
        }
      }
    );
  }
  connectHub() {
    this.disconnectHub();
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.signalrNotificationEndpoint)
        .withAutomaticReconnect()
        .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.on("NotifyQueueTxnTab", (response) => {
        if (!this.showRefreshButton)
          this.showRefreshButton = true;
      });

      this.connection
        .start().then(function () {
          console.info("connected to signalr...")
        })
        .catch(err => console.error(err));
    }
  }

  disconnectHub() {
    if (this.connection) {
      this.connection.stop();
      this.connection = null;
    }
  }

  ngOnDestroy(): void {
    this.disconnectHub();
  }
  
  receiveData(data: { showMsg: boolean; isSuccess: boolean; message: string }) {
    this.message = data.message;
    this.showMsg = data.showMsg;
    this.isSuccess = data.isSuccess;
    this.fetchData();
    this.FadeOutSuccessMsg();
  }
}
