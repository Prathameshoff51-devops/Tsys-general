import { Component, OnDestroy, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import * as signalR from "@microsoft/signalr";
import { QueuedRefund } from "../shared/models/queued-refund.model";
import { BatchQueuedtxnservice } from "../shared/services/batch-queued-txn-rejects";
import { RejectStatuses } from "../shared/enums";
import { ConfigurationService } from "../shared/services/configuration.service";
import { Inject } from "@angular/core";
import { DOCUMENT } from "@angular/common";
import { DropDownListRendererComponent } from "../ui/drop-down-list-renderer/drop-down-list-renderer.component";
import { GridOptions, PaginationChangedEvent } from "ag-grid-community";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import {
  BatchtxnRejects,
  Transactions,
  TransStatus,
  RejectsCount
} from "../shared/models/batch-queued-txn-rejects.model";
import { Constant } from "../shared/constant";
import { Configuration } from "../shared/models/configuration.model";
import { Router } from "@angular/router";
import { Constants } from "../Constants";

@Component({
  selector: "app-batch-queued-txn-rejects",
  templateUrl: "./batch-queued-txn-rejects.component.html",
  styleUrls: ["./batch-queued-txn-rejects.component.css"],
  providers: [BatchQueuedtxnservice]
})
export class BatchQueuedTxnRejectsComponent implements OnInit, OnDestroy {
  public gridOptions: GridOptions;
  config!: Configuration;
  transactions: Transactions[] = null;
  batchtxnRejects: BatchtxnRejects = null;
  gridApiActive: any;
  public paginationPageSize = Constant.DefaultGridPageSizeforBatchTxnRejects;
  public daysToAct = Constant.DaysToActs;
  disabled: boolean;
  showRefreshButton: boolean = false;
  totalResults: any;
  displayMerchantData: boolean;
  context: any;
  public rowSelection;
  public paginationNumberFormatter: any;
  public totalRecords: number | undefined;
  showMsg: boolean = false;
  isSuccess: boolean = true;
  message: string;
  configData: any;
  private connection: signalR.HubConnection;
  public riskLabUrl!: string;
  public signalrNotificationEndpoint!: string;
  style: { height: string };
  IsBatchQueuedRejects: boolean = false;
  overlayNoRowsTemplate = "No records to display.";

  constructor(
    private batchQueuedtxnservice: BatchQueuedtxnservice,
    @Inject(DOCUMENT) private document: Document,
    public configService: ConfigurationService,
    private _dialogSvc: LoadingDialogService,
    private router: Router

  ) {
    this.disabled = true;
    this.config = this.configService.config;
    if (
      this.config.DefaultGridPageSizeforBatchTxnRejects != undefined &&
      this.config.daysToAct != undefined
    ) {
      this.paginationPageSize = this.config.DefaultGridPageSizeforBatchTxnRejects = this.config.daysToAct;
    }

    this.riskLabUrl = this.configService.configData.riskLabApiUrl;
    this.signalrNotificationEndpoint = this.riskLabUrl + "/notification";

    this.context = {
      componentParent: this,
      daysToAct: this.daysToAct
    };

    this.gridOptions = {
      components: {
        DropDownListRenderer: DropDownListRendererComponent
      },
      columnDefs: [
        {
          headerName: "Action",
          field: "actionDropdown",
          editable: false,
          lockPinned: true,
          lockPosition: true,
          pinned: "left",
          cellRenderer: "DropDownListRenderer",
          minWidth: 130,
          maxWidth: 130,
          cellRendererParams: params => {
            let disableDropdrown = false;
            let values = [
              { id: 2, name: "Select Action" },
              { id: 3, name: "Release" },
              { id: 4, name: "Delete" }
            ];
            if (params.data.status !== "Queued") {
              disableDropdrown = true;
            }
            return {
              values: values,
              disableDropdrown: disableDropdrown
            };
          },
          cellStyle: this.changeRowColor
        },
        {
          headerName: "Txn Amount",
          minWidth: 200,
          maxWidth: 200,
          field: "txnAmount",
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.currencyFormatter,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>'
          }
        },
        {
          headerName: "Card Number Masked",
          minWidth: 200,
          maxWidth: 200,
          resizable: true,
          field: "cardNumberMasked",
          sortable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>'
          }
        },
        {
          headerName: "Txn Date (UTC)",
          minWidth: 200,
          maxWidth: 200,
          field: "txnDateUTC",
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>'
          }
        },
        {
          headerName: "Original Batch Number",
          field: "originalBatchNumber",
          minWidth: 200,
          maxWidth: 200,
          sortable: true,
          cellStyle: this.changeRowColor,
          resizable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>'
          }
        },
        {
          headerName: "Reject Reasons",
          field: "rejectReasons",
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          minWidth: 265,
          maxWidth: 265,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>'
          }
        },
        {
          headerName: 'Auth Code',
          minWidth: 150,
          maxWidth:150,
          resizable: true,
          cellStyle: this.changeRowColor,
          field: 'authCode',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Exp Date',
          minWidth: 230,
          maxWidth:230,
          resizable: true,
          field: 'expDate',
          sortable: true,
          cellStyle: this.changeRowColor,
          valueFormatter: this.dateFormatter,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:'<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: 'Txn Type',
          minWidth: 200,
          maxWidth:200,
          resizable: true,
          cellStyle: this.changeRowColor,
          field: 'txnType',
          sortable: true,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending:
              '<i class="fas fa-arrow-down" style="color:white"/>',
          },
        },
        {
          headerName: "Days to Act",
          minWidth: 120,
          maxWidth: 120,
          field: "daysToAct",
          sortable: true,
          resizable: true,
          cellStyle: this.changeRowColor,
          icons: {
            sortAscending: '<i class="fas fa-arrow-up" style="color:white"/>',
            sortDescending: '<i class="fas fa-arrow-down" style="color:white"/>'
          }
        }
      ]
    };

    this.paginationNumberFormatter = function (params: any) {
      return params.value.toLocaleString();
    };
    this.rowSelection = "multiple";
    this.overlayNoRowsTemplate =
      '<span style="color:black;font-size:15px;height:35px">No records to display.</span>';
  
  }

  ngOnInit() {
    this.connectHub();
    this.fetchData();
  }

  currencyFormatter(params: any) {
    return "$" + params.value.toFixed(2);
  }

  fetchData() {
    const batchRejectId = localStorage.getItem(Constants.batchRejectIdforQueuedDrillDown);
    this.batchQueuedtxnservice
      .getBatchtxnRejects(batchRejectId)
      .subscribe((res: BatchtxnRejects) => {
        try {
          let queuedTransactions = [];
          let deletedtransactions = [];
          let releasedtransactions = [];
          this.batchtxnRejects = res;
          this.batchtxnRejects.batchAmount = this.currencyFormatter({
            value: Number(this.batchtxnRejects.batchAmount)
          });
          this.transactions = res.transactions;
          this.transactions.forEach(x => {
            x.originalBatchNumber = res.originalBatchNumber;
            x.batchCloseDateUTC = res.batchCloseDateUTC;
            x.action = 2;
            x.actionDropdown = 3;
            if (x.status === "Queued") {
              queuedTransactions.push(x);
            } else if (x.status === "Released") {
              releasedtransactions.push(x);
            } else if (x.status === "Deleted") {
              deletedtransactions.push(x);
            }
          });
          if (queuedTransactions.length == 0) {
            if (this.IsBatchQueuedRejects) {
              sessionStorage.setItem('batchQueuedRejects', 'true');
              this.router.navigate([Constant.BASE_PATH]);
            }
            else {
              setTimeout(() => {
                this.showMsg = false;
                sessionStorage.setItem('batchQueuedRejects', 'true');
                this.router.navigate([Constant.BASE_PATH]);
              }, 5000);
            }
          }
          this.transactions = queuedTransactions.concat(
            releasedtransactions.concat(deletedtransactions)
          );
          this.displayMerchantData = true;
          localStorage.removeItem(Constants.batchRejectIdforQueuedDrillDown);
        } catch (ex) {
          this.displayMerchantData = false;
          console.log("error");
          console.log(ex);
        }
      });
    this.disabled = true;
    this.showRefreshButton = false;
  }

  onPageSizeChanged(e: any) {
    if (this.totalResults < this.paginationPageSize) {
      this.paginationPageSize = this.totalResults;
    }
    this.setDomLayouts();
    this.gridApiActive.paginationSetPageSize(e.value);
    this.resetPaginationSelection(this);
  }

  changeRowColor(params) {
    if (
      params.data.daysToAct <= params.context.daysToAct &&
      params.data.status !== "Queued"
    ) {
      return { "background-color": "#dee2e6" };
    } else if (params.data.status !== "Queued") {
      return { "background-color": "#dee2e6" };
    } else if (params.data.daysToAct <= params.context.daysToAct) {
      return { backgroundColor: '#ffe6e6' };
    } else {
      return null;
    }
  }

  onSubmit() {
    const options = {
      title: "Confirm!",
      message: "Are you sure you want to submit?",
      cancelText: "No",
      confirmText: "Yes"
    };
    this.isSuccess = true;
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe(
      (confirmed: any) => {
        if (confirmed) {
          let transactionsStatus: TransStatus[] = [];
          this.gridApiActive.forEachNode(node => {
            //if (node.alreadyRendered && node.selectable && node.displayed) {
            if (node.data.hasOwnProperty("action") && node.data.action > 2) {
              const transcation = {
                batchTransactionRejectId: node.data.batchTransactionRejectId,
                newStatus: node.data.action.toString()
              };
              transactionsStatus.push(transcation);
            }
            // }
          });

          const transactionAction = {
            batchRejectId: this.batchtxnRejects.batchRejectId,
            batchTransactionsStatus: transactionsStatus,
            userName: this.configService.configData.username
          };
          localStorage.setItem(
            Constants.batchRejectIdforQueuedDrillDown,
            this.batchtxnRejects.batchRejectId.toString()
          );
          // add API call to save modified row
          const res = this.batchQueuedtxnservice
            .transcationsAction(transactionAction)
            .subscribe((res: any) => {
              let successCount: number = 0;
              let failCount: number = 0;
              let totalCount: number = 0;
              res.batchTransactionRejectUpdateStatuses.forEach(row => {
                totalCount++;
                if (row.updateStatus == Constant.Success) {
                  successCount = successCount + 1;
                } else if (row.updateStatus == Constant.Failed) {
                  failCount = failCount + 1;
                }
              });
              if (failCount == 0) {
                this.message =
                  successCount +
                  "/" +
                  totalCount +
                  " records were processed successfully.";
                this.fetchData();
              } else if (successCount > 0) {
                this.message =
                  failCount +
                  "/" +
                  totalCount +
                  " records were not processed as another user has already worked on the same records.";
                this.fetchData();
                this.isSuccess = false;
              } else {
                this.message = "Transaction(s) update failed.";
                this.fetchData();
                this.isSuccess = false;
              }
              this.showMsg = true;
              this.FadeOutSuccessMsg();
              this.ResetSearch();
              localStorage.setItem("IsChanged", "false");
            });
        } else {
          console.log("No");
        }
      },
      (reason: any) => {
        console.log("Dismissed " + reason);
        console.log("redirec to log out");
      }
    );
  }
  countDisplayedRows(params) {
    this.totalResults = params.api.paginationGetRowCount();
  }
  resetPaginationSelection = self => {
    console.log("resetPaginationSelection");
    //Deselect previously selected rows to reset selection
    // self.gridApiActive.deselectAll();

    //Initialize pagination data
    let paginationSize = self.gridApiActive.paginationGetPageSize();
    let currentPageNum = self.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = self.gridApiActive.getDisplayedRowCount();

    this.setDomLayouts();
    //Calculate current page row indexes
    let currentPageRowStartIndex = currentPageNum * paginationSize;
    let currentPageRowLastIndex = currentPageRowStartIndex + paginationSize;
    if (currentPageRowLastIndex > totalRowsCount)
      currentPageRowLastIndex = totalRowsCount;

    for (let i = 0; i < totalRowsCount; i++) {
      //Set isRowSelectable=true attribute for current page rows, and false for other page rows
      let isWithinCurrentPage =
        i >= currentPageRowStartIndex && i < currentPageRowLastIndex;
      self.gridApiActive
        .getDisplayedRowAtIndex(i)
        .setRowSelectable(isWithinCurrentPage);
    }
  };
  parentMethod() {
    this.DirtyData();
    var flag: boolean = false;
    this.gridApiActive.forEachNode(node => {
      if (node.data.hasOwnProperty("action") && node.data.action > 2) {
        flag = true;
      }
      //else if (node.data.action == 2) {
      //  flag = false;
      //}
    });
    if (flag) {
      this.disabled = false;
    } else {
      this.disabled = true;
    }
  }

  DirtyData() {
    localStorage.setItem("IsNotAllSelected", "true");
    this.gridApiActive.forEachNode(node => {
      if (node.data.hasOwnProperty("action") && node.data.action != 2) {
        localStorage.setItem("IsChanged", "true");
        localStorage.setItem("IsNotAllSelected", "false");
        console.log(node.data.hasOwnProperty("action"), node.data.action);
        return;
      } else if (node.data.action == 2) {
        if (localStorage.getItem("IsChanged") != "true") {
          console.log("action", node.data.action);
          localStorage.removeItem("IsChanged");
          localStorage.setItem("IsChanged", "false");
        } else if (
          localStorage.getItem("IsNotAllSelected") == "true" &&
          node.data.action == 2
        ) {
          localStorage.removeItem("IsChanged");
          localStorage.setItem("IsChanged", "false");
        }
      }
    });
  }

  onGridReady(params: any) {
   // this.gridOptions.api.sizeColumnsToFit();
    this.gridApiActive = params.api;
    this.gridApiActive.addEventListener("paginationChanged", e => {
      //Reset rows selection based on current page
      this.resetPaginationSelection(this);
    });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      this.gridOptions.suppressNoRowsOverlay = false;
      this.gridOptions.overlayNoRowsTemplate =
        '<span style="color:black;font-size:15px;height:35px;margin-top: 1%;">No records to display.</span>';
      this.gridApiActive.api.showNoRowsOverlay();
    } else {
      this.setDomLayouts();
      this.gridApiActive.api.hideOverlay();
    }
  }

  SearchText: any;
  OnFilterBoxChanged() {
    if (this.SearchText != "") {
      localStorage.setItem("IsChanged", "true");
    } else if (this.SearchText == "") {
      localStorage.setItem("IsChanged", "false");
    }
    this.gridApiActive.forEachNode(node => {
      if (node.data.hasOwnProperty("action")) {
        node.data["action"] = 2;
      }
    });
    this.gridApiActive.setQuickFilter(this.SearchText);
    this.gridApiActive.refreshCells({ force: true });
    if (this.gridApiActive.getDisplayedRowCount() == 0) {
      this.gridApiActive.api.showNoRowsOverlay();
    }
    else {
      this.gridApiActive.api.hideOverlay();
    
    }
    this.disabled = true;
    this.setDomLayouts();
  }

  dateFormatter(data) {
    return data.value ? data.value.replace("T", " ").replace("Z", "") : "";
  }
  FadeOutSuccessMsg() {
    setTimeout(() => {
      this.showMsg = false;
    }, 10000);
  }

  ResetSearch() {
    this.gridApiActive.setQuickFilter(null);
    this.SearchText = "";
  }

  onPaginationChanged(params: PaginationChangedEvent) {
    this.gridApiActive = params.api;
    this.gridApiActive.forEachNode(node => {
      if (node.data.hasOwnProperty("action")) {
        /*  delete node.data["action"];
        this.disabled = true; */
      }
    });
    localStorage.setItem("IsChanged", "false");
  }

  onRefreshButtonClick() {
    const options = {
      title: "Confirm!",
      message: "Unsaved actions will get reset, continue with refresh?",
      cancelText: "No",
      confirmText: "Yes"
    };
    this._dialogSvc.openDialog(options);
    this._dialogSvc.confirmed().subscribe((confirmed: any) => {
      if (confirmed) {
        localStorage.setItem(
          Constants.batchRejectIdforQueuedDrillDown,
          this.batchtxnRejects.batchRejectId.toString()
        );
        this.IsBatchQueuedRejects = true;
        this.fetchData();
        this.ResetSearch();
      }
    });
  }
  setDomLayouts() {
    let paginationSize = this.gridApiActive.paginationGetPageSize();
    let currentPageNum = this.gridApiActive.paginationGetCurrentPage();
    let totalRowsCount = this.gridApiActive.getDisplayedRowCount();

    const startResult = currentPageNum * paginationSize;
    const endResult = Math.min(
      startResult + paginationSize - 1,
      totalRowsCount
    );
    if (endResult - startResult + 1 >= this.paginationPageSize) {
      this.style = {
        height: "520px"
      };
      this.gridApiActive.setGridOption("domLayout", "normal");
    } else {
      this.style = {
        height: "auto"
      };
      this.gridApiActive.setGridOption("domLayout", "autoHeight");
    }
  }

  connectHub() {
    this.disconnectHub();
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.signalrNotificationEndpoint)
        .withAutomaticReconnect()
        .configureLogging(signalR.LogLevel.Information)
        .build();

      this.connection.on("NotifyQueueBatchTxnRejectsTab", (response) => {
        if (response == this.batchtxnRejects.batchRejectId.toString() && !this.showRefreshButton)
          this.showRefreshButton = true;
      });

      this.connection
        .start()
        .then(function () {
          console.info("connected to signalr...");
        })
        .catch(err => console.error(err));
    }
  }

  disconnectHub() {
    if (this.connection) {
      this.connection.stop();
      this.connection = null;
    }
  }

  ngOnDestroy(): void {
    this.disconnectHub();
  }
}
