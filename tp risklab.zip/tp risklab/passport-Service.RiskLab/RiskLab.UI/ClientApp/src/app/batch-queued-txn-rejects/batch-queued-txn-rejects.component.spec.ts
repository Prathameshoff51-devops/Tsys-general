
import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick
} from "@angular/core/testing";

import { BatchQueuedTxnRejectsComponent } from "./batch-queued-txn-rejects.component";
import { ConfigurationService } from "../shared/services/configuration.service";
import { AppConfig } from "../shared/models/app-config";
import { HttpTestingController, provideHttpClientTesting } from "@angular/common/http/testing";
import { DebugElement } from "@angular/core";
import { AgGridModule } from "ag-grid-angular";
import { LoadingDialogService } from "../ui/service/loading-dialog.service";
import { of } from "rxjs";
import { BatchQueuedtxnservice } from "../shared/services/batch-queued-txn-rejects";
import { BatchtxnRejects } from "../shared/models/batch-queued-txn-rejects.model";
import { ConstantsUnitTest } from "../constant.unit.test";
import { Router } from "@angular/router";
import { Constants } from "../Constants";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import * as signalR from '@microsoft/signalr';
import { provideHttpClient, withInterceptorsFromDi } from "@angular/common/http";

describe("BatchQueuedTxnRejectsComponent", () => {
  let component: BatchQueuedTxnRejectsComponent;
  let fixture: ComponentFixture<BatchQueuedTxnRejectsComponent>;
  let el: DebugElement;
  let httpTestingController: HttpTestingController;
  let mockHubConnection: jasmine.SpyObj<signalR.HubConnection>;

  const mockConfigurationService = jasmine.createSpyObj(
    "ConfigurationService",
    ["configData"]
  );
  Object.defineProperty(mockConfigurationService, 'config', {
    get: () => {
      return {
        DefaultGridPageSizeforBatchTxnRejects: 10,
        daysToAct: 10
      };
    },
    configurable: true
  });
  const mockLoadingDialogService = jasmine.createSpyObj(
    "LoadingDialogService",
    ["openDialog", "confirmed", "hideDialog"]
  );
  const mockRouter = {
    navigate: jasmine.createSpy("navigate"),
    getCurrentNavigation: jasmine.createSpy("getCurrentNavigation")
  };
  let apiReponse: BatchtxnRejects = {
    batchRejectId: 53,
    originalBatchNumber: "102030",
    merchantNumber: "650000012036045",
    merchantName: "ANTHONY JACKSON",
    batchAmount: "200",
    batchCloseDateUTC: "2023-01-12T08:22:26.047",
    status: "Queued",
    transactions: [
      {
        batchTransactionRejectId: 698707,
        batchRejectId: 53,
        status: "Queued",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-12T08:22:26.05",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 2,
        daysToAct: 0,
        expDate: "2022-09-23T16:19:53",
        authCode: "02649Z",
        rejectReasons: ["Merchant refund threshold limit exceeded"]
      },
      {
        batchTransactionRejectId: 698734,
        batchRejectId: 53,
        status: "Released",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-16T07:52:21.117",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 2,
        daysToAct: 0,
        expDate: "2022-09-23T16:19:53",
        authCode: "02649Z",
        rejectReasons: ["Merchant refund threshold limit exceeded"]
      },
      {
        batchTransactionRejectId: 698735,
        batchRejectId: 53,
        status: "Deleted",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-16T07:52:32.22",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 2,
        daysToAct: 0,
        authCode: "02649Z",
        expDate: "2022-09-23T16:19:53",
        rejectReasons: [
          "Merchant refund threshold limit exceeded",
          "Suspected fraudulent BIN",
          "Batch refund threshold limit exceeded - PIN Debit transactions excluded"
        ]
      }
    ]
  };
  let apiReponse2: BatchtxnRejects = {
    batchRejectId: 53,
    originalBatchNumber: "102030",
    merchantNumber: "650000012036045",
    merchantName: "ANTHONY JACKSON",
    batchAmount: "200",
    batchCloseDateUTC: "2023-01-12T08:22:26.047",
    status: "New",
    transactions: [
      {
        batchTransactionRejectId: 698707,
        batchRejectId: 53,
        status: "New",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-12T08:22:26.05",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 2,
        daysToAct: 0,
        expDate: "2022-09-23T16:19:53",
        authCode: "02649Z",
        rejectReasons: ["Merchant refund threshold limit exceeded"]
      },
      {
        batchTransactionRejectId: 698734,
        batchRejectId: 53,
        status: "Released",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-16T07:52:21.117",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 2,
        daysToAct: 0,
        expDate: "2022-09-23T16:19:53",
        authCode: "02649Z",
        rejectReasons: ["Merchant refund threshold limit exceeded"]
      },
      {
        batchTransactionRejectId: 698735,
        batchRejectId: 53,
        status: "Deleted",
        txnAmount: 100,
        txnType: "Refund",
        cardNumberMasked: "123456******1234",
        txnDateUTC: "2023-01-16T07:52:32.22",
        originalBatchNumber: "102030",
        batchCloseDateUTC: "2023-01-12T08:22:26.047",
        actionDropdown: 3,
        action: 2,
        daysToAct: 0,
        authCode: "02649Z",
        expDate: "2022-09-23T16:19:53",
        rejectReasons: [
          "Merchant refund threshold limit exceeded",
          "Suspected fraudulent BIN",
          "Batch refund threshold limit exceeded - PIN Debit transactions excluded"
        ]
      }
    ]
  };
  const bodytranscationsAction = {
    batchRejectId: 53,
    batchTransactionsStatus: [
      { batchTransactionRejectId: 698707, newStatus: "3" },
      { batchTransactionRejectId: 698734, newStatus: "3" },
      { batchTransactionRejectId: 698735, newStatus: "3" }
    ],
    userName: "Nikhil.Akole"
  };
  const transcationsActionResponse = {
    batchTransactionRejectUpdateStatuses: [
      {
        batchTransactionRejectId: 698707,
        updateStatus: "Success",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698734,
        updateStatus: "Success",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698735,
        updateStatus: "Success",
        statusCode: "200"
      }
    ]
  };
  const transcationsActionResponseTwoFailed = {
    batchTransactionRejectUpdateStatuses: [
      {
        batchTransactionRejectId: 698707,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698734,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698735,
        updateStatus: "Success",
        statusCode: "200"
      }
    ]
  };
  const transcationsActionResponseAllFailed = {
    batchTransactionRejectUpdateStatuses: [
      {
        batchTransactionRejectId: 698707,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698734,
        updateStatus: "Failed",
        statusCode: "200"
      },
      {
        batchTransactionRejectId: 698735,
        updateStatus: "Failed",
        statusCode: "200"
      }
    ]
  };

  beforeEach(async () => {
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    await TestBed.configureTestingModule({
    declarations: [BatchQueuedTxnRejectsComponent],
    imports: [AgGridModule,
        FormsModule,
        CommonModule],
    providers: [
        {
            provide: ConfigurationService,
            useValue: mockConfigurationService
        },
        BatchQueuedtxnservice,
        {
            provide: LoadingDialogService,
            useValue: mockLoadingDialogService
        },
        {
            provide: AppConfig,
            useValue: new AppConfig(ConstantsUnitTest.config)
        },
        { provide: Router, useValue: mockRouter },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting()
    ]
}).compileComponents();
  });
  beforeEach(() => {
    localStorage.setItem(Constants.batchRejectIdforQueuedDrillDown, "53");
    fixture = TestBed.createComponent(BatchQueuedTxnRejectsComponent);
    httpTestingController = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    mockHubConnection = jasmine.createSpyObj('HubConnection', ['start', 'stop', 'on']);
    // Ensure .start always returns a Promise to avoid TypeError on .then
    mockHubConnection.start.and.returnValue(Promise.resolve());



    // Mock the builder chain using prototype spies
    spyOn(signalR.HubConnectionBuilder.prototype, 'withUrl').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'withAutomaticReconnect').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'configureLogging').and.callFake(function () { return this; });
    spyOn(signalR.HubConnectionBuilder.prototype, 'build').and.returnValue(mockHubConnection);

    // Mock gridApiActive and its required methods to prevent undefined errors in tests
    component.gridApiActive = {
      hideOverlay: jasmine.createSpy('hideOverlay'),
      showNoRowsOverlay: jasmine.createSpy('showNoRowsOverlay'),
      forEachNode: jasmine.createSpy('forEachNode'),
      getDisplayedRowCount: jasmine.createSpy('getDisplayedRowCount').and.returnValue(3),
      paginationGetCurrentPage: jasmine.createSpy('paginationGetCurrentPage').and.returnValue(0),
      paginationGoToNextPage: jasmine.createSpy('paginationGoToNextPage'),
      paginationGetTotalPages: jasmine.createSpy('paginationGetTotalPages').and.returnValue(2),
      setQuickFilter: jasmine.createSpy('setQuickFilter'),
      deselectAll: jasmine.createSpy('deselectAll'),
      sizeColumnsToFit: jasmine.createSpy('sizeColumnsToFit'),
      refreshCells: jasmine.createSpy('refreshCells'),
      redrawRows: jasmine.createSpy('redrawRows'),
      getSelectedRows: jasmine.createSpy('getSelectedRows').and.returnValue([]),
      setDomLayout: jasmine.createSpy('setDomLayout'),
      paginationSetPageSize: jasmine.createSpy('paginationSetPageSize'),
      addEventListener: jasmine.createSpy('addEventListener'),
      paginationGetPageSize: jasmine.createSpy('paginationGetPageSize').and.returnValue(15),
      paginationGetRowCount: jasmine.createSpy('paginationGetRowCount').and.returnValue(100),
      getDisplayedRowAtIndex: jasmine.createSpy('getDisplayedRowAtIndex').and.returnValue({
        setRowSelectable: jasmine.createSpy('setRowSelectable')
      }),
      api: {
        hideOverlay: jasmine.createSpy('api.hideOverlay'),
        showNoRowsOverlay: jasmine.createSpy('api.showNoRowsOverlay')
      }
    };

    // Mock gridOptions if needed
    component.gridOptions = component.gridOptions || {};
    component.gridOptions.overlayNoRowsTemplate = '<span style="color:black;font-size:15px;height:35px;margin-top: 1%;">No records to display.</span>';

    fixture.detectChanges();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
  it(`should have config paginationPageSize be 15`, () => {
    component.config.defaultGridPageSize = 15;
    component.config.daysToAct = 10;
    expect(component.daysToAct).toEqual(10);
    expect(component.paginationPageSize).toEqual(10);
  });
  it(`should have called changeRowColor`, () => {
    let params = {
      data: {
        daysToAct: 10,
        status: "Queued"
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color.backgroundColor).toEqual('#ffe6e6' );
  });
  it(`should changeRowColor and backgroundColor`, () => {
    let params = {
      data: {
        daysToAct: 14,
        status: "Deleted"
      },
      context: {
        daysToAct: 12
      }
    };
    let color = component.changeRowColor(params);

    expect(color["background-color"]).toEqual("#dee2e6");
  });
  it(`should be return null from changeRowColor`, () => {
    let params = {
      data: {
        status: "Queued"
      },
      context: {}
    };
    let color = component.changeRowColor(params);
    expect(color).toEqual(null);
  });
  it("should be No data ", async () => {
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridOptions.overlayNoRowsTemplate).toEqual(
      '<span style="color:black;font-size:15px;height:35px;margin-top: 1%;">No records to display.</span>'
    );
  });
  it("should called fetchData ", async () => {
    localStorage.setItem(Constants.batchRejectIdforQueuedDrillDown, "53");
    const req = httpTestingController.expectOne(
      "https://localhost:7247/BatchTransactionRejects?batchRejectId=53"
    );
    req.flush(apiReponse); // Respond with empty search results
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(3);
  });
  it("should be called resetPaginationSelection ", async () => {
    let apiResponsePageChange = JSON.parse(JSON.stringify(apiReponse));
    for (let i = 0; i < 15; i++) {
      apiResponsePageChange.transactions.push(
        apiResponsePageChange.transactions[0]
      );
    }
    component.transactions = apiResponsePageChange.transactions;
    component.displayMerchantData = true;
    component.batchtxnRejects = apiResponsePageChange;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(0);
    component.gridApiActive.paginationGoToNextPage();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.onRefreshButtonClick();

    expect(component.gridApiActive.paginationGetCurrentPage()).toEqual(1);
    expect(component.gridApiActive.paginationGetTotalPages()).toEqual(2);
    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(18);
    expect(component.showRefreshButton).toEqual(false);
  });
  it("should be called onPageSizeChanged ", async () => {
    let e = {
      value: 20
    };
    component.batchtxnRejects = apiReponse;
    component.transactions = [
      ...apiReponse.transactions,
      ...apiReponse.transactions,
      ...apiReponse.transactions,
      ...apiReponse.transactions
    ];
    component.displayMerchantData = true;
    component.totalResults = 12;
    component.paginationPageSize = 20;

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    component.onPageSizeChanged(e);

    expect(component.gridApiActive.getDisplayedRowCount()).toEqual(12);
  });
  it("should be All transcations successfully update ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    component.configService.configData.username = "Nikhil.Akole";

    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchTransactionRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponse);
    expect(component.message).toEqual(
      "3/3 records were processed successfully."
    );
  });
  it("should be some transcations successfully update ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchTransactionRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseTwoFailed);
    expect(component.message).toEqual(
      "2/3 records were not processed as another user has already worked on the same records."
    );
  });
  it("should be All transcations failed update ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    component.configService.configData.username = "Nikhil.Akole";
    component.onSubmit();
    const req = httpTestingController.expectOne({
      method: "POST",
      url: "https://localhost:7247/BatchTransactionRejects"
    });
    expect(req.request.body).toEqual(bodytranscationsAction);
    req.flush(transcationsActionResponseAllFailed);
    expect(component.message).toEqual("Transaction(s) update failed.");
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  it("should handle confirmed dialog correctly", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 3;
    }
    mockLoadingDialogService.confirmed.and.returnValue(of(false));
    component.onSubmit();
    expect(localStorage.getItem("IsChanged")).toEqual("false");
  });
  // Test for search functionality - Fixed version
  it("should handle search text filtering", async () => {
     // Add setGridOption to the mock if not already present
    if (!component.gridApiActive.setGridOption) {
      component.gridApiActive.setGridOption = jasmine.createSpy('setGridOption');
    }
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();

    component.SearchText = "102030";

    // Mock the forEachNode callback properly
    component.gridApiActive.forEachNode.and.callFake((callback) => {
      apiReponse.transactions.forEach((txn) => {
        callback({ data: { ...txn, action: 1 } });
      });
    });

    component.OnFilterBoxChanged();

    expect(component.gridApiActive.setQuickFilter).toHaveBeenCalledWith("102030");
    expect(component.gridApiActive.refreshCells).toHaveBeenCalledWith({ force: true });
    expect(localStorage.getItem("IsChanged")).toBe("true");
  });


  it("should be disabled  ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it("should be !disabled  ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    apiReponse.transactions[0].action = 3;
    await component.parentMethod();

    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeFalse();
  });
  it("should be parentMethod return disabled  ", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;
    component.displayMerchantData = true;
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    localStorage.setItem("IsChanged", "true");
    await component.parentMethod();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.disabled).toBeTrue();
  });
  it(
    `should have called FadeOutSuccessMsg`,
    fakeAsync(() => {
      component.showMsg = true;
      component.FadeOutSuccessMsg();
      tick(10000);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.showMsg).toEqual(false);
      });
    })
  );

  it("should test ResetSearch method", () => {
    component.SearchText = "test";
    component.ResetSearch();

    expect(component.SearchText).toBe("");
    expect(component.gridApiActive.setQuickFilter).toHaveBeenCalledWith(null);
  });

  it("should test dateFormatter with valid date", () => {
    const result = component.dateFormatter({ value: "2023-01-12T08:22:26.047Z" });
    expect(result).toBe("2023-01-12 08:22:26.047");
  });

  it("should test dateFormatter with null value", () => {
    const result = component.dateFormatter({ value: null });
    expect(result).toBe("");
  });

  it("should test currencyFormatter", () => {
    const result = component.currencyFormatter({ value: 100.5 });
    expect(result).toBe("$100.50");
  });

  it("should test onPaginationChanged", () => {
    const mockParams = {
      api: component.gridApiActive,
      newPage: 1,
      columnApi: null,
      context: null,
      type: 'paginationChanged'
    } as any;
    component.onPaginationChanged(mockParams);
    expect(component.gridApiActive.forEachNode).toHaveBeenCalled();
  });

  it("should test ngOnDestroy", () => {
    spyOn(component, 'ngOnDestroy').and.callThrough();
    component.ngOnDestroy();
    expect(component.ngOnDestroy).toHaveBeenCalled();
  });

  it("should test OnFilterBoxChanged with empty search text", () => {
     // Add setGridOption to the mock if not already present
    if (!component.gridApiActive.setGridOption) {
      component.gridApiActive.setGridOption = jasmine.createSpy('setGridOption');
    }
    component.SearchText = "";
    component.OnFilterBoxChanged();

    expect(component.gridApiActive.setQuickFilter).toHaveBeenCalledWith("");
    expect(component.disabled).toBe(true);
  });

  it("should test OnFilterBoxChanged with search text", () => {
     // Add setGridOption to the mock if not already present
    if (!component.gridApiActive.setGridOption) {
      component.gridApiActive.setGridOption = jasmine.createSpy('setGridOption');
    }
    component.SearchText = "test";
    component.OnFilterBoxChanged();

    expect(component.gridApiActive.setQuickFilter).toHaveBeenCalledWith("test");
    expect(component.disabled).toBe(true);
  });

  it("should test component initialization", () => {
    expect(component.disabled).toBe(true);
    expect(component.showRefreshButton).toBe(false);
    expect(component.showMsg).toBe(false);
    expect(component.isSuccess).toBe(true);
    expect(component.IsBatchQueuedRejects).toBe(false);
  });

  it("should test setDomLayouts method", () => {
    // Add setGridOption to the mock if not already present
    if (!component.gridApiActive.setGridOption) {
      component.gridApiActive.setGridOption = jasmine.createSpy('setGridOption');
    }
    component.paginationPageSize = 15;
    component.setDomLayouts();
    expect(component.gridApiActive.paginationGetPageSize).toHaveBeenCalled();
    expect(component.gridApiActive.paginationGetCurrentPage).toHaveBeenCalled();
    expect(component.gridApiActive.getDisplayedRowCount).toHaveBeenCalled();
  });

  it("should test resetPaginationSelection method", () => {
    // Add setGridOption to the mock if not already present
    if (!component.gridApiActive.setGridOption) {
      component.gridApiActive.setGridOption = jasmine.createSpy('setGridOption');
    }
    component.resetPaginationSelection(component);
    expect(component.gridApiActive.paginationGetPageSize).toHaveBeenCalled();
    expect(component.gridApiActive.paginationGetCurrentPage).toHaveBeenCalled();
    expect(component.gridApiActive.getDisplayedRowCount).toHaveBeenCalled();
  });

  it("should test connectHub method", () => {
    spyOn(component, 'disconnectHub');
    component.connectHub();
    expect(component.disconnectHub).toHaveBeenCalled();
  });

  it("should test DirtyData method", () => {
    spyOn(console, 'log');
    component.DirtyData();
    expect(component.gridApiActive.forEachNode).toHaveBeenCalled();
  });

  it("should test onRefreshButtonClick", () => {
    component.batchtxnRejects = apiReponse;
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    spyOn(component, 'fetchData');
    spyOn(component, 'ResetSearch');

    component.onRefreshButtonClick();

    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(component.IsBatchQueuedRejects).toBe(true);
  });
  it('should call fetchData when onRefreshButtonClick is triggered', () => {
    // Arrange
    const fetchDataSpy = spyOn(component, 'fetchData');
    spyOn(component, 'ResetSearch');
    component.batchtxnRejects = apiReponse;
    mockLoadingDialogService.confirmed.and.returnValue(of(true));
    // Act
    component.onRefreshButtonClick();
    // Assert
    expect(fetchDataSpy).toHaveBeenCalled();
    expect(component.ResetSearch).toHaveBeenCalled();
    expect(mockLoadingDialogService.openDialog).toHaveBeenCalled();
    expect(component.IsBatchQueuedRejects).toBe(true);
  });
  it("should test countDisplayedRows", () => {
    const mockParams = {
      api: {
        paginationGetRowCount: jasmine.createSpy('paginationGetRowCount').and.returnValue(50)
      }
    };

    component.countDisplayedRows(mockParams);
    expect(component.totalResults).toBe(50);
  });

  it("should test parentMethod with different scenarios", async () => {
    component.batchtxnRejects = apiReponse;
    component.transactions = apiReponse.transactions;

    // Test when localStorage IsChanged is false
    localStorage.setItem("IsChanged", "false");
    await component.parentMethod();
    expect(component.disabled).toBe(true);

    // Test when all actions are 2
    for (let res of apiReponse.transactions) {
      res.action = 2;
    }
    await component.parentMethod();
    expect(component.disabled).toBe(true);
  });

  it("should test component properties initialization", () => {
    expect(component.config).toBeDefined();
    expect(component.context).toBeDefined();
    expect(component.gridOptions).toBeDefined();
    expect(component.rowSelection).toBe("multiple");
  });
  it('should call builder chain and connectHub', fakeAsync(() => {
      // The builder chain methods are already spied in beforeEach
      component.connectHub();
      tick(); // Flush microtasks to resolve the Promise
      expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
      expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyQueueBatchTxnRejectsTab', jasmine.any(Function));
      expect(mockHubConnection.start).toHaveBeenCalled();
    }));
  
    it('should set showRefreshButton to true when NotifyQueueBatchTxnRejectsTab event is received', fakeAsync(() => {
      // The builder chain methods are already spied in beforeEach
      let notifyHandler: ((response: any) => void) | undefined;
      mockHubConnection.on.and.callFake((event, handler) => {
        if (event === 'NotifyQueueBatchTxnRejectsTab') {
          notifyHandler = handler;
        }
      });
      component.showRefreshButton = false;
      component.batchtxnRejects = apiReponse;
      component.connectHub();
      tick(); // Flush microtasks to resolve the Promise
      expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
      expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyQueueBatchTxnRejectsTab', jasmine.any(Function));
      expect(mockHubConnection.start).toHaveBeenCalled();
      // Act: simulate event received
      if (notifyHandler) {
        notifyHandler(53);
      }
      // Assert
      expect(component.showRefreshButton).toBeTrue();
    }));
    it('should call catch and log error if SignalR connection fails in connectHub', fakeAsync(() => {
      // The builder chain methods are already spied in beforeEach
      const error = new Error('Connection failed');
      spyOn(console, 'error');
      mockHubConnection.start.and.returnValue(Promise.reject(error));
      component.connectHub();
      tick(); // Flush microtasks to resolve the Promise
      expect(signalR.HubConnectionBuilder.prototype.withUrl).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.withAutomaticReconnect).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.configureLogging).toHaveBeenCalled();
      expect(signalR.HubConnectionBuilder.prototype.build).toHaveBeenCalled();
      expect(mockHubConnection.on).toHaveBeenCalledWith('NotifyQueueBatchTxnRejectsTab', jasmine.any(Function));
      expect(mockHubConnection.start).toHaveBeenCalled();
      expect(console.error).toHaveBeenCalledWith(error);
    }));

  it('should immediately navigate if queuedTransactions is empty and IsBatchQueuedRejects is true', () => {
    localStorage.setItem(Constants.batchRejectIdforQueuedDrillDown, "53");
    // Arrange
    component.IsBatchQueuedRejects = true;
     const req = httpTestingController.expectOne(
      "https://localhost:7247/BatchTransactionRejects?batchRejectId=53"
    );
    req.flush(apiReponse2); // Respond with empty search results
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/']);
  });

  it('should delay navigation and hide showMsg if queuedTransactions is empty and IsBatchQueuedRejects is false', fakeAsync(() => {
    // Arrange
    component.IsBatchQueuedRejects = false;
    component.showMsg = true;
    const req = httpTestingController.expectOne(
      "https://localhost:7247/BatchTransactionRejects?batchRejectId=53"
    );
    req.flush(apiReponse2); // Respond with empty search results
    // Fast-forward time
    tick(5000);
    // Assert
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/']);
  }));
  it('should log error and redirect to logout if dialogSvc.confirmed emits error in onSubmit', () => {
    // Arrange: get the dialog service from TestBed
    const dialogSvc = TestBed.inject(LoadingDialogService) as jasmine.SpyObj<LoadingDialogService>;
    dialogSvc.openDialog.and.stub();
    dialogSvc.confirmed.and.returnValue({
      subscribe: (success, error) => {
        if (error) error('some error reason');
      }
    } as any);
    spyOn(console, 'log');
    // Act
    component.onSubmit();
    // Assert
    expect(console.log).toHaveBeenCalledWith('Dismissed some error reason');
    expect(console.log).toHaveBeenCalledWith('redirec to log out');
  });
  it('should call catch block and log error in fetchData when forEach throws', () => {
    // Arrange: Make the forEach throw an error
    const errorObj = new Error('forEach error');
    spyOn(component['batchQueuedtxnservice'], 'getBatchtxnRejects').and.returnValue({
      subscribe: (success) => {
        success(apiReponse);
      }
    } as any);
    spyOn(localStorage, 'getItem').and.returnValue('16');
    spyOn(localStorage, 'removeItem');
    spyOn(apiReponse.transactions, 'forEach').and.callFake(() => { throw errorObj; });
    //spyOn(console, 'log');

    // Spy on console.log
    if (!(console.log as any).calls) {
      spyOn(console, 'log');
    }
    // Act
    component.fetchData();
    // Assert
    expect(console.log).toHaveBeenCalledWith('error');
    expect(console.log).toHaveBeenCalledWith(errorObj);
  });
  
    it('should call showNoRowsOverlay if getDisplayedRowCount is 0 after OnFilterBoxChanged', () => {
       // Add setGridOption to the mock if not already present
    if (!component.gridApiActive.setGridOption) {
      component.gridApiActive.setGridOption = jasmine.createSpy('setGridOption');
    }
    // Arrange
    component.gridApiActive.getDisplayedRowCount.and.returnValue(0);
    // Ensure api and showNoRowsOverlay are defined and are spies
    if (!component.gridApiActive.api) {
      component.gridApiActive.api = { showNoRowsOverlay: jasmine.createSpy('showNoRowsOverlay') };
    } else if (!component.gridApiActive.api.showNoRowsOverlay) {
      component.gridApiActive.api.showNoRowsOverlay = jasmine.createSpy('showNoRowsOverlay');
    }
    // Act
    component.OnFilterBoxChanged();
    // Assert
    expect(component.gridApiActive.api.showNoRowsOverlay).toHaveBeenCalled();
  });
});
