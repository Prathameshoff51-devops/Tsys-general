import {
  NgModule,
  APP_INITIALIZER,
  CUSTOM_ELEMENTS_SCHEMA,
  ErrorHandler,
} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { IndividualRefundsComponent } from './individual-refunds/individual-refunds.component';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSelectModule } from '@angular/material/select';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MenuListItemComponent } from './ui/menu-list-item/menu-list-item.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { RiskrejectsComponent } from './riskrejects/riskrejects.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ConfigurationService } from './shared/services/configuration.service';
import { TopNavbarComponent } from './navigation/top-navbar/top-navbar.component';
import { SideNavbarComponent } from './navigation/side-navbar/side-navbar.component';
import { QueuedTxnRefundsComponent } from './queued-txn-refunds/queued-txn-refunds.component';
import { AgGridModule } from 'ag-grid-angular';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatExpansionModule } from '@angular/material/expansion';
import { OKTA_CONFIG, OktaAuthGuard, OktaAuthModule } from '@okta/okta-angular';
import { OktaAuth, OktaAuthOptions } from '@okta/okta-auth-js';
import { AppConfig } from './shared/models/app-config';
import { AuthInterceptor } from './shared/interceptor/auth.interceptor';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ErrorDialogComponent } from './ui/error-dialog/error-dialog.component';
import { LogoutComponent } from './logout/logout.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { ErrorDialogService } from './ui/service/error-dialog.service';
import { LoadingDialogService } from './ui/service/loading-dialog.service';
import { GlobalErrorHandler } from './shared/services/global-error-handler.service';
import { ErrorService } from './shared/services/error.service';
import { DropDownListRendererComponent } from './ui/drop-down-list-renderer/drop-down-list-renderer.component';
import { LoaderComponent } from './ui/loader/loader.component';
import { LoaderService } from './ui/service/loader.service';
import { LoadingDialogComponent } from './ui/loading-dialog/loading-dialog.component';
import { IdleTimeoutService } from './shared/services/idle-timeout.service';
import { MerchantRejectedtxnsComponent } from './merchant-rejectedtxns/merchant-rejectedtxns.component';
import { FraudServiceComponent } from './fraud-service/fraud-service.component';
import { AlertDialogComponent } from './ui/alert-dialog/alert-dialog.component';
import { AlertService } from './ui/service/alert.service';
import { BulkRefundsComponent } from './bulk-refunds/bulk-refunds.component';
import { QueuedBulkRefundsComponent } from './queued-bulk-refunds/queued-bulk-refunds.component';
import { RouterLinkRendererComponent } from './navigation/router-link-renderer/router-link-renderer.component';
import { RiskrejectsBulkComponent } from './riskrejects-bulk/riskrejects-bulk.component';
import { BatchNewtxnRejectsComponent } from './batch-new-txn-rejects/batch-new-txn-rejects.component';
import { BatchQueuedTxnRejectsComponent } from './batch-queued-txn-rejects/batch-queued-txn-rejects.component';
import { ExportImportComponent } from './export-import/export-import.component';
import { VegaComponentModule } from '@heartlandone/vega-angular';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    IndividualRefundsComponent,
    MaintenanceComponent,
    MenuListItemComponent,
    RiskrejectsComponent,
    TopNavbarComponent,
    SideNavbarComponent,
    QueuedTxnRefundsComponent,
    ErrorDialogComponent,
    LogoutComponent,
    UnauthorizedComponent,
    DropDownListRendererComponent,
    LoaderComponent,
    LoadingDialogComponent,
    MerchantRejectedtxnsComponent,
    FraudServiceComponent,
    AlertDialogComponent,
    BulkRefundsComponent,
    QueuedBulkRefundsComponent,
    RouterLinkRendererComponent,
    RiskrejectsBulkComponent,
    BatchNewtxnRejectsComponent,
    BatchQueuedTxnRejectsComponent,
    ExportImportComponent,
  ],
  bootstrap: [AppComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatTabsModule,
    FormsModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    FlexLayoutModule,
    MatMenuModule,
    MatButtonModule,
    BrowserAnimationsModule,
    AgGridModule,
    MatInputModule,
    MatDialogModule,
    OktaAuthModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    MatExpansionModule,
    VegaComponentModule,
  ],
  providers: [
    {
      provide: OKTA_CONFIG,
      deps: [AppConfig],

      useFactory: (oktaConfig: AppConfig) => ({
        oktaAuth: new OktaAuth({ ...oktaConfig.config }),
      }),
    },
    LoaderService,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    ErrorDialogService,
    LoadingDialogService,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    ErrorService,
    IdleTimeoutService,
    AlertService,
    provideHttpClient(withInterceptorsFromDi()),
  ],
})
export class AppModule {}
