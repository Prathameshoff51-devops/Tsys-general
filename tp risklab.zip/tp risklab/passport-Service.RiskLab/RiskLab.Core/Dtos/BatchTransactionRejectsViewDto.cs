﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectsViewDto
    {
        public int BatchRejectId { get; set; }

        public string OriginalBatchNumber { get; set; }

        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public float BatchAmount { get; set; }

        public DateTime BatchCloseDateUTC { get; set; }

        public string Status { get; set; }

        public List<BatchTransactionRejectViewDto> Transactions { get; set; }
            = new List<BatchTransactionRejectViewDto>();
    }
}