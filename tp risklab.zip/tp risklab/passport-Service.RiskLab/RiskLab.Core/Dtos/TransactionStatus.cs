﻿namespace RiskLab.Core.Dtos
{
    public class TransactionStatus
    {
        public int? TransactionId { get; set; }

        public string? NewStatus { get; set; }
    }
}
