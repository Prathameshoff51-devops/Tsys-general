﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Dtos
{
    public class IndividualTransactionViewDto
    {
        public IndividualTransactionViewDto()
        {
            FraudRejectReasonCodes = new List<string>();
        }

        public int IndividualTxnId { get; set; }

        public Guid MessageId { get; set; }

        public long TxnUuid { get; set; }

        public int TxnDetailId { get; set; }

        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public string LegalName { get; set; }

        public string ChainOID { get; set; }

        public string MCC { get; set; }

        public decimal Amount { get; set; }

        public string CardNumberMask { get; set; }

        public DateTime TxnDateUtc { get; set; }

        public List<string> FraudRejectReasonCodes { get; set; }

        public string OriginalBatchNumber { get; set; }

        public string AuthCode { get; set; }

        public DateTime? ExpDate { get; set; }

        public string TxnTypeDescription { get; set; }

        public DateTime BatchCloseDate { get; set; }

        public string SubmitterIDDescription { get; set; }

        public int DaysToAct { get; set; }

        public string Status { get; set; }
    }
}