﻿namespace RiskLab.Core.Dtos
{
    public class BatchRejectUpdateDto
    {
        public int BatchRejectId { get; set; }

        public string NewStatus { get; set; }

        public string UserName { get; set; }
    }
}