﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectViewDto
    {
        public int BatchTransactionRejectId { get; set; }

        public int BatchRejectId { get; set; }

        public string Status { get; set; }

        public float TxnAmount { get; set; }

        public string TxnType { get; set; }

        public string CardNumberMasked { get; set; }

        public string AuthCode { get; set; }

        public DateTime? ExpDate { get; set; }

        public DateTime TxnDateUTC { get; set; }

        public int DaysToAct { get; set; }

        public List<string> RejectReasons { get; set; } = new List<string>();
    }
}
