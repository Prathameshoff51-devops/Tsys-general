﻿namespace RiskLab.Core.Dtos
{
    public class IndividualTransactionDto
    {
        /// <summary>
        /// Constructor for the class.
        /// </summary>
        public IndividualTransactionDto()
        {
            FraudRejectReasonCodes = new List<string>();
            FraudRejectReasonCodeIds = new List<int>();
        }

        public int IndividualTxnId { get; set; }

        public Guid MessageId { get; set; }

        public long TxnUuid { get; set; }

        public int TxnDetailId { get; set; }

        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public string LegalName { get; set; }

        public string? ChainOID { get; set; }

        public string MCC { get; set; }

        public decimal Amount { get; set; }

        public string CardNumberMask { get; set; }

        public DateTimeOffset TxnDateUtc { get; set; }

        public List<string> FraudRejectReasonCodes { get; set; }

        public string OriginalBatchNumber { get; set; }

        public string? AuthCode { get; set; }

        public DateTimeOffset? ExpDate { get; set; }

        public int ServiceOptionTxnTypeID { get; set; }

        public string TxnTypeDescription { get; set; }

        public DateTimeOffset BatchCloseDate { get; set; }

        public List<int> FraudRejectReasonCodeIds { get; set; }

        public int SubmitterId { get; set; }

        public string SubmitterIDDescription { get; set; }

        public int DaysToAct { get; set; }

        public int LastUpdatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTimeOffset? BusinessDateUtc { get; set; }

        public string Status { get; set; }
    }
}
