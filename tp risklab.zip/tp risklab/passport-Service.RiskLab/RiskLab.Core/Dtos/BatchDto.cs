﻿using EasyNetQ;
using static log4net.Appender.RollingFileAppender;

namespace RiskLab.Core.Dtos
{
    public class BatchDto
    {
        /// <summary>
        /// Constructor for the class.
        /// </summary>
        public BatchDto()
        {
            FraudRejectReasonCodeIds = new List<int>();
            TransactionList = new List<BatchTransactionDto>();
        }

        public Guid MessageId { get; set; }

        public string OriginalBatchNumber { get; set; }

        public long TxnUuid { get; set; }

        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public string LegalName { get; set; }

        public string ChainOID { get; set; }

        public string MCC { get; set; }

        public DateTimeOffset BusinessDateUTC { get; set; }

        public decimal BatchAmount { get; set; }

        public int CreditCount { get; set; }

        public DateTimeOffset BatchCloseDate { get; set; }

        public int SubmitterID { get; set; }

        public string SubmitterIdDescription { get; set; }

        public List<int> FraudRejectReasonCodeIds { get; set; }

        public List<BatchTransactionDto> TransactionList { get; set; }

        public int DaysToAct { get; set; }

        public int LastUpdatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string Status { get; set; }
    }
}
