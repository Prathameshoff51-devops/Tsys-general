﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectsUpdateDto
    {
        public int BatchRejectId { get; set; }

        public List<BatchTransactionStatus> BatchTransactionsStatus { get; set; }
            = new List<BatchTransactionStatus>();

        public string UserName { get; set; }
    }
}
