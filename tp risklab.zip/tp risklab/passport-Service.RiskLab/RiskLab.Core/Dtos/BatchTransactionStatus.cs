﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionStatus
    {
        public int BatchTransactionRejectId { get; set; }

        public string? NewStatus { get; set; }
    }
}
