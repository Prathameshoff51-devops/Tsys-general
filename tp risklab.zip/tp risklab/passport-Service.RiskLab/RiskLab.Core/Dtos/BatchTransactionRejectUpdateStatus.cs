﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectUpdateStatus
    {
        public int BatchTransactionRejectId { get; set; }

        public string UpdateStatus { get; set; }

        public string StatusCode { get; set; }
    }
}
