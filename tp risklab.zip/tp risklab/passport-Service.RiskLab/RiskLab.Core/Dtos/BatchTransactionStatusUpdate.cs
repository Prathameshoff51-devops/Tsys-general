﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionStatusUpdate
    {
        public int BatchTransactionRejectId { get; set; }

        public string NewStatus { get; set; }

        public int BatchRejectId { get; set; }
    }
}
