﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Dtos
{
    public class MerchantRejects
    {
        public MerchantRejects()
        {
            FraudRejectReasonCodes = new List<string>();
        }

        public int Id { get; set; }

        public DateTime BusinessDateUtc { get; set; }

        public string BatchNumber { get; set; }

        public string TxnTypeDescription { get; set; }

        public decimal Amount { get; set; }

        public DateTime TxnDateUtc { get; set; }

        public string CardNumberMask { get; set; }

        public List<string> FraudRejectReasonCodes { get; set; }

        public DateTime StatusDate { get; set; }

        public string Status { get; set; }

        public string MerchantName { get; set; }

        public string SuspensionType { get; set; }
    }
}
