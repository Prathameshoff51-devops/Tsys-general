﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Dtos
{
    public class ReleasedBatchDto
    {
        /// <summary>
        /// Gets or sets the message identifier.
        /// </summary>
        /// <value>
        /// The message identifier.
        /// </value>
        public Guid MessageId { get; set; }

        /// <summary>
        /// Gets or sets the TXN UUID.
        /// </summary>
        /// <value>
        /// The TXN UUID.
        /// </value>
        public long TxnUuid { get; set; }

        /// <summary>
        /// Gets or sets the jville message identifier.
        /// </summary>
        /// <value>
        /// The jville message identifier.
        /// </value>
        public Guid JvilleMessageId { get; set; }

        /// <summary>
        /// Number of retry attempts
        /// </summary>
        public int NumberOfAttempts { get; set; }

        public string? LastRetriedDateUtc { get; set; }
    }
}
