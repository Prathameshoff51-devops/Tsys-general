﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Dtos
{
    public class NotificationMessageDto
    {
        public Guid MessageId { get; set; }
    }
}
