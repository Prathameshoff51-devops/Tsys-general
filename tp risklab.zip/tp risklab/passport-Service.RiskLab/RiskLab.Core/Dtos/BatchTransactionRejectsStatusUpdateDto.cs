using System.Collections.Generic;

namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectsStatusUpdateDto
    {
        public List<BatchTransactionStatusUpdate> BatchTransactionsStatus { get; set; } = new List<BatchTransactionStatusUpdate>();

        public string UserName { get; set; }
    }
}
