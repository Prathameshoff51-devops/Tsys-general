﻿namespace RiskLab.Core.Dtos
{
    public class IndividualTransactionStatusUpdateDto
    {
        public IEnumerable<TransactionStatus> TransactionsStatus { get; set; }

        public string? UserName { get; set; }
    }
}