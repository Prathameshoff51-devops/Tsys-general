﻿namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectsStatusUpdateResultDto
    {
        public int BatchRejectId { get; set; }

        public List<BatchTransactionRejectUpdateStatus> BatchTransactionRejectUpdateStatuses { get; set; }
                    = new List<BatchTransactionRejectUpdateStatus>();
    }
}
