﻿namespace RiskLab.Core.Dtos
{
    public class RejectsCountDto
    {
        public int Count { get; set; }

        public string? Status { get; set; }
    }
}
