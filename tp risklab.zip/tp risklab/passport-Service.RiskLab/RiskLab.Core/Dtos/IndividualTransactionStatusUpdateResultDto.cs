﻿namespace RiskLab.Core.Dtos
{
    public class IndividualTransactionStatusUpdateResultDto
    {
        public int TransactionId { get; set; }

        public string? UpdateStatus { get; set; }

        public string StatusCode { get; set; }
    }
}
