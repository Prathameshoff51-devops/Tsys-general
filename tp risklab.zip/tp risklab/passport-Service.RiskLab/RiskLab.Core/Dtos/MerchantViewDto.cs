﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Dtos
{
    public class MerchantViewDto
    {
        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public IEnumerable<MerchantRejects> MerchantRejects { get; set; }
    }
}
