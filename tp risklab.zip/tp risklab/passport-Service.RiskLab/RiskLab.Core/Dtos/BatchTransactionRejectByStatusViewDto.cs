using System;

namespace RiskLab.Core.Dtos
{
    public class BatchTransactionRejectByStatusViewDto
    {/// <summary>
        /// Constructor for the class.
        /// </summary>
        public BatchTransactionRejectByStatusViewDto()
        {
            FraudRejectReasonCodes = new List<string>();
            FraudRejectReasonCodeIds = new List<int>();
        }

        public int BatchTransactionRejectId { get; set; }

        public int BatchRejectId { get; set; }

        public Guid MessageId { get; set; }

        public long TxnUUID { get; set; }

        public int TxnDetailID { get; set; }

        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public string LegalName { get; set; }

        public string? ChainOID { get; set; }

        public string MCC { get; set; }

        public decimal TxnAmount { get; set; }

        public decimal BatchAmount { get; set; }

        public string CardNumberMasked { get; set; }

        public DateTimeOffset TxnDateUtc { get; set; }

        public List<string> FraudRejectReasonCodes { get; set; }

        public string OriginalBatchNumber { get; set; }

        public string? AuthCode { get; set; }

        public DateTimeOffset? ExpDate { get; set; }

        public DateTimeOffset BatchCreateDate { get; set; }

        public DateTimeOffset BatchCloseDate { get; set; }

        public List<int> FraudRejectReasonCodeIds { get; set; }

        public string SubmitterIdDescription { get; set; }

        public int DaysToAct { get; set; }

        public string Status { get; set; }

        public string TxnType { get; set; }
    }
}
