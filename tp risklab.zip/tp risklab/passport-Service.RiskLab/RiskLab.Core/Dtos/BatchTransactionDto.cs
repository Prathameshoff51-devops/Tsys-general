﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Dtos
{
    public class BatchTransactionDto
    {
        public BatchTransactionDto()
        {
            FraudRejectReasonCodeIds = new List<int>();
        }

        public int TxnDetailId { get; set; }

        public decimal Amount { get; set; }

        public string CardNumberMask { get; set; }

        public DateTime TxnDateUtc { get; set; }

        public string? AuthCode { get; set; }

        public DateTimeOffset? ExpDate { get; set; }

        public int ServiceOptionTxnTypeID { get; set; }

        public string TxnTypeDescription { get; set; }

        public List<int> FraudRejectReasonCodeIds { get; set; }

        public int DaysToAct { get; set; }

        public int LastUpdatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string Status { get; set; }
    }
}
