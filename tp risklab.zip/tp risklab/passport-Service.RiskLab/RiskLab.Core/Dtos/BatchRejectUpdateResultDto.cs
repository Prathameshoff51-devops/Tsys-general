﻿namespace RiskLab.Core.Dtos
{
    public class BatchRejectUpdateResultDto
    {
        public int BatchRejectId { get; set; }

        public string? UpdateStatus { get; set; }

        public string StatusCode { get; set; }
    }
}
