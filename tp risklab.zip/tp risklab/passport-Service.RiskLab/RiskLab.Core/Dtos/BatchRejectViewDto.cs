﻿namespace RiskLab.Core.Dtos
{
    public class BatchRejectViewDto
    {
        public int BatchRejectId { get; set; }

        public string BatchNumber { get; set; }

        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }

        public string LegalName { get; set; }

        public string ChainOID { get; set; }

        public string MCC { get; set; }

        public float BatchAmount { get; set; }

        public int RefundCount { get; set; }

        public DateTime TxnDateUTC { get; set; }

        public int DaysToAct { get; set; }

        public DateTime BatchCloseDate { get; set; }

        public string Status { get; set; }

        public string SubmitterIdDescription { get; set; }

        public bool CanTakeBatchAction { get; set; }

        public List<string> RejectReasons { get; set; } = new List<string>();
    }
}
