﻿namespace RiskLab.Core.Settings
{
    public class ApplicationSettings
    {
        public string EnvironmentCode { get; set; }

        public string AppName { get; set; }

        public int DefaultGridPageSize { get; set; }

        public int DefaultBatchGridPageSize { get; set; }

        public int DefaultBackOfficeGridPageSize { get; set; }

        public string ApiKey { get; set; }

        public string RiskLabUiUrl { get; set; }

        public string RiskLabApiUrl { get; set; }

        public string TokenOauthUrl { get; set; }

        public string ClientId { get; set; }

        public string ClientSecret { get; set; }

        public string Scopes { get; set; }

        public string CoreloggingServiceUrl { get; set; }

        public int DaysToAct { get; set; }

        public string Issuer { get; set; }

        public string AuthorizationServer { get; set; }

        public string IntrospectEndPoint { get; set; }

        public bool IsProduction
        {
            get
            {
                return EnvironmentCode.Equals("Production");
            }
        }

        public override string ToString()
        {
            return $"{AppName}-{EnvironmentCode}";
        }
    }
}
