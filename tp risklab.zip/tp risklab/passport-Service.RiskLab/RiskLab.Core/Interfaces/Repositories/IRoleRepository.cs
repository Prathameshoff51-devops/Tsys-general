﻿using RiskLab.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Interfaces.Repositories
{
    public interface IRoleRepository
    {
        Task<IEnumerable<UserRole>> GetUserRoles(int userID);
    }
}
