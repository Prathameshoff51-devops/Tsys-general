﻿namespace RiskLab.Core.Interfaces.Repositories
{
    using RiskLab.Core.Entities;

    public interface IUserRepository
    {
        static readonly string SystemEmail = "noreply@globalpay.com";

        Task<User> GetUserByEmail(string email);

        Task<User> GetUserByUserId(int userId);

        Task<User> GetUserByLoginName(string loginName);
    }
}
