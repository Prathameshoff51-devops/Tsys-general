﻿using Acquisition.Contracts.Risk.Jville;
using Acquisition.Contracts.Risk.Passport;
using RiskLab.Core.Dtos;

namespace RiskLab.Core.Interfaces.Repositories
{
    public interface IBatchRejectsRepository
    {
        Task<IEnumerable<BatchRejectViewDto>> GetBatchRejects(string status);

        Task<BatchRejectUpdateResultDto> UpdateBatchRejectStatus(BatchRejectUpdateDto batchReject);

        Task<BatchRejectViewDto> GetBatchRejectById(int batchRejectId);

        Task<BatchTransactionRejectsViewDto> GetBatchTransactionRejects(int batchRejectId);

        Task<BatchTransactionRejectUpdateStatus> UpdateBatchTransactionRejectStatus(BatchTransactionStatus batchTransactionReject, string userName);

        Task<BatchTransactionRejectViewDto> GetBatchTransactionRejectById(int batchTransactionRejectId);

        Task<IEnumerable<BatchTransactionRejectByStatusViewDto>> GetBatchTransactionRejectByStatus(string status);

        Task<IEnumerable<ReleasedBatchDto>> GetReleasedBatchesForPassport();

        Task<Tuple<bool, string, string>> InsertReleasedBatchToPassport(FraudReleasedBatch fraudReleasedBatch, ReleasedBatchDto batch, string stringTransaction);

        Task<bool> CheckIfBatchIsInProcess(ReleasedBatchDto batch);

        Task ResetInFlightBatch(ReleasedBatchDto batch);

        Task<IEnumerable<NotificationMessageDto>> CheckNotificationStatusForMessageIds(List<ReleasedBatchDto> unAckBatches);

        Task<int> UpdateReleasedBatchAck(FraudReleasedBatchConfirmation fraudReleasedBatchConfirmation);

        Task<bool> UpdateNotificationStatusForMessageIds(List<ReleasedBatchDto> unAckBatchList);
    }
}
