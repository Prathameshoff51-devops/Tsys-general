﻿using System.Data;
using RiskLab.Core.Dtos;

namespace RiskLab.Core.Interfaces.Repositories
{
    public interface IBatchTransactionsRepository
    {
        Task<int> InsertBatchFromPassport(BatchDto batchDeatils, DataTable batchRejectReasons, DataTable transactionList);

        Task<bool> CheckIfMessageConsumed(Guid messageId);

        Task<Tuple<bool, string, string>> InsertBatchAck(string payload, BatchDto batchDeatils);

        Task<Tuple<bool, string, string>> InsertErrorPayload(string payload, string error, Guid messageId);
    }
}
