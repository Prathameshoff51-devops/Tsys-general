﻿namespace RiskLab.Core.Interfaces.Repositories
{
    using System;
    using System.Data;
    using Acquisition.Contracts.Risk.Jville;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Entities;

    /// <summary>
    /// Interface for Individual Transactions Repository.
    /// </summary>
    public interface IIndividualTransactionsRepository
    {
        Task<IndividualTransactionViewDto> GetTransaction(int id);

        Task<IEnumerable<IndividualTransactionViewDto>> GetTransactions(string status);

        Task<IEnumerable<IndividualTransactionStatusUpdateResultDto>> UpdateIndividualTransactionStatus(IndividualTransactionStatusUpdateDto transactions);

        /// <summary>
        /// Individual transaction status update result DTO.
        /// </summary>
        /// <param name="individualTransaction"><see cref="IndividualTransactionDto"/>object.</param>
        /// <returns><see cref="IndividualTransactionStatusUpdateResultDto"/>object.</returns>
        Task<int> InsertIndividualTransactionFromPassport(IndividualTransactionDto individualTransaction, DataTable transactionRejectReasons);

        /// <summary>
        /// Save the individual Transaction acknowledgment.
        /// </summary>
        /// <param name="payload">Payload received from RMQ.</param>
        /// <param name="individualTransactionMessageId">Individual transaction message id.</param>
        /// <returns>Int.</returns>
        Task<Tuple<bool, string, string>> InsertIndividualTransactionAck(string payload, IndividualTransactionDto individualTransactionDto);

        /// <summary>
        /// Checks if message consumed.
        /// </summary>
        /// <param name="messageId">The message identifier.</param>
        /// <returns>True if message is consumed.</returns>
        Task<bool> CheckIfMessageConsumed(Guid messageId);

        /// <summary>
        /// Gets the released transaction reject.
        /// </summary>
        /// <param name="transactionRejectIds">The transaction reject ids.</param>
        /// <returns></returns>
        Task<IEnumerable<FraudReleasedTransaction>> GetReleasedTransactionReject(List<int> transactionRejectIds);

        /// <summary>
        /// Updates the released transaction acknowledgment.
        /// </summary>
        /// <param name="FraudReleasedTransactionConfirmation">The fraud released transaction confirmation.</param>
        /// <returns></returns>
        Task<int> UpdateReleasedTransactionAck(Acquisition.Contracts.Risk.Passport.FraudReleasedTransactionConfirmation fraudReleasedTransactionConfirmation);

        /// <summary>
        /// Gets all the Transaction to publish
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<ReleasedIndividualTransactionDto>> GetTransactionsForPassport();

        /// <summary>
        /// Inserts the released transaction to passport
        /// </summary>
        /// <param name="fraudReleasedTransaction"></param>
        /// <param name="releasedIndividualTransactionRejectDto"></param>
        /// <param name="payload"></param>
        /// <returns></returns>
        Task<Tuple<bool, string, string>> InsertReleasedTransactionToPassport(FraudReleasedTransaction fraudReleasedTransaction, ReleasedIndividualTransactionDto releasedIndividualTransactionRejectDto, string payload);

        Task<IEnumerable<MerchantRejects>> GetRejectsByMerchantNumber(string merchantNumber);

        Task<Merchant> GetMerchantNumberFromSequenceKey(int sequenceKey);

        Task<bool> CheckIfTransactionIsInFlight(FraudReleasedTransaction fraudReleasedTransaction);

        Task ResetInflightFlagForTransaction(FraudReleasedTransaction fraudReleasedTransaction);

        Task<IEnumerable<NotificationMessageDto>> CheckNotificationStatusForMessageIds(List<ReleasedIndividualTransactionDto> unAckTransactionsList);

        Task<bool> UpdateNotificationStatusForMessageIds(List<ReleasedIndividualTransactionDto> unAckTransactionsList);
    }
}