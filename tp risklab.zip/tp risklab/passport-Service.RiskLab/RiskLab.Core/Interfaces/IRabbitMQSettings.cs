﻿namespace RiskLab.Infrastructure.Interfaces
{
    /// <summary>
    /// Interface to get the RabbitMQ setting from SettinsManager.
    /// </summary>
    public interface IRabbitMQSettings : IDisposable
    {
        /// <summary>
        /// Gets the RabbitMQ connection string.
        /// </summary>
        /// <param name="key">Key stored in SettingsManager.</param>
        /// <returns>Returns the value against the key.</returns>
        string this[string key] { get; }
    }
}