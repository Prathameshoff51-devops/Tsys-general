﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Acquisition.Contracts.Risk.Passport;
using RiskLab.Core.Interfaces.Services;

namespace RiskLab.Core.Interfaces.Processors
{
    /// <summary>
    /// Interface to process the batch request.
    /// </summary>
    public interface ISuspectedFraudulentBatch : IMessageProcessor<SuspectedFraudulentBatch>
    {
    }
}
