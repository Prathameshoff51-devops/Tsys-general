﻿namespace RiskLab.Core.Interfaces.Processors
{
    using Acquisition.Contracts.Risk.Passport;
    using RiskLab.Core.Interfaces.Services;

    public interface IFraudReleasedTransactionConfirmation : IMessageProcessor<FraudReleasedTransactionConfirmation>
    {
    }
}
