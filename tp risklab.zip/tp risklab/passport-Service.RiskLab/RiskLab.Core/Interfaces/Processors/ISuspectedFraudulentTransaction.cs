﻿namespace RiskLab.Core.Interfaces.Processors
{
    using Acquisition.Contracts.Risk.Passport;
    using RiskLab.Core.Interfaces.Services;

    /// <summary>
    /// Interface to process the transaction request.
    /// </summary>
    public interface ISuspectedFraudulentTransaction : IMessageProcessor<SuspectedFraudulentTransaction>
    {
    }
}