﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Interfaces.Services
{
     public interface IExcelExportService
    {
        byte[] ExportJsonTOExcel(System.Text.Json.JsonElement json, string sheetName, string txnStatus);
    }
}
