﻿namespace RiskLab.Core.Interfaces.Services
{
    using RiskLab.Core.Constants;

    /// <summary>
    /// Interface to process the message queue.
    /// </summary>
    public interface IMessageQueueService : IDisposable
    {
        /// <summary>
        /// Subscribe to a processor method.
        /// </summary>
        /// <typeparam name="T">Identify the contract type class.</typeparam>
        /// <param name="processor"><see cref="IMessageProcessor"/>object.</param>
        /// <param name="getGuid"><see cref="GUID"/>.</param>
        /// <param name="messageIdentifier"><see cref="MessageIdentifier"/>.</param>
        void SubscribeProcessor<T>(IMessageProcessor<T> processor, Func<T, Guid> getGuid, MessageIdentifier messageIdentifier)
            where T : class;

        /// <summary>
        /// Subscribe to a advance consume of a queue.
        /// </summary>
        /// <param name="queueName">The queue name.</param>
        /// <param name="process">Process the payload</param>
        void SubscribeAdvanced(string queueName, Action<byte[]> process);

        /// <summary>
        /// Publish a message for passport.
        /// </summary>
        /// <typeparam name="T">Message.</typeparam>
        /// <param name="message">Message object.</param>
        /// <returns>Boolean if the message was publish.</returns>
        bool PublishMessage<T>(T message, byte[] payload)
            where T : class;
    }
}