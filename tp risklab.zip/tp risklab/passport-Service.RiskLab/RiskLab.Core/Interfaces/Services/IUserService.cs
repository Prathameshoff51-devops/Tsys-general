﻿using RiskLab.Core.Entities;

namespace RiskLab.Core.Interfaces.Services
{
    public interface IUserService
    {
        Task<User> GetUserByEmail(string email);

        Task<User> GetUserByUserId(int userId);

        Task<User> GetUserByLoginName(string loginName);

        Task<bool> IsUserValid(string loginName);
    }
}
