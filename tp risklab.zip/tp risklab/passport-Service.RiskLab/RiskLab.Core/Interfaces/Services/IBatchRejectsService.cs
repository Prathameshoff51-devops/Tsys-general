﻿using RiskLab.Core.Dtos;

namespace RiskLab.Core.Interfaces.Services
{
    public interface IBatchRejectsService
    {
        Task<BatchRejectViewDto> GetBatchRejectById(int batchRejectId);

        Task<IEnumerable<BatchRejectViewDto>> GetBatchRejectsByStatus(string status);

        Task<BatchRejectUpdateResultDto> UpdateBatchRejectStatus(BatchRejectUpdateDto batchReject);

        Task<BatchTransactionRejectsViewDto> GetBatchTransactionRejects(int batchRejectId);

        Task<BatchTransactionRejectsStatusUpdateResultDto> UpdateBatchTransactionRejects(BatchTransactionRejectsUpdateDto batchTransactionRejects);

        Task<BatchTransactionRejectViewDto> GetBatchTransactionRejectById(int batchTransactionRejectId);

        Task<IEnumerable<BatchTransactionRejectByStatusViewDto>> GetBatchTransactionRejectByStatus(string status);

        Task<BatchTransactionRejectsStatusUpdateResultDto> UpdateBulkBatchTransactionRejects(BatchTransactionRejectsStatusUpdateDto batchTransactionRejects);
    }
}