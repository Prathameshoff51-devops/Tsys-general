﻿namespace RiskLab.Core.Interfaces.Services
{
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Entities;
    using System.Data;

    /// <summary>
    /// Interface for  Individual Transaction Service.
    /// </summary>
    public interface IIndividualTransactionsService
    {
        Task<IndividualTransactionViewDto> GetIndividualTransaction(int id);

        Task<IEnumerable<IndividualTransactionViewDto>> GetNewIndividualTransactions();

        Task<IEnumerable<IndividualTransactionViewDto>> GetQueuedIndividualTransactions();

        Task<IEnumerable<IndividualTransactionViewDto>> GetReleasedIndividualTransactions();

        Task<IEnumerable<IndividualTransactionViewDto>> GetDeletedIndividualTransactions();

        Task<IEnumerable<IndividualTransactionViewDto>> GetIndividualTransactionsByStatus(string status);

        Task<IEnumerable<IndividualTransactionStatusUpdateResultDto>> UpdateIndividualTransactionStatus(IndividualTransactionStatusUpdateDto transactions);

        /// <summary>
        /// Individual transaction status update result DTO.
        /// </summary>
        /// <param name="individualTransaction"></param>
        /// <param name="transactionRejectReasons"></param>
        /// <returns></returns>
        Task<int> SaveIndividualTransactionFromPassport(IndividualTransactionDto individualTransaction, DataTable transactionRejectReasons);

        bool CanUpdateStatus(string currentStatus, string newStatus);

        Task<bool> IsUserValid(string loginName);

        Task<IEnumerable<MerchantRejects>> GetRejectsByMerchantNumber(string merchantNumber);

        Task<Merchant> GetMerchantNumberFromSequenceKey(int sequenceKey);
    }
}