﻿using RiskLab.Core.Constants;

namespace RiskLab.Core.Interfaces.Services
{
    /// <summary>
    /// Interface for message processor.
    /// </summary>
    /// <typeparam name="T">for message processors.</typeparam>
    public interface IMessageProcessor<T>
    {
        /// <summary>
        /// Generic process method for various queues from RabbitMQ.
        /// </summary>
        /// <param name="payLoad">Payload received from RabbitMQ.</param>
        /// <returns><see cref="ProcessingStatus"/>object.</returns>
        Task<MessageStatusIdentifier> Process(string payLoad);
    }

    /// <summary>
    /// Class to store the Processing status.
    /// </summary>
    public class ProcessingStatus
    {
        /// Set the <see cref="ProcessingStatus"/>.
        private static readonly ProcessingStatus _true = new ProcessingStatus { Success = true };

        /// <summary>
        /// Set the <see cref="ProcessingStatus"/>.
        /// </summary>
        private static ProcessingStatus _false = new ProcessingStatus { Success = false };

        /// <summary>
        /// Set the <see cref="ProcessingStatus"/>.
        /// </summary>
        public static ProcessingStatus True
        {
            get { return _true; }
        }

        /// Set the <see cref="ProcessingStatus"/>.
        public static ProcessingStatus False
        {
            get { return _false; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether gets or Sets the status as Success.
        /// </summary>
        public bool Success { get; set; }
    }
}