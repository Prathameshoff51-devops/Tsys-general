﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Interfaces.Services
{
    public interface ITokenValidationService
    {
        public Task<bool> IsTokenValid(string token, string url, string clientId);
    }
}
