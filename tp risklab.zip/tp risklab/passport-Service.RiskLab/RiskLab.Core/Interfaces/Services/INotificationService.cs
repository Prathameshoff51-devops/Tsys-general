﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Interfaces.Services
{
    public interface INotificationService
    {
        Task<bool> NotifySignalrHub(string riskLabUrl, string hubMethodName, int batchRejectId);
    }
}
