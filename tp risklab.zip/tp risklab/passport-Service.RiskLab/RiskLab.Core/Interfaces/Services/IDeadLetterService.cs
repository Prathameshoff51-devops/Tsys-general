﻿namespace RiskLab.Core.Interfaces.Services
{
    /// <summary>
    /// Interface to implement the dead letters.
    /// </summary>
    public interface IDeadLetterService : IDisposable
    {
        /// <summary>
        /// Process the incoming dead letter recceived from RabbitMQ.
        /// </summary>
        /// <param name="payload">The payload received.</param>
        /// <returns><see cref="ProcessingStatus"/>object.</returns>
        ProcessingStatus ProcessIncoming(string payload);
    }
}