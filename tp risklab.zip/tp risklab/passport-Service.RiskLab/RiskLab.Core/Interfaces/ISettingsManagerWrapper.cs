﻿using Hps.SettingsManagerClient;

namespace RiskLab.Core.Interfaces
{
    public interface ISettingsManagerWrapper
    {
        SettingsManager RabbitMQSettingsManager { get; }

        SettingsManager ApplicationSettingsManager { get; }
    }
}
