﻿namespace RiskLab.Core.Services
{
    using RiskLab.Core.Interfaces.Services;

    /// <summary>
    /// Class to process the dead letters.
    /// </summary>
    public class DeadLetterService : IDeadLetterService
    {
        /// <summary>
        /// Dispose the class.
        /// </summary>
        public void Dispose()
        {
            // throw new NotImplementedException();
        }

        /// <summary>
        /// Process the incoming dead letters.
        /// </summary>
        /// <param name="payload">The payload received from the queue.</param>
        /// <returns><see cref="ProcessingStatus"/>object.</returns>
        public ProcessingStatus ProcessIncoming(string payload)
        {
            TODO: // Implement DataDog and email receiver for the failed queue.
            return ProcessingStatus.True;
        }
    }
}