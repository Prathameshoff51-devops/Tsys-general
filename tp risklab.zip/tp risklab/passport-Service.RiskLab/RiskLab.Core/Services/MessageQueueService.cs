﻿namespace RiskLab.Core.Services
{
    using System.Text;
    using EasyNetQ;
    using EasyNetQ.Consumer;
    using EasyNetQ.Topology;
    using Hps.RabbitMq.Consumer.Common;
    using Hps.RabbitMq.Consumer.EasyNetQ;
    using log4net;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json.Linq;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Infrastructure.Interfaces;

    /// <summary>
    /// Message queue service to transform RabbitMQ message to be stored.
    /// </summary>
    public class MessageQueueService : IMessageQueueService
    {
        /// <summary>
        /// Object to store the <see cref="IRabbitMQSettings"/>.
        /// </summary>
        private readonly IRabbitMQSettings settings;

        /// <summary>
        /// The logger.
        /// </summary>
        private readonly ILog log = LogManager.GetLogger(typeof(MessageQueueService));

        /// <summary>
        /// Object to store a list of <see cref="List{T}"/> subscription result.
        /// </summary>
        private readonly List<SubscriptionResult> subscribers = new List<SubscriptionResult>();

        /// <summary>
        /// Object to store the <see cref="IBus"/>object.
        /// </summary>
        private IBus subscriberBus;

        /// <summary>
        /// Boolean variable to be used for <see cref="IDisposable"/>.
        /// </summary>
        private bool disposed = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageQueueService"/> class.
        /// </summary>
        /// <param name="settings"><see cref="IRabbitMQSettings"/>object.</param>
        public MessageQueueService(IRabbitMQSettings settings)
        {
            this.settings = settings;
            this.CreateSubscriberBus();
        }

        /// <summary>
        /// Gets the connection string fetched from setting manager.
        /// </summary>
        private string ConnectionString
        {
            get
            {
                 return this.settings["RiskLabRabbitMqConnection"].Replace(@"\", string.Empty);
            }
        }

        /// <summary>
        /// Subscriber processor method for different type queues subscribed.
        /// </summary>
        /// <typeparam name="T">object.</typeparam>
        /// <param name="processor"><see cref="IMessageProcessor{T}"/>object.</param>
        /// <param name="getGuid"><Func<T, Guid>>object.</param>
        /// <param name="messageIdentifier"><see cref="MessageIdentifier"/>object.</param>
        public void SubscribeProcessor<T>(IMessageProcessor<T> processor, Func<T, Guid> getGuid, MessageIdentifier messageIdentifier)
            where T : class
        {
            try
            {
                var routingKey = typeof(T).FullName + ".#";
                var exchangeName = RabbitMQConfig.ExchangeName;
                var deadLetterExchangeName = RabbitMQConfig.DeadLetterExchangeName;
                var queueName = typeof(T).FullName;
                var createExchange = this.subscriberBus.Advanced.ExchangeDeclare(exchangeName, RabbitMQ.Client.ExchangeType.Topic);
                var createDeadLetterExchange = this.subscriberBus.Advanced.ExchangeDeclare(deadLetterExchangeName, RabbitMQ.Client.ExchangeType.Topic);
                var createQueue = this.subscriberBus.Advanced.QueueDeclare(queueName, config =>
                {
                    if (config is null)
                    {
                        throw new ArgumentNullException(nameof(config));
                    }

                    config.WithDeadLetterExchange(createDeadLetterExchange);
                });
                this.subscriberBus.Advanced.Bind(createExchange, createQueue, routingKey);
                Task Handler(ReadOnlyMemory<byte> payload, MessageProperties basicproperties, MessageReceivedInfo messageReceivedInfo)
                {
                    return Task.Factory.StartNew(async () =>
                                {
                                    await this.ProcessTransaction(processor, payload.ToArray());
                                });
                }

                subscriberBus.Advanced.Consume(createQueue, Handler);
            }
            catch (Exception ex)
            {
                log.ErrorFormat("MessageQueueService::Exception while subscribing to a processor in SubscribeProcessor() {0},{1},{2}", ex.TargetSite, typeof(T).FullName, ex);
            }
        }

        /// <summary>
        /// Subscribe to a advance queue and consume.
        /// </summary>
        /// <param name="queueName">Queue name.</param>
        /// <param name="process"><see cref="Action"/>process.</param>
        public void SubscribeAdvanced(string queueName, Action<byte[]> process)
        {
            try
            {
                var subscriber = this.subscriberBus.Advanced.Consume(
                    this.subscriberBus.Advanced.QueueDeclare(queueName), (b, p, i) =>
                    Task.Factory.StartNew(() => process(b.ToArray())));

                this.subscribers.Add(new SubscriptionResult(
                    exchange: new Exchange(queueName),
                    queue: new Queue(queueName, false),
                    subscriber));
            }
            catch (Exception ex)
            {
                log.ErrorFormat("MessageQueueService::Exception while subscribing using advance to a processor  {0},{1}", ex.TargetSite, ex);
            }
        }

        /// <summary>
        /// Dispose the class.
        /// </summary>
        public void Dispose()
        {
            if (this.disposed)
            {
                return;
            }

            foreach (var subscriber in this.subscribers)
            {
                subscriber.Dispose();
            }

            this.subscribers.Clear();
            this.subscriberBus.Advanced.Dispose();
            this.subscriberBus.Dispose();

            this.disposed = true;
        }

        /// <summary>
        /// Publish a Acknowledgment message for passport.
        /// </summary>
        /// <typeparam name="T">Message.</typeparam>
        /// <param name="message">Message object.</param>
        /// <returns>Boolean if the message was publish.</returns>
        public bool PublishMessage<T>(T message, byte[] payload)
            where T : class
        {
            try
            {
                using (var bus = this.CreateBus())
                {
                    var basicProperties = new MessageProperties();
                    basicProperties.Type = typeof(T).AssemblyQualifiedName;

                    var routingKey = typeof(T).FullName + ".#";
                    var exchangeName = RabbitMQConfig.ExchangeName;
                    var deadLetterExchangeName = RabbitMQConfig.DeadLetterExchangeName;
                    var queueName = typeof(T).FullName;
                    var createExchange = this.subscriberBus.Advanced.ExchangeDeclare(exchangeName, RabbitMQ.Client.ExchangeType.Topic);
                    var createDeadLetterExchange = this.subscriberBus.Advanced.ExchangeDeclare(deadLetterExchangeName, RabbitMQ.Client.ExchangeType.Topic);
                    var createQueue = this.subscriberBus.Advanced.QueueDeclare(queueName, config =>
                    {
                        if (config is null)
                        {
                            throw new ArgumentNullException(nameof(config));
                        }

                        config.WithDeadLetterExchange(createDeadLetterExchange);
                    });
                    this.subscriberBus.Advanced.Bind(createExchange, createQueue, routingKey);
                    this.subscriberBus.Advanced.Publish(createExchange, routingKey, true, basicProperties, payload);
                    return true;
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("MessageQueueService::Exception while publishing a message to RMQ in  {0},{1},{2}", ex.TargetSite, typeof(T).FullName, ex);
                return false;
            }
        }

        /// <summary>
        /// Process the Transaction Received from RMQ.
        /// </summary>
        /// <typeparam name="T"><see cref="IMessageProcessor{T}"/>object.</typeparam>
        /// <param name="processor"><see cref="IMessageProcessor{T}"/>object.</param>
        /// <returns>The message object.</returns>
        //private Func<byte[], MessageProperties, MessageReceivedInfo, Task> ProcessTransaction<T>(IMessageProcessor<T> processor)
        //    where T : class
        //{
        //    return async (payloadBytes, _, _) =>
        //    {
        //        await this.ProcessTransaction(processor, payloadBytes);
        //    };
        //}

        /// <summary>
        /// Process the transaction from the queue.
        /// </summary>
        /// <typeparam name="T">MessageProcessor.</typeparam>
        /// <param name="processor"><see cref="IMessageProcessor"/>object.</param>
        /// <param name="payloadBytes">Payload.</param>
        private async Task ProcessTransaction<T>(IMessageProcessor<T> processor, byte[] payloadBytes)
       where T : class
        {
            try
            {
                MessageStatusIdentifier messageStatus = MessageStatusIdentifier.Failed;
                messageStatus = await processor.Process(Encoding.Default.GetString(payloadBytes));
                this.log.InfoFormat("MessageQueueService::Processing started for: {0}", typeof(T).FullName);
                if (messageStatus == MessageStatusIdentifier.Failed)
                {
                    log.ErrorFormat("MessageQueueService::unable to read the message {0} from queue", typeof(T).FullName);
                }
                else if (messageStatus == MessageStatusIdentifier.FailedToAck)
                {
                    log.ErrorFormat("MessageQueueService::unable to ack the message {0} from queue", typeof(T).FullName);
                }
                else if (messageStatus == MessageStatusIdentifier.FailedToAckDuplicateMessage)
                {
                    log.ErrorFormat("MessageQueueService::unable to ack duplicate message {0} from queue", typeof(T).FullName);
                }
                else if (messageStatus == MessageStatusIdentifier.DuplicateMessage)
                {
                    this.log.DebugFormat("MessageQueueService::processed duplicate message {0} from queue", typeof(T).FullName);
                }
                else if (messageStatus == MessageStatusIdentifier.Successful)
                {
                    this.log.DebugFormat("MessageQueueService::processed message successfully {0} from queue", typeof(T).FullName);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("MessageQueueService::Exception processing the message to RMQ in {0},{1},{2}", ex.TargetSite, typeof(T).FullName, ex);
            }
        }

        /// <summary>
        /// Create a <see cref="RabbitHutch"/> message bus to consume the RabbitMQ queues.
        /// </summary>
        /// <returns>Returns a the connection from <see cref="Ibus"/>interface.</returns>
        /// <exception cref="Exception">Throw a exception when occurred.</exception>
        private IBus CreateBus()
        {
            var credsFactory = new RabbitMqCredentialsFactory();
            var easyNetQConnectionConf = new EasyNetQCredentialsFactory(credsFactory)
              .DeserializeFromString(this.ConnectionString)
              .ToConnectionConfiguration();
            var bus = RabbitHutch.CreateBus(easyNetQConnectionConf, x => x.EnableConsoleLogger());
            return bus;
        }

        /// <summary>
        /// Create a subscriber bus for connecting to RMQ.
        /// </summary>
        /// <returns><see cref="IBus"/>object.</returns>
        private IBus CreateSubscriberBus()
        {
            if (this.subscriberBus != null)
            {
                return this.subscriberBus;
            }

            IBus bus = this.CreateBus();
            this.subscriberBus = bus;
            return bus;
        }
    }
}