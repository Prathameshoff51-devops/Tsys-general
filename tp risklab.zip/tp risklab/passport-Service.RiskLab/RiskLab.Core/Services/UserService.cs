﻿using Microsoft.Extensions.Logging;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;

namespace RiskLab.Core.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository userRepository;
        private readonly ILogger<UserService> logger;

        public UserService(IUserRepository userRepository, ILogger<UserService> logger)
        {
            this.userRepository = userRepository;
            this.logger = logger;
        }

        public async Task<User> GetUserByEmail(string email)
        {
            return await userRepository.GetUserByEmail(email);
        }

        public async Task<User> GetUserByLoginName(string loginName)
        {
            return await userRepository.GetUserByLoginName(loginName);
        }

        public async Task<User> GetUserByUserId(int userId)
        {
            return await userRepository.GetUserByUserId(userId);
        }

        public async Task<bool> IsUserValid(string loginName)
        {
            try
            {
                var user = await userRepository.GetUserByLoginName(loginName);
                return user == null ? false : true;
            }
            catch (Exception)
            {
                this.logger.LogError("Error in fetching user information for LoginName : {0}", loginName);
                return false;
            }
        }
    }
}
