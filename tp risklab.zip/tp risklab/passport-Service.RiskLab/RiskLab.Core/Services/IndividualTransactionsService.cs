﻿namespace RiskLab.Core.Services
{
    using System.Data;
    using System.Text;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using RiskLab.Core.Constants;
    using RiskLab.Core.Dtos;
    using RiskLab.Core.Entities;
    using RiskLab.Core.Interfaces;
    using RiskLab.Core.Interfaces.Repositories;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Core.Settings;

    public class IndividualTransactionsService : IIndividualTransactionsService
    {
        private readonly IIndividualTransactionsRepository individualTransactionsRepository;
        private readonly ILogger<IndividualTransactionsService> logger;
        private readonly IUserRepository userRepository;
        private readonly ApplicationSettings setting;
        private readonly INotificationService notificationService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="individualTransactionsRepository"></param>
        /// <param name="logger"></param>
        /// <param name="userRepository"></param>
        public IndividualTransactionsService(
            IIndividualTransactionsRepository individualTransactionsRepository,
            ILogger<IndividualTransactionsService> logger,
            IUserRepository userRepository,
            IOptions<ApplicationSettings> setting,
            INotificationService notificationService)
        {
            this.individualTransactionsRepository = individualTransactionsRepository;
            this.logger = logger;
            this.userRepository = userRepository;
            this.setting = setting.Value;
            this.notificationService = notificationService;
        }

        /// <summary>
        /// Raise an event when a API controller is hit.
        /// </summary>
        /// <param name="transactionRejectIds">The transaction reject ids.</param>
        /// <returns></returns>
        public delegate Task RaiseEvent(List<int> transactionRejectIds);

        public Task<IEnumerable<IndividualTransactionViewDto>> GetDeletedIndividualTransactions()
        {
            return this.individualTransactionsRepository.GetTransactions(RejectStatuses.Deleted.ToString());
        }

        public Task<IEnumerable<IndividualTransactionViewDto>> GetIndividualTransactionsByStatus(string status)
        {
            return this.individualTransactionsRepository.GetTransactions(status);
        }

        public Task<IndividualTransactionViewDto> GetIndividualTransaction(int id)
        {
            return this.individualTransactionsRepository.GetTransaction(id);
        }

        public Task<IEnumerable<IndividualTransactionViewDto>> GetNewIndividualTransactions()
        {
            return this.individualTransactionsRepository.GetTransactions(RejectStatuses.New.ToString());
        }

        public Task<IEnumerable<IndividualTransactionViewDto>> GetQueuedIndividualTransactions()
        {
            return this.individualTransactionsRepository.GetTransactions(RejectStatuses.Queued.ToString());
        }

        public Task<IEnumerable<IndividualTransactionViewDto>> GetReleasedIndividualTransactions()
        {
            return this.individualTransactionsRepository.GetTransactions(RejectStatuses.Released.ToString());
        }

        /// <summary>
        /// Updates the individual transaction status.
        /// </summary>
        /// <param name="transactions">The transactions.</param>
        /// <returns><see cref="IndividualTransactionStatusUpdateResultDto"/>object.</returns>
        public async Task<IEnumerable<IndividualTransactionStatusUpdateResultDto>> UpdateIndividualTransactionStatus(IndividualTransactionStatusUpdateDto transactions)
        {
            var result = new List<IndividualTransactionStatusUpdateResultDto>();

            List<KeyValuePair<string, string>> statusMap = new List<KeyValuePair<string, string>>();

            foreach (TransactionStatus txnReject in transactions.TransactionsStatus)
            {
                var txnUpdateResult = new IndividualTransactionStatusUpdateResultDto() { TransactionId = txnReject.TransactionId.Value };
                try
                {
                    if (!txnReject.TransactionId.HasValue)
                    {
                        txnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        txnUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                        result.Add(txnUpdateResult);
                        this.logger.LogDebug("IndividualTransactionsService::Failed to update transaction status for TxnRejectId {0} : Invalid transaction reject id", txnReject.TransactionId);
                        continue;
                    }

                    var txn = await this.GetIndividualTransaction(txnReject.TransactionId.Value);

                    //Validate transaction
                    if (txn == null)
                    {
                        txnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        txnUpdateResult.StatusCode = ((int)StatusCodes.NotFound).ToString();
                        result.Add(txnUpdateResult);
                        this.logger.LogDebug("IndividualTransactionsService::Failed to update transaction status for TxnRejectId {0} : Transaction reject id not found", txnReject.TransactionId);
                        continue;
                    }

                    //Validate new status
                    if (!Enum.TryParse(txnReject.NewStatus, true, out RejectStatuses newStatus) || !this.CanUpdateStatus(txn.Status, txnReject.NewStatus))
                    {
                        txnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        txnUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                        result.Add(txnUpdateResult);
                        this.logger.LogDebug("IndividualTransactionsService::Failed to update transaction status for TxnRejectId {0} : Invalid new status", txnReject.TransactionId);
                        continue;
                    }

                    Enum.TryParse(txn.Status, true, out RejectStatuses orgnStatus);
                    Enum.TryParse(txnReject.NewStatus, true, out RejectStatuses targetStatus);
                    statusMap.Add(new KeyValuePair<string, string>(orgnStatus.ToString(), targetStatus.ToString()));

                    //Update transaction status
                    await this.individualTransactionsRepository.UpdateIndividualTransactionStatus(new IndividualTransactionStatusUpdateDto
                    {
                        TransactionsStatus = new List<TransactionStatus>() { txnReject },
                        UserName = transactions.UserName,
                    });

                    txnUpdateResult.UpdateStatus = UpdateStatuses.Success;
                    txnUpdateResult.StatusCode = ((int)StatusCodes.Ok).ToString();
                    result.Add(txnUpdateResult);
                    this.logger.LogDebug("IndividualTransactionsService:: Updated transaction status for TxnRejectId {0} from '{1}' to '{2}'", txnReject.TransactionId, txn.Status, txnReject.NewStatus);
                }
                catch (Exception ex)
                {
                    txnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                    txnUpdateResult.StatusCode = ((int)StatusCodes.InternalServerError).ToString();
                    result.Add(txnUpdateResult);
                    this.logger.LogError("IndividualTransactionsService::Failed to update transaction status for TxnRejectId {0}, Exception - {1}", txnReject.TransactionId, ex.ToString());
                }
            }

            await BroadCastMessage(result, statusMap);

            return result;
        }

        public async Task BroadCastMessage(List<IndividualTransactionStatusUpdateResultDto> result, List<KeyValuePair<string, string>> statusMap)
        {
            if (result.Any(x => x.UpdateStatus == UpdateStatuses.Success))
            {
                if (statusMap.Any(c => c.Key == RejectStatuses.New.ToString()))
                {
                    await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedIndividualRefunds, 0);
                }

                if (statusMap.Any(c => c.Key == RejectStatuses.Queued.ToString()) ||
                     statusMap.Any(c => c.Value == RejectStatuses.Queued.ToString()))
                {
                    await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.Queued, 0);
                }
            }
        }

        public bool CanUpdateStatus(string currentStatus, string newStatus)
        {
            Enum.TryParse(currentStatus, true, out RejectStatuses fromStatus);
            Enum.TryParse(newStatus, true, out RejectStatuses toStatus);

            if (toStatus <= fromStatus)
            {
                return false;
            }

            if ((toStatus == RejectStatuses.Deleted && fromStatus == RejectStatuses.Released) || (toStatus == RejectStatuses.Released && fromStatus == RejectStatuses.Deleted))
            {
                return false;
            }

            if (toStatus == RejectStatuses.Purged)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert the individual transaction (TransactionRequest) received from RMQ.
        /// </summary>
        /// <param name="individualTransaction"></param>
        /// <param name="transactionRejectReasons"></param>
        /// <returns></returns>
        public async Task<int> SaveIndividualTransactionFromPassport(IndividualTransactionDto individualTransaction, DataTable transactionRejectReasons)
        {
            return await this.individualTransactionsRepository.InsertIndividualTransactionFromPassport(individualTransaction, transactionRejectReasons);
        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }

        public async Task<bool> IsUserValid(string loginName)
        {
            try
            {
                var user = await this.userRepository.GetUserByLoginName(loginName);
                return user == null ? false : true;
            }
            catch (Exception)
            {
                this.logger.LogError("Error in fetching user information for LoginName : {0}", loginName);
                return false;
            }
        }

        public Task<IEnumerable<MerchantRejects>> GetRejectsByMerchantNumber(string merchantNumber)
        {
            return this.individualTransactionsRepository.GetRejectsByMerchantNumber(merchantNumber);
        }

        public Task<Merchant> GetMerchantNumberFromSequenceKey(int sequenceKey)
        {
            return this.individualTransactionsRepository.GetMerchantNumberFromSequenceKey(sequenceKey);
        }
    }
}