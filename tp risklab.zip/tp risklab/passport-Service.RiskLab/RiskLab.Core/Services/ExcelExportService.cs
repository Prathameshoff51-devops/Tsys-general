﻿using System.Text.Json;
using Microsoft.Extensions.Logging;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using RiskLab.Core.Interfaces.Services;

namespace RiskLab.Core.Services
{
    public class ExcelExportService : IExcelExportService
    {
        // Individual transaction header mapping
        private static readonly List<(string Key, string Header)> IndividualHeaderMap = new ()
        {
            ("CurrentStatus", "Current Status"),
            ("NewStatus", "New Status"),
            ("IndividualTxnId", "Individual Txn ID"),
            ("MerchantNumber", "Merchant Number"),
            ("MerchantName", "Merchant Name"),
            ("LegalName", "Legal Name"),
            ("ChainOID", "Processing Chain ID"),
            ("MCC", "MCC"),
            ("Amount", "Txn Amount"),
            ("CardNumberMask", "Card Number Masked"),
            ("TxnDateUtc", "Txn Date (UTC)"),
            ("FraudRejectReasonCodes", "Reject Reasons"),
            ("OriginalBatchNumber", "Original Batch Number"),
            ("BatchCloseDate", "Batch Close Date (UTC)"),
            ("AuthCode", "Auth Code"),
            ("ExpDate", "Exp Date"),
            ("TxnTypeDescription", "Txn Type"),
            ("SubmitterIDDescription", "Submitter"),
            ("DaysToAct", "Days To Act"),
        };

        // Batch transaction header mapping based on BatchTransactionRejectByStatusViewDto
        private static readonly List<(string Key, string Header)> BatchHeaderMap = new ()
        {
            ("CurrentStatus", "Current Status"),
            ("NewStatus", "New Status"),
            ("BatchTransactionRejectId", "Batch Transaction Reject ID"),
            ("BatchRejectId", "Batch Reject ID"),
            ("OriginalBatchNumber", "Original Batch Number"),
            ("MerchantNumber", "Merchant Number"),
            ("MerchantName", "Merchant Name"),
            ("LegalName", "Legal Name"),
            ("ChainOID", "Processing Chain ID"),
            ("MCC", "MCC"),
            ("BatchAmount", "Batch Amount"),
            ("BatchCreateDate", "Batch Create Date (UTC)"),
            ("BatchCloseDate", "Batch Close Date (UTC)"),
            ("TxnAmount", "Txn Amount"),
            ("CardNumberMasked", "Card Number Masked"),
            ("TxnDateUtc", "Txn Date (UTC)"),
            ("FraudRejectReasonCodes", "Reject Reasons"),
            ("AuthCode", "Auth Code"),
            ("ExpDate", "Exp Date"),
            ("TxnType", "Txn Type"),
            ("SubmitterIdDescription", "Submitter"),
            ("DaysToAct", "Days To Act"),
        };

        private readonly ILogger<ExcelExportService> _logger;

        public ExcelExportService(ILogger<ExcelExportService> logger)
        {
            _logger = logger;
        }

        public byte[] ExportJsonTOExcel(JsonElement json, string sheetName, string txnStatus)
        {
            try
            {
                _logger.LogInformation("Starting Excel export for sheet: {SheetName}, status: {TxnStatus}", sheetName, txnStatus);

                ExcelPackage.License.SetNonCommercialOrganization("<Your Noncommercial Organization>");

                List<Dictionary<string, object>> records;
                try
                {
                    records = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(json.ToString());
                }
                catch (JsonException ex)
                {
                    _logger.LogError(ex, "Failed to deserialize JSON data for Excel export");
                    throw new InvalidOperationException("Invalid JSON data provided for Excel export", ex);
                }

                if (records == null || records.Count == 0)
                {
                    _logger.LogWarning("No records found for Excel export");
                    throw new InvalidOperationException("No records found to export");
                }

                using var package = new ExcelPackage();

                try
                {
                    bool hasBatchRejectId = records.Any(r => r.ContainsKey("BatchRejectId"));
                    if (hasBatchRejectId)
                    {
                        var batchRejects = records.
                            Where(d => d.ContainsKey("BatchRejectId"))
                            .GroupBy(d => d["BatchRejectId"].ToString());

                        foreach (var batchReject in batchRejects)
                        {
                            var batchRejectToList = batchReject.ToList();
                            AddSheet(package, "SheetName", batchRejectToList, txnStatus);
                        }
                    }
                    else
                    {
                        AddSheet(package, sheetName, records, txnStatus);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error processing data for Excel export");
                    throw new InvalidOperationException("Error processing data for Excel export", ex);
                }

                var result = package.GetAsByteArray();
                _logger.LogInformation("Successfully created Excel file with {RecordCount} records", records.Count);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during Excel export");
                throw;
            }
        }

        private void AddSheet(ExcelPackage package, string sheetName, List<Dictionary<string, object>> data, string txnStatus)
        {
            try
            {
                if (data == null || data.Count == 0)
                {
                    _logger.LogWarning("No data provided for sheet: {SheetName}", sheetName);
                    throw new ArgumentException("No data provided for sheet creation", nameof(data));
                }

                if (sheetName == "SheetName")
                {
                    try
                    {
                        sheetName = "Batch_Transactions_" + data[0]["OriginalBatchNumber"].ToString() + "_" + txnStatus;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error creating sheet name from BatchRejectId");
                        sheetName = "Batch_Transactions_" + txnStatus;
                    }
                }

                _logger.LogDebug("Adding sheet: {SheetName} with {DataCount} records", sheetName, data.Count);

                var worksheet = package.Workbook.Worksheets.Add(sheetName);

                try
                {
                    // Add instruction in the first row
                    var instructionCell = worksheet.Cells[1, 1];
                    instructionCell.Value = "Please do not edit the data in any column except 'New Status'.";
                    // Check if the sheetName contains both "Batch" and "New"
                    if (sheetName.Contains("Batch", StringComparison.OrdinalIgnoreCase) && sheetName.Contains("New", StringComparison.OrdinalIgnoreCase))
                    {
                        instructionCell.Value += " If the batch is partially actioned, all remaining unactioned transactions will be moved to 'Queued' status.";
                    }

                    instructionCell.Style.Font.Bold = true;
                    instructionCell.Style.Font.Italic = true;
                    instructionCell.Style.Font.Color.SetColor(System.Drawing.Color.Red);

                    // Merge the instruction cell across all columns
                    int totalColumns = data.FirstOrDefault()?.Count ?? 1; // Calculate the number of columns dynamically
                    worksheet.Cells[1, 1, 1, totalColumns].Merge = true;
                    worksheet.Cells[1, 1, 1, totalColumns].Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;

                    // Process data items
                    foreach (var item in data)
                    {
                        try
                        {
                            // Create a new dictionary to control the order
                            var orderedItem = new Dictionary<string, object>();
                            if (item.TryGetValue("Status", out var statusValue))
                            {
                                item.Remove("Status");
                                orderedItem["CurrentStatus"] = statusValue;
                                orderedItem["NewStatus"] = string.Empty;
                            }

                            // Add all other items except excluded columns
                            foreach (var kvp in item)
                            {
                                orderedItem[kvp.Key] = kvp.Value;
                            }

                            item.Clear();
                            foreach (var kvp in orderedItem)
                            {
                                item[kvp.Key] = kvp.Value;
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Error processing data item, skipping");
                            continue;
                        }
                    }

                    // Choose header map based on data type (batch or individual)
                    List<string> headers;
                    List<(string Key, string Header)> headerMap;
                    if (data.Any(d => d.ContainsKey("BatchRejectId")))
                    {
                        headerMap = BatchHeaderMap;
                        _logger.LogDebug("Using batch header mapping for sheet: {SheetName}", sheetName);
                    }
                    else
                    {
                        headerMap = IndividualHeaderMap;
                        _logger.LogDebug("Using individual header mapping for sheet: {SheetName}", sheetName);
                    }

                    // Filter headers based on data presence
                    headers = headerMap.Select(h => h.Key).Where(k => data.Any(d => d.ContainsKey(k))).ToList();

                    // Create headers using the mapped display names
                    for (int col = 0; col < headers.Count; col++)
                    {
                        try
                        {
                            var cell = worksheet.Cells[2, col + 1]; // Headers start from the second row
                            var headerTitle = headerMap.FirstOrDefault(h => h.Key == headers[col]).Header ?? headers[col];
                            cell.Value = headerTitle;
                            cell.Style.Font.Bold = true;
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Error setting header for column {Column}", headers[col]);
                        }
                    }

                    // Lock all cells by default
                    if (worksheet.Dimension != null)
                    {
                        worksheet.Cells[worksheet.Dimension.Address].Style.Locked = true;
                    }

                    // Fill data rows and unlock 'New Status' column cells in the same loop
                    var statusCol = headers.FindIndex(h => h == "NewStatus");
                    for (int row = 0; row < data.Count; row++)
                    {
                        for (int col = 0; col < headers.Count; col++)
                        {
                            try
                            {
                                if (data[row].TryGetValue(headers[col], out var value))
                                {
                                    // Handle specific formatting for amount columns
                                    if (headers[col].IndexOf("amount", StringComparison.OrdinalIgnoreCase) >= 0
                                        && value != null
                                        && decimal.TryParse(value.ToString(), out var amount))
                                    {
                                        worksheet.Cells[row + 3, col + 1].Value = amount; // Data starts from the third row
                                        worksheet.Cells[row + 3, col + 1].Style.Numberformat.Format = "$#,##0.00";
                                        worksheet.Cells[row + 3, col + 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                                    }
                                    else
                                    {
                                        worksheet.Cells[row + 3, col + 1].Value = value?.ToString();
                                    }

                                    // Unlock the 'New Status' column cells
                                    if (col == statusCol && statusCol >= 0)
                                    {
                                        worksheet.Cells[row + 3, col + 1].Style.Locked = false;
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning(ex, "Error setting cell value at row {Row}, column {Col}", row + 3, col + 1);
                            }
                        }
                    }

                    // Add dropdown validation for NewStatus column and protect worksheet
                    try
                    {
                        if (statusCol >= 0)
                        {
                            var dropDownOptions = new List<string> { "Queue", "Release", "Delete" };
                            if (txnStatus == "Queued")
                            {
                                dropDownOptions.RemoveAt(0);
                            }

                            for (int row = 3; row <= data.Count + 2; row++)
                            {
                                try
                                {
                                    var cell = worksheet.Cells[row, statusCol + 1];
                                    var validation = worksheet.DataValidations.AddListValidation(cell.Address);
                                    foreach (var option in dropDownOptions)
                                    {
                                        validation.Formula.Values.Add(option);
                                    }

                                    validation.ShowErrorMessage = true;
                                    validation.ErrorTitle = "Invalid Input";
                                    validation.Error = "Please select a value from the dropdown list only.";
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogWarning(ex, "Error adding dropdown validation for row {Row}", row);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Error adding dropdown validation for NewStatus column");
                    }

                    // Auto-fit columns
                    try
                    {
                        // Protect the worksheet
                        worksheet.Protection.IsProtected = true;
                        worksheet.Protection.AllowSelectLockedCells = true;
                        worksheet.Protection.AllowSelectUnlockedCells = true;
                        worksheet.Protection.AllowDeleteColumns = false;
                        worksheet.Protection.AllowDeleteRows = false;
                        worksheet.Protection.AllowEditObject = false;
                        worksheet.Protection.AllowEditScenarios = false;
                        worksheet.Protection.AllowFormatCells = false;
                        worksheet.Protection.AllowFormatColumns = false;
                        worksheet.Protection.AllowFormatRows = false;
                        worksheet.Protection.AllowInsertColumns = false;
                        worksheet.Protection.AllowInsertRows = false;
                        worksheet.Protection.AllowSort = true;
                        worksheet.Protection.AllowAutoFilter = true;
                        worksheet.Protection.AllowPivotTables = true;
                        worksheet.Cells[2, 1, 2 + data.Count, headers.Count].AutoFilter = true;
                        worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Error auto-fitting columns for sheet: {SheetName}", sheetName);
                    }

                    _logger.LogDebug("Successfully added sheet: {SheetName}", sheetName);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error populating worksheet: {SheetName}", sheetName);
                    throw new InvalidOperationException($"Error populating worksheet: {sheetName}", ex);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in AddSheet method for sheet: {SheetName}", sheetName);
                throw;
            }
        }
    }
}
