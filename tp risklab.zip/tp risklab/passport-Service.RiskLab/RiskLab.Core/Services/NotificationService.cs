﻿namespace RiskLab.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using log4net;
    using Microsoft.AspNetCore.Http.Connections;
    using Microsoft.AspNetCore.SignalR.Client;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using RiskLab.Core.Interfaces.Services;
    using RiskLab.Core.Settings;

    public class NotificationService : INotificationService
    {
        private readonly ILog logger = LogManager.GetLogger(typeof(NotificationService));

        private HubConnection? connection;

        public async Task<bool> NotifySignalrHub(string riskLabUrl, string hubMethodName, int batchRejectId)
        {
            var isSuccess = false;

            try
            {
                string? hubUrl = GetSignalrHubEndpoint(riskLabUrl);

                connection = new HubConnectionBuilder()
                               .WithUrl(
                                new Uri(hubUrl),
                                HttpTransportType.WebSockets)
                               .WithAutomaticReconnect()
                               .Build();

                await connection.StartAsync();

                logger.Info("NotificationService::NotifySignalrHub() : Connected to the hub : " + hubUrl);

                await connection.InvokeAsync(hubMethodName, (object)batchRejectId);

                await connection.StopAsync();

                logger.Info("NotificationService::NotifySignalrHub() : Posted the message to hub method : " + hubMethodName);

                isSuccess = true;
            }
            catch (Exception ex)
            {
                logger.Error("NotificationService::NotifySignalrHub() : Something went wrong : " + ex.ToString());
                return isSuccess;
            }
            finally
            {
                if (connection != null)
                {
                  await connection.DisposeAsync();
                }
            }

            return isSuccess;
        }

        private string GetSignalrHubEndpoint(string url)
        {
            string signalrUrl = string.Empty;

            if (!string.IsNullOrWhiteSpace(url.Trim()))
            {
                signalrUrl = url.Trim() + "/notification";
            }

            return signalrUrl;
        }
    }
}
