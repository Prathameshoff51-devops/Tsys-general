﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RiskLab.Core.Entities;
using RiskLab.Core.Interfaces.Services;

namespace RiskLab.Core.Services
{
    public class TokenValidationService : ITokenValidationService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<TokenValidationService> _logger;

        public TokenValidationService(IHttpClientFactory httpClientFactory, ILogger<TokenValidationService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        public async Task<bool> IsTokenValid(string token, string url, string clientId)
        {
            bool isTokenActive = false;

            HttpClient httpClient = _httpClientFactory.CreateClient();
            httpClient.DefaultRequestHeaders
            .Accept
            .Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var payload = new[]
            {
             new KeyValuePair<string, string>("client_id", System.Net.WebUtility.UrlEncode(clientId)),
             new KeyValuePair<string, string>("token", System.Net.WebUtility.UrlEncode(token)),
            };

            HttpResponseMessage response = await CheckTokenStatus(url, httpClient, payload);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var tokenResponse = JsonConvert.DeserializeObject<OktaIntrospectResponse>(responseContent);
                if (tokenResponse.Active)
                {
                    isTokenActive = true;
                }
            }
            else
            {
                _logger.LogError("TokenValidationService::IsTokenValid() : Invalid response received from okta... " + response.StatusCode);
            }

            return isTokenActive;
        }

        private async Task<HttpResponseMessage> CheckTokenStatus(string url, HttpClient httpClient, KeyValuePair<string, string>[] payload)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Content = new FormUrlEncodedContent(payload);
            var response = await httpClient.SendAsync(request);
            return response;
        }
    }
}
