﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RiskLab.Core.Constants;
using RiskLab.Core.Dtos;
using RiskLab.Core.Interfaces.Repositories;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Core.Settings;

namespace RiskLab.Core.Services
{
    public class BatchRejectsService : IBatchRejectsService
    {
        private readonly IBatchRejectsRepository batchRejectsRepository;
        private readonly ILogger<BatchRejectsService> logger;
        private readonly ApplicationSettings setting;
        private readonly INotificationService notificationService;

        public BatchRejectsService(
            IBatchRejectsRepository batchRejectsRepository,
            ILogger<BatchRejectsService> logger,
            IOptions<ApplicationSettings> setting,
            INotificationService notificationService)
        {
            this.batchRejectsRepository = batchRejectsRepository;
            this.logger = logger;
            this.setting = setting.Value;
            this.notificationService = notificationService;
        }

        public async Task<BatchRejectViewDto> GetBatchRejectById(int batchRejectId)
        {
            return await batchRejectsRepository.GetBatchRejectById(batchRejectId);
        }

        public async Task<IEnumerable<BatchRejectViewDto>> GetBatchRejectsByStatus(string status)
        {
            return await batchRejectsRepository.GetBatchRejects(status);
        }

        public async Task<BatchRejectUpdateResultDto> UpdateBatchRejectStatus(BatchRejectUpdateDto batchReject)
        {
            BatchRejectUpdateResultDto batchRejectUpdateResult = new BatchRejectUpdateResultDto();
            try
            {
                batchRejectUpdateResult.BatchRejectId = batchReject.BatchRejectId;
                if (batchReject.BatchRejectId <= 0)
                {
                    batchRejectUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                    batchRejectUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                    this.logger.LogDebug("BatchRejectsService::Failed to update status for BatchRejectId {0} : Invalid batch reject id", batchReject.BatchRejectId);
                    return batchRejectUpdateResult;
                }

                var br = await this.GetBatchRejectById(batchReject.BatchRejectId);

                //Validate Batch reject
                if (br == null)
                {
                    batchRejectUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                    batchRejectUpdateResult.StatusCode = ((int)StatusCodes.NotFound).ToString();
                    this.logger.LogDebug("BatchRejectsService::Failed to update status for BatchRejectId {0} : Batch reject id not found", batchReject.BatchRejectId);
                    return batchRejectUpdateResult;
                }

                //Validate new status
                if (!Enum.TryParse(batchReject.NewStatus, true, out BatchRejectStatuses newStatus)
                    || !this.CanUpdateBatchStatus(br.Status, batchReject.NewStatus))
                {
                    batchRejectUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                    batchRejectUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                    this.logger.LogDebug("BatchRejectsService::Failed to update status for BatchRejectId {0} : Invalid new status", batchReject.BatchRejectId);
                    return batchRejectUpdateResult;
                }

                Enum.TryParse(br.Status, true, out BatchRejectStatuses orgnStatus);
                Enum.TryParse(batchReject.NewStatus, true, out BatchRejectStatuses targetStatus);

                batchReject.NewStatus = targetStatus.ToString();

                //Update Batch reject status
                var result = await this.batchRejectsRepository.UpdateBatchRejectStatus(batchReject);

                batchRejectUpdateResult.UpdateStatus = result.UpdateStatus;

                if (result.UpdateStatus == UpdateStatuses.Success)
                {
                    batchRejectUpdateResult.StatusCode = ((int)StatusCodes.Ok).ToString();
                    if (orgnStatus.ToString() == RejectStatuses.New.ToString())
                    {
                        await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedNewBatchRefunds, batchRejectUpdateResult.BatchRejectId);
                        await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedNewBatchTxnRefunds, batchRejectUpdateResult.BatchRejectId);
                    }

                    if (orgnStatus.ToString() == RejectStatuses.Queued.ToString())
                    {
                        await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedQueueBatchRefunds, batchRejectUpdateResult.BatchRejectId);
                        await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedQueueBatchTxnRefunds, batchRejectUpdateResult.BatchRejectId);
                    }

                    if (orgnStatus.ToString() == RejectStatuses.New.ToString() && targetStatus.ToString() == RejectStatuses.Queued.ToString())
                    {
                        await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedQueueBatchRefunds, batchRejectUpdateResult.BatchRejectId);
                    }

                    this.logger.LogDebug("BatchRejectsService:: Updated status for BatchRejectId {0} from '{1}' to '{2}'", batchReject.BatchRejectId, br.Status, batchReject.NewStatus);
                }
                else
                {
                    batchRejectUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                    this.logger.LogDebug("BatchRejectsService::Failed to update status for BatchRejectId {0}", batchReject.BatchRejectId);
                }
            }
            catch (Exception ex)
            {
                batchRejectUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                batchRejectUpdateResult.StatusCode = ((int)StatusCodes.InternalServerError).ToString();
                this.logger.LogError("BatchRejectsService::Failed to update status for BatchRejectId {0}, Exception - {1}", batchReject.BatchRejectId, ex.ToString());
            }

            return batchRejectUpdateResult;
        }

        public bool CanUpdateStatus(string currentStatus, string newStatus)
        {
            Enum.TryParse(currentStatus, true, out RejectStatuses fromStatus);
            Enum.TryParse(newStatus, true, out RejectStatuses toStatus);

            var maxVaue = Enum.GetValues(typeof(RejectStatuses)).Cast<RejectStatuses>().Max();

            if (toStatus > maxVaue)
            {
                return false;
            }

            if (toStatus <= fromStatus)
            {
                return false;
            }

            if ((toStatus == RejectStatuses.Deleted && fromStatus == RejectStatuses.Released)
                || (toStatus == RejectStatuses.Released && fromStatus == RejectStatuses.Deleted))
            {
                return false;
            }

            if (toStatus == RejectStatuses.Purged)
            {
                return false;
            }

            return true;
        }

        public bool CanUpdateBatchStatus(string currentStatus, string newStatus)
        {
            Enum.TryParse(currentStatus, true, out BatchRejectStatuses fromStatus);
            Enum.TryParse(newStatus, true, out BatchRejectStatuses toStatus);

            var maxVaue = Enum.GetValues(typeof(BatchRejectStatuses)).Cast<BatchRejectStatuses>().Max();

            if (toStatus > maxVaue)
            {
                return false;
            }

            if (toStatus <= fromStatus)
            {
                return false;
            }

            if ((toStatus == BatchRejectStatuses.Deleted && fromStatus == BatchRejectStatuses.Released)
                || (toStatus == BatchRejectStatuses.Released && fromStatus == BatchRejectStatuses.Deleted))
            {
                return false;
            }

            if (toStatus == BatchRejectStatuses.Purged || toStatus == BatchRejectStatuses.Actioned)
            {
                return false;
            }

            return true;
        }

        public async Task<BatchTransactionRejectsViewDto> GetBatchTransactionRejects(int batchRejectId)
        {
            return await batchRejectsRepository.GetBatchTransactionRejects(batchRejectId);
        }

        public async Task<BatchTransactionRejectsStatusUpdateResultDto> UpdateBatchTransactionRejects(BatchTransactionRejectsUpdateDto batchTransactionRejects)
        {
            var result = new List<BatchTransactionRejectUpdateStatus>();
            List<KeyValuePair<string, string>> statusMap = new List<KeyValuePair<string, string>>();
            bool isFirstQueuedProcessed = false;

            foreach (BatchTransactionStatus batchTxnStatus in batchTransactionRejects.BatchTransactionsStatus)
            {
                BatchTransactionRejectUpdateStatus batchTxnUpdateResult = new BatchTransactionRejectUpdateStatus() { BatchTransactionRejectId = batchTxnStatus.BatchTransactionRejectId };
                try
                {
                    if (batchTxnStatus.BatchTransactionRejectId <= 0)
                    {
                        batchTxnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                        result.Add(batchTxnUpdateResult);
                        this.logger.LogDebug(
                            "BatchRejectsService::Failed to update batch transaction status for BatchTxnRejectId {0} : Invalid BatchTransactionRejectId",
                            batchTxnStatus.BatchTransactionRejectId);
                        continue;
                    }

                    var batchTxn = await this.GetBatchTransactionRejectById(batchTxnStatus.BatchTransactionRejectId);

                    //Validate transaction
                    if (batchTxn == null)
                    {
                        batchTxnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.NotFound).ToString();
                        result.Add(batchTxnUpdateResult);
                        this.logger.LogDebug(
                            "BatchRejectsService::Failed to update batch transaction status for BatchTxnRejectId {0} : BatchTransactionRejectId not found",
                            batchTxnStatus.BatchTransactionRejectId);
                        continue;
                    }

                    // Validate if transaction belongs to the same batch
                    if (batchTxn.BatchRejectId != batchTransactionRejects.BatchRejectId)
                    {
                        batchTxnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                        result.Add(batchTxnUpdateResult);
                        this.logger.LogDebug(
                            "BatchRejectsService::Failed to update batch transaction status for BatchTxnRejectId {0} : BatchRejectIds did not match",
                            batchTxnStatus.BatchTransactionRejectId);
                        continue;
                    }

                    // For Queued transitions, only the first transaction is processed for database update.
                    // For Released or Deleted transitions, each is processed for database update.
                    // All remaining transactions will be automatically marked as queued without updating the database.
                    if (isFirstQueuedProcessed && Enum.TryParse(batchTxnStatus.NewStatus, true, out RejectStatuses parsedStatus) &&
                        parsedStatus == RejectStatuses.Queued)
                    {
                        batchTxnUpdateResult.UpdateStatus = UpdateStatuses.Success;
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.Ok).ToString();
                        result.Add(batchTxnUpdateResult);
                        this.logger.LogDebug(
                            "BatchRejectsService:: Updated batch transaction status for BatchTxnRejectId {0} from '{1}' to '{2}' (direct success)",
                            batchTxnStatus.BatchTransactionRejectId,
                            batchTxn.Status,
                            batchTxnStatus.NewStatus);
                        continue;
                    }

                    //Validate new status
                    if (!Enum.TryParse(batchTxnStatus.NewStatus, true, out RejectStatuses newStatus) || !CanUpdateStatus(batchTxn.Status, batchTxnStatus.NewStatus))
                    {
                        batchTxnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                        result.Add(batchTxnUpdateResult);
                        this.logger.LogDebug(
                            "BatchRejectsService::Failed to update batch transaction status for BatchTxnRejectId {0} : Invalid new status",
                            batchTxnStatus.BatchTransactionRejectId);
                        continue;
                    }

                    Enum.TryParse(batchTxn.Status, true, out RejectStatuses orgnStatus);
                    Enum.TryParse(batchTxnStatus.NewStatus, true, out RejectStatuses targetStatus);
                    statusMap.Add(new KeyValuePair<string, string>(orgnStatus.ToString(), targetStatus.ToString()));
                    batchTxnStatus.NewStatus = targetStatus.ToString();

                    //Update transaction status
                    var updateResult = await this.batchRejectsRepository.UpdateBatchTransactionRejectStatus(batchTxnStatus, batchTransactionRejects.UserName);

                    batchTxnUpdateResult.UpdateStatus = updateResult.UpdateStatus;

                    if (updateResult.UpdateStatus == UpdateStatuses.Success)
                    {
                        isFirstQueuedProcessed = true;
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.Ok).ToString();
                        this.logger.LogDebug(
                            "BatchRejectsService:: Updated batch transaction status for BatchTxnRejectId {0} from '{1}' to '{2}'",
                            batchTxnStatus.BatchTransactionRejectId,
                            batchTxn.Status,
                            batchTxnStatus.NewStatus);
                    }
                    else
                    {
                        batchTxnUpdateResult.StatusCode = ((int)StatusCodes.BadRequest).ToString();
                        this.logger.LogDebug(
                            "BatchRejectsService:: Failed to update batch transaction status for BatchTxnRejectId {0} from '{1}' to '{2}'",
                            batchTxnStatus.BatchTransactionRejectId,
                            batchTxn.Status,
                            batchTxnStatus.NewStatus);
                    }

                    result.Add(batchTxnUpdateResult);
                }
                catch (Exception ex)
                {
                    batchTxnUpdateResult.UpdateStatus = UpdateStatuses.Failed;
                    batchTxnUpdateResult.StatusCode = ((int)StatusCodes.InternalServerError).ToString();
                    result.Add(batchTxnUpdateResult);
                    this.logger.LogError(
                        "BatchRejectsService::Failed to update batch transaction status for BatchTxnRejectId {0}, Exception - {1}",
                        batchTxnStatus.BatchTransactionRejectId,
                        ex.ToString());
                }
            }

            await BroadCastMessage(result, statusMap, batchTransactionRejects.BatchRejectId);
            return new BatchTransactionRejectsStatusUpdateResultDto
            {
                BatchRejectId = batchTransactionRejects.BatchRejectId,
                BatchTransactionRejectUpdateStatuses = result,
            };
        }

        public async Task BroadCastMessage(List<BatchTransactionRejectUpdateStatus> result, List<KeyValuePair<string, string>> statusMap, int batchRejectId)
        {
            if (result.Any(x => x.UpdateStatus == UpdateStatuses.Success))
            {
                if (statusMap.Any(c => c.Key == RejectStatuses.New.ToString()))
                {
                    await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedNewBatchRefunds, batchRejectId);
                    await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedNewBatchTxnRefunds, batchRejectId);
                }

                if (statusMap.Any(c => c.Key == RejectStatuses.Queued.ToString()) ||
                     statusMap.Any(c => c.Value == RejectStatuses.Queued.ToString()))
                {
                    await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedQueueBatchRefunds, batchRejectId);
                    await notificationService.NotifySignalrHub(setting.RiskLabApiUrl.Trim(), SignalRConstants.RejectedQueueBatchTxnRefunds, batchRejectId);
                }
            }
        }

        public Task<BatchTransactionRejectViewDto> GetBatchTransactionRejectById(int batchTransactionRejectId)
        {
            return batchRejectsRepository.GetBatchTransactionRejectById(batchTransactionRejectId);
        }

        public Task<IEnumerable<BatchTransactionRejectByStatusViewDto>> GetBatchTransactionRejectByStatus(string status)
        {
            return batchRejectsRepository.GetBatchTransactionRejectByStatus(status);
        }

        public async Task<BatchTransactionRejectsStatusUpdateResultDto> UpdateBulkBatchTransactionRejects(BatchTransactionRejectsStatusUpdateDto batchTransactionRejects)
        {
            try
            {
                // Basic validation
                if (batchTransactionRejects == null)
                {
                    this.logger.LogDebug("BatchRejectsService::UpdateBulkBatchTransactionRejects - Request is null");
                    return new BatchTransactionRejectsStatusUpdateResultDto
                    {
                        BatchRejectId = 0,
                        BatchTransactionRejectUpdateStatuses = new List<BatchTransactionRejectUpdateStatus>(),
                    };
                }

                if (string.IsNullOrEmpty(batchTransactionRejects.UserName))
                {
                    this.logger.LogDebug("BatchRejectsService::UpdateBulkBatchTransactionRejects - UserName is required");
                    return new BatchTransactionRejectsStatusUpdateResultDto
                    {
                        BatchRejectId = 0,
                        BatchTransactionRejectUpdateStatuses = new List<BatchTransactionRejectUpdateStatus>(),
                    };
                }

                if (batchTransactionRejects.BatchTransactionsStatus == null || !batchTransactionRejects.BatchTransactionsStatus.Any())
                {
                    this.logger.LogDebug("BatchRejectsService::UpdateBulkBatchTransactionRejects - No batch transactions to update");
                    return new BatchTransactionRejectsStatusUpdateResultDto
                    {
                        BatchRejectId = 0,
                        BatchTransactionRejectUpdateStatuses = new List<BatchTransactionRejectUpdateStatus>(),
                    };
                }

                // Group transactions by BatchRejectId to handle multiple batches
                var groupedTransactions = batchTransactionRejects.BatchTransactionsStatus
                    .GroupBy(x => x.BatchRejectId)
                    .ToList();

                var allResults = new List<BatchTransactionRejectUpdateStatus>();
                var processedBatchIds = new List<int>();

                this.logger.LogDebug(
                    "BatchRejectsService::UpdateBulkBatchTransactionRejects - Processing {0} different batches with {1} total transactions",
                    groupedTransactions.Count,
                    batchTransactionRejects.BatchTransactionsStatus.Count);

                // Process each batch separately
                foreach (var batchGroup in groupedTransactions)
                {
                    var batchRejectId = batchGroup.Key;
                    var batchTransactions = batchGroup.ToList();

                    try
                    {
                        this.logger.LogDebug(
                            "BatchRejectsService::UpdateBulkBatchTransactionRejects - Processing BatchRejectId {0} with {1} transactions",
                            batchRejectId,
                            batchTransactions.Count);

                        // Convert the grouped transactions to the existing DTO format
                        var convertedDto = new BatchTransactionRejectsUpdateDto
                        {
                            BatchRejectId = batchRejectId,
                            UserName = batchTransactionRejects.UserName,
                            BatchTransactionsStatus = batchTransactions.Select(x => new BatchTransactionStatus
                            {
                                BatchTransactionRejectId = x.BatchTransactionRejectId,
                                NewStatus = x.NewStatus,
                            }).ToList(),
                        };

                        // Call the existing method for this batch
                        var batchResult = await UpdateBatchTransactionRejects(convertedDto);

                        // Add results from this batch to the overall results
                        if (batchResult?.BatchTransactionRejectUpdateStatuses != null)
                        {
                            allResults.AddRange(batchResult.BatchTransactionRejectUpdateStatuses);
                            processedBatchIds.Add(batchRejectId);

                            this.logger.LogDebug(
                                "BatchRejectsService::UpdateBulkBatchTransactionRejects - Successfully processed BatchRejectId {0}, added {1} results",
                                batchRejectId,
                                batchResult.BatchTransactionRejectUpdateStatuses.Count);
                        }
                    }
                    catch (Exception batchEx)
                    {
                        this.logger.LogError(
                            "BatchRejectsService::UpdateBulkBatchTransactionRejects - Failed to process BatchRejectId {0}, Exception: {1}",
                            batchRejectId,
                            batchEx.ToString());

                        // Add failed results for this batch's transactions
                        foreach (var transaction in batchTransactions)
                        {
                            allResults.Add(new BatchTransactionRejectUpdateStatus
                            {
                                BatchTransactionRejectId = transaction.BatchTransactionRejectId,
                                UpdateStatus = UpdateStatuses.Failed,
                                StatusCode = ((int)StatusCodes.InternalServerError).ToString(),
                            });
                        }
                    }
                }

                // Return consolidated results
                // Use the first processed batch ID, or 0 if none were processed successfully
                var resultBatchId = processedBatchIds.FirstOrDefault();

                this.logger.LogDebug(
                    "BatchRejectsService::UpdateBulkBatchTransactionRejects - Completed processing. Total results: {0}, Processed batches: {1}",
                    allResults.Count,
                    processedBatchIds.Count);

                return new BatchTransactionRejectsStatusUpdateResultDto
                {
                    BatchRejectId = resultBatchId,
                    BatchTransactionRejectUpdateStatuses = allResults,
                };
            }
            catch (Exception ex)
            {
                this.logger.LogError("BatchRejectsService::UpdateBulkBatchTransactionRejects - Exception: {0}", ex.ToString());
                return new BatchTransactionRejectsStatusUpdateResultDto
                {
                    BatchRejectId = 0,
                    BatchTransactionRejectUpdateStatuses = new List<BatchTransactionRejectUpdateStatus>(),
                };
            }
        }
    }
}
