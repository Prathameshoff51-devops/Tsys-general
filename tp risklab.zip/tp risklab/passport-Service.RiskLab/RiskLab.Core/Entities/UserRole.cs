﻿namespace RiskLab.Core.Entities
{
    public class UserRole
    {
        public int Id { get; set; }

        public string Role { get; set; }

        public string Type { get; set; }
    }
}
