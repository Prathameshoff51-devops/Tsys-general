﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Entities
{
    public class Merchant
    {
        public string MerchantNumber { get; set; }

        public string MerchantName { get; set; }
    }
}
