﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Entities
{
    public class OktaIntrospectResponse
    {
        public bool Active { get; set; }

        public string Username { get; set; }

        public string Sub { get; set; }

        public string Scope { get; set; }
    }
}
