﻿namespace RiskLab.Core.Entities
{
    public class User
    {
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string GranteeOID { get; set; }

        public string UserName { get; set; }

        public string LoginName { get; set; }
    }
}