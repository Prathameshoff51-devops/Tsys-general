﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Constants
{
    public static class SignalRConstants
    {
        public const string RejectedIndividualRefunds = "SendMessageForIndividualTxn";
        public const string Queued = "SendMessageForQueueTxn";
        public const string RejectedNewBatchRefunds = "SendMessageForBatchNew";
        public const string RejectedNewBatchTxnRefunds = "SendMessageForBatchNewTxn";
        public const string RejectedQueueBatchRefunds = "SendMessageForBatchQueue";
        public const string RejectedQueueBatchTxnRefunds = "SendMessageForBatchQueueTxn";
    }
}
