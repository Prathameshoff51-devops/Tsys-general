﻿namespace RiskLab.Core.Constants
{
    /// <summary>
    /// Declare the name of the exchanges and queue for RMQ.
    /// </summary>
    public static class RabbitMQConfig
    {
        public const string ExchangeName = "Acquisition.Risk.Exchange";
        /// <summary>
        /// Released individual transaction exchange queue.
        /// </summary>

        public const string FraudReleasedTransactionQueue = "Acquisition.Contracts.Risk.Jville.FraudReleasedTransaction";
        public const string FraudReleasedTransactionRoutingKey = "Acquisition.Contracts.Risk.Jville.FraudReleasedTransaction.#";

        /// <summary>
        /// Released batch queue.
        /// </summary>

        public const string FraudReleasedBatchQueue = "Acquisition.Contracts.Risk.Jville.FraudReleasedBatch";
        public const string FraudReleasedBatchRoutingKey = "Acquisition.Contracts.Risk.Jville.FraudReleasedBatch.#";

        public const string DeadLetterExchangeName = "Acquisition.Risk.DeadLetters";
    }
}
