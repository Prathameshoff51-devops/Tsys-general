﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiskLab.Core.Constants
{
    public class SettingsManagerKeys
    {
        public const string RiskLabRabbitMqConnection = nameof(RiskLabRabbitMqConnection);
        public const string PublisherJobInterval = nameof(PublisherJobInterval);
        public const string FailureRetryCount = nameof(FailureRetryCount);
        public const string HPS_SMTP_MAIL_SERVER = nameof(HPS_SMTP_MAIL_SERVER);
        public const string PassportUnAckEmailTo = nameof(PassportUnAckEmailTo);
        public const string PassportUnAckEmailFrom = nameof(PassportUnAckEmailFrom);
    }
}
