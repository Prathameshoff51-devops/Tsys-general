﻿namespace RiskLab.Core.Constants
{
    public static class UpdateStatuses
    {
        public const string Success = "Success";
        public const string Failed = "Failed";
    }
}
