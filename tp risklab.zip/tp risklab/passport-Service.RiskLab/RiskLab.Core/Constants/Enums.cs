﻿namespace RiskLab.Core.Constants
{
    public enum RejectReasons
    {
        BatchThresholdExceeds,
        MerchantThresholdExceeds,
        FraudulentBin,
    }

    public enum RejectStatuses
    {
        New = 1,
        Queued = 2,
        Released = 3,
        Deleted = 4,
        Purged = 5,
    }

    public enum BatchRejectStatuses
    {
        New = 1,
        Queued = 2,
        Released = 3,
        Deleted = 4,
        Actioned = 5,
        Purged = 6,
    }

    public enum DBs
    {
        RiskLab = 1,
        HCSDB = 2,
    }

    /// <summary>
    /// Transaction status codes.
    /// </summary>
    public enum StatusCodes
    {
        Ok = 200,
        BadRequest = 400,
        NotFound = 404,
        InternalServerError = 500,
    }

    /// <summary>
    /// Mesage Identifier for Rabbit MQ queue.
    /// </summary>
    public enum MessageIdentifier
    {
        /// <summary>
        /// Unknown message identifier.
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Incoming passport individual transaction.
        /// </summary>
        TransactionRequest = 1,

        /// <summary>
        /// Incoming passport Batches.
        /// </summary>
        BatchRequest = 2,
    }

    /// <summary>
    /// Rabbit MQ status identifier.
    /// </summary>
    public enum MessageStatusIdentifier
    {
        /// <summary>
        /// Successful.
        /// </summary>
        Successful = 0,

        /// <summary>
        /// Failed.
        /// </summary>
        Failed = 1,

        /// <summary>
        /// Duplicate Message.
        /// </summary>
        DuplicateMessage = 2,

        /// <summary>
        /// Wrong queue format.
        /// </summary>
        WrongQueueFormat = 3,

        /// <summary>
        /// Connection failure.
        /// </summary>
        ConnectionFailure = 4,

        /// <summary>
        /// Call back failed.
        /// </summary>
        CallBackFailed = 5,

        /// <summary>
        /// Failed to Ack
        /// </summary>
        FailedToAck = 6,

        /// <summary>
        /// Failed to Ack
        /// </summary>
        FailedToAckDuplicateMessage = 7,

        /// <summary>
        /// Unknown.
        /// </summary>
        Unknown = 8,
    }
}