﻿using Acquisition.Contracts.Risk.Passport;
using Moq;
using NUnit.Framework;
using RiskLab.Core.Constants;
using RiskLab.Core.Interfaces.Services;
using RiskLab.Infrastructure.Interfaces;
using System;
using System.ComponentModel;

namespace RiskLab.Subscriber.WindowsService.UnitTests
{
    public class SuspectedFraudulentTransactionProcessorTests
    {
        private Mock<IRabbitMQSettings> settings;
        private Mock<IContainer> ioc;
        private Mock<IMessageQueueService> messageQueueService;
        private Mock<Func<IDeadLetterService>> deadLetterServiceMock;
        private WSPassportSubscriber objectUnderTest;

        private Mock<IMessageProcessor<SuspectedFraudulentTransaction>> suspectedFraudulentTransactionMock;
        private Mock<IMessageProcessor<FraudReleasedTransactionConfirmation>> fraudReleasedTransactionConfirmationMock;
        private Mock<IMessageProcessor<SuspectedFraudulentBatch>> suspectedFraudulentBatchMock;
        private Mock<IMessageProcessor<FraudReleasedBatchConfirmation>> fraudReleasedBatchConfirmationMock;

        [SetUp]
        public void Init()
        {
            settings = new Mock<IRabbitMQSettings>();
            messageQueueService = new Mock<IMessageQueueService>();
            deadLetterServiceMock = new Mock<Func<IDeadLetterService>>();

            suspectedFraudulentTransactionMock = new Mock<IMessageProcessor<SuspectedFraudulentTransaction>>();
            fraudReleasedTransactionConfirmationMock = new Mock<IMessageProcessor<FraudReleasedTransactionConfirmation>>();
            suspectedFraudulentBatchMock = new Mock<IMessageProcessor<SuspectedFraudulentBatch>>();
            fraudReleasedBatchConfirmationMock = new Mock<IMessageProcessor<FraudReleasedBatchConfirmation>>();

            var ioc = new StructureMap.Container(x =>
            {
                x.For<IMessageProcessor<SuspectedFraudulentTransaction>>().Use(y => suspectedFraudulentTransactionMock.Object);
                x.For<IMessageProcessor<FraudReleasedTransactionConfirmation>>().Use(y => fraudReleasedTransactionConfirmationMock.Object);
                x.For<IMessageProcessor<SuspectedFraudulentBatch>>().Use(y => suspectedFraudulentBatchMock.Object);
                x.For<IMessageProcessor<FraudReleasedBatchConfirmation>>().Use(y => fraudReleasedBatchConfirmationMock.Object);
            });

            objectUnderTest = new WSPassportSubscriber(settings.Object, ioc, messageQueueService.Object, deadLetterServiceMock.Object);
        }

        [Test]
        public void Ws_Start_Subscriptions()
        {
            var suspectedFraudulentTransactionProcessor = new Mock<ISuspectedFraudulentTransaction>();
            var startResult = objectUnderTest.Start();

            messageQueueService.Verify(
                x => x.SubscribeProcessor(suspectedFraudulentTransactionMock.Object, It.IsAny<Func<SuspectedFraudulentTransaction, Guid>>(), MessageIdentifier.TransactionRequest), "Incoming passport individual transaction.");

            messageQueueService.Verify(
                 x => x.SubscribeProcessor(fraudReleasedTransactionConfirmationMock.Object, It.IsAny<Func<FraudReleasedTransactionConfirmation, Guid>>(), MessageIdentifier.TransactionRequest), "Incoming passport individual transaction.");

            Assert.IsTrue(startResult, "Service starts");
        }

        [Test]
        public void Ws_Start_SubscriptionsException()
        {
            messageQueueService.Setup(
                x =>
                    x.SubscribeProcessor(It.IsAny<IMessageProcessor<FraudReleasedTransactionConfirmation>>(), It.IsAny<Func<FraudReleasedTransactionConfirmation, Guid>>(), It.IsAny<MessageIdentifier>())).Throws(new Exception(""));

            var ioc = new StructureMap.Container(x => { });

            objectUnderTest = new WSPassportSubscriber(settings.Object, ioc, messageQueueService.Object, deadLetterServiceMock.Object);

            var startResult = objectUnderTest.Start();

            Assert.IsTrue(startResult, "Error while subscribing to RMQ");
        }

        [Test]
        public void Ws_stop()
        {
            objectUnderTest.Dispose();
            var startResult = objectUnderTest.Stop();

            Assert.IsTrue(startResult);
        }
    }
}